# -*- coding: utf8 -*-
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG
from Plugins.Extensions.IPTVPlayer.tsiplayer.libs.tstools import TSCBaseHostClass,tscolor,tshost,T
import base64,urllib,re,time,datetime,os,requests,hashlib,subprocess,threading,json,sys
from PIL import Image
try:
    from urllib.parse import quote_plus  # Python 3
except ImportError:
    from urllib import quote_plus        # Python 2
################################################################   20260421
def getinfo():
    info_={}
    name='Lodynet'
    hst = 'https://lodynet.watch'
    info_['old_host'] = hst
    hst_ = tshost(name)
    if hst_!='': hst = hst_
    info_['host']= hst
    info_['name']=name
    info_['version']='8.0 16/02/2026'
    info_['dev']='RGYSoft + Angel_heart'
    info_['cat_id']='21'
    info_['desc']='افلام و مسلسلات وبرامج وحفلات وكرتون وأغاني وممثلين'
    info_['icon']='https://lodynet.watch/wp-content/themes/Lodynet2020/Img/Logo.webp'
    info_['recherche_all']='0'
    return info_
class TSIPHost(TSCBaseHostClass):
    def __init__(self):
        TSCBaseHostClass.__init__(self,{})
        self.MAIN_URL = getinfo()['host']
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        self.defaultParams = {'header': {'User-Agent': self.USER_AGENT}}
        self.DEFAULT_ICON_URL = 'https://lodynet.watch/wp-content/themes/Lodynet2020/Img/Logo.webp'
# ==========================================================================================
    def showmenu(self,cItem):
        TAB = [('مسلسلات','','10',0),('أفلام','','10',1),('برامج و حفلات','/category/البرامج-و-حفلات-tv/','20',''),('أغاني','','10',2),
        ('المضاف حديثاً','/','20','newly'),('الممثلين','/','20','/all_actors/'),]
        self.add_menu(cItem,'','','','','',TAB=TAB,search=False)
        self.addDir({'import':cItem['import'],'category' :'host2','title':T('Search')  ,'icon':'https://i.ibb.co/dQg0hSG/search.png','mode':'50'})
# ==========================================================================================
    def showmenu1(self,cItem):
        gnr = cItem.get('sub_mode','')
        if gnr == 0 : 
            TAB = [
                ('مسلسلات هندية','/category/مسلسلات-هندية-مترجمة/','20',''),
                ('مسلسلات هندية مدبلجة','/dubbed-indian-series-p5/','20',''),
                ('مسلسلات ويب هندية','/category/مسلسل-ويب-هندية/','20',''),
                ('مسلسلات هندية 2020','/release-year/مسلسلات-هندية-2020-a/','20',''),
                ('مسلسلات هندية 2019','/release-year/مسلسلات-هندية-2019/','20',''),
                ('مسلسلات هندية 2018','/release-year/مسلسلات-هندية-2018/','20',''),
                ('مسلسلات تركية','/category/مسلسلات-تركي/','20',''),
                ('مسلسلات تركية مدبلجة','/dubbed-turkish-series-g/','20',''),
                ('مسلسلات كورية','/korean-series-b/','20',''),
                ('مسلسلات صينية','/category/مسلسلات-صينية-مترجمة/','20',''),
                ('مسلسلات تايلاندية','/مشاهدة-مسلسلات-تايلندية/','20',''),
                ('مسلسلات باكستانية','/category/المسلسلات-باكستانية/','20',''),
                ('مسلسلات آسيوية حديثة','/tag/new-asia/','20',''),
                ('مسلسلات مكسيكية','/category/مسلسلات-مكسيكية-a/','20',''),
                ('مسلسلات أجنبية','/category/مسلسلات-اجنبية/','20',''),
            ]
        elif gnr == 1:
            TAB = [
                ('افلام هندية', '/category/افلام-هندية/', '20', ''),
                ('أفلام هندية مدبلجة', '/category/أفلام-هندية-مدبلجة/', '20', ''),
                ('افلام هندية جنوبية', '/tag/الافلام-الهندية-الجنوبية/', '20', ''),
                ('أفلام هندي 2025', '/release-year/أفلام-هندي-2025/', '20', ''),
                ('أفلام هندي 2024', '/release-year/أفلام-هندي-2024/', '20', ''),
                ('أفلام هندي 2023', '/release-year/أفلام-هندية-2023/', '20', ''),
                ('أفلام هندي 2021', '/release-year/movies-hindi-2021/', '20', ''),
                ('أفلام هندي 2020', '/release-year/افلام-هندي-2020-a/', '20', ''),
                ('افلام هندي 2019', '/release-year/افلام-هندي-2019/', '20', ''),
                ('افلام هندي 2018', '/release-year/افلام-هندي-2018/', '20', ''),
                ('افلام هندي 2017', '/release-year/افلام-هندي-2017/', '20', ''),
                ('افلام هندي 2016', '/release-year/2016/', '20', ''),
                ('افلام هندية 4K', '/tag/افلام-هندية-مترجمة-بجودة-4k/', '20', ''),
                ('أميتاب باتشان', '/actor/أميتاب-باتشان/', '20', ''),
                ('اعمال شاروخان', '/actor/شاه-روخ-خان-a/', '20', ''),
                ('أعمال سلمان خان', '/actor/سلمان-خان-a/', '20', ''),
                ('أعمال عامر خان', '/actor/عامر-خان-a/', '20', ''),
                ('أعمال شاهد كابور', '/actor/شاهيد-كابور/', '20', ''),
                ('أعمال رانبير كابور', '/actor/رانبير-كابور/', '20', ''),
                ('أعمال ديبيكا بادكون', '/actor/ديبيكا-بادكون/', '20', ''),
                ('أعمال جينيفر ونجت', '/actor/جينيفر-ونجت/', '20', ''),
                ('أعمال هريتيك روشان', '/actor/هريتيك-روشان/', '20', ''),
                ('أعمال اكشاي كومار', '/actor/اكشاي-كومار/', '20', ''),
                ('أعمال تابسي بانو', '/actor/تابسي-بانو/', '20', ''),
                ('أعمال سانجاي دوت', '/actor/سانجاي-دوت-a/', '20', ''),
                ('ترجمات احمد بشير', '/tag/جميع-الأفلام-في-هذا-القسم-من-ترجمة-أحمد/', '20', ''),
                ('افلام تركية مترجم', '/category/افلام-تركية-مترجم/', '20', ''),
                ('افلام باكستانية', '/tag/افلام-باكستانية-مترجمة/', '20', ''),
                ('افلام اسيوية', '/category/افلام-اسيوية-a/', '20', ''),
                ('افلام اجنبي', '/category/افلام-اجنبية-مترجمة-a/', '20', ''),
                ('انيمي', '/category/انيمي/', '20', ''),
            ]
        elif gnr == 2:
            TAB = [
                ('أغاني المسلسلات', '/category/اغاني/اغاني-المسلسلات-الهندية/','20',''),
                ('تصاميم مسلسلات هندية', '/category/تصاميم-مسلسلات-هندية/','20',''),
                ('أغاني الأفلام','/category/اغاني-الافلام/','20',''),
                ('اغاني هندية mp3', '/category/اغاني/اغاني-هندية-mp3/','20',''),
            ]
        self.add_menu(cItem,'','','','','',TAB=TAB)
# ==========================================================================================
    def showsearch(self,cItem):
        self.addDir({'import':cItem['import'],'category' : 'host2','title':'البحث في الموقع','icon':'https://i.ibb.co/2nztSQz/all.png','mode':'51','section':''})
        self.addDir({'import':cItem['import'],'category' : 'host2','title':'البحث عن فيلم','icon':'https://i.ibb.co/k56BbCm/aflam.png','mode':'51','section':'فيلم'})
        self.addDir({'import':cItem['import'],'category' : 'host2','title':'البحث عن مسلسل','icon':'https://i.ibb.co/3M38qkV/mousalsalat.png','mode':'51','section':'مسلسل'})
# ==========================================================================================
    def extract_series_episodes(self, url):
        episodes = []
        sts, data = self.getPage(url)
        if not sts or not data: return episodes
        block = re.search(r'<div id="ListEpisodes".*?>(.*?)</div>\s*</div>', data, re.S)
        if not block: return episodes
        links = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>([^<]+)</a>', block.group(1))
        for ep_url, ep_title in links:
            ep_url = self.std_url(ep_url)
            title = ep_title.strip()
            if not title: continue
            episodes.append({'title': title,'url': ep_url,'category': 'video','mode': '21','good_for_fav': True,'hst': 'tshost'})
        return episodes
# ==========================================================================================
    def SearchAll(self, str_ch, page, extra, section=None, type_=''):
        if section and section.strip() != '': str_ch = section + " " + str_ch
        printDBG("SearchAll: كلمة البحث [%s], صفحة [%s], القسم [%s]" % (str_ch, page, section))
        url = "https://lodynet.watch/wp-content/themes/Lodynet2020/Api/RequestSearch.php?value=%s" % quote_plus(str_ch)
        sts, data = self.getPage(url)
        results = []
        if not sts or not data: return results
        try:
            js = json.loads(data)
            if isinstance(js, list) and len(js) > 1:
                for item in js[1]:
                    title = item.get("Title", "").strip()
                    link = item.get("Url", "").replace("\\/", "/")
                    cover = item.get("Cover", "").replace("\\/", "/")
                    cat = item.get("Category", "").strip()
                    if not link.startswith("http"):
                        link = self.MAIN_URL.rstrip('/') + '/' + link.lstrip('/')
                    icon = self.fix_image_url(cover)
                    if '/actor/' in link or 'ممثل' in cat or 'نجم' in cat:
                        params = {'title': title, 'url': link, 'icon': icon, 'desc': cat,'category': 'host2', 'hst': 'tshost', 'import': 'from Plugins.Extensions.IPTVPlayer.tsiplayer.host_lodynet import ','mode': '20'}
                        results.append(params)
                        continue
                    if 'مسلسل' in title or 'series' in link:
                        params = {'title': title, 'url': link, 'icon': icon,'desc': cat, 'category': 'host2', 'hst': 'tshost', 'import': 'from Plugins.Extensions.IPTVPlayer.tsiplayer.host_lodynet import ','mode': '21','good_for_fav': True}
                        results.append(params)
                        continue
                    params = {'title': title,'url': link,'icon': icon,'desc': cat,'category': 'host2','hst': 'tshost','import': 'from Plugins.Extensions.IPTVPlayer.tsiplayer.host_lodynet import ','mode': '20'}
                    results.append(params)
        except Exception as e:
            printDBG("SearchAll exception: %s" % str(e))
        return results
# ==========================================================================================
    def SearchMovies(self, str_ch, page=1, extra=''):
        return self.SearchAll(str_ch, page, extra=extra, type_='فيلم')
# ==========================================================================================
    def SearchSeries(self, str_ch, page=1, extra=''):
        return self.SearchAll(str_ch, page, extra=extra, type_='مسلسل')
# ==========================================================================================
    def get_items(self, cItem={}):
        elms = []
        extra = cItem.get('import')
        str_ch = cItem.get('str_ch')
        page = cItem.get('page', 1)
        url_ = cItem.get('url', '')
        type_ = cItem.get('type_', '')
        if not url_: return elms
        url0 = url_.strip('/')
        if not url0.startswith('http'):
            if url0.startswith(('tag/', 'release-year/', 'actor/', 'category/', 'مشاهدة-')):
                url0 = self.MAIN_URL + '/' + url0
            else: url0 = self.MAIN_URL + '/category/' + url0
        if page > 1: url0 = url0 + '/page/' + str(page)
        sts, data = self.getPage(url0)
        if not sts or not data: return elms
        items = re.findall(
            r'<div class="ItemNewly">\s*<a title="([^"]+)" href="([^"]+)".*?data-src="([^"]+)".*?(?:<div class="NewlyRibbon">([^<]*)</div>).*?(?:<div class="NewlyTimeAgo">([^<]*)</div>)',
            data, re.S)
        for title, url, img, ribbon, timeago in items:
            url = self.std_url(url)
            img = self.fix_image_url(self.std_url(img))
            desc = ""
            if ribbon.strip(): desc += tscolor('\c00??????') + ribbon.strip() + '\n'
            if timeago.strip(): desc += tscolor('\c0090??00') + timeago.strip()
            elms.append({'import': cItem['import'],'category': 'host2','title': title.strip(),'url': url,'desc': desc,'icon': img,'mode': '21','good_for_fav': True,'sub_mode': '1','EPG': True,'hst': 'tshost'})
        if 'الصفحة التالية' in data or 'class="next"' in data:
            elms.append({'import': extra,'category': 'host2','title': T('Next'),'url': url_,'desc': 'Next','icon': '','hst': 'tshost','mode': '20','page': page + 1,'str_ch': str_ch,'type_': type_})
        return elms
# ==========================================================================================
    def fix_image_url(self, url):
        DEFAULT_IMAGE = 'https://lodynet.watch/wp-content/uploads/2015/12/logo-1.png'
        if not url or not isinstance(url, str) or url.strip() == '':
            return DEFAULT_IMAGE
        if url.startswith('file://'): return url
        try:
            parsed_url = list(urllib.parse.urlparse(url))
            decoded_path = urllib.parse.unquote(parsed_url[2])
            encoded_path = urllib.parse.quote(decoded_path, safe="/%")
            parsed_url[2] = encoded_path
            final_url = urllib.parse.urlunparse(parsed_url)
            return final_url
        except Exception as e:
            printDBG(f"Error encoding image URL: {url}, Error: {e}")
            return DEFAULT_IMAGE
# ==========================================================================================
    def showitms(self, cItem):
        url = cItem.get('url', '')
        if not url.startswith('http'):
            url = self.MAIN_URL + '/' + url.lstrip('/')
        page = cItem.get('page', 1)
        sub_mode = cItem.get('sub_mode', '')
        sts, data = self.getPage(url)
        if not sts:
            return
        items_added = 0
        item_blocks = re.findall(r'(<div class="ItemNewly">.*?</div>\s*</a>\s*</div>)', data, re.S)
        if item_blocks:
            for item_block in item_blocks:
                title_match = re.search(r'<a title="([^"]+)"', item_block)
                url_match = re.search(r'href="([^"]+)"', item_block)
                img_match = re.search(r'data-src="([^"]+)"', item_block)
                new_title_match = re.search(r'<div class="NewlyTitle">([^<]+)</div>', item_block)
                if not all([title_match, url_match, img_match]): continue
                title = title_match.group(1)
                item_url = url_match.group(1)
                img = img_match.group(1)
                new_title = new_title_match.group(1) if new_title_match else ''
                if any(x in str(value) for value in [title, item_url, img] for x in ["+ CategoryItem.", "CategoryItem."]):
                    printDBG("تخطي عنصر غير صالح: " + title)
                    continue
                icon = self.fix_image_url(self.std_url(img))
                content_type = self.determine_content_type(title, url)
                desc = self.extract_desc_from_newly(item_block)
                if content_type == 'series':
                    self.addDir({'import': cItem.get('import'),'category': 'host2','title': title.strip(),'url': item_url,'icon': icon,'desc': desc,'good_for_fav': True,'hst': 'tshost','mode': '21'})
                else:
                    self.addVideo({'import': cItem.get('import'),'title': title.strip(),'url': item_url,'icon': icon,'desc': desc,'good_for_fav': True,'hst': 'tshost'})
                items_added += 1
        exp_match = re.search(r"GetExpansion\(\s*(\d+)\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)", data)
        if exp_match:
            indicator = exp_match.group(1)
            exp_type = exp_match.group(2)
            exp_id = exp_id = exp_match.group(3)
            self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'عرض المزيد','url': url,'icon': self.DEFAULT_ICON_URL,'mode': '22','is_expansion': True,'indicator': indicator,'exp_type': exp_type,'exp_id': exp_id})
        more_match = re.search(r"GetMoreCategory\(\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)", data)
        if more_match:
            pick_up_order = more_match.group(1)
            pick_up_id = more_match.group(2)
            parent_id = more_match.group(3)
            data_type = more_match.group(4)
            taxonomy = more_match.group(5)
            self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'تحميل المزيد','url': url,'icon': self.DEFAULT_ICON_URL,'desc': '','good_for_fav': False,'hst': 'tshost','mode': '22','pick_up_order': pick_up_order,'pick_up_id': pick_up_id,'parent_id': parent_id,'data_type': data_type,'taxonomy': taxonomy})
            printDBG(f"تم إضافة زر تحميل المزيد: order={pick_up_order}, id={pick_up_id}, parent={parent_id}")
        else:
            printDBG("لم يتم العثور على زر تحميل المزيد، جاري البحث عن الصفحة التالية")
            next_match = re.search(r'class="next page-numbers".*?href="([^"]+)"', data)
            if next_match:
                next_url = next_match.group(1)
                if not next_url.startswith('http'):
                    next_url = self.MAIN_URL + '/' + next_url.lstrip('/')
                self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'الصفحة التالية','url': next_url,'desc': '','icon': self.DEFAULT_ICON_URL,'hst': 'tshost','mode': '20'})
            elif sub_mode == 'newly' and items_added > 0:
                is_newly_section = (url == self.MAIN_URL + '/' or 
                                   url.startswith(self.MAIN_URL + '/page/'))
                if is_newly_section:
                    next_page = page + 1
                    next_url = self.MAIN_URL + '/page/' + str(next_page) + '/'
                    self.addDir({'import': cItem.get('import'),'category': 'host2', 'title': tscolor('\c00????20') + 'Page (' + str(next_page) + ')','url': next_url,'icon': self.DEFAULT_ICON_URL,'desc': tscolor('\c00????20') + 'الانتقال إلى الصفحة ' + str(next_page),'good_for_fav': False,'hst': 'tshost','mode': '20','page': next_page,'sub_mode': 'newly'})
# ==========================================================================================
    def determine_content_type(self, title, url=''):
        title_lower = title.lower()
        url_lower = url.lower() if url else ''
        episode_keywords = ['حلقة', 'الحلقة', 'episode', 'الحلقة الأخيرة', 'حلقة جديدة','اعلان',]
        series_keywords = ['مسلسل', 'المسلسل', 'series', 'مسلسلات', 'المسلسلات','season', 'موسم', 'الموسم', 'سلسلة', 'برنامج']
        movie_keywords = [
            'فيلم', 'الفيلم', 'movie', 'film', 'أفلام', 'الأفلام', 
            'أغنية', 'اغنية', 'أغاني', 'اغاني',
            'كليب', 'تصميم', 'تصاميم', 'مقطع', 'مقاطع'
            ]
        if any(keyword in url_lower for keyword in ['/اغاني/', '/أغاني/', '/music/', '/songs/', '/تصاميم-', '/design/']):
            return 'movie'
        if any(keyword in title_lower for keyword in ['أغنية', 'اغنية', 'أغاني', 'اغاني', 'music', 'كليب', 'كلب', 'تصميم', 'تصاميم']):
            return 'movie'
        for keyword in episode_keywords:
            if keyword in title_lower: return 'episode'
        for keyword in series_keywords:
            if keyword in title_lower: return 'series'
        for keyword in movie_keywords:
            if keyword in title_lower: return 'movie'
        if re.search(r'(season|موسم|s)\s*\d+', title_lower): return 'series'
        if any(keyword in url_lower for keyword in ['/series/', '/مسلسلات/', '/مسلسل/', '/seasons/']): return 'series'
        if any(keyword in url_lower for keyword in ['/movies/', '/أفلام/', '/فيلم/', '/film/']): return 'movie'
        if '/category/مسلسلات-اجنبية' in url_lower or '/series' in url_lower: return 'series'
        if '/أفلام' in url_lower or '/movies' in url_lower: return 'movie'
        return 'movie'
# ==========================================================================================
    def getTimeAgo(self, date_str):
        try:
            dt = datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
            elapsed = int(time.time() - time.mktime(dt.timetuple()))
        except: return date_str
        if elapsed < 60: return "قبل ثواني"
        units = [(31207680, "سنة", "سنتين", "سنوات"),(2600640, "شهر", "شهرين", "أشهر"),(604800, "أسبوع", "أسبوعين", "أسابيع"),(86400, "يوم", "يومان", "أيام"),(3600, "ساعة", "ساعتين", "ساعات"),(60, "دقيقة", "دقيقتين", "دقائق"),]
        for seconds, one, two, many in units:
            if elapsed >= seconds:
                value = int(round(float(elapsed) / seconds))
                if value == 1: return "قبل %s واحدة" % one
                elif value == 2: return "قبل (2) %s" % two
                elif 3 <= value <= 10: return "قبل %s %s" % (value, many)
                else: return "قبل %s %s" % (value, one)
        return "قبل ثواني"
# ==========================================================================================
    def extract_desc_from_newly(self, html_block):
        desc_parts = []
        type_match = re.search(r'NewlyRibbon">([^<]+)</div>', html_block)
        if type_match: desc_parts.append(tscolor('\c00????00') + 'النوع: ' + tscolor('\c00????FF') + type_match.group(1).strip())
        time_match = re.search(r'NewlyTimeAgo[^>]*data-date="([^"]+)"', html_block)
        if time_match:
            ago_text = self.getTimeAgo(time_match.group(1).strip())
            desc_parts.append(tscolor('\c00????00') + 'وقت النشر: ' + tscolor('\c00????FF') + ago_text)
        episode_match = re.search(r'NewlyEpNumber[^>]*>.*?(\d+)</div>', html_block)
        if episode_match: desc_parts.append(tscolor('\c00????00') + 'الحلقة: ' + tscolor('\c00????FF') + episode_match.group(1).strip())
        summary_match = re.search(r'class="NewlySummary"[^>]*>([^<]+)</div>', html_block)
        if summary_match: desc_parts.append(tscolor('\c00????00') + 'الملخص: ' + tscolor('\c00FFFFFF') + summary_match.group(1).strip())
        if desc_parts: return '\n'.join(desc_parts)
        else: return tscolor('\c00????00') + 'محتوى مضاف حديثاً'
# ==========================================================================================
    def load_more(self, cItem):
        if cItem.get('is_expansion'):
            indicator = cItem.get('indicator')
            exp_type = cItem.get('exp_type')
            exp_id = cItem.get('exp_id')
            API_URL = self.MAIN_URL + "/wp-content/themes/Lodynet2020/Api/RequestExpansion.php"
            post_data = urllib.parse.urlencode({"indicator": indicator, "type": exp_type, "id": exp_id}).encode('utf-8')
            headers = {"User-Agent": self.USER_AGENT, "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
            try:
                req = urllib.request.Request(API_URL, data=post_data, headers=headers)
                response = urllib.request.urlopen(req, timeout=30)
                js_data = json.loads(response.read().decode('utf-8'))
                if 'Items' in js_data:
                    for item in js_data['Items']:
                        title = item.get('name', '').strip()
                        url = item.get('url', '')
                        if not url.startswith('http'): url = self.MAIN_URL + url
                        image = item.get('cover', '')
                        if image:
                            image = image.strip()
                            if image.startswith('/'):
                                image = self.MAIN_URL + image
                            icon = self.fix_image_url(self.std_url(image))
                        else:
                            icon = self.DEFAULT_ICON_URL
                        desc_parts = []
                        if item.get('ribbon'): 
                            desc_parts.append(tscolor('\c00????00') + 'النوع: ' + tscolor('\c00????FF') + item.get('ribbon'))
                        if item.get('Date'): 
                            ago = self.getTimeAgo(item.get('Date'))
                            desc_parts.append(tscolor('\c00????00') + 'وقت النشر: ' + tscolor('\c00????FF') + ago)
                        if item.get('episode'): 
                            desc_parts.append(tscolor('\c00????00') + 'الحلقة: ' + tscolor('\c00????FF') + str(item.get('episode')))
                        desc = '\n'.join(desc_parts)
                        item_type = item.get('type', '')
                        if item_type == 'actor' or cItem.get('is_actors'):
                            self.addDir({
                                'import': cItem.get('import'),
                                'category': 'host2',
                                'title': title,
                                'url': url,
                                'icon': icon,
                                'mode': '21',
                                'hst': 'tshost'
                            })
                        else:
                            content_type = self.determine_content_type(title, url)
                            if content_type == 'series':
                                 self.addDir({'import': cItem.get('import'), 'category': 'host2', 'title': title, 'url': url, 'icon': icon, 'desc': desc, 'mode': '21', 'hst': 'tshost'})
                            else:
                                 self.addVideo({'import': cItem.get('import'), 'title': title, 'url': url, 'icon': icon, 'desc': desc, 'hst': 'tshost'})
                    if js_data.get('Recall') is True and js_data.get('Items'):
                        new_indicator = str(int(indicator) + 1)
                        self.addDir({'import': cItem.get('import'), 'category': 'host2', 'title': tscolor('\c00????20') + 'عرض المزيد...','url': cItem.get('url'), 'mode': '22', 'is_expansion': True,'indicator': new_indicator, 'exp_type': exp_type, 'exp_id': exp_id, 'hst': 'tshost'})
                    else:
                        printDBG("Lodynet: No more items to load (Recall is False or Items empty)")
            except Exception as e:
                printDBG("Error in load_more Expansion: " + str(e))
            return
        pick_up_order = cItem.get('pick_up_order', 'category')
        pick_up_id = cItem.get('pick_up_id')
        parent_id = cItem.get('parent_id')
        data_type = cItem.get('data_type', 'Category')
        taxonomy = cItem.get('taxonomy', 'category')
        is_episodes = cItem.get('is_episodes', False)
        if not pick_up_id or not parent_id:
            self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'لا يمكن تحميل المزيد','url': '','icon': self.DEFAULT_ICON_URL,'mode': ''})
            return
        API_URL = self.MAIN_URL + "/wp-content/themes/Lodynet2020/Api/RequestMoreCategory.php"
        try:
            post_data = urllib.parse.urlencode({"order": pick_up_order,"parent": parent_id,"type": data_type,"taxonomy": taxonomy,"id": pick_up_id}).encode('utf-8')
            headers = {"User-Agent": self.USER_AGENT,"X-Requested-With": "XMLHttpRequest","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"}
            req = urllib.request.Request(API_URL, data=post_data, headers=headers)
            response = urllib.request.urlopen(req, timeout=30)
            response_text = response.read().decode('utf-8')
            if response_text:
                items = json.loads(response_text)
                if isinstance(items, list) and items:
                    for item in items:
                        if not isinstance(item, dict) or 'name' not in item: continue
                        title = item.get("name", "")
                        url_path = item.get("url", "")
                        image = item.get("cover", "")
                        if url_path and not url_path.startswith('http'):
                            url = self.MAIN_URL + (url_path if url_path.startswith('/') else '/' + url_path)
                        else: url = url_path
                        icon = self.fix_image_url(self.std_url(image)) if image else ''
                        desc_parts = []
                        if item.get("ribbon"): desc_parts.append(tscolor('\c00????00') + 'النوع: ' + tscolor('\c00????FF') + item.get("ribbon"))
                        if item.get("ago"): desc_parts.append(tscolor('\c00????00') + 'وقت النشر: ' + tscolor('\c00????FF') + item.get("ago"))
                        if item.get("episode"): desc_parts.append(tscolor('\c00????00') + 'الحلقة: ' + tscolor('\c00????FF') + str(item.get("episode")))
                        desc = '\n'.join(desc_parts)
                        if cItem.get('is_actors'):
                            self.addDir({'import': cItem.get('import'),'category': 'host2','title': title,'url': url,'icon': icon,'desc': desc,'mode': '21','hst': 'tshost'})
                        else:
                            content_type = self.determine_content_type(title, url)
                            if is_episodes or content_type == 'episode' or content_type == 'movie':
                                self.addVideo({'import': cItem.get('import'),'title': title,'url': url,'icon': icon,'desc': desc,'hst': 'tshost'})
                            else:
                                self.addDir({'import': cItem.get('import'),'category': 'host2','title': title,'url': url,'icon': icon,'desc': desc,'mode': '21','hst': 'tshost'})
                    if len(items) >= 20 and items[-1].get("ID"):
                        new_pick_up_id = str(items[-1].get("ID", ""))
                        self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'تحميل المزيد','url': cItem.get('url', ''),'icon': self.DEFAULT_ICON_URL,'mode': '22','pick_up_order': pick_up_order,'pick_up_id': new_pick_up_id,'parent_id': parent_id,'data_type': data_type,'taxonomy': taxonomy,'is_episodes': is_episodes,'is_actors': cItem.get('is_actors', False),'hst': 'tshost'})
        except Exception as e:
            printDBG("Error in old load_more: " + str(e))
# ==========================================================================================
    def show_actors(self, cItem):
        printDBG("Lodynet.show_actors")
        sub_mode = cItem.get('sub_mode', '')
        if sub_mode:
            url = self.MAIN_URL.rstrip('/') + sub_mode
        else:
            url = cItem.get('url', '')
            if not url.startswith('http'):
                url = self.MAIN_URL + '/' + url.lstrip('/')
        sts, data = self.getPage(url)
        if not sts: return
        items = re.findall(r'<div class="ItemNewly">.*?<a title="(.*?)".*?href="(.*?)".*?data-src="(.*?)".*?>', data, re.S)
        for title, item_url, img in items:
            if any(x in str(value) for value in [title, item_url, img] for x in ["+ CategoryItem.", "CategoryItem."]):
                continue
            if not item_url.startswith('http'): 
                item_url = self.MAIN_URL + item_url
            icon = self.fix_image_url(self.std_url(img)) if img else self.DEFAULT_ICON_URL
            self.addDir({
                'import': cItem.get('import'),
                'category': 'host2',
                'title': title.strip(),
                'url': item_url,
                'icon': icon,
                'mode': '21',
                'hst': 'tshost',
                'good_for_fav': True
            })
        exp_match = re.search(r"GetExpansion\(\s*(\d+)\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)", data)
        if exp_match:
            indicator = exp_match.group(1)
            exp_type = exp_match.group(2)
            exp_id = exp_match.group(3)
            self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'عرض المزيد من الممثلين...','url': url,'mode': '22','is_expansion': True,'is_actors': True,'indicator': indicator,'exp_type': exp_type,'exp_id': exp_id,'hst': 'tshost'})
# ==========================================================================================
    def show_actor_movies(self, cItem):
        url = cItem.get('url', '')
        if not url.startswith('http'):
            url = self.MAIN_URL + '/' + url.lstrip('/')
        sts, data = self.getPage(url)
        if not sts:
            return
        matches = re.findall(r'<div class="ItemNewly">.*?<a title="([^"]+)" href="([^"]+)".*?<div class="NewlyCover[^>]+(?:data-src|src)="([^"]+)".*?<div class="NewlyTitle">([^<]+)</div>', data, re.S)
        for (title, url_, img, new_title) in matches:
            icon = self.fix_image_url(self.std_url(img)) if img else self.DEFAULT_ICON_URL
            self.addVideo({'import': cItem.get('import'),'title': title.strip(),'url': url_,'desc': '','icon': icon,'good_for_fav': True,'hst': 'tshost'})
        next_match = re.search(r'class="next page-numbers".*?href="([^"]+)"', data)
        if next_match:
            self.addDir({'import': cItem.get('import'),'category': 'host2','title': 'Next','url': next_url.group(1),'desc': 'Next','icon': self.DEFAULT_ICON_URL,'hst': 'tshost','mode': '21'})
# ==========================================================================================
    def showelms(self, cItem):
        printDBG("Lodynet.showelms")
        url = cItem.get('url', '')
        sts, data = self.cm.getPage(url)
        if not sts: return
        items = re.findall(r'<div class="ItemNewly">.*?<a title="(.*?)".*?href="(.*?)".*?data-src="(.*?)".*?>(.*?)</a>', data, re.S)
        items_added = 0
        for title, item_url, img, extra_html in items:
            if any(x in str(value) for value in [title, item_url, img] for x in ["+ CategoryItem.", "CategoryItem."]):
                continue
            if not item_url.startswith('http'): item_url = self.MAIN_URL + item_url
            ep_match = re.search(r'حلقة رقم </small>\s*(\d+)', extra_html)
            ep_num = ep_match.group(1) if ep_match else ""
            desc = tscolor('\c00????00') + 'رقم الحلقة: ' + tscolor('\c00????FF') + ep_num if ep_num else ""
            icon = self.fix_image_url(self.std_url(img))
            self.addVideo({'import': cItem.get('import'), 'title': title.strip(), 'url': item_url, 'icon': icon, 'desc': desc, 'good_for_fav': True, 'hst': 'tshost'})
            items_added += 1
        if items_added == 0:
            self.addDir({'import': cItem.get('import'), 'category': 'host2', 'title': tscolor('\c00????20') + 'لا توجد حلقات متاحة', 'url': '', 'icon': '', 'desc': 'لا توجد حلقات متاحة حالياً', 'hst': 'tshost'})
        exp_match = re.search(r"GetExpansion\(\s*(\d+)\s*,\s*'([^']+)'\s*,\s*'([^']+)'\s*\)", data)
        if exp_match:
            if len(items) >= 10: 
                indicator = exp_match.group(1)
                exp_type = exp_match.group(2)
                exp_id = exp_match.group(3)
                self.addDir({'import': cItem.get('import'),'category': 'host2','title': tscolor('\c00????20') + 'عرض المزيد...','url': url,'mode': '22','is_expansion': True,'indicator': indicator,'exp_type': exp_type,'exp_id': exp_id,'hst': 'tshost'})
# ==========================================================================================
    def SearchResult(self,str_ch,page,extra):
        url = self.MAIN_URL+'/search/'+str_ch+'/page/'+str(page)
        desc = [('Info','Ribbon">(.*?)</div>','',''),('Time','<time>(.*?)</time>','','')]
        self.add_menu({'import':extra,'url':url},'','<div class="ItemNewly">.*?<a title="(.*?)" href="(.*?)".*?<div class="NewlyCover[^>]+(?:data-src|src)="(.*?)".*?<div class="NewlyTitle">(.*?)</div>','','21',ord=[0,1,2,3],Desc=desc,u_titre=True)
# ==========================================================================================
    def get_links(self, cItem):
        printDBG("LodyNet.get_links --------------------------------")
        url = cItem.get('url', '')
        sts, data = self.getPage(url)
        if not sts:
            return []
        links = []
        post_id = None
        post_id_match = re.search(r'SwitchServer\(this,\s*\d+,\s*(\d+)\)', data)
        if post_id_match:
            post_id = post_id_match.group(1)
        if not post_id:
            printDBG("لم يتم العثور على PostID")
            return []
        printDBG(f"تم العثور على PostID: {post_id}")
        servers = re.findall(r'<button[^>]+id="ServerWatch(\d+)"[^>]*>([^<]+)</button>', data)
        if not servers:
            printDBG("لم يتم العثور على أي سيرفرات")
            return []
        printDBG(f"تم العثور على {len(servers)} سيرفر")
        for server_id, server_name in servers:
            server_name = self.cleanHtmlStr(server_name).strip()
            if not server_name:
                continue
            embed_url = self.get_video_url_from_api_fast(post_id, server_id)
            if embed_url:
                if any(domain in embed_url for domain in ['vidlo.us']) and ('.m3u8' in embed_url or '.mp4' in embed_url):
                    links.append({'name': server_name,'url': embed_url,'need_resolve': 0})
                    printDBG(f"  >> تم إضافة سيرفر: {server_name} مع رابط مباشر")
                else:
                    links.append({'name': server_name,'url': embed_url,'need_resolve': 1})
                    printDBG(f"  >> تم إضافة سيرفر: {server_name} مع رابط embed")
            else:
                printDBG(f"  >> فشل جلب الرابط للسيرفر: {server_name}")
        return links
# ==========================================================================================
    def get_video_url_from_api_fast(self, post_id, server_id):
        """جلب سريع لرابط API"""
        try:
            api_url = self.MAIN_URL + "/wp-content/themes/Lodynet2020/Api/RequestServerEmbed.php"
            post_data = f'PostID={post_id}&ServerID={server_id}'
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            }
            req = urllib.request.Request(api_url, data=post_data.encode('utf-8'), headers=headers)
            response = urllib.request.urlopen(req, timeout=5)
            video_url = response.read().decode('utf-8').strip()
            if not video_url.startswith('http'):
                iframe_match = re.search(r'src=["\'](https?://[^"\']+)["\']', video_url)
                if iframe_match:
                    video_url = iframe_match.group(1)
                else:
                    try:
                        json_data = json.loads(video_url)
                        if isinstance(json_data, dict):
                            for v in json_data.values():
                                if isinstance(v, str) and 'http' in v:
                                    video_url = v
                                    break
                    except:
                        pass
            if video_url and ('http' in video_url or '//' in video_url):
                if video_url.startswith('//'):
                    video_url = 'https:' + video_url
                return video_url
        except Exception as e:
            printDBG(f"خطأ في جلب رابط API للسيرفر {server_id}: {str(e)}")
        return None
# ==========================================================================================
    def getVideoLinks(self, videoUrl):
        """النظام سيتولى تحليل الروابط تلقائياً"""
        return [{'name': 'رابط فيديو', 'url': videoUrl, 'need_resolve': 0}]
# ==========================================================================================
    def getVideos(self, videoUrl):
        printDBG("LodyNet.getVideos --------------------------------")
        printDBG(f"videoUrl: {videoUrl}")
        if isinstance(videoUrl, dict) and videoUrl.get('type') == 'lodynet_api':
            post_id = videoUrl.get('post_id')
            server_id = videoUrl.get('server_id')
            api_url = videoUrl.get('url')
            referer = videoUrl.get('referer', self.MAIN_URL)
            if not all([post_id, server_id, api_url]):
                return []
            printDBG(f"طلب رابط التشغيل - PostID: {post_id}, ServerID: {server_id}")
            post_data = f'PostID={post_id}&ServerID={server_id}'
            headers = {
                'User-Agent': self.USER_AGENT,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Content-Length': str(len(post_data)),
                'X-Requested-With': 'XMLHttpRequest',
                'Origin': self.MAIN_URL,
                'Referer': referer
            }
            try:
                req = urllib.request.Request(api_url, data=post_data.encode('utf-8'), headers=headers)
                response = urllib.request.urlopen(req, timeout=30)
                response_data = response.read().decode('utf-8').strip()
                printDBG(f"استجابة API: {response_data}")
                if response_data and (response_data.startswith('http') or '//' in response_data):
                    video_url = response_data.strip()
                    if not video_url.startswith('http'):
                        video_url = 'https:' + video_url if video_url.startswith('//') else video_url
                    printDBG(f"تم الحصول على الرابط: {video_url}")
                    return [{'name': 'رابط مباشر', 'url': video_url, 'need_resolve': 0}]
                else:
                    printDBG("لم يتم إرجاع رابط صالح من API")
                    return []
            except urllib.error.HTTPError as e:
                printDBG(f"خطأ HTTP في طلب API: {e.code} - {e.reason}")
                return []
            except Exception as e:
                printDBG(f"خطأ في طلب API: {str(e)}")
                return []
        elif isinstance(videoUrl, str):
            return [{'name': 'رابط مباشر', 'url': videoUrl, 'need_resolve': 0}]
        return []
# ==========================================================================================
    def start(self, cItem):
        mode = cItem.get('mode', None)
        if mode == '00': self.showmenu(cItem)
        elif mode == '10': self.showmenu1(cItem)	
        elif mode == '11': self.showmenu2(cItem)
        elif mode == '19': self.showfilter(cItem)                    
        elif mode == '20':
            if cItem.get('sub_mode') == '/all_actors/':
                self.show_actors(cItem)
            else:
                self.showitms(cItem)
        elif mode == '21': self.showelms(cItem)
        elif mode == '22': self.load_more(cItem)
        elif mode == '50': self.showsearch(cItem)
        elif mode == '51': self.searchResult(cItem)
        elif mode == 'schedules': self.showSchedules(cItem)
        return True
# ==========================================================================================