# -*- coding: utf-8 -*-
# Last modified: 13/10/2025 - popking (odem2014)
# Last updated:  16/08/2026 - M.Elsafty (angel_heart)
###################################################
# LOCAL import
###################################################
# localization library
# -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
import re
import base64
import json
try:
	from urllib.parse import urlparse, parse_qs, urlencode, unquote, quote
except ImportError:
	from urllib import urlencode, urlopen, unquote, quote
def GetConfigList():
    return []
def gettytul():
    return 'https://arabseed.store/'
class ArabSeed(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'arabseed', 'cookie': 'arabseed.cookie'})  # names for history and cookie files in cache
        self.urlencode = urlencode
        self.MAIN_URL = gettytul()
        self.SEARCH_URL = 'https://arabseed.store/search'
        self.DEFAULT_ICON_URL = "https://raw.githubusercontent.com/oe-mirrors/e2iplayer/gh-pages/Thumbnails/arabseed.png"
        self.HEADER = self.cm.getDefaultHeader(browser='chrome')
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
    def getPage(self, base_url, add_params=None, post_data=None):
        if '?' in base_url:
            path_part, query_part = base_url.split('?', 1)
            if any(ord(c) > 127 for c in path_part):
                path_part = urllib_quote_plus(path_part, safe="://")
            base_url = path_part + '?' + query_part
        else:
            if any(ord(c) > 127 for c in base_url):
                base_url = urllib_quote_plus(base_url, safe="://")
        if add_params is None:
            add_params = dict(self.defaultParams)
        add_params["cloudflare_params"] = {"cookie_file": self.COOKIE_FILE, "User-Agent": self.HEADER.get("User-Agent")}
        return self.cm.getPageCFProtection(base_url, add_params, post_data)
    def listMainMenu(self, cItem):
        printDBG('ArabSeed.listMainMenu')
        self.MAIN_CAT_TAB = [
            {'category': 'movies_folder', 'title': 'الافلام'},
            {'category': 'series_folder', 'title': 'المسلسلات'},
            {'category': 'ramadan_folder', 'title': 'رمضان'},
            {'category': 'anime_folder', 'title': 'انمي'},
            {'category': 'series_packs_folder', 'title': 'مواسم مسلسلات - برامج - أنمي'},
            {'category': 'other_folder', 'title': 'اخري'},
        ] + self.searchItems()
        self.MOVIES_CAT_TAB = [
            {'category': 'list_items', 'title': 'أفلام Netflix', 'url': self.getFullUrl('/category/الافلام/افلام-netflix/')},
            {'category': 'list_items', 'title': 'أفلام أجنبية', 'url': self.getFullUrl('/category/الافلام/افلام-اجنبي/')},
            {'category': 'list_items', 'title': 'أفلام آسيوية', 'url': self.getFullUrl('/category/الافلام/افلام-اسيوية/')},
            {'category': 'list_items', 'title': 'أفلام انيميشن', 'url': self.getFullUrl('/category/الافلام/افلام-انيميشن/')},
            {'category': 'list_items', 'title': 'أفلام تركية', 'url': self.getFullUrl('/category/الافلام/افلام-تركية/')},
            {'category': 'list_items', 'title': 'أفلام عربية', 'url': self.getFullUrl('/category/الافلام/افلام-عربي/')},
            {'category': 'list_items', 'title': 'أفلام كلاسيكية', 'url': self.getFullUrl('/category/الافلام/افلام-كلاسيكيه/')},
            {'category': 'list_items', 'title': 'أفلام مدبلجة', 'url': self.getFullUrl('/category/الافلام/افلام-مدبلجة/')},
            {'category': 'list_items', 'title': 'أفلام هندية', 'url': self.getFullUrl('/category/الافلام/افلام-هندى/')},
        ]
        self.SERIES_CAT_TAB = [
            {'category': 'series', 'title': 'مسلسلات Netflix', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-netflix/')},
            {'category': 'series', 'title': 'مسلسلات أجنبية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-اجنبي/')},
            {'category': 'series', 'title': 'مسلسلات تركية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-تركيه/')},
            {'category': 'series', 'title': 'مسلسلات عربية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-عربي/')},
            {'category': 'series', 'title': 'مسلسلات كرتون', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-كرتون/')},
            {'category': 'series', 'title': 'مسلسلات كورية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-كوريه/')},
            {'category': 'series', 'title': 'مسلسلات هندية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-هندية/')},
        ]
        self.SERIES_PACKS_CAT_TAB = [
            {'category': 'series_packs', 'title': 'مواسم Netflix', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-netflix/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم أجنبية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-اجنبي/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم تركية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-تركيه/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم عربية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-عربي/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم كرتون', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-كرتون/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم كورية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-كوريه/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم هندية', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-هندية/') + '?type=series'},
            {'category': 'series_packs', 'title': 'مواسم برامج تلفزيونية', 'url': self.getFullUrl('/category/برامج-تلفزيونية/') + '?type=series'},
        ]
        self.RAMADAN_CAT_TAB = [
            {'category': 'series', 'title': 'مسلسلات رمضان 2026', 'url': self.getFullUrl('/category/مسلسلات-رمضان/مسلسلات-رمضان-2026/')},
            {'category': 'series', 'title': 'مسلسلات رمضان 2025', 'url': self.getFullUrl('/category/مسلسلات-رمضان/مسلسلات-رمضان-2025/')},
        ]
        self.ANIME_CAT_TAB = [
            {'category': 'list_items', 'title': 'أفلام انيميشن', 'url': self.getFullUrl('/category/الافلام/افلام-انيميشن/')},
            {'category': 'series', 'title': 'مسلسلات كرتون', 'url': self.getFullUrl('/category/المسلسلات/مسلسلات-كرتون/')},
        ]
        self.OTHER_CAT_TAB = [
            {'category': 'list_items', 'title': 'برامج تلفزيونية', 'url': self.getFullUrl('/category/برامج-تلفزيونية/')},
            {'category': 'list_items', 'title': 'مسرحيات عربية', 'url': self.getFullUrl('/category/مسرحيات-عربيه/')},
            {'category': 'list_items', 'title': 'مصارعة', 'url': self.getFullUrl('/category/مصارعه/')},
        ]
        self.listsTab(self.MAIN_CAT_TAB, cItem)
    def listMoviesFolder(self, cItem):
        printDBG('ArabSeed.listMoviesFolder')
        self.listsTab(self.MOVIES_CAT_TAB, cItem)
    def listSeriesFolder(self, cItem):
        printDBG('ArabSeed.listSeriesFolder')
        self.listsTab(self.SERIES_CAT_TAB, cItem)
    def listSeriesPacksFolder(self, cItem):
        printDBG('ArabSeed.listSeriesPacksFolder')
        self.listsTab(self.SERIES_PACKS_CAT_TAB, cItem)
    def listRamadanFolder(self, cItem):
        printDBG('ArabSeed.listRamadanFolder')
        self.listsTab(self.RAMADAN_CAT_TAB, cItem)
    def listAnimeFolder(self, cItem):
        printDBG('ArabSeed.listAnimeFolder')
        self.listsTab(self.ANIME_CAT_TAB, cItem)
    def listOtherFolder(self, cItem):
        printDBG('ArabSeed.listOtherFolder')
        self.listsTab(self.OTHER_CAT_TAB, cItem)
    def getLinksForVideo(self, cItem):
        printDBG("ArabSeed.getLinksForVideo %s" % cItem)
        url = cItem.get('url', '')
        title = cItem.get('title', '')
        need_resolve = cItem.get('need_resolve', 1)
        if 'arabseed.store' in url and '/watch/?url=' not in url:
            printDBG("ArabSeed: Extracting servers from watch page")
            urlTab = []
            if '/watch/' not in url:
                url = url.rstrip('/') + '/watch/'
            sts, data = self.getPage(url)
            if not sts or not data:
                return urlTab
            csrf_token = self.cm.ph.getSearchGroups(data, r"csrf__token'\s*:\s*'([^']+)'")[0]
            if not csrf_token:
                csrf_token = self.cm.ph.getSearchGroups(data, r'"csrf__token"\s*:\s*"([^"]+)"')[0]
            post_id = self.cm.ph.getSearchGroups(data, r"post_id'\s*:\s*(\d+)")[0]
            if not post_id:
                post_id = self.cm.ph.getSearchGroups(data, r'"post_id"\s*:\s*(\d+)')[0]
            if not post_id or not csrf_token:
                printDBG("ArabSeed: Missing post_id or csrf_token")
                return urlTab
            printDBG("ArabSeed: post_id=%s csrf=%s" % (post_id, csrf_token))
            qualities = re.findall(r'data-quality="(\d+)"', data)
            if not qualities:
                qualities = ['1080', '720', '480']
            qualities = sorted(list(set(qualities)), key=lambda x: int(x), reverse=True)
            ajax_url = self.MAIN_URL.rstrip('/') + '/get__quality__servers/'
            headers = dict(self.HEADER)
            headers.update({
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': url,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            })
            for quality in qualities:
                post_data = {'post_id': post_id, 'quality': quality, 'csrf_token': csrf_token}
                sts, response = self.cm.getPage(ajax_url, {'header': headers}, post_data)
                if not sts:
                    continue
                try:
                    js = json_loads(response)
                except Exception:
                    continue
                html = js.get('html', '')
                items = re.findall(r'data-src="([^"]+)".*?<span>(.*?)</span>', html, re.S)
                for link, name in items:
                    printDBG("ArabSeed SERVER RAW: name=[%s] url=[%s]" % (self.cleanHtmlStr(name), link))
                    if link.startswith('/'):
                        link = self.MAIN_URL.rstrip('/') + link
                    printDBG("ArabSeed SERVER FINAL: name=[%s] url=[%s]" % (self.cleanHtmlStr(name), link))
                    label = "[%sp] %s" % (quality, self.cleanHtmlStr(name))
                    urlTab.append({'name': label, 'url': link, 'need_resolve': 1})
            printDBG("ArabSeed: Total links = %d" % len(urlTab))
            return urlTab
        common_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1'
        }
        if 'youtube.com' in url or 'youtu.be' in url:
            return [{'name': 'YouTube', 'url': strwithmeta(url, {'User-Agent': common_headers['User-Agent'], 'Referer': 'https://www.youtube.com/'}), 'need_resolve': 1}]
        if 'imdb.com/video/' in url:
            imdb_links = self.getIMDBTrailer(url)
            return imdb_links if imdb_links else []
        if need_resolve == 1:
            printDBG("ArabSeed: Resolving external server: %s" % url)
            if 'arabseed.store/watch/?url=' in url:
                external_url = url.split('arabseed.store/watch/?url=', 1)[1]
                printDBG("ArabSeed: Unwrapped external URL: %s" % external_url)
                return [{'name': title,'url': strwithmeta(external_url, common_headers),'need_resolve': 1}]
            try:
                linksTab = self.up.getVideoLinkExt(url)
                if linksTab and isinstance(linksTab, list):
                    fixed_links = []
                    for link in linksTab:
                        if not isinstance(link, dict):
                            link = {'url': link, 'name': title}
                        fixed_link = dict(link)
                        if fixed_link.get('url'):
                            fixed_link['url'] = strwithmeta(fixed_link['url'],common_headers)
                        fixed_links.append(fixed_link)
                    return fixed_links
            except Exception as e:
                printDBG("ArabSeed.getVideoLinkExt error: %s" % str(e))
            domain_match = re.search(r'https?://([^/]+)', url)
            stream_domain = domain_match.group(1) if domain_match else ''
            dynamic_headers = {
                'User-Agent': common_headers['User-Agent'],
                'Referer': 'https://%s/' % stream_domain if stream_domain else url,
                'Origin': 'https://%s' % stream_domain if stream_domain else ''
            }
            return [{'name': title,'url': strwithmeta(url, dynamic_headers),'need_resolve': 1}]
        return [{'name': title, 'url': strwithmeta(url, common_headers), 'need_resolve': 0}]
    def getVideoLinks(self, url):
        printDBG("ArabSeed.getVideoLinks [%s]" % url)
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
    def getVideoLinks(self, url):
        printDBG("ArabSeed.getVideoLinks [%s]" % url)
        if '/watch/?url=' in url:
            url = url.split('/watch/?url=', 1)[1]
            printDBG("ArabSeed.getVideoLinks unwrapped [%s]" % url)
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return []
    def listItems(self, cItem):
        printDBG("ArabSeed.listItems [%s]" % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts or not data:
            return
        data_items = re.findall(r'<li[^>]*class="[^"]*box__xs__2[^"]*"[^>]*>(.*?)</li>', data, re.S)
        printDBG("Items found: %s" % len(data_items))
        for m in data_items:
            title = self.cm.ph.getSearchGroups(m, r'title=[\'"]([^\'"]+)[\'"]')[0] or ''
            pureurl = self.cm.ph.getSearchGroups(m, r'href=[\'"]([^\'"]+)[\'"]')[0] or ''
            pureicon = self.cm.ph.getSearchGroups(m, r'data-src=[\'"]([^\'"]+)[\'"]')[0] or ''
            url = ''
            if pureurl and '/' in pureurl:
                baseurl, filenameurl = pureurl.rsplit('/', 1)
                url = baseurl + "/" + urllib_quote_plus(filenameurl) + "watch/"
            icon = ''
            if pureicon and '/' in pureicon:
                baseicon, filenameicon = pureicon.rsplit('/', 1)
                icon = baseicon + "/" + urllib_quote_plus(filenameicon)
            genre = self.cleanHtmlStr(
                self.cm.ph.getDataBeetwenMarkers(m, '<div class="__genre hide__md">', '</div>', False)[1]
            ).strip()
            quality = self.cleanHtmlStr(
                self.cm.ph.getDataBeetwenMarkers(m, '<div class="__quality hide__md">', '</div>', False)[1]
            ).strip()
            Ratings = self.cleanHtmlStr(
                self.cm.ph.getDataBeetwenMarkers(m, '<div class="post__ratings">', '</div>', False)[1]
            ).strip()
            story = self.cleanHtmlStr(
                self.cm.ph.getDataBeetwenMarkers(m, '<p>', '</p>', False)[1]
            ).strip()
            line1_parts = []
            line2_parts = []
            if genre:
                line1_parts.append(f"{E2ColoR('yellow')}Genre:{E2ColoR('white')} {genre}")
            if quality:
                q_color = 'white'
                if re.search(r'4K|1080|HD|BluRay', quality, re.I):
                    q_color = 'green'
                elif re.search(r'720|HDRip|WEB', quality, re.I):
                    q_color = 'orange'
                elif re.search(r'CAM|TS|HDCAM', quality, re.I):
                    q_color = 'red'
                line1_parts.append(
                    f"{E2ColoR('yellow')}Quality:{E2ColoR('white')} {E2ColoR(q_color)}{quality}{E2ColoR('white')}"
                )
            if Ratings:
                rate_match = re.search(r'(\d+(\.\d+)?)', Ratings)
                rate_color = 'white'
                if rate_match:
                    rate_value = float(rate_match.group(1))
                    if rate_value >= 7:
                        rate_color = 'green'
                    elif rate_value >= 5:
                        rate_color = 'orange'
                    else:
                        rate_color = 'red'
                line1_parts.append(
                    f"{E2ColoR('yellow')}Ratings:{E2ColoR('white')} {E2ColoR(rate_color)}{Ratings}{E2ColoR('white')}"
                )
            if story:
                line2_parts.append(f"{E2ColoR('yellow')}Story:{E2ColoR('white')} {story}")
            desc = " | ".join(line1_parts)
            if line2_parts:
                desc += "\n" + " ".join(line2_parts)
            clean_title = self.clean_title_prefix(title, sub_mode=0, url=cItem.get('url', ''))
            colored_title = self.colorizeTitle(clean_title)
            params = {
                'category': 'explore_item',
                'title': colored_title,
                'icon': icon,
                'url': url,
                'desc': desc
            }
            self.addDir(params)
        pagination = self.cm.ph.getDataBeetwenMarkers(
            data, '<div class="paginate">', '</div>', False
        )[1]
        next_page = self.cm.ph.getSearchGroups(
            pagination,
            r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"'
        )[0]
        if next_page:
            next_page = self.getFullUrl(next_page)
            printDBG("NEXT PAGE FOUND >>> %s" % next_page)
            params = dict(cItem)
            params.update({
                'title': 'Next Page ▶',
                'url': next_page,
                'category': 'list_items',
            })
            self.addDir(params)
    def listSeriesItems(self, cItem):
        printDBG("ArabSeed.listSeriesItems ----------")
        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        data_items = self.cm.ph.getAllItemsBeetwenMarkers(data, '<li class="box__xs__2', '</li>')
        for m in data_items:
            title = self.cm.ph.getSearchGroups(m, r'title=[\'"]([^\'"]+)[\'"]')[0]
            pureurl = self.cm.ph.getSearchGroups(m, r'href=[\'"]([^\'"]+)[\'"]')[0]
            pureicon = self.cm.ph.getSearchGroups(m, r'data-src=[\'"]([^\'"]+)[\'"]')[0]
            if pureurl:
                baseurl, filenameurl = pureurl.rsplit('/', 1)
                fixedfilenameurl = urllib_quote_plus(filenameurl)
                url = baseurl + "/" + fixedfilenameurl + "watch/"
            else:
                url = ''
            if pureicon:
                baseicon, filenameicon = pureicon.rsplit('/', 1)
                fixedfilenameicon = urllib_quote_plus(filenameicon)
                icon = baseicon + "/" + fixedfilenameicon
            else:
                icon = ''
            genre = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="__genre hide__md">', '</div>', False)[1]).strip()
            quality = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="__quality hide__md">', '</div>', False)[1]).strip()
            Ratings = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="post__ratings">', '</div>', False)[1]).strip()
            story = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<p>', '</p>', False)[1]).strip()
            first_line_parts = []
            if genre: first_line_parts.append(f"{E2ColoR('yellow')}Genre:{E2ColoR('white')} {genre}")
            if quality:
                q_color = 'white'
                if re.search(r'4K|1080|HD|BluRay', quality, re.I): q_color = 'green'
                elif re.search(r'720|HDRip|WEB', quality, re.I): q_color = 'orange'
                elif re.search(r'CAM|TS|HDCAM', quality, re.I): q_color = 'red'
                first_line_parts.append(
                    f"{E2ColoR('yellow')}Quality:{E2ColoR('white')} "
                    f"{E2ColoR(q_color)}{quality}{E2ColoR('white')}"
                )
            if Ratings:
                rate_match = re.search(r'(\d+(\.\d+)?)', Ratings)
                rate_color = 'white'
                rate_text = Ratings
                if rate_match:
                    rate_value = float(rate_match.group(1))
                    if rate_value >= 7: rate_color = 'green'
                    elif rate_value >= 5: rate_color = 'orange'
                    else: rate_color = 'red'
                first_line_parts.append(
                    f"{E2ColoR('yellow')}Ratings:{E2ColoR('white')} "
                    f"{E2ColoR(rate_color)}{rate_text}{E2ColoR('white')}"
                )
            line1 = " | ".join(first_line_parts)
            line2 = ""
            if story: line2 = f"{E2ColoR('yellow')}Story:{E2ColoR('white')} {story}"
            desc = line1
            if line2: desc += "\n" + line2
            clean_title = self.clean_title_prefix(title, sub_mode=1, url=cItem.get('url', ''))
            colored_title = self.colorizeTitle(clean_title)
            params = {'category': 'explore_item','title': colored_title,'icon': icon,'url': url,'desc': desc}
            printDBG(str(params))
            self.addDir(params)
        pagination = self.cm.ph.getDataBeetwenMarkers(data, '<div class="paginate">', '</div>', False)[1]
        next_page = self.cm.ph.getSearchGroups(pagination, r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"')[0]
        if next_page:
            next_page = self.getFullUrl(next_page)
            printDBG("NEXT PAGE FOUND >>> %s" % next_page)
            params = dict(cItem)
            params.update({'title': 'Next Page ▶','url': next_page,'category': 'series',})
            self.addDir(params)
    def exploreItems(self, cItem):
        printDBG("ArabSeed.exploreItems >>> %s" % cItem)
        url = cItem.get('url')
        details_url = url.replace('/watch/', '/').rstrip('/') + '/'
        sts, data = self.getPage(details_url)
        if not sts or not data:
            sts, data = self.getPage(url)
            if not sts or not data:
                return
        trailer_url = self.cm.ph.getSearchGroups(data, r'data-iframe="([^"]+)"')[0]
        if trailer_url:
            if 'youtube.com/embed/' in trailer_url:
                trailer_url = trailer_url.replace('youtube.com/embed/', 'youtube.com/watch?v=')
            original_title = cItem.get('title', '')
            plain_title = re.sub(r'\\c00[0-9A-F]{6}', '', original_title)
            clean_title = self.clean_title_prefix(plain_title, sub_mode=-1, url=url)
            colored_clean_title = self.colorizeTitle(clean_title)
            self.addVideo({
                'title': f"{E2ColoR('lime')}TRAILER{E2ColoR('white')} | {colored_clean_title}",
                'url': trailer_url,
                'type': 'video',
                'need_resolve': 1,
                'icon': cItem.get('icon', '')
            })
            printDBG('ArabSeed: Trailer found >>> %s' % trailer_url)
        sts, watch_data = self.getPage(url)
        if not sts or not watch_data:
            return
        post_id = self.cm.ph.getSearchGroups(watch_data, r'post_id["\']?\s*[:=]\s*["\']?(\d+)')[0] or \
                  self.cm.ph.getSearchGroups(watch_data, r'psot_id["\']?\s*[:=]\s*["\']?(\d+)')[0]
        csrf_token = self.cm.ph.getSearchGroups(watch_data, r'csrf__token["\']?\s*[:=]\s*["\']([^"\']+)')[0]
        if not post_id or not csrf_token:
            printDBG('Missing post_id or csrf_token')
            return
        printDBG('post_id: %s, csrf_token: %s' % (post_id, csrf_token))
        qualities = re.findall(r'data-quality="(\d+)"', watch_data)
        if not qualities:
            qualities = ['1080', '720', '480']
        qualities = sorted(list(set(qualities)), key=lambda x: int(x), reverse=True)
        ajax_url = self.MAIN_URL.rstrip('/') + '/get__quality__servers/'
        headers = dict(self.HEADER)
        headers.update({
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': url,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        })
        results = []
        for quality in qualities:
            post_data = {'post_id': post_id, 'quality': quality, 'csrf_token': csrf_token}
            sts, response = self.cm.getPage(ajax_url, {'header': headers}, post_data)
            if not sts:
                continue
            try:
                js = json_loads(response)
            except Exception:
                continue
            html = js.get('html', '')
            items = re.findall(r'data-src="([^"]+)".*?<span>(.*?)</span>', html, re.S)
            for link, name in items:
                printDBG("ArabSeed SERVER RAW: name=[%s] url=[%s]" % (self.cleanHtmlStr(name), link))
                if link.startswith('/'):
                    link = self.MAIN_URL.rstrip('/') + link
                label = "[%sp] %s" % (quality, self.cleanHtmlStr(name))
                domain = re.search(r'https?://([^/]+)', link)
                domain_name = domain.group(1) if domain else 'unknown'
                results.append({
                    'name': label,
                    'url': link,
                    'need_resolve': 1,
                    'sort': int(quality) * 10,
                    'header': {
                        'Referer': 'https://' + domain_name + '/',
                        'User-Agent': self.HEADER.get('User-Agent', ''),
                        'Origin': 'https://' + domain_name
                    }
                })
        results.sort(key=lambda x: x.get('sort', 0), reverse=True)
        for item in results:
            item.pop('sort', None)
            original_title = cItem.get('title', '')
            plain_title = re.sub(r'\\c00[0-9A-F]{6}', '', original_title)
            clean_title = self.clean_title_prefix(plain_title, sub_mode=-1, url=url)
            colored_clean_title = self.colorizeTitle(clean_title)
            final_title = f"{colored_clean_title} {E2ColoR('white')}| {item['name']}"
            self.addVideo({
                'title': final_title,
                'url': item['url'],
                'type': 'video',
                'need_resolve': item['need_resolve'],
                'header': item.get('header', {})
            })
        printDBG('ArabSeed.exploreItems <<< done - Found %d links' % len(results))
    def safe_b64decode_urlsafe(self, data):
        """Base64 decode with automatic padding fix and URL-safe characters."""
        if not data:
            return None
        data = data.replace('-', '+').replace('_', '/')
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        try:
            return base64.b64decode(data).decode('utf-8', errors='ignore')
        except:
            return None
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("ArabSeed.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        page = cItem.get('page', 1)
        cItem = dict(cItem)
        cItem['search_pattern'] = searchPattern
        cItem['page'] = page
        cItem['url'] = (self.getFullUrl('?s=')+ urllib_quote_plus(searchPattern)+ '&type=&paged=' + str(page))
        self.listSearchItems(cItem)
    def listSearchItems(self, cItem):
        printDBG("ArabSeed.listSearchItems [%s]" % cItem)
        sts, data = self.getPage(cItem['url'])
        if not sts:
            return
        tmp = self.cm.ph.getDataBeetwenMarkers(data, '<div class="series__list">', '<div class="paginate">', False)[1]
        printDBG("tmp.listSearchItems [%s]" % tmp)
        data_items = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<li class="box__xs__2', '</li>')
        printDBG("data_items.listSearchItems [%s]" % data_items)
        for m in data_items:
            title = self.cm.ph.getSearchGroups(m, r'title=[\'"]([^\'"]+)[\'"]')[0]
            pureurl = self.cm.ph.getSearchGroups(m, r'href=[\'"]([^\'"]+)[\'"]')[0]
            pureicon = self.cm.ph.getSearchGroups(m, r'data-src=[\'"]([^\'"]+)[\'"]')[0]
            if pureurl:
                baseurl, filenameurl = pureurl.rsplit('/', 1)
                fixedfilenameurl = urllib_quote_plus(filenameurl)
                url = baseurl + "/" + fixedfilenameurl + "watch/"
            else:
                url = ''
            if pureicon:
                baseicon, filenameicon = pureicon.rsplit('/', 1)
                fixedfilenameicon = urllib_quote_plus(filenameicon)
                icon = baseicon + "/" + fixedfilenameicon
            else:
                icon = ''
            genre = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="__genre hide__md">', '</div>', False)[1]).strip()
            quality = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="__quality hide__md">', '</div>', False)[1]).strip()
            section = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<div class="post__category hide__md">', '</div>', False)[1]).strip()
            story = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(m, '<p>', '</p>', False)[1]).strip()
            line1_parts = []
            line2_parts = []
            if genre: line1_parts.append(f"{E2ColoR('yellow')}Genre:{E2ColoR('white')} {genre}")
            if quality:
                q_color = 'white'
                if re.search(r'4K|1080|HD|BluRay', quality, re.I): q_color = 'green'
                elif re.search(r'720|HDRip|WEB', quality, re.I): q_color = 'orange'
                elif re.search(r'CAM|TS|HDCAM', quality, re.I): q_color = 'red'
                line1_parts.append(
                    f"{E2ColoR('yellow')}Quality:{E2ColoR('white')} "
                    f"{E2ColoR(q_color)}{quality}{E2ColoR('white')}"
                    )
            if section: line1_parts.append(f"{E2ColoR('yellow')}Section:{E2ColoR('white')} {section}")
            if story: line2_parts.append(f"{E2ColoR('yellow')}Story:{E2ColoR('white')} {story}")
            desc = " | ".join(line1_parts)
            if line2_parts: desc += "\n" + " ".join(line2_parts)
            clean_title = self.clean_title_prefix(title, sub_mode=-1, url=cItem.get('url', ''))
            colored_title = self.colorizeTitle(clean_title)
            params = {'category': 'explore_item','title': colored_title,'icon': icon,'url': url,'desc': desc}
            printDBG(str(params))
            self.addDir(params)
        page = cItem.get('page', 1)
        next_page = page + 1
        if len(data_items) > 0:
            params = dict(cItem)
            params.update({'title': _('Next Page ▶'),'page': next_page,})
            self.addDir(params)
    def getFavouriteData(self, cItem):
        printDBG('ArabSeed.getFavouriteData')
        return json_dumps(cItem)
    def getLinksForFavourite(self, fav_data):
        printDBG('ArabSeed.getLinksForFavourite')
        links = []
        try:
            cItem = json_loads(fav_data)
            links = self.getLinksForVideo(cItem)
        except Exception:
            printExc()
        return links
    def setInitListFromFavouriteItem(self, fav_data):
        printDBG('ArabSeed.setInitListFromFavouriteItem')
        try:
            cItem = json_loads(fav_data)
        except Exception:
            cItem = {}
            printExc()
        return cItem
    def listSeriesPacks(self, cItem):
        printDBG('ArabSeed.listSeriesPacks >>> %s' % cItem)
        url = cItem.get('url', '').strip()
        if not url:
            return
        sts, data = self.getPage(url)
        if not sts or not data:
            printDBG('[ArabSeed] Failed to load packs page: %s' % url)
            return
        token = self.cm.ph.getSearchGroups(data, r"csrf__token['\"]:\s*[\"']([^\"']+)")[0]
        if not token:
            token = self.cm.ph.getSearchGroups(data, r"csrf_token['\"]:\s*[\"']([^\"']+)")[0]
        raw_items = re.findall(r'<li[^>]*class="[^"]*box__xs__[^"]*"[^>]*>(.*?)</li>', data, re.S)
        printDBG("Found %d items in packs page" % len(raw_items))
        for item_html in raw_items:
            url_match = re.search(r'<a\s+href=["\']([^"\']+)["\']', item_html)
            if not url_match:
                continue
            href = url_match.group(1)
            title = ''
            title_attr = re.search(r'<a[^>]+title=["\']([^"\']+)["\']', item_html)
            if title_attr:
                title = title_attr.group(1)
            else:
                title_div = re.search(r'<div\s+class=["\']title___["\'][^>]*>([^<]+)</div>', item_html)
                if title_div:
                    title = title_div.group(1)
                else:
                    h3_match = re.search(r'<h3[^>]*>([^<]+)</h3>', item_html)
                    if h3_match:
                        title = h3_match.group(1)
            if not title or not href:
                continue
            icon = ''
            img_match = re.search(r'(?:data-src|src)=["\']([^"\']+)["\']', item_html)
            if img_match:
                icon = img_match.group(1)
            href = quote(href, safe=':/?&=%')
            icon = quote(icon, safe=':/?&=%') if icon else self.DEFAULT_ICON_URL
            desc_parts = []
            info_hide_match = re.search(
                r'<div\s+class=["\']info__box__hide["\'][^>]*>(.*?)</div>\s*(?:<div|$)',
                item_html, re.S
            )
            if info_hide_match:
                hide_content = info_hide_match.group(1)
                rating_hide = re.search(r'<div\s+class=["\']rating["\'][^>]*>(.*?)</div>', hide_content, re.S)
                if rating_hide and rating_hide.group(1).strip():
                    rating_text = self.cleanHtmlStr(rating_hide.group(1)).strip()
                    rating_value = None
                    match_num = re.search(r'(\d+(\.\d+)?)', rating_text)
                    if match_num:
                        try:
                            rating_value = float(match_num.group(1))
                        except:
                            pass
                    rate_color = 'white'
                    if rating_value is not None:
                        if rating_value >= 7: rate_color = 'green'
                        elif rating_value >= 5: rate_color = 'orange'
                        else: rate_color = 'red'
                    desc_parts.append(f"{E2ColoR('yellow')}Rating:{E2ColoR('white')} {E2ColoR(rate_color)}{rating_text}{E2ColoR('white')}")
                story_hide = re.search(r'<p\s+class=["\']story["\'][^>]*>(.*?)</p>', hide_content, re.S)
                if story_hide and story_hide.group(1).strip():
                    desc_parts.append(f"{E2ColoR('yellow')}Story:{E2ColoR('white')} {self.cleanHtmlStr(story_hide.group(1))}")
            meta_line = []
            raw_url = url_match.group(1)
            target_block = None
            for prefix in ['<li class="box__xs__1', '<li class="box__xs__2']:
                blocks = data.split(prefix)
                for block in blocks:
                    if raw_url in block:
                        target_block = prefix + block
                        break
                if target_block:
                    break
            if target_block:
                dots_spans = re.findall(r'<span>([^<]+)</span>', target_block)
                if len(dots_spans) > 0:
                    meta_line.append(f"{E2ColoR('yellow')}Year:{E2ColoR('white')} {self.cleanHtmlStr(dots_spans[0])}")
                if len(dots_spans) > 1:
                    meta_line.append(f"{E2ColoR('yellow')}Country:{E2ColoR('white')} {self.cleanHtmlStr(dots_spans[1])}")
                bottom_ul_match = re.search(r'<ul\s+class=["\']bottom__ul["\'][^>]*>(.*?)</ul>', target_block, re.S)
                if bottom_ul_match:
                    lis = re.findall(r'<li>([^<]+)</li>', bottom_ul_match.group(1))
                    if len(lis) > 0:
                        quality = self.cleanHtmlStr(lis[0])
                        q_color = 'green' if re.search(r'4K|1080|BluRay|FHD', quality, re.I) else 'orange' if re.search(r'720|WEB|HDRip', quality, re.I) else 'white'
                        meta_line.append(f"{E2ColoR('yellow')}Quality:{E2ColoR('white')} {E2ColoR(q_color)}{quality}{E2ColoR('white')}")
                    if len(lis) > 1:
                        meta_line.append(f"{E2ColoR('yellow')}Genre:{E2ColoR('white')} {self.cleanHtmlStr(lis[1])}")
            if meta_line:
                desc_parts.insert(0, ' | '.join(meta_line))
            if not any('Story:' in p for p in desc_parts):
                story_fb = re.search(r'<p\s+class=["\']story["\'][^>]*>([^<]+)</p>', item_html)
                if story_fb and story_fb.group(1).strip():
                    desc_parts.append(f"{E2ColoR('yellow')}Story:{E2ColoR('white')} {self.cleanHtmlStr(story_fb.group(1))}")
            desc = '\n'.join(desc_parts)
            clean_title = self.clean_title_prefix(title, sub_mode=2, url=cItem.get('url', ''))
            colored_title = self.colorizeTitle(clean_title)
            params = dict(cItem)
            params.update({
                'category': 'series_seasons_list',
                'title': colored_title,
                'url': href,
                'icon': icon,
                'desc': desc,
                'csrf_token': token
            })
            self.addDir(params)
        next_match = re.search(r'<a[^>]+class="next page-numbers"[^>]+href="([^"]+)"', data)
        if next_match:
            next_page = next_match.group(1).strip()
            if next_page.startswith('//'):
                next_page = 'https:' + next_page
            elif next_page.startswith('/'):
                next_page = self.MAIN_URL.rstrip('/') + next_page
            params = dict(cItem)
            params.update({'title': _('Next Page ▶'), 'url': next_page, 'category': 'series_packs'})
            self.addDir(params)
        printDBG('ArabSeed.listSeriesPacks <<< done')
    def listSeasons(self, cItem):
        printDBG('ArabSeed.listSeasons >>> %s' % cItem)
        url = cItem.get('url')
        sts, data = self.getPage(url)
        if not sts or not data:
            return
        trailer_url = self.cm.ph.getSearchGroups(data, r'data-iframe="([^"]+)"')[0]
        if trailer_url:
            if 'youtube.com/embed/' in trailer_url:
                trailer_url = trailer_url.replace('youtube.com/embed/', 'youtube.com/watch?v=')
            params = dict(cItem)
            params.update({
                'title': f"{E2ColoR('lime')}TRAILER{E2ColoR('white')}",
                'url': trailer_url,
                'type': 'video',
                'need_resolve': 1
            })
            self.addVideo(params)
        csrf_token = self.cm.ph.getSearchGroups(data, r'csrf__token["\']\s*:\s*["\']([^"\']+)')[0]
        if not csrf_token:
            csrf_token = self.cm.ph.getSearchGroups(data, r'name="csrf_token" value="([^"]+)"')[0]
        seasons_block = self.cm.ph.getDataBeetwenMarkers(data, 'id="seasons__list"', '</div></div>', False)[1]
        if seasons_block:
            season_items = self.cm.ph.getAllItemsBeetwenMarkers(seasons_block, '<li', '</li>')
            for s in season_items:
                season_id = self.cm.ph.getSearchGroups(s, r'data-season="([^"]+)"')[0]
                if not season_id:
                    season_id = self.cm.ph.getSearchGroups(s, r'data-term="([^"]+)"')[0]
                series_id = self.cm.ph.getSearchGroups(s, r'data-series="([^"]+)"')[0]
                title = self.cm.ph.getSearchGroups(s, r'<span>([^<]+)</span>')[0]
                if not season_id or not title:
                    continue
                params = dict(cItem)
                params.update({
                    'category': 'series_episodes_list',
                    'title': title.strip(),
                    'url': url,
                    'season_id': season_id,
                    'series_id': series_id,
                    'csrf_token': csrf_token
                })
                self.addDir(params)
        else:
            printDBG('[ArabSeed] No seasons → trying direct episodes')
            episodes_block = self.cm.ph.getDataBeetwenMarkers(data, '<ul class="episodes__list', '</ul>', False)[1]
            if episodes_block:
                episodes = self.cm.ph.getAllItemsBeetwenMarkers(episodes_block, '<li', '</li>')
                episodes.reverse()
                for ep in episodes:
                    ep_num = self.cm.ph.getSearchGroups(ep, r'<b>(\d+)</b>')[0]
                    if not ep_num:
                        continue
                    ep_url = self.cm.ph.getSearchGroups(ep, r'href="([^"]+)"')[0]
                    if not ep_url:
                        continue
                    if '/watch/' not in ep_url:
                        ep_url += 'watch/'
                    self.addVideo({
                        'title': u'الحلقة %s' % ep_num,
                        'url': ep_url,
                        'icon': cItem.get('icon', ''),
                        'type': 'video',
                        'category': 'explore_episodes'
                    })
                return
            promo_url = self.cm.ph.getSearchGroups(data, r'<div class="watch__and__download.*?<a href="([^"]+/watch/)"')[0]
            if promo_url:
                params = dict(cItem)
                params.update({
                    'title': f"{E2ColoR('yellow')}برومو المسلسل{E2ColoR('white')}",
                    'url': promo_url,
                    'type': 'video',
                    'category': 'explore_episodes'
                })
                self.addDir(params)
    def getIMDBTrailer(self, url):
        printDBG('IMDB resolver start >>> %s' % url)
        links = []
        vid = self.cm.ph.getSearchGroups(url, r'(vi\d+)')[0]
        if not vid:
            printDBG('IMDB: video id not found')
            return []
        embed_url = 'https://www.imdb.com/video/embed/%s/' % vid
        printDBG('IMDB embed URL >>> %s' % embed_url)
        sts, data = self.cm.getPage(embed_url)
        if not sts:
            printDBG('IMDB: failed to load embed page')
            return []
        json_data = self.cm.ph.getSearchGroups(data,r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>')[0]
        if not json_data:
            printDBG('IMDB: __NEXT_DATA__ not found')
            return []
        json_data = json.loads(json_data)
        try:
            videoData = json_data['props']['pageProps'].get('videoEmbedPlaybackData')
            if not videoData:
                printDBG('IMDB: videoEmbedPlaybackData not found')
                return []
            qualities = []
            for item in videoData.get('playbackURLs', []):
                mime = item.get('videoMimeType', '').lower()
                url = item.get('url')
                if not url: continue
                if mime != 'mp4': continue
                display = item.get('displayName', {})
                quality_txt = display.get('value', '')
                try: quality = int(quality_txt.replace('p', '').strip())
                except: continue
                qualities.append({'q': quality,'name': 'IMDb %dp' % quality,'url': url,'need_resolve': 0})
            qualities.sort(key=lambda x: x['q'], reverse=True)
            for q in qualities: links.append({'name': q['name'],'url': q['url'],'need_resolve': 0})
        except Exception as e: printDBG('IMDB extraction error: %s' % e)
        return links
    def listEpisodes(self, cItem):
        printDBG('ArabSeed.listEpisodes >>> %s' % cItem)
        url = cItem.get('url')
        season_id = cItem.get('season_id', '')
        csrf_token = cItem.get('csrf_token', '')
        series_id = cItem.get('series_id', '')
        if not url or not season_id or not csrf_token:
            printDBG('[ArabSeed] Missing required params')
            return
        episodes_html = ''
        post_url = self.getFullUrl('/season__episodes/')
        post_data = {'series_id': series_id, 'season_id': season_id, 'csrf_token': csrf_token}
        headers = {
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': url,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01'
        }
        sts, response = self.cm.getPage(post_url, {'header': headers}, post_data)
        if sts and response:
            try:
                if isinstance(response, bytes):
                    response = response.decode('utf-8')
                result = json_loads(response)
                if result.get('type') == 'success' or 'html' in result:
                    episodes_html = result.get('html', '')
                    printDBG('ArabSeed: AJAX Success for season %s' % season_id)
            except Exception as e:
                printDBG('ArabSeed: JSON Parse Error: %s' % str(e))
                html_match = re.search(r'"html"\s*:\s*"(.*?)"(?:\s*,\s*"hasmore")?', response, re.S)
                if html_match:
                    episodes_html = html_match.group(1).replace('\\/', '/').replace('\\"', '"')
        if not episodes_html:
            sts, page_data = self.getPage(url)
            if sts:
                selected = self.cm.ph.getSearchGroups(page_data, r'<li[^>]+class="selected"[^>]+data-season="(%s)"' % season_id)[0]
                if selected == season_id:
                    block = self.cm.ph.getDataBeetwenMarkers(page_data, '<ul class="episodes__list', '</ul>', False)[1]
                    if block:
                        episodes_html = block
                        printDBG('ArabSeed: Found episodes in main page for season %s' % season_id)
        if episodes_html:
            eps = re.findall(r'<a\s+href=["\']([^"\']+)["\'][^>]*>.*?<div\s+class=["\']epi__num["\'][^>]*>.*?<b>(\d+)</b>', episodes_html, re.S | re.I)
            if not eps:
                eps = re.findall(r'href=["\']([^"\']+)["\'].*?<b>(\d+)</b>', episodes_html, re.S)
            if eps:
                final_eps = []
                for ep_url, ep_num in eps:
                    ep_url = ep_url.replace('\\/', '/')
                    if not ep_url.startswith('http'):
                        ep_url = self.MAIN_URL + ep_url
                    if '/watch/' not in ep_url:
                        ep_url = ep_url.rstrip('/') + '/watch/'
                    final_eps.append((int(ep_num), ep_url))
                final_eps.sort(key=lambda x: x[0])
                for num, link in final_eps:
                    self.addVideo({
                        'title': u'الحلقة %d' % num,
                        'url': quote(link, safe=':/?&=%'),
                        'icon': cItem.get('icon', ''),
                        'desc': cItem.get('desc', ''),
                        'type': 'video',
                        'category': 'explore_episodes'
                    })
                printDBG('ArabSeed: Added %d episodes for season %s' % (len(final_eps), season_id))
            else:
                printDBG('ArabSeed: WARNING - No episode pattern matched')
        else:
            printDBG('ArabSeed: ERROR - Could not retrieve episodes for season %s' % season_id)
    def colorizeTitle(self, title):
        """
        Detects movie title and year in different formats and colorizes both.
        Handles: 2025, (2025), ( 2025 ), - 2025, [2025]
        """
        if not title:
            return title
        match = re.search(r'(.+?)\s*(?:\(|\[|-)?\s*(\d{4})\s*(?:\)|\])?$', title)
        if match:
            movie_title = match.group(1).strip()
            movie_year = match.group(2).strip()
            return (
                f"{E2ColoR('yellow')}{movie_title} "
                f"{E2ColoR('cyan')}{movie_year}{E2ColoR('white')}"
            )
        else:
            return f"{E2ColoR('yellow')}{title}{E2ColoR('white')}"
    def colorizeQuality(self, quality):
        """
        Detect quality level and assign colors
        """
        q_color = 'white'
        if re.search(r'4K|1080|BluRay', quality, re.I): q_color = 'green'
        elif re.search(r'720|HDRip|WEB', quality, re.I): q_color = 'yellow'
        elif re.search(r'CAM|TS|HDCAM', quality, re.I): q_color = 'red'
        return f"{E2ColoR(q_color)}{quality if quality else 'N/A'}{E2ColoR('white')}"
    def colorizeServer(self, name, quality):
        """
        Combine server name + quality with colorized labels
        """
        q_colored = self.colorizeQuality(str(quality))
        return f"{E2ColoR('cyan')}{name}{E2ColoR('white')} [{q_colored}]"
    def clean_title_prefix(self, title, sub_mode=-1, url=''):
        if not title:
            return title
        title = title.strip()
        is_anime_content = False
        if sub_mode == 4:  # قسم الأنمي
            is_anime_content = True
        elif url and any(kw in url.lower() for kw in ['cartoon', 'anime', 'انمي', 'كرتون']):
            is_anime_content = True
        is_program_content = False
        if sub_mode == 5:  # قسم المتنوع
            is_program_content = True
        elif url and any(kw in url.lower() for kw in ['program', 'برامج', 'برنامج']):
            is_program_content = True
        prefixes_to_remove = []
        prefixes_to_remove.extend([
            (r'فيلم\s+', True),
            (r'افلام\s+', True),
            (r'أفلام\s+', True),
        ])
        if not is_anime_content:
            prefixes_to_remove.append((r'مسلسل\s+', True))
        if is_program_content or sub_mode in [2, 3, 5]:
            prefixes_to_remove.extend([
                (r'برنامج\s+', True),
                (r'برامج\s+', True),
            ])
        if is_anime_content:
            prefixes_to_remove.extend([
                (r'انمي\s+', True),
                (r'أنمي\s+', True),
                (r'انمي\:\s+', True),
                (r'أنمي\:\s+', True),
            ])
        prefixes_to_remove.extend([
            (r'أغنية\s+', True),
            (r'اغنية\s+', True),
            (r'اغاني\s+', True),
            (r'أغاني\s+', True),
            (r'مسرحية\s+', True),
            (r'مسرحيات\s+', True),
        ])
        for pattern, condition in prefixes_to_remove:
            if condition and re.match(pattern, title, re.I | re.UNICODE):
                title = re.sub(pattern, '', title, flags=re.I | re.UNICODE)
                break
        return title.strip()
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('ArabSeed.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s] " % (name, category))
        self.currList = []
        if name is None: self.listMainMenu({'name': 'category'})
        elif category == 'list_items': self.listItems(self.currItem)
        elif category == 'series': self.listSeriesItems(self.currItem)
        elif category == 'movies_folder': self.listMoviesFolder(self.currItem)
        elif category == 'series_folder': self.listSeriesFolder(self.currItem)
        elif category == 'series_packs_folder': self.listSeriesPacksFolder(self.currItem)
        elif category == 'series_packs': self.listSeriesPacks(self.currItem)
        elif category == 'series_seasons_list': self.listSeasons(self.currItem)
        elif category == 'series_episodes_list': self.listEpisodes(self.currItem)
        elif category == 'ramadan_folder': self.listRamadanFolder(self.currItem)
        elif category == 'anime_folder': self.listAnimeFolder(self.currItem)
        elif category == 'other_folder': self.listOtherFolder(self.currItem)
        elif category == 'explore_item': self.exploreItems(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)
class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, ArabSeed(), True, [])
    def withArticleContent(self, cItem):
        if 'video' == cItem.get('type', '') or 'explore_item' == cItem.get('category', ''):
            return True
        return False