# # -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.components.ihost import CBaseHostClass, CHostBase
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, E2ColoR
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads
from urllib.parse import unquote
import re

Y, W, L, C, OR = (
    E2ColoR("yellow"),
    E2ColoR("white"),
    E2ColoR("lime"),
    E2ColoR("cyan"),
    E2ColoR("orange"),
)


def GetConfigList():
    return []


def gettytul():
    return "https://officialmoviebox.com"


class MovieBox(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(
            self, {"history": "MovieBox", "cookie": "MovieBox.cookie"}
        )
        self.HEADER = self.cm.getDefaultHeader()
        self.HEADER.update(
            {
                "Accept": "application/json",
                "Origin": "https://officialmoviebox.com",
                "x-request-lang": "en",
            }
        )
        self.defaultParams = {
            "header": self.HEADER,
            "use_cookie": True,
            "load_cookie": True,
            "save_cookie": True,
            "cookiefile": self.COOKIE_FILE,
        }
        self.MAIN_URL = "https://officialmoviebox.com"
        self.API_BASE = "https://officialmoviebox.com/wefeed-h5api-bff"
        self.TAB_API = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
        self.DEFAULT_ICON_URL = self.MAIN_URL + "/logo.png"
        self.MAIN_CAT_TAB = [
            {
                "category": "list_sections",
                "title": _("Home / Sections"),
                "tabId": "1001",
            },
            {
                "category": "list_filter_page",
                "title": _("Movies"),
                "page_url": "/web/film",
                "channel_id": 1,
            },
            {
                "category": "list_filter_page",
                "title": _("TV Shows"),
                "page_url": "/newWeb/tv-series",
                "channel_id": 2,
            },
            {
                "category": "list_filter_page",
                "title": _("Animation"),
                "page_url": "/newWeb/animated-series",
                "channel_id": 1006,
            },
            {"category": "list_most_watched_tabs", "title": _("Most Watched")},
            {"category": "list_upcoming_tabs", "title": _("Upcoming")},
            {"category": "list_football_live", "title": _("Football Live")},
        ] + self.searchItems()

    def getPage(self, baseUrl, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(self.defaultParams)
        else:
            if "header" not in addParams:
                addParams["header"] = dict(self.HEADER)
        addParams["header"]["Referer"] = self.MAIN_URL + "/"
        return self.cm.getPageCFProtection(baseUrl, addParams, post_data)

    def getAPIPage(self, endpoint, params=None, base_url=None):
        if base_url is None:
            base_url = self.API_BASE
        url = base_url + endpoint
        addParams = dict(self.defaultParams)
        addParams["header"]["Referer"] = self.MAIN_URL + "/"
        addParams["header"]["Accept"] = "application/json"
        addParams["header"]["Accept-Encoding"] = "gzip, deflate"
        bearer = self.getBearerToken()
        addParams["header"]["Authorization"] = "Bearer %s" % bearer
        if params:
            url += "?" + "&".join(["%s=%s" % (k, v) for k, v in params.items()])
        sts, data = self.getPage(url, addParams)
        if not sts:
            return False, {}
        try:
            jsonData = json_loads(data)
            return True, jsonData
        except Exception:
            printExc("MovieBox JSON parse error")
            return False, {}

    def postAPIPage(self, endpoint, post_data, base_url=None):
        if base_url is None:
            base_url = self.TAB_API
        url = base_url + endpoint
        bearer = self.getBearerToken()
        import json as json_mod

        post_json = json_mod.dumps(post_data)
        try:
            from urllib.request import Request, urlopen

            req = Request(url, data=post_json.encode("utf-8"), method="POST")
            req.add_header("Referer", self.MAIN_URL + "/")
            req.add_header("Accept", "application/json")
            req.add_header("Content-Type", "application/json")
            req.add_header("Authorization", "Bearer %s" % bearer)
            req.add_header("x-request-lang", "en")
            req.add_header("Origin", self.MAIN_URL)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
            )
            req.add_header("Accept-Encoding", "identity")
            cookie_str = ""
            try:
                with open(self.COOKIE_FILE, "r") as f:
                    lines = f.readlines()
                parts = []
                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    cols = line.split("\t")
                    if len(cols) >= 7:
                        parts.append("%s=%s" % (cols[5], cols[6]))
                cookie_str = "; ".join(parts)
            except Exception:
                pass
            if cookie_str:
                req.add_header("Cookie", cookie_str)
            response = urlopen(req, timeout=30)
            raw_data = response.read().decode("utf-8")
            jsonData = json_loads(raw_data)
            return True, jsonData
        except Exception as e:
            printExc("MovieBox postAPIPage error: %s" % str(e))
            return False, {}

    def getBearerToken(self):
        token = self._readTokenFromCookie()
        if token and self._isTokenValid(token):
            return token
        token = self._fetchNewToken()
        if token:
            return token
        printDBG("MovieBox: No valid token found!")
        return ""

    def _readTokenFromCookie(self):
        try:
            import http.cookiejar

            cj = http.cookiejar.MozillaCookieJar(self.COOKIE_FILE)
            cj.load(ignore_discard=True, ignore_expires=True)
            for cookie in cj:
                if cookie.name in ("token", "mb_token"):
                    val = unquote(cookie.value).strip('"')
                    if val and len(val) > 50:
                        printDBG("MovieBox: Read %s from cookie" % cookie.name)
                        return val
        except Exception as e:
            printDBG("MovieBox _readTokenFromCookie error: %s" % str(e))
        return ""

    def _isTokenValid(self, token):
        try:
            import json
            import base64
            import time

            parts = token.split(".")
            if len(parts) != 3:
                return False
            payload = parts[1]
            padding = 4 - len(payload) % 4
            if padding != 4:
                payload += "=" * padding
            payload = payload.replace("-", "+").replace("_", "/")
            decoded = base64.b64decode(payload)
            data = json.loads(decoded)
            exp = data.get("exp", 0)
            return time.time() < (exp - 3600)
        except Exception:
            return False

    def _fetchNewToken(self):
        try:
            import os

            printDBG("MovieBox: Fetching new token via curl...")
            cookie_dir = os.path.dirname(self.COOKIE_FILE)
            if not os.path.exists(cookie_dir):
                os.makedirs(cookie_dir)
            cmd = (
                'curl -s -o /dev/null -c "%s" -X POST "%s/subject/filter" -H "Content-Type: application/json" -H "Origin: https://officialmoviebox.com" -H "Referer: https://officialmoviebox.com/" -H "User-Agent: Mozilla/5.0" -d \'{"page":1,"perPage":1,"channelId":1}\''
                % (self.COOKIE_FILE, self.TAB_API)
            )
            ret = os.system(cmd)
            printDBG("MovieBox: curl returned %d" % ret)
            if ret == 0:
                try:
                    with open(self.COOKIE_FILE, "a") as f:
                        f.write(
                            "officialmoviebox.com\tFALSE\t/\tFALSE\t1818488272\ti18n_lang\ten\n"
                        )
                except Exception:
                    pass
                token = self._readTokenFromCookie()
                if token:
                    printDBG("MovieBox: Got token via curl")
                    return token
            printDBG("MovieBox: Failed to get token")
            return ""
        except Exception as e:
            printExc("MovieBox _fetchNewToken error: %s" % str(e))
            return ""

    def _addMovieFromSubject(self, cItem, subj):
        title = str(subj.get("title", "") or "").strip()
        subjectId = str(subj.get("subjectId", ""))
        detailPath = subj.get("detailPath", "")
        subjectType = subj.get("subjectType", 1)
        cover = subj.get("cover", {})
        icon = ""
        if isinstance(cover, dict):
            icon = cover.get("url", "")
        elif isinstance(cover, str):
            icon = cover
        genre = subj.get("genre", "")
        imdb = subj.get("imdbRatingValue", "")
        country = subj.get("countryName", "")
        year = subj.get("releaseDate", "")[:4] if subj.get("releaseDate") else ""
        releaseDate = subj.get("releaseDate", "")
        corner = subj.get("corner", "")
        description = subj.get("description", "").strip()
        trailer_url = ""
        trailer = subj.get("trailer", None)
        if trailer and isinstance(trailer, dict):
            video_addr = trailer.get("videoAddress", {})
            if video_addr and isinstance(video_addr, dict):
                trailer_url = video_addr.get("url", "")
        if not title or not subjectId:
            return
        info_parts = []
        if imdb:
            info_parts.append("%sIMDb: %s" % (L, imdb))
        if year:
            info_parts.append(year)
        if country:
            info_parts.append(country)
        if genre:
            info_parts.append("%s%s" % (Y, genre))
        if releaseDate:
            info_parts.append(releaseDate)
        if corner:
            info_parts.append(corner)
        desc = " | ".join(info_parts)
        if description:
            desc += "\n\n%sStory: %s" % (C, description)
        icon_url = self.getFullIconUrl(icon) if icon else ""
        if subjectType == 2:
            cat = "list_seasons"
        else:
            cat = "list_servers"
        params = dict(cItem)
        params.update(
            {
                "category": cat,
                "title": title,
                "subjectId": subjectId,
                "subjectType": subjectType,
                "detailPath": detailPath,
                "icon": icon_url,
                "desc": desc,
                "trailer_url": trailer_url,
                "good_for_fav": True,
            }
        )
        self.addDir(params)

    def listSections(self, cItem):
        printDBG("MovieBox.listSections - Dynamic from operatingList")
        url = self.MAIN_URL + "/?utm_source="
        sts, html_data = self.getPage(url)
        if not sts:
            printDBG("MovieBox.listSections: getPage FAILED")
            return
        import json as json_mod

        nuxt_match = re.search(
            r'id="__NUXT_DATA__"[^>]*>(\[[\s\S]*?)\s*</script>', html_data
        )
        if not nuxt_match:
            printDBG("MovieBox.listSections: No NUXT_DATA found")
            return
        try:
            nuxt_arr = json_mod.loads(nuxt_match.group(1))

            def rv(v):
                if isinstance(v, int) and 0 <= v < len(nuxt_arr):
                    r = nuxt_arr[v]
                    if isinstance(r, (int, float, str, bool)):
                        return r
                    if isinstance(r, int) and 0 <= r < len(nuxt_arr):
                        r2 = nuxt_arr[r]
                        if isinstance(r2, (int, float, str, bool)):
                            return r2
                return v

            operating_list = None
            for item in nuxt_arr:
                if isinstance(item, dict) and "operatingList" in item:
                    ol_ref = item["operatingList"]
                    if isinstance(ol_ref, int) and ol_ref < len(nuxt_arr):
                        ol = nuxt_arr[ol_ref]
                        if isinstance(ol, list):
                            operating_list = ol
                            break
            if not operating_list:
                printDBG("MovieBox.listSections: operatingList not found")
                return
            printDBG(
                "MovieBox.listSections: Found operatingList with %d items"
                % len(operating_list)
            )
            added = 0
            seen_titles = set()
            for op_idx in operating_list:
                if not isinstance(op_idx, int) or op_idx >= len(nuxt_arr):
                    continue
                op = nuxt_arr[op_idx]
                if not isinstance(op, dict):
                    continue
                op_type = str(rv(op.get("type", "")))
                title = str(rv(op.get("title", "")))
                op_id = str(rv(op.get("opId", "")))
                genre_top_id = str(rv(op.get("genreTopId", "")))
                if not title:
                    continue
                if title in seen_titles:
                    continue
                seen_titles.add(title)
                printDBG(
                    "SECTION: type=%s, title=%s, opId=%s, genreTopId=%s"
                    % (op_type, title, op_id, genre_top_id)
                )
                if op_type == "SPORT_LIVE":
                    printDBG("MovieBox.listSections: Skipping SPORT_LIVE: %s" % title)
                    continue
                if op_type == "CUSTOM":
                    printDBG("MovieBox.listSections: Skipping CUSTOM: %s" % title)
                    continue
                if op_type == "FILTER":
                    printDBG("MovieBox.listSections: Skipping FILTER: %s" % title)
                    continue
                if op_type == "BANNER":
                    banner_items = []
                    banner_ref = op.get("banner")
                    if isinstance(banner_ref, int) and banner_ref < len(nuxt_arr):
                        banner_obj = nuxt_arr[banner_ref]
                        if isinstance(banner_obj, dict):
                            items_ref = banner_obj.get("items")
                            if isinstance(items_ref, int) and items_ref < len(nuxt_arr):
                                items_list = nuxt_arr[items_ref]
                                if isinstance(items_list, list):
                                    for it_idx in items_list:
                                        if isinstance(it_idx, int) and it_idx < len(
                                            nuxt_arr
                                        ):
                                            banner_item = nuxt_arr[it_idx]
                                            if not isinstance(banner_item, dict):
                                                continue
                                            subj_ref = banner_item.get("subject")
                                            if not (
                                                isinstance(subj_ref, int)
                                                and subj_ref < len(nuxt_arr)
                                            ):
                                                continue
                                            raw_subj = nuxt_arr[subj_ref]
                                            if not (
                                                isinstance(raw_subj, dict)
                                                and "subjectId" in raw_subj
                                            ):
                                                continue
                                            sid = rv(raw_subj.get("subjectId"))
                                            ttl = rv(raw_subj.get("title"))
                                            dp = rv(raw_subj.get("detailPath"))
                                            stype = rv(raw_subj.get("subjectType", 2))
                                            cover_url = ""
                                            cover_ref = raw_subj.get("cover")
                                            if isinstance(
                                                cover_ref, int
                                            ) and cover_ref < len(nuxt_arr):
                                                cover_obj = nuxt_arr[cover_ref]
                                                if isinstance(cover_obj, dict):
                                                    cover_url = rv(
                                                        cover_obj.get("url", "")
                                                    )
                                            if sid and ttl:
                                                banner_items.append(
                                                    {
                                                        "subjectId": str(sid),
                                                        "title": str(ttl),
                                                        "subjectType": (
                                                            int(stype)
                                                            if str(stype).isdigit()
                                                            else 2
                                                        ),
                                                        "detailPath": str(dp or ""),
                                                        "cover": (
                                                            {"url": str(cover_url)}
                                                            if cover_url
                                                            else {}
                                                        ),
                                                    }
                                                )
                    if banner_items:
                        p = dict(cItem)
                        p.update(
                            {
                                "category": "list_section_banner",
                                "title": title,
                                "opId": op_id,
                                "op_type": op_type,
                                "_banner_items": banner_items,
                                "good_for_fav": True,
                            }
                        )
                        self.addDir(p)
                        added += 1
                        printDBG(
                            "MovieBox.listSections: Added BANNER '%s' with %d items"
                            % (title, len(banner_items))
                        )
                    continue
                if op_type == "APPOINTMENT_LIST":
                    appt_items = []
                    subjects_ref = op.get("subjects")
                    if isinstance(subjects_ref, int) and subjects_ref < len(nuxt_arr):
                        subjects_list = nuxt_arr[subjects_ref]
                        if isinstance(subjects_list, list):
                            for s_idx in subjects_list:
                                if isinstance(s_idx, int) and s_idx < len(nuxt_arr):
                                    raw_subj = nuxt_arr[s_idx]
                                    if (
                                        isinstance(raw_subj, dict)
                                        and "subjectId" in raw_subj
                                    ):
                                        resolved = {}
                                        for k, v in raw_subj.items():
                                            if k == "cover":
                                                if isinstance(v, int) and v < len(
                                                    nuxt_arr
                                                ):
                                                    cover_obj = nuxt_arr[v]
                                                    if isinstance(cover_obj, dict):
                                                        rc = {}
                                                        for ck, cv in cover_obj.items():
                                                            rc[ck] = (
                                                                rv(cv)
                                                                if isinstance(cv, int)
                                                                else cv
                                                            )
                                                        resolved["cover"] = rc
                                                else:
                                                    resolved["cover"] = v
                                            elif k == "trailer":
                                                if isinstance(v, int) and v < len(
                                                    nuxt_arr
                                                ):
                                                    tr_obj = nuxt_arr[v]
                                                    if isinstance(tr_obj, dict):
                                                        rt = {}
                                                        for tk, tv in tr_obj.items():
                                                            if tk == "videoAddress":
                                                                if isinstance(
                                                                    tv, int
                                                                ) and tv < len(
                                                                    nuxt_arr
                                                                ):
                                                                    va = nuxt_arr[tv]
                                                                    if isinstance(
                                                                        va, dict
                                                                    ):
                                                                        rva = {}
                                                                        for (
                                                                            vk,
                                                                            vv,
                                                                        ) in va.items():
                                                                            rva[vk] = (
                                                                                rv(vv)
                                                                                if isinstance(
                                                                                    vv,
                                                                                    int,
                                                                                )
                                                                                else vv
                                                                            )
                                                                        rt[
                                                                            "videoAddress"
                                                                        ] = rva
                                                                else:
                                                                    rt[
                                                                        "videoAddress"
                                                                    ] = tv
                                                            else:
                                                                rt[tk] = (
                                                                    rv(tv)
                                                                    if isinstance(
                                                                        tv, int
                                                                    )
                                                                    else tv
                                                                )
                                                        resolved["trailer"] = rt
                                                else:
                                                    resolved["trailer"] = v
                                            else:
                                                resolved[k] = (
                                                    rv(v) if isinstance(v, int) else v
                                                )
                                        appt_items.append(resolved)
                    if appt_items:
                        p = dict(cItem)
                        p.update(
                            {
                                "category": "list_section_banner",
                                "title": title,
                                "opId": op_id,
                                "op_type": op_type,
                                "_banner_items": appt_items,
                                "good_for_fav": True,
                            }
                        )
                        self.addDir(p)
                        added += 1
                        printDBG(
                            "MovieBox.listSections: Added APPOINTMENT '%s' with %d items"
                            % (title, len(appt_items))
                        )
                    else:
                        printDBG(
                            "MovieBox.listSections: APPOINTMENT '%s' empty, skipping"
                            % title
                        )
                    continue
                if op_type in ("PLAY_LIST", "SUBJECTS_MOVIE"):
                    p = dict(cItem)
                    p.update(
                        {
                            "category": "list_section_playlist",
                            "title": title,
                            "opId": op_id,
                            "op_type": op_type,
                            "genreTopId": genre_top_id,
                            "good_for_fav": True,
                        }
                    )
                    self.addDir(p)
                    added += 1
                    continue
                printDBG(
                    "MovieBox.listSections: Unknown type '%s' for '%s', trying playlist"
                    % (op_type, title)
                )
                p = dict(cItem)
                p.update(
                    {
                        "category": "list_section_playlist",
                        "title": title,
                        "opId": op_id,
                        "op_type": op_type,
                        "genreTopId": genre_top_id,
                        "good_for_fav": True,
                    }
                )
                self.addDir(p)
                added += 1
            printDBG("MovieBox.listSections: Added %d sections" % added)
        except Exception as e:
            printExc("MovieBox.listSections error: %s" % str(e))

    def listSectionPlaylist(self, cItem):
        printDBG("MovieBox.listSectionPlaylist [%s]" % cItem.get("title", ""))
        op_id = cItem.get("opId", "")
        genre_top_id = cItem.get("genreTopId", "")
        page = cItem.get("page", 1)
        ranking_id = genre_top_id or op_id
        if not ranking_id:
            printDBG("MovieBox.listSectionPlaylist: No ranking_id")
            return
        api_base = "https://mzfi.me/wefeed-h5api-bff"
        sts, data = self.getAPIPage(
            "/ranking-list/content",
            {"id": ranking_id, "page": str(page), "perPage": "30"},
            base_url=api_base,
        )
        if sts and data.get("code") == 0:
            pager = data.get("data", {}).get("pager", {})
            items = data.get("data", {}).get("subjectList", [])
            hasMore = pager.get("hasMore", False)
            count = 0
            for subj in items:
                if isinstance(subj, dict) and subj.get("subjectId"):
                    self._addMovieFromSubject(cItem, subj)
                    count += 1
            printDBG("MovieBox.listSectionPlaylist: Added %d items" % count)
            if hasMore:
                p = dict(cItem)
                p.update(
                    {
                        "good_for_fav": False,
                        "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                        "page": page + 1,
                    }
                )
                self.addDir(p)
        else:
            printDBG("MovieBox.listSectionPlaylist: API failed for id=%s" % ranking_id)

    def listSectionBanner(self, cItem):
        printDBG("MovieBox.listSectionBanner [%s]" % cItem.get("title", ""))
        items = cItem.get("_banner_items", [])
        if not items:
            printDBG("MovieBox.listSectionBanner: No items")
            return
        count = 0
        for subj in items:
            if isinstance(subj, dict) and subj.get("subjectId"):
                self._addMovieFromSubject(cItem, subj)
                count += 1
        printDBG("MovieBox.listSectionBanner: Added %d items" % count)

    def listFilterPage(self, cItem):
        printDBG("MovieBox.listFilterPage [%s]" % cItem.get("title", ""))
        page = cItem.get("page", 1)
        page_url = cItem.get("page_url", "")
        channel_id = int(cItem.get("channel_id", 0))
        if not page_url or not channel_id:
            return
        extra_params = {}
        anim_filter = cItem.get("anim_filter", None)
        if anim_filter and cItem.get("_apply_filter"):
            post_data = {
                "page": page,
                "perPage": 36,
                "channelId": channel_id,
                "sort": "ForYou",
            }
            post_data.update(extra_params)
            post_data.update(anim_filter)
            sts, data = self.postAPIPage("/subject/filter", post_data)
            if sts and data.get("code") == 0:
                pager = data.get("data", {}).get("pager", {})
                items = data.get("data", {}).get("items", [])
                hasMore = pager.get("hasMore", False)
                for subj in items:
                    self._addMovieFromSubject(cItem, subj)
                if hasMore:
                    p = dict(cItem)
                    p.update(
                        {
                            "good_for_fav": False,
                            "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                            "page": page + 1,
                        }
                    )
                    self.addDir(p)
                return
        if page > 1:
            post_data = {
                "page": page,
                "perPage": 36,
                "channelId": channel_id,
                "sort": "ForYou",
            }
            post_data.update(extra_params)
            if anim_filter:
                post_data.update(anim_filter)
            sts, data = self.postAPIPage("/subject/filter", post_data)
            if sts and data.get("code") == 0:
                items = data.get("data", {}).get("items", [])
                if items:
                    pager = data.get("data", {}).get("pager", {})
                    hasMore = pager.get("hasMore", False)
                    for subj in items:
                        self._addMovieFromSubject(cItem, subj)
                    if hasMore:
                        p = dict(cItem)
                        p.update(
                            {
                                "good_for_fav": False,
                                "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                                "page": page + 1,
                            }
                        )
                        self.addDir(p)
                    return
            url = "%s%s?utm_source=&page=%d" % (self.MAIN_URL, page_url, page)
            sts, html_data = self.getPage(url)
            if sts:
                self._extractSubjectsFromNuxt(cItem, html_data)
            return
        selected_filter_type = cItem.get("selected_filter_type", "")
        if selected_filter_type:
            self._listFilterPageOptions(cItem)
            return
        if cItem.get("show_filters"):
            filter_groups = cItem.get("_filter_groups", {})
            if filter_groups:
                self._listFilterPageCategories(cItem, filter_groups)
                return
        url = "%s%s?utm_source=" % (self.MAIN_URL, page_url)
        sts, html_data = self.getPage(url)
        if not sts:
            return
        import json as json_mod

        nuxt_match = re.search(
            r'<script[^>]+id="__NUXT_DATA__"[^>]*>(\[[\s\S]*?)\s*</script>', html_data
        )
        if not nuxt_match:
            return
        try:
            nuxt_arr = json_mod.loads(nuxt_match.group(1))

            def resolve_val(val):
                if isinstance(val, int) and 0 <= val < len(nuxt_arr):
                    resolved = nuxt_arr[val]
                    if isinstance(resolved, (int, float, str, bool)):
                        return resolved
                    if isinstance(resolved, int) and 0 <= resolved < len(nuxt_arr):
                        second = nuxt_arr[resolved]
                        if isinstance(second, (int, float, str, bool)):
                            return second
                return val

            filter_groups = {}
            for item in nuxt_arr:
                if (
                    isinstance(item, dict)
                    and "filterType" in item
                    and "title" in item
                    and "filterVals" in item
                ):
                    ft = resolve_val(item["filterType"])
                    title = resolve_val(item["title"])
                    vals_ref = item["filterVals"]
                    if isinstance(vals_ref, int) and vals_ref < len(nuxt_arr):
                        vals_list = nuxt_arr[vals_ref]
                    elif isinstance(vals_ref, list):
                        vals_list = vals_ref
                    else:
                        continue
                    options = []
                    if isinstance(vals_list, list):
                        for v_idx in vals_list:
                            if isinstance(v_idx, int) and v_idx < len(nuxt_arr):
                                val_obj = nuxt_arr[v_idx]
                                if isinstance(val_obj, dict) and "name" in val_obj:
                                    name = resolve_val(val_obj["name"])
                                    vid = resolve_val(val_obj.get("id", ""))
                                    options.append({"name": str(name), "id": str(vid)})
                    if options and ft:
                        filter_groups[str(ft)] = {
                            "title": str(title),
                            "options": options,
                        }
            if filter_groups:
                p = dict(cItem)
                p.update(
                    {
                        "category": "list_filter_page",
                        "title": "%s🔍 Filter" % Y,
                        "_filter_groups": filter_groups,
                        "show_filters": True,
                        "good_for_fav": True,
                    }
                )
                self.addDir(p)
            self._extractSubjectsFromNuxtArr(cItem, nuxt_arr, resolve_val)
        except Exception as e:
            printExc("MovieBox listFilterPage error: %s" % str(e))

    def _extractSubjectsFromNuxt(self, cItem, html_data):
        import json as json_mod

        nuxt_match = re.search(
            r'<script[^>]+id="__NUXT_DATA__"[^>]*>(\[[\s\S]*?)\s*</script>', html_data
        )
        if not nuxt_match:
            return
        try:
            nuxt_arr = json_mod.loads(nuxt_match.group(1))

            def resolve_val(val):
                if isinstance(val, int) and 0 <= val < len(nuxt_arr):
                    resolved = nuxt_arr[val]
                    if isinstance(resolved, (int, float, str, bool)):
                        return resolved
                    if isinstance(resolved, int) and 0 <= resolved < len(nuxt_arr):
                        second = nuxt_arr[resolved]
                        if isinstance(second, (int, float, str, bool)):
                            return second
                return val

            self._extractSubjectsFromNuxtArr(cItem, nuxt_arr, resolve_val)
        except Exception as e:
            printDBG("MovieBox _extractSubjectsFromNuxt error: %s" % str(e))

    def _extractSubjectsFromNuxtArr(self, cItem, nuxt_arr, resolve_val):
        for item in nuxt_arr:
            if isinstance(item, dict) and "items" in item and "pager" in item:
                items_ref = item["items"]
                pager_ref = item["pager"]
                if isinstance(items_ref, int) and items_ref < len(nuxt_arr):
                    items_list = nuxt_arr[items_ref]
                elif isinstance(items_ref, list):
                    items_list = items_ref
                else:
                    continue
                hasMore = False
                if isinstance(pager_ref, int) and pager_ref < len(nuxt_arr):
                    pager_obj = nuxt_arr[pager_ref]
                    if isinstance(pager_obj, dict):
                        hm = pager_obj.get("hasMore", False)
                        hasMore = resolve_val(hm) if isinstance(hm, int) else hm
                if isinstance(items_list, list):
                    count = 0
                    for s_idx in items_list:
                        if isinstance(s_idx, int) and s_idx < len(nuxt_arr):
                            subj = nuxt_arr[s_idx]
                            if isinstance(subj, dict) and "subjectId" in subj:
                                resolved_subj = {}
                                for k, v in subj.items():
                                    resolved_subj[k] = (
                                        resolve_val(v) if isinstance(v, int) else v
                                    )
                                cover_ref = subj.get("cover")
                                if isinstance(cover_ref, int) and cover_ref < len(
                                    nuxt_arr
                                ):
                                    cover_obj = nuxt_arr[cover_ref]
                                    if isinstance(cover_obj, dict):
                                        resolved_cover = {}
                                        for ck, cv in cover_obj.items():
                                            resolved_cover[ck] = (
                                                resolve_val(cv)
                                                if isinstance(cv, int)
                                                else cv
                                            )
                                        resolved_subj["cover"] = resolved_cover
                                self._addMovieFromSubject(cItem, resolved_subj)
                                count += 1
                    printDBG("MovieBox NUXT extract: Added %d items" % count)
                page = cItem.get("page", 1)
                if hasMore:
                    p = dict(cItem)
                    p.update(
                        {
                            "good_for_fav": False,
                            "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                            "page": page + 1,
                        }
                    )
                    self.addDir(p)
                break

    def _listFilterPageCategories(self, cItem, filter_groups):
        current_filters = cItem.get("anim_filter", {})
        for ft, fdata in filter_groups.items():
            selected_id = current_filters.get(ft, "")
            selected_name = "All"
            for opt in fdata["options"]:
                if str(opt["id"]) == str(selected_id):
                    selected_name = opt["name"]
                    break
            title = "%s: %s%s" % (fdata["title"], L, selected_name)
            p = dict(cItem)
            p.update(
                {
                    "category": "list_filter_page",
                    "title": title,
                    "selected_filter_type": ft,
                    "_filter_groups": filter_groups,
                    "anim_filter": current_filters,
                    "good_for_fav": True,
                }
            )
            self.addDir(p)
        if current_filters:
            filter_parts = []
            for ft, fid in current_filters.items():
                fdata = filter_groups.get(ft, {})
                fname = fdata.get("title", ft)
                vname = fid
                for opt in fdata.get("options", []):
                    if str(opt["id"]) == str(fid):
                        vname = opt["name"]
                        break
                filter_parts.append("%s=%s" % (fname, vname))
            filter_desc = ", ".join(filter_parts)
            p = dict(cItem)
            p.update(
                {
                    "category": "list_filter_page",
                    "title": "%s▶ Show Results (%s)" % (Y, filter_desc),
                    "anim_filter": current_filters,
                    "_apply_filter": True,
                    "good_for_fav": False,
                }
            )
            self.addDir(p)

    def _listFilterPageOptions(self, cItem):
        filter_groups = cItem.get("_filter_groups", {})
        selected_filter_type = cItem.get("selected_filter_type", "")
        current_filters = dict(cItem.get("anim_filter", {}))
        fdata = filter_groups.get(selected_filter_type, {})
        options = fdata.get("options", [])
        for opt in options:
            new_filters = dict(current_filters)
            if opt["name"].lower() == "all":
                new_filters.pop(selected_filter_type, None)
            else:
                new_filters[selected_filter_type] = opt["id"]
            is_selected = str(current_filters.get(selected_filter_type, "")) == str(
                opt["id"]
            )
            prefix = "✓ " if is_selected else ""
            p = dict(cItem)
            p.update(
                {
                    "category": "list_filter_page_select",
                    "title": "%s%s" % (prefix, opt["name"]),
                    "anim_filter": new_filters,
                    "_filter_groups": filter_groups,
                    "good_for_fav": True,
                }
            )
            self.addDir(p)

    def listFilterPageSelect(self, cItem):
        filter_groups = cItem.get("_filter_groups", {})
        self._listFilterPageCategories(cItem, filter_groups)

    def _enrichDescWithStory(self, cItem):
        desc = cItem.get("desc", "")
        if "Story:" in desc:
            return desc
        detailPath = cItem.get("detailPath", "")
        subjectId = cItem.get("subjectId", "")
        if not detailPath or not subjectId:
            return desc
        try:
            detail_url = "%s/moviesDetail/%s?id=%s&type=/movie/detail" % (
                self.MAIN_URL,
                detailPath,
                subjectId,
            )
            sts, html_data = self.getPage(detail_url)
            if sts:
                desc_match = re.search(
                    r'<meta\s+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']',
                    html_data,
                )
                if desc_match:
                    story = desc_match.group(1).strip()
                    story = re.sub(
                        r"^Watch\s+.*?free streaming online on\s+\w+\.?\s*",
                        "",
                        story,
                        flags=re.IGNORECASE,
                    ).strip()
                    story = re.sub(
                        r"\.\s*Enjoy HD quality.*$", ".", story, flags=re.IGNORECASE
                    ).strip()
                    if story and len(story) > 10:
                        desc += "\n\n%sStory: %s" % (C, story)
        except Exception:
            pass
        return desc

    def listUpcoming(self, cItem):
        printDBG("MovieBox.listUpcoming [%s]" % cItem.get("title", ""))
        page = cItem.get("page", 1)
        upcoming_cat = cItem.get("upcoming_category", "")
        url = "%s/upcoming-subject-list?page=%d&perPage=23" % (self.TAB_API, page)
        if upcoming_cat:
            url += "&category=%s" % upcoming_cat
        bearer = self.getBearerToken()
        try:
            from urllib.request import Request, urlopen

            req = Request(url)
            req.add_header("Referer", self.MAIN_URL + "/")
            req.add_header("Accept", "application/json")
            req.add_header("Accept-Encoding", "identity")
            req.add_header("Authorization", "Bearer %s" % bearer)
            req.add_header("x-request-lang", "en")
            req.add_header("Origin", self.MAIN_URL)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            )
            cookie_str = ""
            try:
                with open(self.COOKIE_FILE, "r") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        cols = line.split("\t")
                        if len(cols) >= 7:
                            cookie_str += "%s=%s; " % (cols[5], cols[6])
            except Exception:
                pass
            if cookie_str:
                req.add_header("Cookie", cookie_str.rstrip("; "))
            response = urlopen(req, timeout=30)
            raw_data = response.read().decode("utf-8")
            data = json_loads(raw_data)
            if data.get("code") == 0:
                subjects = data.get("data", {}).get("subjects", [])
                pager = data.get("data", {}).get("pager", {})
                hasMore = pager.get("hasMore", False)
                for subj in subjects:
                    if isinstance(subj, dict) and subj.get("subjectId"):
                        self._addMovieFromSubject(cItem, subj)
                if hasMore:
                    p = dict(cItem)
                    p.update(
                        {
                            "good_for_fav": False,
                            "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                            "page": page + 1,
                        }
                    )
                    self.addDir(p)
                printDBG(
                    "MovieBox upcoming: %d items, hasMore=%s" % (len(subjects), hasMore)
                )
            else:
                printDBG("MovieBox upcoming API error: %s" % data.get("message"))
        except Exception as e:
            printExc("MovieBox upcoming error: %s" % str(e))

    def listUpcomingTabs(self, cItem):
        printDBG("MovieBox.listUpcomingTabs")
        tabs = [
            {"title": "Movie", "category_param": "movie"},
            {"title": "TV", "category_param": "tv"},
            {"title": "Anime", "category_param": "anime"},
        ]
        for tab in tabs:
            p = dict(cItem)
            p.update(
                {
                    "category": "list_upcoming",
                    "title": tab["title"],
                    "upcoming_category": tab["category_param"],
                    "good_for_fav": True,
                }
            )
            self.addDir(p)

    def listSectionMoviesAPI(self, cItem):
        printDBG("MovieBox.listSectionMoviesAPI [%s]" % cItem.get("title", ""))
        page = cItem.get("page", 1)
        subjects = cItem.get("_subjects", [])
        genreTopId = cItem.get("genreTopId", "")
        opId = cItem.get("opId", "")
        rankingId = genreTopId or opId
        if rankingId:
            sts, data = self.getAPIPage(
                "/ranking-list/content",
                {"id": rankingId, "page": str(page), "perPage": "20"},
                base_url=self.TAB_API,
            )
            if sts and data.get("code") == 0:
                pager = data.get("data", {}).get("pager", {})
                items = data.get("data", {}).get("subjectList", [])
                hasMore = pager.get("hasMore", False)
                for subj in items:
                    if isinstance(subj, dict) and subj.get("subjectId"):
                        self._addMovieFromSubject(cItem, subj)
                if hasMore:
                    p = dict(cItem)
                    p.update(
                        {
                            "good_for_fav": False,
                            "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                            "page": page + 1,
                        }
                    )
                    self.addDir(p)
                return
        count = 0
        for subj in subjects:
            if isinstance(subj, dict) and subj.get("subjectId"):
                self._addMovieFromSubject(cItem, subj)
                count += 1
        printDBG("MovieBox: Added %d movies from cache" % count)

    def listRankingContent(self, cItem):
        """Display movies from a specific ranking sub-tab with Smart Filtering"""
        printDBG("MovieBox.listRankingContent [%s]" % cItem.get("title", ""))
        page = cItem.get("page", 1)
        ranking_id = cItem.get("ranking_id", "")
        if not ranking_id:
            return
        api_base = "https://mzfi.me/wefeed-h5api-bff"
        sts, data = self.getAPIPage(
            "/ranking-list/content",
            {"id": ranking_id, "page": str(page), "perPage": "30"},
            base_url=api_base,
        )
        if sts and data.get("code") == 0:
            pager = data.get("data", {}).get("pager", {})
            items = data.get("data", {}).get("subjectList", [])
            hasMore = pager.get("hasMore", False)
            title_lower = cItem.get("title", "").lower()
            filter_type = None
            if any(x in title_lower for x in ["drama", "series", "tv", "anime"]):
                filter_type = 2  # TV Series
            elif any(x in title_lower for x in ["movie", "film"]):
                filter_type = 1  # Movie
            count = 0
            for subj in items:
                if isinstance(subj, dict) and subj.get("subjectId"):
                    subj_type = subj.get("subjectType")
                    if filter_type and subj_type != filter_type:
                        continue
                    if subj.get("title") and subj.get("cover"):
                        self._addMovieFromSubject(cItem, subj)
                        count += 1
            printDBG(
                "MovieBox.listRankingContent: Displayed %d items (Filtered by type: %s)"
                % (count, filter_type)
            )
            if hasMore:
                params = dict(cItem)
                params.update(
                    {
                        "good_for_fav": False,
                        "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                        "page": page + 1,
                    }
                )
                self.addDir(params)
        else:
            printDBG("MovieBox.listRankingContent: API failed")

    def _fetchRankingTabsFromPage(self, page_url):
        """جلب كل أقسام Most Watched ديناميكيًا من HTML"""
        try:
            printDBG("=== MovieBox: START _fetchRankingTabsFromPage ===")
            printDBG("=== MovieBox: Fetching URL: %s ===" % page_url)
            sts, html_data = self.getPage(page_url)
            printDBG(
                "=== MovieBox: getPage status=%s, html_len=%d ==="
                % (sts, len(html_data) if html_data else 0)
            )
            if not sts:
                printDBG("=== MovieBox: getPage FAILED, returning [] ===")
                return []
            tabs = []
            seen_ids = set()
            import json as json_mod

            nuxt_match = re.search(
                r'id="__NUXT_DATA__"[^>]*>(\[[\s\S]*?)\s*</script>', html_data
            )
            printDBG("=== MovieBox: NUXT match found=%s ===" % bool(nuxt_match))
            if nuxt_match:
                try:
                    nuxt_arr = json_mod.loads(nuxt_match.group(1))

                    def rv(v):
                        if isinstance(v, int) and 0 <= v < len(nuxt_arr):
                            r = nuxt_arr[v]
                            if isinstance(r, (int, float, str, bool)):
                                return r
                            if isinstance(r, int) and 0 <= r < len(nuxt_arr):
                                r2 = nuxt_arr[r]
                                if isinstance(r2, (int, float, str, bool)):
                                    return r2
                        return v

                    nuxt_count = 0
                    for item in nuxt_arr:
                        if isinstance(item, dict) and "rankingList" in item:
                            rl = item["rankingList"]
                            if isinstance(rl, int) and rl < len(nuxt_arr):
                                lst = nuxt_arr[rl]
                                if isinstance(lst, list):
                                    for ti in lst:
                                        if isinstance(ti, int) and ti < len(nuxt_arr):
                                            t = nuxt_arr[ti]
                                            if (
                                                isinstance(t, dict)
                                                and "name" in t
                                                and "id" in t
                                            ):
                                                name = str(rv(t["name"]))
                                                tid = str(rv(t["id"]))
                                                if tid not in seen_ids:
                                                    seen_ids.add(tid)
                                                    tabs.append(
                                                        {
                                                            "title": name,
                                                            "ranking_id": tid,
                                                        }
                                                    )
                                                    nuxt_count += 1
                    printDBG("=== MovieBox: NUXT extracted %d tabs ===" % nuxt_count)
                except Exception as e:
                    printDBG("=== MovieBox: NUXT parse error: %s ===" % str(e))
            link_pattern = re.compile(
                r'/ranking-list/([a-zA-Z0-9_-]+)\?[^"\']*?id=(\d+)', re.IGNORECASE
            )
            link_count = 0
            for m in link_pattern.finditer(html_data):
                path = m.group(1)
                rid = m.group(2)
                if rid in seen_ids:
                    continue
                seen_ids.add(rid)
                tabs.append({"title": path, "ranking_id": rid})
                link_count += 1
            printDBG("=== MovieBox: HTML link regex found %d new tabs ===" % link_count)
            name_id_pattern = re.compile(
                r'"name"\s*:\s*"([^"]+)"[^}]*?"id"\s*:\s*"(\d+)"', re.DOTALL
            )
            name_count = 0
            for m in name_id_pattern.finditer(html_data):
                name = m.group(1)
                rid = m.group(2)
                if rid in seen_ids:
                    for t in tabs:
                        if t["ranking_id"] == rid and t["title"] == t["title"]:
                            if t["title"] not in [name]:
                                t["title"] = name
                            break
                else:
                    seen_ids.add(rid)
                    tabs.append({"title": name, "ranking_id": rid})
                    name_count += 1
            printDBG(
                "=== MovieBox: HTML name+id regex found %d new tabs ===" % name_count
            )
            printDBG("=== MovieBox: FINAL TABS (%d) ===" % len(tabs))
            for i, t in enumerate(tabs):
                printDBG(
                    "=== TAB[%d]: '%s' -> %s ===" % (i, t["title"], t["ranking_id"])
                )
            return tabs
        except Exception as e:
            printDBG(
                "=== MovieBox _fetchRankingTabsFromPage EXCEPTION: %s ===" % str(e)
            )
            return []

    def listMostWatchedTabs(self, cItem):
        """Display Most Watched sub-categories dynamically from page"""
        printDBG("MovieBox.listMostWatchedTabs")
        tabs = self._fetchRankingTabsFromPage(
            "%s/ranking-list?utm_source=" % self.MAIN_URL
        )
        if not tabs:
            printDBG("MovieBox: Dynamic fetch failed, using static fallback")
            tabs = [
                {"title": "Popular", "ranking_id": "1232643093049001320"},
                {"title": "TOP100", "ranking_id": "6159907949583500480"},
                {"title": "Anime", "ranking_id": "62133389738001440"},
                {"title": "K-Drama", "ranking_id": "4380734070238626200"},
                {"title": "Black Drama", "ranking_id": "8505361996374835640"},
                {"title": "SA Drama", "ranking_id": "1503943377597910848"},
                {"title": "C-Drama", "ranking_id": "173752404280836544"},
                {"title": "Thai-Drama", "ranking_id": "1164329479448281992"},
                {"title": "New", "ranking_id": "2529702013798074864"},
                {"title": "Returnings", "ranking_id": "8109661952110199232"},
                {"title": "Action", "ranking_id": "6978603205429526968"},
                {"title": "Fantasy", "ranking_id": "7219449993227633120"},
                {"title": "Sci-Fi", "ranking_id": "4075118481979722960"},
                {"title": "Superhero", "ranking_id": "7317586330186645624"},
                {"title": "Romance", "ranking_id": "2389813900859556536"},
                {"title": "Comedy", "ranking_id": "8785384881686725944"},
                {"title": "Period", "ranking_id": "1826888755169346232"},
                {"title": "Teen Romance", "ranking_id": "1746633591129342248"},
                {"title": "Teen Fantasy", "ranking_id": "6934224112055632896"},
                {"title": "Cop Drama", "ranking_id": "8897504261530175160"},
                {"title": "Medical Drama", "ranking_id": "4162236365956153536"},
                {"title": "Animation", "ranking_id": "3130672938110833528"},
            ]
        else:
            printDBG("MovieBox: Using %d dynamic tabs" % len(tabs))
        for tab in tabs:
            p = dict(cItem)
            p.update(
                {
                    "category": "list_ranking_content",
                    "title": tab["title"],
                    "ranking_id": tab["ranking_id"],
                    "good_for_fav": True,
                }
            )
            self.addDir(p)
        printDBG("MovieBox: Added %d most watched tabs" % len(tabs))

    def listSeasons(self, cItem):
        printDBG("MovieBox.listSeasons [%s]" % cItem.get("title", ""))
        subjectId = cItem.get("subjectId", "")
        detailPath = cItem.get("detailPath", "")
        movieDesc = self._enrichDescWithStory(cItem)
        trailer_url = cItem.get("trailer_url", "")
        if not detailPath or not subjectId:
            self.listServers(cItem)
            return
        detail_url = "%s/moviesDetail/%s?id=%s&type=/movie/detail" % (
            self.MAIN_URL,
            detailPath,
            subjectId,
        )
        sts, html_data = self.getPage(detail_url)
        if not sts:
            self.listServers(cItem)
            return
        import json as json_mod

        nuxt_match = re.search(
            r'<script[^>]+id="__NUXT_DATA__"[^>]*>(\[[\s\S]*?)\s*</script>', html_data
        )
        found_seasons = False
        if nuxt_match:
            try:
                nuxt_arr = json_mod.loads(nuxt_match.group(1))

                def resolve_val(val):
                    if isinstance(val, int) and 0 <= val < len(nuxt_arr):
                        resolved = nuxt_arr[val]
                        if isinstance(resolved, (int, float, str, bool)):
                            return resolved
                        if isinstance(resolved, int) and 0 <= resolved < len(nuxt_arr):
                            second = nuxt_arr[resolved]
                            if isinstance(second, (int, float, str, bool)):
                                return second
                    return val

                for item in nuxt_arr:
                    if isinstance(item, dict):
                        if "seasons" in item:
                            seasons_ref = item["seasons"]
                            if isinstance(seasons_ref, int) and seasons_ref < len(
                                nuxt_arr
                            ):
                                seasons_list = nuxt_arr[seasons_ref]
                            elif isinstance(seasons_ref, list):
                                seasons_list = seasons_ref
                            else:
                                continue
                            if isinstance(seasons_list, list):
                                for season_item in seasons_list:
                                    if isinstance(
                                        season_item, int
                                    ) and season_item < len(nuxt_arr):
                                        season = nuxt_arr[season_item]
                                    elif isinstance(season_item, dict):
                                        season = season_item
                                    else:
                                        continue
                                    if isinstance(season, dict) and "se" in season:
                                        se = resolve_val(season.get("se", 1))
                                        maxEp = resolve_val(season.get("maxEp", 1))
                                        if not isinstance(se, int):
                                            try:
                                                se = int(se)
                                            except Exception:
                                                se = 1
                                        if not isinstance(maxEp, int):
                                            try:
                                                maxEp = int(maxEp)
                                            except Exception:
                                                maxEp = 1
                                        p = dict(cItem)
                                        p.update(
                                            {
                                                "category": "list_episodes",
                                                "title": "Season %d (%d episodes)"
                                                % (se, maxEp),
                                                "season": se,
                                                "maxEp": maxEp,
                                                "desc": movieDesc,
                                                "good_for_fav": False,
                                            }
                                        )
                                        self.addDir(p)
                                        found_seasons = True
                        if "videoAddress" in item and not trailer_url:
                            va = item["videoAddress"]
                            if isinstance(va, int) and va < len(nuxt_arr):
                                va = nuxt_arr[va]
                            if isinstance(va, dict):
                                url_val = va.get("url", "")
                                if isinstance(url_val, int) and url_val < len(nuxt_arr):
                                    url_val = nuxt_arr[url_val]
                                if isinstance(url_val, str) and url_val.startswith(
                                    "http"
                                ):
                                    trailer_url = url_val
                if found_seasons:
                    if trailer_url:
                        p = dict(cItem)
                        p.update(
                            {
                                "category": "list_servers",
                                "title": "%s🎬 Trailer-%s"
                                % (Y, cItem.get("title", "")),
                                "trailer_url": trailer_url,
                                "desc": movieDesc,
                                "good_for_fav": False,
                            }
                        )
                        self.addDir(p)
                    printDBG(
                        "MovieBox.listSeasons: Found seasons + trailer=%s"
                        % bool(trailer_url)
                    )
                    return
            except Exception as e:
                printDBG("MovieBox listSeasons NUXT error: %s" % str(e))
        self.listServers(cItem)

    def listEpisodes(self, cItem):
        printDBG("MovieBox.listEpisodes")
        season = cItem.get("season", 1)
        maxEp = cItem.get("maxEp", 1)
        movieDesc = cItem.get("desc", "")
        for ep in range(1, maxEp + 1):
            p = dict(cItem)
            p.update(
                {
                    "category": "list_servers",
                    "title": "Episode %d" % ep,
                    "episode": ep,
                    "season": season,
                    "desc": movieDesc,
                    "good_for_fav": False,
                }
            )
            self.addDir(p)

    def listFilterMovies(self, cItem):
        printDBG("MovieBox.listFilterMovies [%s]" % cItem.get("title", ""))
        page = cItem.get("page", 1)
        filter_query = cItem.get("filter_query", "")
        channelId = int(cItem.get("channelId", "1"))
        if not filter_query:
            return
        params = {}
        for part in filter_query.split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k] = v
        categoryType = params.get("categoryType", "")
        post_data = {
            "page": page,
            "perPage": 28,
            "channelId": channelId,
            "sort": "ForYou",
        }
        if categoryType:
            post_data["categoryType"] = categoryType
        sts, data = self.postAPIPage("/subject/filter", post_data)
        if sts and data.get("code") == 0:
            pager = data.get("data", {}).get("pager", {})
            items = data.get("data", {}).get("items", [])
            hasMore = pager.get("hasMore", False)
            for subj in items:
                self._addMovieFromSubject(cItem, subj)
            if hasMore:
                p = dict(cItem)
                p.update(
                    {
                        "good_for_fav": False,
                        "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                        "page": page + 1,
                    }
                )
                self.addDir(p)

    def _getCaptions(self, subjectId, detailPath, streamId):
        captions = []
        if not streamId or not subjectId:
            return captions
        try:
            sts, data = self.getAPIPage(
                "/subject/caption",
                {
                    "format": "MP4",
                    "id": streamId,
                    "subjectId": subjectId,
                    "detailPath": detailPath,
                },
                base_url=self.TAB_API,
            )
            if sts and data.get("code") == 0:
                for cap in data.get("data", {}).get("captions", []):
                    cap_url = cap.get("url", "")
                    lanName = cap.get("lanName", "")
                    lan = cap.get("lan", "")
                    if cap_url:
                        captions.append(
                            {"url": cap_url, "lang": lanName or lan, "lan": lan}
                        )
        except Exception as e:
            printDBG("MovieBox _getCaptions error: %s" % str(e))
        return captions

    def _downloadSubtitle(self, sub_url, video_title, lang_code):
        try:
            import os

            sub_dir = "/hdd/IPTVCache/Subtitles"
            if not os.path.exists(sub_dir):
                os.makedirs(sub_dir)
            safe_title = (
                re.sub(r"[^\w\s-]", "", video_title).strip().replace(" ", ".")[:60]
            )
            filepath = os.path.join(sub_dir, "%s.%s.srt" % (safe_title, lang_code))
            if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                return filepath
            from urllib.request import Request, urlopen

            req = Request(sub_url)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            )
            req.add_header("Referer", self.MAIN_URL + "/")
            response = urlopen(req, timeout=15)
            data = response.read()
            with open(filepath, "wb") as f:
                f.write(data)
            return filepath
        except Exception as e:
            printDBG("MovieBox _downloadSubtitle error: %s" % str(e))
            return ""

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("MovieBox.listSearchResult pattern[%s]" % searchPattern)
        if not searchPattern or not searchPattern.strip():
            self._listSearchSuggestions(cItem, "")
            return
        page = cItem.get("page", 1)
        subjectType = 1
        if searchType == "tv":
            subjectType = 2
        post_data = {
            "keyword": searchPattern,
            "page": page,
            "perPage": 28,
            "subjectType": subjectType,
        }
        sts, data = self.postAPIPage("/subject/search", post_data)
        if sts and data.get("code") == 0:
            pager = data.get("data", {}).get("pager", {})
            items = data.get("data", {}).get("items", [])
            hasMore = pager.get("hasMore", False)
            for subj in items:
                self._addMovieFromSubject(cItem, subj)
            if hasMore:
                p = dict(cItem)
                p.update(
                    {
                        "good_for_fav": False,
                        "title": "%s%s" % (Y, _("Next page ▶▶▶")),
                        "page": page + 1,
                    }
                )
                self.addDir(p)
            return
        self._listSearchSuggestions(cItem, searchPattern)

    def _listSearchSuggestions(self, cItem, keyword):
        printDBG("MovieBox._listSearchSuggestions keyword[%s]" % keyword)
        post_data = {"keyword": keyword, "perPage": 10}
        sts, data = self.postAPIPage("/subject/search-suggest", post_data)
        if sts and data.get("code") == 0:
            items = data.get("data", {}).get("items", [])
            for item in items:
                word = item.get("word", "").strip()
                if word:
                    p = dict(cItem)
                    p.update(
                        {
                            "category": "search_suggestion",
                            "title": word,
                            "search_keyword": word,
                            "good_for_fav": False,
                        }
                    )
                    self.addDir(p)

    def listServers(self, cItem):
        printDBG("MovieBox.listServers")
        movieDesc = self._enrichDescWithStory(cItem)
        movieTitle = cItem.get("title", "")
        subjectId = cItem.get("subjectId", "")
        detailPath = cItem.get("detailPath", "")
        linksTab = self.getLinksForVideo(cItem)
        for item in linksTab:
            params = dict(cItem)
            params.update(
                {
                    "title": item["name"],
                    "url": item["url"],
                    "type": "video",
                    "desc": movieDesc,
                }
            )
            self.addVideo(params)
        if linksTab and subjectId and detailPath:
            p = dict(cItem)
            p.update(
                {
                    "category": "list_subtitle_langs",
                    "title": "%s📥 %s" % (C, _("Download Subtitles")),
                    "movie_title": movieTitle,
                    "good_for_fav": False,
                }
            )
            self.addDir(p)
        trailer_url = cItem.get("trailer_url", "")
        if not trailer_url and detailPath and subjectId:
            detail_url = "%s/moviesDetail/%s?id=%s&type=/movie/detail" % (
                self.MAIN_URL,
                detailPath,
                subjectId,
            )
            sts, html_data = self.getPage(detail_url)
            if sts:
                meta_match = re.search(
                    r'<meta\s+name=["\']video["\'][^>]+content=["\']([^"\']+)["\']',
                    html_data,
                )
                if not meta_match:
                    meta_match = re.search(
                        r'<meta\s+property=["\']og:video:url["\'][^>]+content=["\']([^"\']+)["\']',
                        html_data,
                    )
                if meta_match:
                    trailer_url = meta_match.group(1)
        if trailer_url:
            params = dict(cItem)
            params.update(
                {
                    "title": "%s🎬 Trailer-%s" % (Y, movieTitle),
                    "type": "video",
                    "url": strwithmeta(
                        trailer_url,
                        {
                            "Referer": self.MAIN_URL + "/",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "desc": movieDesc,
                }
            )
            self.addVideo(params)
        if not linksTab and not trailer_url:
            params = dict(cItem)
            params.update(
                {
                    "title": "⏳ %s" % _("Not available yet"),
                    "type": "video",
                    "url": "",
                    "desc": movieDesc + "\n\n⚠️ This content is not yet available.",
                }
            )
            self.addVideo(params)

    def listSubtitleLangs(self, cItem):
        printDBG("MovieBox.listSubtitleLangs [%s]" % cItem.get("title", ""))
        subjectId = cItem.get("subjectId", "")
        detailPath = cItem.get("detailPath", "")
        movieTitle = cItem.get("movie_title", cItem.get("title", ""))
        if not subjectId or not detailPath:
            return
        stream_id = ""
        bearer = self.getBearerToken()
        referer = (
            "%s/movies/%s?id=%s&type=/movie/detail&detailSe=&detailEp=&lang=en"
            % (self.MAIN_URL, detailPath, subjectId)
        )
        cookie_str = ""
        play_url = "%s/subject/play?subjectId=%s&se=0&ep=0&detailPath=%s" % (
            self.TAB_API,
            subjectId,
            detailPath,
        )
        try:
            from urllib.request import Request, urlopen

            req = Request(play_url)
            req.add_header("Referer", referer)
            req.add_header("Accept", "application/json")
            req.add_header("Accept-Encoding", "identity")
            req.add_header("Authorization", "Bearer %s" % bearer)
            req.add_header("x-request-lang", "en")
            req.add_header("Origin", self.MAIN_URL)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
            )
            cookie_str = ""
            try:
                with open(self.COOKIE_FILE, "r") as f:
                    lines = f.readlines()
                parts = []
                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    cols = line.split("\t")
                    if len(cols) >= 7:
                        parts.append("%s=%s" % (cols[5], cols[6]))
                cookie_str = "; ".join(parts)
            except Exception:
                pass
            if cookie_str:
                req.add_header("Cookie", cookie_str)
            response = urlopen(req, timeout=30)
            jsonData = json_loads(response.read().decode("utf-8"))
            if jsonData.get("code") == 0:
                streams = jsonData.get("data", {}).get("streams", [])
                if streams:
                    stream_id = streams[0].get("id", "")
                    printDBG(
                        "MovieBox: Got stream_id=%s from /subject/play" % stream_id
                    )
        except Exception as e:
            printDBG("MovieBox listSubtitleLangs play error: %s" % str(e))
        if not stream_id:
            play_url = "%s/subject/play?subjectId=%s&se=1&ep=1&detailPath=%s" % (
                self.TAB_API,
                subjectId,
                detailPath,
            )
            try:
                from urllib.request import Request, urlopen

                req = Request(play_url)
                req.add_header("Referer", referer)
                req.add_header("Accept", "application/json")
                req.add_header("Accept-Encoding", "identity")
                req.add_header("Authorization", "Bearer %s" % bearer)
                req.add_header("x-request-lang", "en")
                req.add_header("Origin", self.MAIN_URL)
                req.add_header(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
                )
                if cookie_str:
                    req.add_header("Cookie", cookie_str)
                response = urlopen(req, timeout=30)
                jsonData = json_loads(response.read().decode("utf-8"))
                if jsonData.get("code") == 0:
                    streams = jsonData.get("data", {}).get("streams", [])
                    if streams:
                        stream_id = streams[0].get("id", "")
                        printDBG(
                            "MovieBox: Got stream_id=%s from /subject/play (se=1)"
                            % stream_id
                        )
            except Exception as e:
                printDBG("MovieBox listSubtitleLangs play2 error: %s" % str(e))
        if not stream_id:
            printDBG("MovieBox: No stream_id found, cannot fetch captions")
            self.addMarker(
                {"title": "%s✗ %s" % (Y, _("No stream ID found")), "desc": ""}
            )
            return
        captions = self._getCaptions(subjectId, detailPath, stream_id)
        if not captions:
            printDBG("MovieBox: No captions available for this title")
            self.addMarker(
                {"title": "%s✗ %s" % (Y, _("No subtitles available")), "desc": ""}
            )
            return
        LANG_DISPLAY_MAP = {
            "bn": "Bengali",  #  বাংলা
            "pa": "Punjabi",  # ਪੰਜਾਬੀ
            "hi": "Hindi",  # हिन्दी
            "km": "Khmer",  # ខេមរភាសា
        }
        for cap in captions:
            lan_code = cap.get("lan", "")
            raw_name = cap.get("lang", "") or cap.get("lanName", "")
            display_name = LANG_DISPLAY_MAP.get(lan_code, "")
            if not display_name:
                display_name = raw_name if raw_name else lan_code.upper()
            p = dict(cItem)
            p.update(
                {
                    "category": "download_subtitle",
                    "title": display_name,
                    "subtitle_url": cap["url"],
                    "subtitle_lan": lan_code,
                    "movie_title": movieTitle,
                    "good_for_fav": False,
                }
            )
            printDBG("Displaying Language: [%s] Code: [%s]" % (display_name, lan_code))
            self.addDir(p)
        printDBG("MovieBox: Listed %d subtitle languages" % len(captions))

    def downloadSubtitle(self, cItem):
        printDBG("MovieBox.downloadSubtitle")
        sub_url = cItem.get("subtitle_url", "")
        lan = cItem.get("subtitle_lan", "")
        movieTitle = cItem.get("movie_title", "")
        if not sub_url or not movieTitle:
            return
        filepath = self._downloadSubtitle(sub_url, movieTitle, lan)
        if filepath:
            from Screens.MessageBox import MessageBox

            self.sessionEx.open(
                MessageBox,
                "Subtitle downloaded successfully!\n\nFile: %s" % filepath,
                MessageBox.TYPE_INFO,
                timeout=10,
            )
        else:
            from Screens.MessageBox import MessageBox

            self.sessionEx.open(
                MessageBox,
                "Failed to download subtitle.",
                MessageBox.TYPE_ERROR,
                timeout=5,
            )
        self.listSubtitleLangs(cItem)

    def _makePlayRequest(self, url):
        bearer = self.getBearerToken()
        if not bearer:
            return {}
        try:
            from urllib.request import Request, urlopen

            req = Request(url)
            req.add_header("Referer", self.MAIN_URL + "/")
            req.add_header("Accept", "application/json")
            req.add_header("Accept-Encoding", "identity")
            req.add_header("Authorization", "Bearer %s" % bearer)
            req.add_header("x-request-lang", "en")
            req.add_header("Origin", self.MAIN_URL)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
            )
            cookie_str = ""
            try:
                with open(self.COOKIE_FILE, "r") as f:
                    lines = f.readlines()
                parts = []
                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    cols = line.split("\t")
                    if len(cols) >= 7:
                        parts.append("%s=%s" % (cols[5], cols[6]))
                cookie_str = "; ".join(parts)
            except Exception:
                pass
            if cookie_str:
                req.add_header("Cookie", cookie_str)
            response = urlopen(req, timeout=30)
            raw_data = response.read().decode("utf-8")
            return json_loads(raw_data)
        except Exception as e:
            printDBG("MovieBox _makePlayRequest error: %s" % str(e))
            return {}

    def getLinksForVideo(self, cItem):
        printDBG("MovieBox.getLinksForVideo [%s]" % cItem.get("title", ""))
        urlTab = []
        movieTitle = cItem.get("title", "").strip()
        currUrl = cItem.get("url", "")
        if currUrl:
            url_str = currUrl
            if hasattr(currUrl, "meta"):
                url_str = currUrl.meta.get("url", "") or str(currUrl)
            if isinstance(url_str, str) and (
                ".m3u8" in url_str
                or ".mp4" in url_str
                or "play.sportsteam" in url_str
                or "embed.st" in url_str
                or "aisports.mobi" in url_str
                or cItem.get("is_live_match")
            ):
                printDBG("MovieBox.getLinksForVideo: Returning direct URL")
                urlTab.append(
                    {
                        "name": movieTitle if movieTitle else "stream",
                        "url": currUrl,
                        "need_resolve": 0,
                    }
                )
                return urlTab
        if currUrl and (
            "bcdnxw." in currUrl or "playstream.mpd" in currUrl or ".mp4" in currUrl
        ):
            name = "%s - direct" % movieTitle if movieTitle else "direct"
            urlTab.append({"name": name, "url": currUrl})
            return urlTab
        subjectId = cItem.get("subjectId", "")
        detailPath = cItem.get("detailPath", "")
        if not subjectId:
            url = cItem.get("url", "")
            idMatch = re.search(r"[?&]id=(\d+)", url)
            if idMatch:
                subjectId = idMatch.group(1)
        if not subjectId:
            return []
        referer = (
            "%s/movies/%s?id=%s&type=/movie/detail&detailSe=&detailEp=&lang=en"
            % (self.MAIN_URL, detailPath, subjectId)
        )
        bearer = self.getBearerToken()
        playData = None
        for se, ep in [("0", "0"), ("1", "1")]:
            if playData:
                break
            play_url = "%s/subject/play?subjectId=%s&se=%s&ep=%s&detailPath=%s" % (
                self.TAB_API,
                subjectId,
                se,
                ep,
                detailPath,
            )
            try:
                from urllib.request import Request, urlopen

                req = Request(play_url)
                req.add_header("Referer", referer)
                req.add_header("Accept", "application/json")
                req.add_header("Accept-Encoding", "identity")
                req.add_header("Authorization", "Bearer %s" % bearer)
                req.add_header("x-request-lang", "en")
                req.add_header("Origin", self.MAIN_URL)
                req.add_header(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
                )
                cookie_str = ""
                try:
                    with open(self.COOKIE_FILE, "r") as f:
                        lines = f.readlines()
                    parts = []
                    for line in lines:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        cols = line.split("\t")
                        if len(cols) >= 7:
                            parts.append("%s=%s" % (cols[5], cols[6]))
                    cookie_str = "; ".join(parts)
                except Exception:
                    pass
                if cookie_str:
                    req.add_header("Cookie", cookie_str)
                response = urlopen(req, timeout=30)
                jsonData = json_loads(response.read().decode("utf-8"))
                if jsonData.get("code") == 0:
                    pd = jsonData.get("data", {})
                    if pd.get("streams") or pd.get("dash"):
                        playData = pd
            except Exception as e:
                printDBG("MovieBox play error (se=%s): %s" % (se, str(e)))
        if not playData:
            return urlTab
        for stream in playData.get("streams", []):
            res = stream.get("resolutions", "?")
            fmt = stream.get("format", "MP4")
            size_mb = int(stream.get("size", 0)) // (1024 * 1024)
            codec = stream.get("codecName", "")
            if movieTitle:
                name = "%s - %sp %s (%dMB) [%s]" % (
                    movieTitle,
                    res,
                    fmt,
                    size_mb,
                    codec,
                )
            else:
                name = "%sp %s (%dMB) [%s]" % (res, fmt, size_mb, codec)
            urlTab.append(
                {
                    "name": name,
                    "url": strwithmeta(
                        stream["url"],
                        {
                            "Referer": referer,
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "need_resolve": 0,
                }
            )
        for dash in playData.get("dash", []):
            res = dash.get("resolutions", "?")
            size_mb = int(dash.get("size", 0)) // (1024 * 1024)
            codec = dash.get("codecName", "hevc")
            if movieTitle:
                name = "%s - %sp DASH (%dMB) [%s]" % (movieTitle, res, size_mb, codec)
            else:
                name = "%sp DASH (%dMB) [%s]" % (res, size_mb, codec)
            urlTab.append(
                {
                    "name": name,
                    "url": strwithmeta(
                        dash["url"],
                        {
                            "Referer": referer,
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "need_resolve": 0,
                }
            )
        urlTab.sort(
            key=lambda x: (
                int(re.search(r"(\d+)p", x["name"]).group(1))
                if re.search(r"(\d+)p", x["name"])
                else 0
            )
        )
        printDBG("MovieBox.getLinksForVideo: Found %d links" % len(urlTab))
        return urlTab

    def listFootballLive(self, cItem):
        """قسم Football Live - أيام الماتشات"""
        printDBG("MovieBox.listFootballLive")
        import time as time_mod

        now = time_mod.time()
        today_start = int(now // 86400 * 86400)
        day_names = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
        p = dict(cItem)
        p.update(
            {
                "category": "list_football_live_past",
                "title": "%s◀◀ %s (Previous Days)" % (OR, _("Previous Days")),
                "past_offset": 1,
                "good_for_fav": False,
            }
        )
        self.addDir(p)
        for offset in range(0, 7):
            day_ts = today_start + offset * 86400
            lt = time_mod.localtime(day_ts)
            day_name = day_names[lt.tm_wday]
            date_str = time_mod.strftime("%d/%m", lt)
            if offset == 0:
                label = "%s📅 TODAY - %s %s" % (C, day_name, date_str)
            elif offset == 1:
                label = "%s📅 TOMORROW - %s %s" % (Y, day_name, date_str)
            else:
                label = "%s📅 %s %s" % (W, day_name, date_str)
            p = dict(cItem)
            p.update(
                {
                    "category": "list_football_live_day",
                    "title": label,
                    "day_start_ts": day_ts,
                    "good_for_fav": False,
                }
            )
            self.addDir(p)

    def listFootballLivePast(self, cItem):
        printDBG("MovieBox.listFootballLivePast")
        import time as time_mod

        now = time_mod.time()
        today_start = int(now // 86400 * 86400)
        day_names = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]
        offset = cItem.get("past_offset", 1)
        start_offset = offset
        end_offset = offset + 7
        for i in range(start_offset, end_offset):
            day_ts = today_start - i * 86400
            lt = time_mod.localtime(day_ts)
            day_name = day_names[lt.tm_wday]
            date_str = time_mod.strftime("%d/%m", lt)
            if i == 1:
                label = "%s📅 YESTERDAY - %s %s" % (W, day_name, date_str)
            else:
                label = "%s📅 %s %s (-%d)" % (W, day_name, date_str, i)
            p = dict(cItem)
            p.update(
                {
                    "category": "list_football_live_day",
                    "title": label,
                    "day_start_ts": day_ts,
                    "good_for_fav": False,
                }
            )
            self.addDir(p)
        p = dict(cItem)
        p.update(
            {
                "category": "list_football_live_past",
                "title": "%s%s ▶▶▶" % (Y, _("Older Days")),
                "past_offset": offset + 7,
                "good_for_fav": False,
            }
        )
        self.addDir(p)

    def listFootballLiveDay(self, cItem):
        printDBG("MovieBox.listFootballLiveDay")
        day_start = cItem.get("day_start_ts", 0)
        if not day_start:
            return
        start_ms = day_start * 1000
        end_ms = start_ms + 86400000 - 1
        url = (
            "https://h5-sport-api.aoneroom.com/wefeed-h5api-bff/live/match-list-v3"
            "?status=0&matchType=football&startTime=%d&endTime=%d" % (start_ms, end_ms)
        )
        try:
            from urllib.request import Request, urlopen

            req = Request(url)
            req.add_header("Referer", "https://www.sportslive.wine/")
            req.add_header("Accept", "application/json")
            req.add_header("Accept-Encoding", "identity")
            req.add_header("Origin", "https://www.sportslive.wine")
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
            )
            req.add_header("X-Device-Info", "{}")
            response = urlopen(req, timeout=30)
            data = json_loads(response.read().decode("utf-8"))
        except Exception as e:
            printDBG("MovieBox.listFootballLiveDay error: %s" % str(e))
            self.addMarker({"title": "%s✗ %s" % (OR, _("Failed")), "desc": ""})
            return
        if data.get("code") != 0:
            return
        leagues = data.get("data", {}).get("list", [])
        total = 0
        for league_group in leagues:
            league_name = league_group.get("league", "")
            match_list = league_group.get("matchList", [])
            if not match_list:
                continue
            if league_name:
                self.addMarker(
                    {
                        "title": "%s🏆 %s (%d)" % (Y, league_name, len(match_list)),
                        "desc": "",
                        "good_for_fav": False,
                    }
                )
            for m in match_list:
                self._addFootballMatch(cItem, m)
                total += 1
        printDBG("MovieBox.listFootballLiveDay: Added %d matches" % total)

    def _getSportToken(self):
        """جلب token من sportslive.wine"""
        try:
            from urllib.request import Request, urlopen

            req = Request("https://www.sportslive.wine/live?sportType=football")
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            )
            req.add_header("Accept", "text/html")
            response = urlopen(req, timeout=15)
            cookies = response.headers.get_all("Set-Cookie") or []
            for c in cookies:
                if "token=" in c:
                    token = c.split("token=")[1].split(";")[0]
                    printDBG("MovieBox: Got sport token: %s..." % token[:50])
                    return token
        except Exception as e:
            printDBG("MovieBox _getSportToken error: %s" % str(e))
        return ""

    def _addFootballMatch(self, cItem, m):
        """إضافة ماتش للقائمة مع وصف نظيف غير مكرر"""
        try:
            team1 = m.get("team1", {})
            team2 = m.get("team2", {})
            name1 = team1.get("name", "?")
            name2 = team2.get("name", "?")
            score1 = team1.get("score", "0")
            score2 = team2.get("score", "0")
            avatar1 = team1.get("avatar", "")
            league = m.get("leagueName") or m.get("league")
            if not league and isinstance(m.get("leagueItem"), dict):
                league = m.get("leagueItem", {}).get("name", "")
            match_round = m.get("matchRound", "")
            status = m.get("status", "")
            statusLive = m.get("statusLive", "")
            playPath = m.get("playPath", "")
            playSource = m.get("playSource", [])
            start_time = m.get("startTime", "")
            match_id = m.get("id", "")
            if status in ["MatchIng", "1", 1] or statusLive == "LIVE":
                status_icon = "%s🔴 " % C
                status_text = "LIVE"
            elif status in ["MatchEnded", "2", 2, "FT"]:
                status_icon = "%s✓ " % L
                status_text = "Full Time"
            else:
                status_icon = "%s⏰ " % Y
                status_text = "Upcoming"
            time_str = ""
            date_str = ""
            if start_time:
                try:
                    import time as time_mod

                    ts = int(start_time) / 1000
                    lt = time_mod.localtime(ts)
                    time_str = time_mod.strftime("%H:%M", lt)
                    date_str = time_mod.strftime("%d/%m", lt)
                except Exception:
                    pass
            if status_text in ["LIVE", "Full Time"]:
                title = "%s%s %s - %s %s" % (status_icon, name1, score1, score2, name2)
            else:
                title = "%s%s vs %s" % (status_icon, name1, name2)
            desc_parts = []
            if league:
                desc_parts.append("%s%s" % (Y, league))
            if match_round:
                desc_parts.append(str(match_round))
            if date_str:
                desc_parts.append(date_str)
            if time_str:
                desc_parts.append(time_str)
            desc_parts.append(status_text)
            new_desc = " | ".join(desc_parts)
            icon_url = self.getFullIconUrl(avatar1) if avatar1 else ""
            params = {
                "category": "list_football_live_streams",
                "title": title,
                "desc": new_desc,
                "icon": icon_url,
                "match_id": str(match_id),
                "match_play_path": playPath,
                "match_play_source": playSource,
                "match_replay": m.get("replay", []),
                "match_highlights": m.get("highlights", []),
                "match_cuts": m.get("cuts", []),
                "match_team1": name1,
                "match_team2": name2,
                "match_league": league,
                "match_status": status_text,
                "good_for_fav": False,
            }
            self.addDir(params)
        except Exception as e:
            printDBG("MovieBox _addFootballMatch error: %s" % str(e))

    def listFootballLiveStreams(self, cItem):
        printDBG("MovieBox.listFootballLiveStreams [%s]" % cItem.get("title", ""))
        play_path = cItem.get("match_play_path", "")
        play_source = cItem.get("match_play_source", [])
        replay = cItem.get("match_replay", [])
        highlights = cItem.get("match_highlights", [])
        cuts = cItem.get("match_cuts", [])
        status = cItem.get("match_status", "")
        added = 0
        if play_path and play_path.startswith("http"):
            params = dict(cItem)
            params.update(
                {
                    "title": "%s🔴 Live - Main" % C,
                    "url": strwithmeta(
                        play_path,
                        {
                            "Referer": "https://www.sportslive.wine/",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "type": "video",
                    "need_resolve": 0,
                }
            )
            self.addVideo(params)
            added += 1
        for src in play_source:
            src_title = src.get("title", "Channel")
            src_path = src.get("path", "")
            if not src_path or not src_path.startswith("http"):
                continue
            if "play.88player.top/m3u8.html" in src_path:
                from urllib.parse import urlparse, parse_qs, unquote

                parsed = urlparse(src_path)
                qs = parse_qs(parsed.query)
                real_url = qs.get("url", [""])[0]
                if real_url:
                    real_url = unquote(real_url)
                    params = dict(cItem)
                    params.update(
                        {
                            "title": "%s📺 %s" % (C, src_title),
                            "url": strwithmeta(
                                real_url,
                                {
                                    "Referer": "https://play.88player.top/",
                                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                                },
                            ),
                            "type": "video",
                            "need_resolve": 0,
                        }
                    )
                    self.addVideo(params)
                    added += 1
                    continue
            if ".m3u8" in src_path or "playlist" in src_path:
                params = dict(cItem)
                params.update(
                    {
                        "title": "%s📺 %s" % (C, src_title),
                        "url": strwithmeta(
                            src_path,
                            {
                                "Referer": "https://www.sportslive.wine/",
                                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                            },
                        ),
                        "type": "video",
                        "need_resolve": 0,
                    }
                )
                self.addVideo(params)
                added += 1
                continue
            extracted = self._extractStreamFromPage(src_path)
            if extracted and (".m3u8" in extracted or ".mp4" in extracted):
                params = dict(cItem)
                params.update(
                    {
                        "title": "%s📺 %s" % (C, src_title),
                        "url": strwithmeta(
                            extracted,
                            {
                                "Referer": src_path,
                                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                            },
                        ),
                        "type": "video",
                        "need_resolve": 0,
                    }
                )
                self.addVideo(params)
                added += 1
            else:
                params = dict(cItem)
                params.update(
                    {
                        "title": "%s📺 %s (iframe)" % (C, src_title),
                        "url": src_path,
                        "type": "video",
                        "need_resolve": 0,
                    }
                )
                self.addVideo(params)
                added += 1
        for rep in replay:
            rep_title = rep.get("title", "Replay")
            rep_path = rep.get("path", "")
            rep_dur = rep.get("duration", "0")
            if not rep_path:
                continue
            try:
                dur_min = int(rep_dur) // 60
            except Exception:
                dur_min = 0
            params = dict(cItem)
            params.update(
                {
                    "title": "%s▶ %s (%dmin)" % (Y, rep_title, dur_min),
                    "url": strwithmeta(
                        rep_path,
                        {
                            "Referer": "https://www.sportslive.wine/",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "type": "video",
                    "need_resolve": 0,
                    "icon": (
                        rep.get("cover", {}).get("url", "")
                        if isinstance(rep.get("cover"), dict)
                        else ""
                    ),
                }
            )
            self.addVideo(params)
            added += 1
        for hl in highlights:
            hl_title = hl.get("title", "Highlights")
            hl_path = hl.get("path", "")
            hl_dur = hl.get("duration", "0")
            if not hl_path:
                continue
            try:
                dur_min = int(hl_dur) // 60
            except Exception:
                dur_min = 0
            params = dict(cItem)
            params.update(
                {
                    "title": "%s✨ %s (%dmin)" % (L, hl_title, dur_min),
                    "url": strwithmeta(
                        hl_path,
                        {
                            "Referer": "https://www.sportslive.wine/",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "type": "video",
                    "need_resolve": 0,
                    "icon": (
                        hl.get("cover", {}).get("url", "")
                        if isinstance(hl.get("cover"), dict)
                        else ""
                    ),
                }
            )
            self.addVideo(params)
            added += 1
        if cuts:
            self.addMarker(
                {
                    "title": "%s🎬 %s (%d)" % (Y, _("Match Cuts"), len(cuts)),
                    "desc": "",
                    "good_for_fav": False,
                }
            )
        for cut in cuts:
            cut_title = cut.get("title", "Cut")
            cut_path = cut.get("path", "")
            cut_dur = cut.get("duration", "0")
            if not cut_path:
                continue
            try:
                dur_sec = int(cut_dur)
            except Exception:
                dur_sec = 0
            params = dict(cItem)
            params.update(
                {
                    "title": "%s🎬 %s (%ds)" % (W, cut_title, dur_sec),
                    "url": strwithmeta(
                        cut_path,
                        {
                            "Referer": "https://www.sportslive.wine/",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        },
                    ),
                    "type": "video",
                    "need_resolve": 0,
                    "icon": (
                        cut.get("cover", {}).get("url", "")
                        if isinstance(cut.get("cover"), dict)
                        else ""
                    ),
                }
            )
            self.addVideo(params)
            added += 1
        if added == 0:
            if status == "MatchNotStart":
                self.addMarker(
                    {"title": "%s⏰ %s" % (Y, _("Match not started yet")), "desc": ""}
                )
            else:
                self.addMarker(
                    {"title": "%s✗ %s" % (OR, _("No stream available")), "desc": ""}
                )
        printDBG("MovieBox.listFootballLiveStreams: Added %d streams" % added)

    def _extractStreamFromPage(self, url):
        try:
            from urllib.request import Request, urlopen

            req = Request(url)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            )
            req.add_header("Referer", "https://www.sportslive.wine/")
            response = urlopen(req, timeout=15)
            html = response.read().decode("utf-8", errors="ignore")
            m = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', html)
            if m:
                return m.group(1)
            m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html)
            if m:
                inner = m.group(1)
                if inner.startswith("//"):
                    inner = "https:" + inner
                elif inner.startswith("/"):
                    from urllib.parse import urlparse

                    p = urlparse(url)
                    inner = "%s://%s%s" % (p.scheme, p.netloc, inner)
                return inner
        except Exception as e:
            printDBG("MovieBox _extractStreamFromPage error: %s" % str(e))
        return ""

    def handleService(self, index, refresh=0, searchPattern="", searchType=""):
        printDBG("handleService start")
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", "")
        category = self.currItem.get("category", "")
        printDBG("handleService: name[%s], category[%s]" % (name, category))
        self.currList = []
        if name is None:
            self.listsTab(self.MAIN_CAT_TAB, {"name": "category"})
        elif category == "list_sections":
            self.listSections(self.currItem)
        elif category == "list_section_movies_api":
            self.listSectionMoviesAPI(self.currItem)
        elif category == "list_filter_movies":
            self.listFilterMovies(self.currItem)
        elif category == "list_servers":
            self.listServers(self.currItem)
        elif category == "list_subtitle_langs":
            self.listSubtitleLangs(self.currItem)
        elif category == "download_subtitle":
            self.downloadSubtitle(self.currItem)
        elif category == "list_filter_page":
            self.listFilterPage(self.currItem)
        elif category == "list_filter_page_select":
            self.listFilterPageSelect(self.currItem)
        elif category == "list_ranking_content":
            self.listRankingContent(self.currItem)
        elif category == "list_upcoming_tabs":
            self.listUpcomingTabs(self.currItem)
        elif category == "list_upcoming":
            self.listUpcoming(self.currItem)
        elif category == "list_most_watched_tabs":
            self.listMostWatchedTabs(self.currItem)
        elif category == "list_seasons":
            self.listSeasons(self.currItem)
        elif category == "list_episodes":
            self.listEpisodes(self.currItem)
        elif category == "list_section_banner":
            self.listSectionBanner(self.currItem)
        elif category == "list_section_playlist":
            self.listSectionPlaylist(self.currItem)
        elif category == "list_football_live":
            self.listFootballLive(self.currItem)
        elif category == "list_football_live_streams":
            self.listFootballLiveStreams(self.currItem)
        elif category == "list_football_live_past":
            self.listFootballLivePast(self.currItem)
        elif category == "list_football_live_day":
            self.listFootballLiveDay(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({"search_item": False, "name": "category"})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory(
                {"name": "history", "category": "search"}, "desc", _("Type: ")
            )
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, MovieBox(), True, [])
