# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
###################################################
#  TorrentYTS Host for E2iPlayer (YTS + TorrServer)
#  Compatible with Python 2.7 / 3.x
#  Last modified: 29/10/2025 - popking (odem2014)
#  Last Update: 04/06/2026 - angel-heart (Mohamed Elsafty)
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts, E2ColoR
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
from Plugins.Extensions.IPTVPlayer.p2p3.UrlParse import urljoin
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
from Components.config import config, ConfigSubsection, ConfigText
import re
import time
import base64
import os
import subprocess
import socket
config.plugins.iptvplayer.torserver = ConfigSubsection()
config.plugins.iptvplayer.torserver_ip = ConfigText(default="127.0.0.1", fixed_size=False)
config.plugins.iptvplayer.torserver_port = ConfigText(default="8090", fixed_size=False)
config.plugins.iptvplayer.torserver_api = ConfigText(default="", fixed_size=False)  # Changed default to empty
config.plugins.iptvplayer.torserver_path = ConfigText(default="/media/hdd/TorrServer", fixed_size=False)
config.plugins.iptvplayer.torserver_config = ConfigText(default="/media/hdd/config", fixed_size=False)
def GetConfigList():
    """Show TorServer config in E2iPlayer settings."""
    from Components.config import getConfigListEntry
    optionList = []
    optionList.append(getConfigListEntry(_("TorServer IP (default 127.0.0.1)"), config.plugins.iptvplayer.torserver_ip))
    optionList.append(getConfigListEntry(_("TorServer Port (default 8090)"), config.plugins.iptvplayer.torserver_port))
    optionList.append(getConfigListEntry(_("TorServer API path (usually empty)"), config.plugins.iptvplayer.torserver_api))  # Updated description
    optionList.append(getConfigListEntry(_("TorServer Binary Path"), config.plugins.iptvplayer.torserver_path))
    optionList.append(getConfigListEntry(_("TorServer Config Path"), config.plugins.iptvplayer.torserver_config))
    return optionList
def gettytul():
    return 'https://en.ytstv.bz'  # main url of host
class TorrentYTSHost(CBaseHostClass):
    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'yts.torrent', 'cookie': 'yts.cookie'})
        self.MAIN_URL = 'https://en.ytstv.bz'
        self.SEARCH_URL = self.MAIN_URL + '/movies?keyword='
        self.TORSERVER_PORT = 8090
        self.TORSERVER_IP = "127.0.0.1"
        self.TORSERVER_PATH = "/media/hdd/TorrServer"
        self.TORSERVER_CONFIG = "/media/hdd/config"
        self.DEFAULT_ICON_URL = 'https://raw.githubusercontent.com/popking159/mye2iplayer/refs/heads/main/torrentyts.jpg'
        self.updateTorServerUrl()
        self.defaultParams = {
            'header': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'Accept-Language': 'en,ar;q=0.9',
                'Accept-Encoding': 'gzip, deflate',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Upgrade-Insecure-Requests': '1',
                'Referer': 'https://en.ytstv.bz/',
                'Origin': 'https://en.ytstv.bz',
                'Connection': 'keep-alive',
            },
            'use_cookie': True,
            'load_cookie': True,
            'save_cookie': True,
            'cookiefile': self.COOKIE_FILE
        }
    def updateTorServerUrl(self):
        ip = config.plugins.iptvplayer.torserver_ip.value.strip()
        port = config.plugins.iptvplayer.torserver_port.value.strip()
        api = config.plugins.iptvplayer.torserver_api.value.strip()
        if api:
            self.TORSERVER_BASE = 'http://%s:%s/%s' % (ip, port, api.rstrip('/'))
        else:
            self.TORSERVER_BASE = 'http://%s:%s' % (ip, port)
        printDBG("TorServer base URL: %s" % self.TORSERVER_BASE)
    def isPortOpen(self, host, port, timeout=1.0):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            return result == 0
        except Exception as e:
            printDBG("isPortOpen error: %s" % str(e))
            return False
    def ensureTorServerRunning(self):
        """
        Ensure TorrServer is running and listening.
        If already running, restart cleanly.
        """
        port = int(config.plugins.iptvplayer.torserver_port.value.strip() or "8090")
        ip = config.plugins.iptvplayer.torserver_ip.value.strip() or "127.0.0.1"
        binary = config.plugins.iptvplayer.torserver_path.value.strip()
        config_path = config.plugins.iptvplayer.torserver_config.value.strip()
        if config_path and not os.path.exists(config_path):
            printDBG("Config directory does not exist, creating: %s" % config_path)
            try:
                os.makedirs(config_path, mode=0o755)  # Create directory with read/write/execute permissions for owner, read/execute for group/others
                printDBG("Successfully created config directory: %s" % config_path)
            except Exception as e:
                printDBG("Failed to create config directory %s: %s" % (config_path, str(e)))
        running = self.isPortOpen(ip, port)
        if running:
            printDBG("TorServer already running at %s:%s — restarting..." % (ip, port))
            try:
                shutdown_url = "http://%s:%s/shutdown" % (ip, port)
                self.cm.getPage(shutdown_url)
                time.sleep(2)
            except Exception as e:
                printDBG("Failed to shutdown old instance: %s" % e)
        try:
            if binary and os.path.exists(binary):
                cmd = "%s -path %s -port %d > /dev/null 2>&1 &" % (binary, config_path, port)
                printDBG("Starting TorServer binary: %s" % cmd)
                os.system(cmd)
                time.sleep(4)
            else:
                printDBG("TorServer binary not found at: %s" % binary)
                return False
        except Exception as e:
            printDBG("Failed to start TorServer: %s" % e)
            return False
        running = self.isPortOpen(ip, port, timeout=3.0)
        if running:
            printDBG("TorServer started successfully on %s:%d" % (ip, port))
        else:
            printDBG("TorServer failed to start on %s:%d" % (ip, port))
        return running
    def getPage(self, url, params=None, post_data=None):
        if params is None:
            params = dict(self.defaultParams)
        params['cloudflare_params'] = {
            'cookie_file': self.COOKIE_FILE,
            'User-Agent': params['header']['User-Agent']
        }
        return self.cm.getPageCFProtection(url, params, post_data)
    def listMainMenu(self, cItem):
        printDBG('TorrentYTSHost.listMainMenu')
        MAIN_CAT_TAB = [
            {'category': 'movies_root', 'title': _('🎬 Movies'), 'icon': self.DEFAULT_ICON_URL, 'desc': _('Movies categories and collections')},
            {'category': 'tv_root', 'title': _('📺 TV Shows'), 'icon': self.DEFAULT_ICON_URL, 'desc': _('TV Series and Shows categories')},
        ] + self.searchItems()
        self.listsTab(MAIN_CAT_TAB, cItem)
    def listMoviesRoot(self, cItem):
        printDBG('TorrentYTSHost.listMoviesRoot')
        cats = [
            {'category': 'list_movies', 'title': _('🔥 Popular'), '_api_params': {'mode': 'movie', 'api': 'popular', 'sort': 'popularity.desc'}},
            {'category': 'list_movies', 'title': _('⭐ Top Rated'), '_api_params': {'mode': 'movie', 'api': 'top_rated', 'sort': 'vote_average.desc'}},
            {'category': 'list_movies', 'title': _('🎬 Now Playing'), '_api_params': {'mode': 'movie', 'api': 'now_playing', 'sort': 'primary_release_date.desc'}},
            {'category': 'list_movies', 'title': _('📅 Upcoming'), '_api_params': {'mode': 'movie', 'api': 'upcoming', 'sort': 'primary_release_date.desc'}},
            {'category': 'sub_menu', 'title': _('📈 Trending'), 'sub_type': 'trending_movie'},
            {'category': 'sub_menu', 'title': _('🎭 Genres'), 'sub_type': 'genres_movie'},
            {'category': 'sub_menu', 'title': _('📺 Streaming Services'), 'sub_type': 'streaming_movie'},
            {'category': 'sub_menu', 'title': _('🌍 Countries'), 'sub_type': 'countries_movie'},
            {'category': 'sub_menu', 'title': _('🏢 Studios'), 'sub_type': 'studios_movie'},
            {'category': 'sub_menu', 'title': _('📦 Collections'), 'sub_type': 'collections_movie'},
            {'category': 'sub_menu', 'title': _('🏆 Best Of'), 'sub_type': 'best_movie'},
        ]
        self.listsTab(cats, cItem)
    def listTvRoot(self, cItem):
        printDBG('TorrentYTSHost.listTvRoot')
        cats = [
            {'category': 'list_movies', 'title': _('🔥 Popular'), '_api_params': {'mode': 'tv', 'api': 'popular', 'sort': 'popularity.desc'}},
            {'category': 'list_movies', 'title': _('⭐ Top Rated'), '_api_params': {'mode': 'tv', 'api': 'top_rated', 'sort': 'vote_average.desc'}},
            {'category': 'list_movies', 'title': _('📺 On The Air'), '_api_params': {'mode': 'tv', 'api': 'on_the_air', 'sort': 'popularity.desc'}},
            {'category': 'list_movies', 'title': _('🕐 Airing Today'), '_api_params': {'mode': 'tv', 'api': 'airing_today', 'sort': 'popularity.desc'}},
            {'category': 'sub_menu', 'title': _('📈 Trending'), 'sub_type': 'trending_tv'},
            {'category': 'sub_menu', 'title': _('🎭 Genres'), 'sub_type': 'genres_tv'},
            {'category': 'sub_menu', 'title': _('📡 TV Networks'), 'sub_type': 'networks_tv'},
            {'category': 'sub_menu', 'title': _('🌍 Countries'), 'sub_type': 'countries_tv'},
            {'category': 'sub_menu', 'title': _('🏆 Best Of'), 'sub_type': 'best_tv'},
        ]
        self.listsTab(cats, cItem)
    def listSubMenu(self, cItem):
        """عرض القائمة الفرعية حسب النوع"""
        sub_type = cItem.get('sub_type', '')
        printDBG('TorrentYTSHost.listSubMenu type[%s]' % sub_type)
        if sub_type == 'trending_movie':
            items = [
                {'category': 'list_movies', 'title': _('📈 This Week'), '_api_params': {'mode': 'movie', 'api': 'trending', 'time': 'week', 'sort': 'popularity.desc'}},
                {'category': 'list_movies', 'title': _('⚡ Today'), '_api_params': {'mode': 'movie', 'api': 'trending', 'time': 'day', 'sort': 'popularity.desc'}},
            ]
        elif sub_type == 'genres_movie':
            items = [
                {'category': 'list_movies', 'title': _('💥 Action'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '28'}},
                {'category': 'list_movies', 'title': _('🗺️ Adventure'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '12'}},
                {'category': 'list_movies', 'title': _('🎨 Animation'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '16'}},
                {'category': 'list_movies', 'title': _('😂 Comedy'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '35'}},
                {'category': 'list_movies', 'title': _('🔪 Crime'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '80'}},
                {'category': 'list_movies', 'title': _('📹 Documentary'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '99'}},
                {'category': 'list_movies', 'title': _('🎭 Drama'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '18'}},
                {'category': 'list_movies', 'title': _('👨‍👩‍👧 Family'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '10751'}},
                {'category': 'list_movies', 'title': _('🧙 Fantasy'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '14'}},
                {'category': 'list_movies', 'title': _('🏛️ History'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '36'}},
                {'category': 'list_movies', 'title': _('👻 Horror'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '27'}},
                {'category': 'list_movies', 'title': _('🎵 Music'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '10402'}},
                {'category': 'list_movies', 'title': _('🕵️ Mystery'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '9648'}},
                {'category': 'list_movies', 'title': _('💕 Romance'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '10749'}},
                {'category': 'list_movies', 'title': _('🚀 Sci-Fi'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '878'}},
                {'category': 'list_movies', 'title': _('😱 Thriller'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '53'}},
                {'category': 'list_movies', 'title': _('⚔️ War'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '10752'}},
                {'category': 'list_movies', 'title': _('🤠 Western'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '37'}},
            ]
        elif sub_type == 'streaming_movie':
            items = [
                {'category': 'list_movies', 'title': _('🔴 Netflix'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '8'}},
                {'category': 'list_movies', 'title': _('🔵 Prime Video'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '9'}},
                {'category': 'list_movies', 'title': _('🏰 Disney+'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '337'}},
                {'category': 'list_movies', 'title': _('🟪 Max (HBO)'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '1899'}},
                {'category': 'list_movies', 'title': _('💚 Hulu'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '15'}},
                {'category': 'list_movies', 'title': _('🍎 Apple TV+'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '350'}},
                {'category': 'list_movies', 'title': _('⛰️ Paramount+'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '531'}},
                {'category': 'list_movies', 'title': _('🦚 Peacock'), '_api_params': {'mode': 'movie', 'api': 'discover', 'provider': '386'}},
            ]
        elif sub_type == 'countries_movie':
            items = [
                {'category': 'list_movies', 'title': _('🇰🇷 Korean'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'KR'}},
                {'category': 'list_movies', 'title': _('🇯🇵 Japanese'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'JP'}},
                {'category': 'list_movies', 'title': _('🎌 Anime'), '_api_params': {'mode': 'movie', 'api': 'discover', 'genre': '16', 'lang': 'ja'}},
                {'category': 'list_movies', 'title': _('🇮🇳 Indian'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'IN'}},
                {'category': 'list_movies', 'title': _('🇬🇧 British'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'GB'}},
                {'category': 'list_movies', 'title': _('🇫🇷 French'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'FR'}},
                {'category': 'list_movies', 'title': _('🇪🇸 Spanish'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'ES'}},
                {'category': 'list_movies', 'title': _('🇮🇹 Italian'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'IT'}},
                {'category': 'list_movies', 'title': _('🇨🇳 Chinese'), '_api_params': {'mode': 'movie', 'api': 'discover', 'origin': 'CN'}},
            ]
        elif sub_type == 'studios_movie':
            items = [
                {'category': 'list_movies', 'title': _('🦸 Marvel Studios'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '420'}},
                {'category': 'list_movies', 'title': _('🪄 Pixar'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '3'}},
                {'category': 'list_movies', 'title': _('🐉 DreamWorks'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '521'}},
                {'category': 'list_movies', 'title': _('🏰 Walt Disney'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '2'}},
                {'category': 'list_movies', 'title': _('🎞️ Warner Bros'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '174'}},
                {'category': 'list_movies', 'title': _('🌐 Universal'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '33'}},
                {'category': 'list_movies', 'title': _('🎭 A24'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '41077'}},
                {'category': 'list_movies', 'title': _('🍃 Studio Ghibli'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '10342'}},
                {'category': 'list_movies', 'title': _('🐲 Legendary'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '923'}},
                {'category': 'list_movies', 'title': _('🔥 Lionsgate'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '1632'}},
                {'category': 'list_movies', 'title': _('😱 Blumhouse'), '_api_params': {'mode': 'movie', 'api': 'discover', 'company': '3172'}},
            ]
        elif sub_type == 'collections_movie':
            items = [
                {'category': 'list_movies', 'title': _('🦸 The Avengers'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '86311'}},
                {'category': 'list_movies', 'title': _('⚡ Harry Potter'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '1241'}},
                {'category': 'list_movies', 'title': _('🌌 Star Wars'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '10'}},
                {'category': 'list_movies', 'title': _('🕴️ James Bond 007'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '645'}},
                {'category': 'list_movies', 'title': _('🏎️ Fast & Furious'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '9485'}},
                {'category': 'list_movies', 'title': _('💍 Lord of the Rings'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '119'}},
                {'category': 'list_movies', 'title': _('🧝 The Hobbit'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '121938'}},
                {'category': 'list_movies', 'title': _('🦖 Jurassic Park'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '328'}},
                {'category': 'list_movies', 'title': _('🏹 Hunger Games'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '131635'}},
                {'category': 'list_movies', 'title': _('🏴‍☠️ Pirates Caribbean'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '295'}},
                {'category': 'list_movies', 'title': _('🕵️ Mission Impossible'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '87359'}},
                {'category': 'list_movies', 'title': _('🔫 John Wick'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '404609'}},
                {'category': 'list_movies', 'title': _('🦇 The Dark Knight'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '263'}},
                {'category': 'list_movies', 'title': _('🕶️ The Matrix'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '2344'}},
                {'category': 'list_movies', 'title': _('🧸 Toy Story'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '10194'}},
                {'category': 'list_movies', 'title': _('🟢 Shrek'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '2150'}},
                {'category': 'list_movies', 'title': _('🍌 Despicable Me'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '86066'}},
                {'category': 'list_movies', 'title': _('🌊 Avatar'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '87096'}},
                {'category': 'list_movies', 'title': _('🧬 X-Men'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '748'}},
                {'category': 'list_movies', 'title': _('👽 Alien'), '_api_params': {'mode': 'movie', 'api': 'collection', 'id': '8091'}},
            ]
        elif sub_type == 'best_movie':
            items = [
                {'category': 'list_movies', 'title': _('🏆 Best 2025'), '_api_params': {'mode': 'movie', 'api': 'best_2025'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2024'), '_api_params': {'mode': 'movie', 'api': 'best_2024'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2023'), '_api_params': {'mode': 'movie', 'api': 'best_2023'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2022'), '_api_params': {'mode': 'movie', 'api': 'best_2022'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2021'), '_api_params': {'mode': 'movie', 'api': 'best_2021'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2020'), '_api_params': {'mode': 'movie', 'api': 'best_2020'}},
            ]
        elif sub_type == 'trending_tv':
            items = [
                {'category': 'list_movies', 'title': _('📈 This Week'), '_api_params': {'mode': 'tv', 'api': 'trending', 'time': 'week'}},
                {'category': 'list_movies', 'title': _('⚡ Today'), '_api_params': {'mode': 'tv', 'api': 'trending', 'time': 'day'}},
            ]
        elif sub_type == 'genres_tv':
            items = [
                {'category': 'list_movies', 'title': _('💥 Action & Adventure'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10759'}},
                {'category': 'list_movies', 'title': _('🎨 Animation'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '16'}},
                {'category': 'list_movies', 'title': _('😂 Comedy'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '35'}},
                {'category': 'list_movies', 'title': _('🔪 Crime'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '80'}},
                {'category': 'list_movies', 'title': _('📹 Documentary'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '99'}},
                {'category': 'list_movies', 'title': _('🎭 Drama'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '18'}},
                {'category': 'list_movies', 'title': _('👨‍👩‍👧 Family'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10751'}},
                {'category': 'list_movies', 'title': _('🧒 Kids'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10762'}},
                {'category': 'list_movies', 'title': _('🕵️ Mystery'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '9648'}},
                {'category': 'list_movies', 'title': _('📰 News'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10763'}},
                {'category': 'list_movies', 'title': _('🎤 Reality'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10764'}},
                {'category': 'list_movies', 'title': _('🚀 Sci-Fi & Fantasy'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10765'}},
                {'category': 'list_movies', 'title': _('💔 Soap'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10766'}},
                {'category': 'list_movies', 'title': _('🎙️ Talk'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10767'}},
                {'category': 'list_movies', 'title': _('⚔️ War & Politics'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '10768'}},
                {'category': 'list_movies', 'title': _('🤠 Western'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '37'}},
            ]
        elif sub_type == 'networks_tv':
            items = [
                {'category': 'list_movies', 'title': _('🔴 Netflix'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '213'}},
                {'category': 'list_movies', 'title': _('🟣 HBO'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '49'}},
                {'category': 'list_movies', 'title': _('🟪 Max'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '3186'}},
                {'category': 'list_movies', 'title': _('🏰 Disney+'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '2739'}},
                {'category': 'list_movies', 'title': _('🔵 Prime Video'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '1024'}},
                {'category': 'list_movies', 'title': _('🍎 Apple TV+'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '2552'}},
                {'category': 'list_movies', 'title': _('💚 Hulu'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '453'}},
                {'category': 'list_movies', 'title': _('⛰️ Paramount+'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '4330'}},
                {'category': 'list_movies', 'title': _('🦚 Peacock'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '3353'}},
                {'category': 'list_movies', 'title': _('🎌 Crunchyroll'), '_api_params': {'mode': 'tv', 'api': 'discover', 'network': '2697'}},
            ]
        elif sub_type == 'countries_tv':
            items = [
                {'category': 'list_movies', 'title': _('🇰🇷 Korean Drama'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'KR'}},
                {'category': 'list_movies', 'title': _('🇯🇵 Japanese Anime'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'JP'}},
                {'category': 'list_movies', 'title': _('🎌 Anime Series'), '_api_params': {'mode': 'tv', 'api': 'discover', 'genre': '16', 'lang': 'ja'}},
                {'category': 'list_movies', 'title': _('🇬🇧 British'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'GB'}},
                {'category': 'list_movies', 'title': _('🇮🇳 Indian'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'IN'}},
                {'category': 'list_movies', 'title': _('🇪🇸 Spanish'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'ES'}},
                {'category': 'list_movies', 'title': _('🇫🇷 French'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'FR'}},
                {'category': 'list_movies', 'title': _('🇹🇷 Turkish'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'TR'}},
                {'category': 'list_movies', 'title': _('🇨🇳 Chinese'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'CN'}},
                {'category': 'list_movies', 'title': _('🇩🇪 German'), '_api_params': {'mode': 'tv', 'api': 'discover', 'origin': 'DE'}},
            ]
        elif sub_type == 'best_tv':
            items = [
                {'category': 'list_movies', 'title': _('🏆 Best 2025'), '_api_params': {'mode': 'tv', 'api': 'best_2025'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2024'), '_api_params': {'mode': 'tv', 'api': 'best_2024'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2023'), '_api_params': {'mode': 'tv', 'api': 'best_2023'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2022'), '_api_params': {'mode': 'tv', 'api': 'best_2022'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2021'), '_api_params': {'mode': 'tv', 'api': 'best_2021'}},
                {'category': 'list_movies', 'title': _('🏆 Best 2020'), '_api_params': {'mode': 'tv', 'api': 'best_2020'}},
            ]
        else:
            items = []
        self.listsTab(items, cItem)
    def listMovies(self, cItem):
        printDBG("TorrentYTSHost.listMovies url[%s]" % cItem.get('url', ''))
        api_url = self._buildApiUrl(cItem)
        printDBG("API Request: %s" % api_url)
        sts, data = self.getPage(api_url)
        if not sts or not data:
            printDBG("Failed to fetch API data")
            return
        try:
            json_data = json_loads(data)
        except Exception as e:
            printDBG("JSON parse error: %s" % str(e))
            printExc()
            return
        results = []
        total_pages = 1
        current_page = 1
        if 'results' in json_data:
            results = json_data['results']
            total_pages = json_data.get('total_pages', 1)
            current_page = json_data.get('page', 1)
        elif 'parts' in json_data:
            results = json_data['parts']
            total_pages = 1
        elif 'hits' in json_data:
            results = json_data['hits']
        printDBG("API Response: page=%d/%d, results=%d" % (current_page, total_pages, len(results)))
        for item in results:
            try:
                title = item.get('name') or item.get('title') or item.get('original_name', '')
                if not title:
                    continue
                media_type = item.get('media_type', cItem.get('_api_params', {}).get('mode', 'movie'))
                year = ''
                date_field = item.get('release_date') if media_type == 'movie' else item.get('first_air_date')
                if date_field and len(date_field) >= 4:
                    year = date_field[:4]
                poster = item.get('poster_path', '')
                if poster and not poster.startswith('http'):
                    icon = 'https://image.tmdb.org/t/p/w342' + poster
                else:
                    icon = poster or self.DEFAULT_ICON_URL
                rating = item.get('vote_average', 0)
                rating_str = '%.1f' % rating if rating else 'N/A'
                try:
                    rating_val = float(rating)
                    rating_color = 'green' if rating_val >= 7.0 else ('yellow' if rating_val >= 5.0 else 'red')
                except:
                    rating_color = 'gray'
                genres = item.get('genre_ids', [])
                genre_str = ', '.join(str(g) for g in genres[:2]) if genres else 'Unknown'
                item_id = item.get('id')
                if not item_id:
                    continue
                url = '%s/%s/%s' % (self.MAIN_URL, media_type, item_id)
                if year:
                    colored_title = (E2ColoR('white') + title + ' ' +
                                     E2ColoR('green') + '(' +
                                     E2ColoR('yellow') + year +
                                     E2ColoR('green') + ')' +
                                     E2ColoR('white'))
                else:
                    colored_title = E2ColoR('white') + title + E2ColoR('white')
                desc = ('Genre: ' + E2ColoR('yellow') + genre_str + E2ColoR('white') +
                        ' | Rating: ' + E2ColoR(rating_color) + rating_str + E2ColoR('white'))
                params = dict(cItem)
                params.update({
                    'title': colored_title,
                    'url': url,
                    'icon': icon,
                    'desc': desc,
                    'category': 'movie_torrents',
                    '_media_type': media_type,
                    '_item_id': item_id
                })
                self.addDir(params)
            except Exception as e:
                printDBG("Error processing item: %s" % str(e))
                printExc()
                continue
        if current_page < total_pages and total_pages > 1:
            next_params = dict(cItem.get('_api_params', {}))
            params = dict(cItem)
            params.update({
                'title': _('>> Next Page (%d/%d)' % (current_page + 1, total_pages)),
                'category': 'list_movies',
                '_page': current_page + 1,
                '_api_params': next_params
            })
            self.addDir(params)
    def _buildApiUrl(self, cItem):
        """بناء رابط API مع دعم جميع البارامترات"""
        base_url = self.MAIN_URL + '/movies'
        api_params = cItem.get('_api_params', {})
        api_type = api_params.get('api', 'popular')
        mode = api_params.get('mode', 'movie')
        page = cItem.get('_page', 1)
        params = {'api': api_type, 'mode': mode, 'page': page}
        if api_params.get('sort'):
            params['sort'] = api_params['sort']
        elif api_type in ['popular', 'trending']:
            params['sort'] = 'popularity.desc'
        elif api_type == 'top_rated':
            params['sort'] = 'vote_average.desc'
        if api_params.get('time'):
            params['time'] = api_params['time']
        if api_params.get('genre'):
            params['genre'] = api_params['genre']
        if api_params.get('quality'):
            params['quality'] = api_params['quality']
        if api_params.get('year'):
            params['year'] = api_params['year']
        for key in ['provider', 'network', 'origin', 'lang', 'company']:
            if api_params.get(key):
                params[key] = api_params[key]
        if api_type == 'collection' and api_params.get('id'):
            params['id'] = api_params['id']
        if api_type == 'search' and cItem.get('search_pattern'):
            params['q'] = cItem['search_pattern']
            params.pop('api', None)
        query = '&'.join('%s=%s' % (k, v) for k, v in params.items())
        return '%s?%s' % (base_url, query)
    def exploreItems(self, cItem):
        """استخراج روابط التورنت من API الموقع - نسخة مُحسّنة"""
        printDBG("TorrentYTSHost.exploreItems url[%s]" % cItem.get('url', ''))
        item_url = cItem.get('url', '')
        item_id = cItem.get('_item_id') or self.cm.ph.getSearchGroups(item_url, r'/\w+/(\d+)')[0]
        media_type = cItem.get('_media_type', 'movie')
        raw_title = cItem.get('title', '')
        printDBG("Raw title: [%s]" % raw_title)
        clean_title = re.sub(r'\\c[0-9A-Fa-f]{6,8}', '', raw_title)
        printDBG("After color remove: [%s]" % clean_title)
        year = ''
        year_patterns = [
            r'\((\d{4})\)',
            r'\s(\d{4})\s*$',
            r'^(\d{4})\s',
        ]
        for pattern in year_patterns:
            match = re.search(pattern, clean_title)
            if match:
                year = match.group(1)
                break
        printDBG("Extracted year: [%s]" % year)
        search_title = re.sub(r'\(\s*\d{4}\s*\)', '', clean_title)
        search_title = re.sub(r'\(\s*\)', '', search_title)
        search_title = re.sub(r'\s+', ' ', search_title).strip()
        printDBG("Final search title: [%s]" % search_title)
        torrents_url = '%s/movies?api=torrents&mode=%s&name=%s&year=%s&quality=all' % (
            self.MAIN_URL,
            media_type,
            urllib_quote_plus(search_title),
            year
        )
        printDBG("Torrents API URL: %s" % torrents_url)
        sts, data = self.getPage(torrents_url)
        if not sts or not data:
            printDBG("Failed to fetch torrents API")
            return
        try:
            json_data = json_loads(data)
        except Exception as e:
            printDBG("JSON parse error: %s" % str(e))
            printExc()
            return
        torrents = json_data.get('hits', [])
        total = json_data.get('total', 0)
        printDBG("API Response: total=%d, found=%d" % (total, len(torrents)))
        if not torrents:
            printDBG("No torrents found")
            return
        torrents_sorted = sorted(torrents, key=lambda x: x.get('seeds', 0), reverse=True)
        for torrent in torrents_sorted:
            try:
                title = torrent.get('title', 'Unknown')
                magnet = torrent.get('magnetUrl', '')
                seeds = torrent.get('seeds', 0)
                peers = torrent.get('peers', 0)
                size_bytes = torrent.get('bytes', 0)
                source = torrent.get('source', 'Unknown')
                torrent_hash = torrent.get('hash', '')
                if not magnet:
                    continue
                quality = self._extractQuality(title)
                quality_color = self._getQualityColor(quality)
                size_str = self._formatSize(size_bytes)
                seeds_color = 'green' if seeds >= 100 else ('yellow' if seeds >= 10 else 'red')
                display_title = (
                    E2ColoR('white') + title + ' ' +
                    E2ColoR(quality_color) + '[' + quality + '] ' +
                    E2ColoR('cyan') + size_str + ' ' +
                    E2ColoR('yellow') + '[' + source + ']' +
                    E2ColoR('white')
                )
                params = dict(cItem)
                params.update({
                    'title': display_title,
                    'url': magnet,
                    'icon': cItem.get('icon', self.DEFAULT_ICON_URL),
                    'desc': (
                        E2ColoR('green') + 'Seeds: ' +
                        E2ColoR(seeds_color) + str(seeds) +
                        E2ColoR('white') + ' | ' +
                        E2ColoR('yellow') + 'Peers: ' +
                        E2ColoR('gray') + str(peers) +
                        E2ColoR('white') + ' | ' +
                        E2ColoR('cyan') + 'Size: ' + size_str +
                        E2ColoR('white')
                    ),
                    'category': 'video',
                    '_torrent_hash': torrent_hash,
                    '_torrent_seeds': seeds,
                    '_torrent_size': size_bytes
                })
                self.addVideo(params)
            except Exception as e:
                printDBG("Error processing torrent: %s" % str(e))
                printExc()
                continue
        printDBG("Added %d torrent videos" % len(self.currList))
    def _extractQuality(self, title):
        """استخراج دقة الفيديو من عنوان التورنت"""
        title_upper = title.upper()
        if '2160P' in title_upper or '4K' in title_upper or 'UHD' in title_upper:
            return '4K'
        elif '1080P' in title_upper:
            return '1080p'
        elif '720P' in title_upper:
            return '720p'
        elif '480P' in title_upper or 'SD' in title_upper:
            return '480p'
        elif 'HDR' in title_upper or 'DV' in title_upper:
            return 'HDR'
        else:
            return 'Unknown'
    def _getQualityColor(self, quality):
        """إرجاع لون مناسب للجودة"""
        colors = {
            '4K': 'purple',
            '1080p': 'lime',
            '720p': 'cyan',
            '480p': 'yellow',
            'HDR': 'pink',
            'Unknown': 'gray'
        }
        return colors.get(quality, 'white')
    def _formatSize(self, bytes_val):
        """تنسيق حجم الملف"""
        if not bytes_val or bytes_val <= 0:
            return '0 B'
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        i = 0
        size = float(bytes_val)
        while size >= 1024 and i < len(units) - 1:
            size /= 1024
            i += 1
        return '%.2f %s' % (size, units[i])
    def searchMovies(self, pattern, cItem):
        if not pattern:
            pattern = self.searchPattern
        printDBG("TorrentYTSHost.searchMovies pattern[%s]" % pattern)
        api_params = {
            'mode': 'movie',
            'api': 'search'
        }
        params = dict(cItem)
        params.update({
            'category': 'list_movies',
            '_api_params': api_params,
            'search_pattern': urllib_quote_plus(pattern)
        })
        self.listMovies(params)
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("TorrentYTSHost.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        cItem = dict(cItem)
        cItem['url'] = self.SEARCH_URL + urllib_quote_plus(searchPattern)
        self.listMovies(cItem)
    def getLinksForVideo(self, cItem):
        """Get direct stream URL from TorServer M3U"""
        self.updateTorServerUrl()
        printDBG("TORSERVER_BASE = [%s]" % self.TORSERVER_BASE)
        ip = config.plugins.iptvplayer.torserver_ip.value.strip() or "127.0.0.1"
        port = int(config.plugins.iptvplayer.torserver_port.value.strip() or "8090")
        if not self.isPortOpen(ip, port):
            printDBG("TorServer not running, starting...")
            self.ensureTorServerRunning()
        video_url = cItem.get('url', '')
        if not video_url:
            printDBG("No video URL found!")
            return []
        printDBG("getLinksForVideo: url=[%s]" % video_url)
        if video_url.startswith('magnet:'):
            encoded_magnet = urllib_quote_plus(video_url)
            m3u_url = "%s/stream?link=%s&m3u=m3u" % (
                self.TORSERVER_BASE,
                encoded_magnet
            )
            printDBG("Loading TorServer M3U: %s" % m3u_url)
            sts, data = self.getPage(m3u_url)
            if not sts:
                printDBG("Failed to load TorServer M3U")
                return []
            printDBG("TorServer response status: %s" % sts)
            try:
                lines = data.splitlines()
                for line in lines:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    if line.startswith('http://') or line.startswith('https://'):
                        printDBG("Found direct stream URL: %s" % line)
                        return [{
                            'name': 'TorServer Stream',
                            'url': line,
                            'need_resolve': 0
                        }]
            except Exception:
                printExc()
            printDBG("No stream URL found inside M3U")
            return []
        elif '.torrent' in video_url or '/download/' in video_url:
            encoded_url = urllib_quote_plus(video_url)
            stream_url = "%s/stream?link=%s&m3u=m3u" % (
                self.TORSERVER_BASE,
                encoded_url
            )
            return [{
                'name': 'TorServer Torrent',
                'url': stream_url,
                'need_resolve': 0
            }]
        elif self.cm.isValidUrl(video_url):
            return self.up.getVideoLinkExt(video_url)
        return []
    def parseM3UContent(self, m3u_data, base_url):
        """Parse M3U content and extract stream URLs"""
        streams = []
        try:
            lines = m3u_data.split('\n')
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#') and line.startswith('http'):
                    printDBG("Found stream URL in M3U: %s" % line)
                    stream_url = strwithmeta(line, {
                        'iptv_proto': 'http',
                        'Referer': base_url,
                        'User-Agent': 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36'
                    })
                    name = 'TorServer Stream'
                    if '720p' in line:
                        name = '720p Stream'
                    elif '1080p' in line:
                        name = '1080p Stream'
                    elif '480p' in line:
                        name = '480p Stream'
                    streams.append({'name': name, 'url': stream_url, 'need_resolve': 0})
            printDBG("Parsed %d streams from M3U" % len(streams))
        except Exception as e:
            printDBG("Error parsing M3U content: %s" % str(e))
            printExc()
        return streams
    def getVideoLinks(self, url):
        printDBG("TorrentYTSHost.getVideoLinks [%s]" % url)
        urlTab = []
        if '/stream/' in str(url) and '&play' in str(url):
            return [{
                'name': 'direct',
                'url': url,
                'need_resolve': 0
            }]
        if self.cm.isValidUrl(url):
            return self.up.getVideoLinkExt(url)
        return urlTab
    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('TorrentYTSHost.handleService start')
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: >> name[%s], category[%s]" % (name, category))
        self.currList = []
        if name is None:
            self.listMainMenu({'name': 'category'})
        elif category == 'movies_root':
            self.listMoviesRoot(self.currItem)
        elif category == 'tv_root':
            self.listTvRoot(self.currItem)
        elif category == 'sub_menu':
            self.listSubMenu(self.currItem)
        elif category == 'movie_torrents':
            self.exploreItems(self.currItem)
        elif category == 'list_movies':
            self.listMovies(self.currItem)
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        CBaseHostClass.endHandleService(self, index, refresh)
class IPTVHost(CHostBase):
    def __init__(self):
        CHostBase.__init__(self, TorrentYTSHost(), True, [])