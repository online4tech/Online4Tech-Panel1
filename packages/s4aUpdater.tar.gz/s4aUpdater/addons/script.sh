# Wed Aug 28 10:59:58 PM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
tmpval=$(basename $0)
str=${tmpval%%_*}'_data.sh'
tmpval=${tmpval#*_}
tmpval=${tmpval%.*}
/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater/addons/$str $tmpval