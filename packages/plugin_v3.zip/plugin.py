from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from os import remove, rename, system

class PictureScreen(Screen):
    skin = """
        <screen name="PictureScreen" position="center,center" size="513,520" title="GosatPlus V3.0 Activation QR">
            <eLabel position="0,0" size="513,50" backgroundColor="#40000000" />
            <widget source="Title" render="Label" position="10,10" size="513,30" font="Regular;22" foregroundColor="#ffffffff" backgroundColor="#00000000" halign="center"/>
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GosatPlus/qr.png" position="center,center" size="512,512"  />
        </screen>"""

    def __init__(self, session, picPath=None):
        Screen.__init__(self, session)
        self["Title"] = Label(_("GosatPlus V3.0 Activation QR"))
          
        self["myActionMap"] = ActionMap(["SetupActions"],
                                        {
                                            "ok": self.cancel,
                                            "cancel": self.cancel
                                        }, -1)

    def cancel(self):
        print("[PictureScreen] - cancel\n")
        self.close(None)

def main(session, **kwargs):
        
        session.open(PictureScreen, picPath="/usr/lib/enigma2/python/Plugins/Extensions/GosatPlus/qr.png")

def Plugins(**kwargs):
    return PluginDescriptor(
        name="GosatPlus V3",
        description="ICAM Enabled",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="gosatplus.png",
        fnc=main
    )
