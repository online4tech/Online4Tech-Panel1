from Screen import Screen
from Screens.Setup import getConfigMenuItem, Setup
from Screens.InputBox import PinInput
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ServiceEventTracker import ServiceEventTracker
from Components.ActionMap import NumberActionMap
from Components.ConfigList import ConfigListScreen
from Components.ChoiceList import ChoiceList
from Components.config import config, ConfigSubsection, getConfigListEntry, ConfigNothing, ConfigSelection, ConfigOnOff, ConfigYesNo
from Components.Label import Label
from Components.Sources.List import List
from Components.Sources.Boolean import Boolean
from Components.SystemInfo import SystemInfo
from Components.VolumeControl import VolumeControl
from time import time

from enigma import iPlayableService, eTimer, eSize, eDVBDB, eServiceReference, eServiceCenter, iServiceInformation

FOCUS_CONFIG, FOCUS_STREAMS = range(2)
[PAGE_AUDIO, PAGE_SUBTITLES] = ["audio", "subtitles"]

TIMESHIFT_DELAY_CHOICES = [("off", "Disabled TimeShift")] + [
	("%.1f" % (x / 2.0), "%.1f seconds" % (x / 2.0)) for x in range(2, 61)
]


def initTimeshiftDelayConfig():
	if not hasattr(config, "plugins"):
		config.plugins = ConfigSubsection()
	if not hasattr(config.plugins, "audioselection"):
		config.plugins.audioselection = ConfigSubsection()
	if not hasattr(config.plugins.audioselection, "timeshift_delay"):
		config.plugins.audioselection.timeshift_delay = ConfigSelection(choices=TIMESHIFT_DELAY_CHOICES, default="off")


initTimeshiftDelayConfig()

# Use the real timeshift position when available so the selected value stays accurate
# even when audio plugins already opened/changed the timeshift buffer.
TIMESHIFT_DELAY_FALLBACK_CORRECTION = 1.0
TIMESHIFT_DELAY_TOLERANCE = 0.10
TIMESHIFT_DELAY_POLL_MS = 100
TIMESHIFT_DELAY_RESET_WATCHDOG_MS = 1000

_timeshift_delay_watchdog_timer = None
_timeshift_delay_watchdog_session = None


def setTimeshiftDelayDisabled(save=True):
	initTimeshiftDelayConfig()
	try:
		if config.plugins.audioselection.timeshift_delay.value != "off":
			config.plugins.audioselection.timeshift_delay.setValue("off")
			if save:
				config.plugins.audioselection.timeshift_delay.save()
			return True
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] reset to Disabled TimeShift failed: %s" % error)
	return False


def getTimeshiftRemainingSecondsFromSession(session):
	try:
		service = session.nav.getCurrentService()
		seek = service and service.seek()
		if not seek:
			return None
		position = seek.getPlayPosition()
		length = seek.getLength()
		if not position or not length:
			return None
		if position[0] or length[0]:
			return None
		pos = position[1]
		end = length[1]
		if pos is None or end is None or pos < 0 or end < 0:
			return None
		remaining = float(end - pos) / 90000.0
		if remaining < 0:
			remaining = 0.0
		return remaining
	except Exception:
		return None


def isTimeshiftDelayRunning(session):
	try:
		service = session.nav.getCurrentService()
		timeshift = service and service.timeshift()
		if not timeshift:
			return False

		# Prefer real timeshift state when the image exposes it.
		for method_name in ("isTimeshiftActive", "isTimeshiftEnabled", "isTimeshiftRunning", "isActive"):
			try:
				method = getattr(timeshift, method_name, None)
				if callable(method):
					if method():
						return True
			except Exception:
				pass

		# Fallback for images without an explicit active flag.
		remaining = getTimeshiftRemainingSecondsFromSession(session)
		return remaining is not None and remaining > TIMESHIFT_DELAY_TOLERANCE
	except Exception:
		return False


def stopTimeshiftDelayWatchdog():
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		if _timeshift_delay_watchdog_timer:
			_timeshift_delay_watchdog_timer.stop()
	except Exception:
		pass
	_timeshift_delay_watchdog_session = None


def _timeshiftDelayWatchdogPoll():
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		initTimeshiftDelayConfig()
		if config.plugins.audioselection.timeshift_delay.value == "off":
			stopTimeshiftDelayWatchdog()
			return
		if not _timeshift_delay_watchdog_session or not isTimeshiftDelayRunning(_timeshift_delay_watchdog_session):
			setTimeshiftDelayDisabled()
			stopTimeshiftDelayWatchdog()
			return
		_timeshift_delay_watchdog_timer.start(TIMESHIFT_DELAY_RESET_WATCHDOG_MS, True)
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] watchdog failed: %s" % error)


def startTimeshiftDelayWatchdog(session):
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		if not session:
			return
		_timeshift_delay_watchdog_session = session
		if _timeshift_delay_watchdog_timer is None:
			_timeshift_delay_watchdog_timer = eTimer()
			_timeshift_delay_watchdog_timer.timeout.get().append(_timeshiftDelayWatchdogPoll)
		_timeshift_delay_watchdog_timer.start(TIMESHIFT_DELAY_RESET_WATCHDOG_MS, True)
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] watchdog start failed: %s" % error)


def syncTimeshiftDelayConfigWithState(session):
	initTimeshiftDelayConfig()
	try:
		if config.plugins.audioselection.timeshift_delay.value != "off":
			if isTimeshiftDelayRunning(session):
				startTimeshiftDelayWatchdog(session)
			else:
				setTimeshiftDelayDisabled()
				stopTimeshiftDelayWatchdog()
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] state sync failed: %s" % error)


class AudioSelection(Screen, ConfigListScreen):
	def __init__(self, session, infobar=None, page=PAGE_AUDIO):
		Screen.__init__(self, session)

		self["streams"] = List([], enableWrapAround=True)
		self["key_red"] = Boolean(False)
		self["key_green"] = Boolean(False)
		self["key_yellow"] = Boolean(True)
		self["key_blue"] = Boolean(False)
		self.protectContextMenu = True
		self.Plugins = []
		ConfigListScreen.__init__(self, [])
		self.infobar = infobar or self.session.infobar

		self.__event_tracker = ServiceEventTracker(screen=self, eventmap=
			{
				iPlayableService.evUpdatedInfo: self.__updatedInfo
			})
		self.cached_subtitle_checked = False
		self.__selected_subtitle = None

		self["actions"] = NumberActionMap(["AudioSelectionActions", "SetupActions", "DirectionActions", "MenuActions"],
		{
			"red": self.keyRed,
			"green": self.keyGreen,
			"yellow": self.keyYellow,
			"blue": self.keyBlue,
			"ok": self.keyOk,
			"cancel": self.cancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"left": self.keyLeft,
			"right": self.keyRight,
			"volumeUp": self.volumeUp,
			"volumeDown": self.volumeDown,
			"volumeMute": self.volumeMute,
			"menu": self.openAutoLanguageSetup,
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
		}, -2)

		self.settings = ConfigSubsection()
		choicelist = [(PAGE_AUDIO,""), (PAGE_SUBTITLES,"")]
		self.settings.menupage = ConfigSelection(choices = choicelist, default=page)
		self.onLayoutFinish.append(self.__layoutFinished)

	def __layoutFinished(self):
		self["config"].instance.setSelectionEnable(False)
		self.focus = FOCUS_STREAMS
		self.settings.menupage.addNotifier(self.fillList)

	def fillList(self, arg=None):
		from Tools.ISO639 import LanguageCodes
		streams = []
		conflist = []
		selectedidx = 0
		self.timeshift_delay_index = None

		self["key_blue"].setBoolean(False)

		subtitlelist = self.getSubtitleList()

		if self.settings.menupage.getValue() == PAGE_AUDIO:
			self.setTitle(_("Select audio track"))
			service = self.session.nav.getCurrentService()
			self.audioTracks = audio = service and service.audioTracks()
			n = audio and audio.getNumberOfTracks() or 0
			if SystemInfo["CanDownmixAC3"]:
				self.settings.downmix = ConfigOnOff(default=config.av.downmix_ac3.value)
				self.settings.downmix.addNotifier(self.changeAC3Downmix, initial_call = False)
				conflist.append(getConfigListEntry(_("Multi channel downmix"), self.settings.downmix))
				self["key_red"].setBoolean(True)

			if n > 0:
				self.audioChannel = service.audioChannel()
				if self.audioChannel:
					choicelist = [("0",_("left")), ("1",_("stereo")), ("2", _("right"))]
					self.settings.channelmode = ConfigSelection(choices = choicelist, default = str(self.audioChannel.getCurrentChannel()))
					self.settings.channelmode.addNotifier(self.changeMode, initial_call = False)
					conflist.append(getConfigListEntry(_("Audio channel"), self.settings.channelmode))
					self["key_green"].setBoolean(True)
				else:
					conflist.append(('',))
					self["key_green"].setBoolean(False)
				selectedAudio = self.audioTracks.getCurrentTrack()
				for x in range(n):
					number = str(x + 1)
					i = audio.getTrackInfo(x)
					languages = i.getLanguage().split('/')
					description = i.getDescription() or ""
					selected = ""
					language = ""

					if selectedAudio == x:
						selected = "X"
						selectedidx = x

					cnt = 0
					for lang in languages:
						if cnt:
							language += ' / '
						if lang in LanguageCodes:
							language += _(LanguageCodes[lang][0])
						elif lang == "und":
							""
						else:
							language += lang
						cnt += 1

					streams.append((x, "", number, description, language, selected))

			else:
				streams = []
				conflist.append(('',))
				self["key_green"].setBoolean(False)

			if subtitlelist:
				self["key_yellow"].setBoolean(True)
				conflist.append(getConfigListEntry(_("To subtitle selection"), self.settings.menupage))
			else:
				self["key_yellow"].setBoolean(False)
				conflist.append(('',))

			from Components.PluginComponent import plugins
			from Plugins.Plugin import PluginDescriptor

			if hasattr(self.infobar, "runPlugin"):
				class PluginCaller:
					def __init__(self, fnc, *args):
						self.fnc = fnc
						self.args = args
					def __call__(self, *args, **kwargs):
						self.fnc(*self.args)

				self.Plugins = [ (p.name, PluginCaller(self.infobar.runPlugin, p)) for p in plugins.getPlugins(where = PluginDescriptor.WHERE_AUDIOMENU) ]

				if self.Plugins:
					self["key_blue"].setBoolean(True)
					if len(self.Plugins) > 1:
						conflist.append(getConfigListEntry(_("Audio plugins"), ConfigNothing()))
						self.plugincallfunc = [(x[0], x[1]) for x in self.Plugins]
					else:
						conflist.append(getConfigListEntry(self.Plugins[0][0], ConfigNothing()))
						self.plugincallfunc = self.Plugins[0][1]

			# Keep Timeshift Delay as the last item in AudioSelection and show the selected value.
			self.syncTimeshiftDelayConfig()
			timeshift_delay_value = config.plugins.audioselection.timeshift_delay.value
			timeshift_delay_label = self.getTimeshiftDelayDisplay()
			self.settings.timeshift_delay = ConfigSelection(choices=[(timeshift_delay_value, timeshift_delay_label)], default=timeshift_delay_value)
			self.timeshift_delay_index = len(conflist)
			conflist.append(getConfigListEntry(_("Timeshift Delay"), self.settings.timeshift_delay, self.openTimeshiftDelay))
			if self.timeshift_delay_index == 3:
				self["key_blue"].setBoolean(True)

		elif self.settings.menupage.getValue() == PAGE_SUBTITLES:

			self.setTitle(_("Subtitle selection"))
			conflist.append(('',))
			conflist.append(('',))
			self["key_red"].setBoolean(False)
			self["key_green"].setBoolean(False)

			idx = 0

			for x in subtitlelist:
				number = str(x[1])
				description = "?"
				language = ""
				selected = ""

				if self.selectedSubtitle and x[:4] == self.selectedSubtitle[:4]:
					selected = "X"
					selectedidx = idx

				try:
					if x[4] != "und":
						if x[4] in LanguageCodes:
							language = _(LanguageCodes[x[4]][0])
						else:
							language = x[4]
				except:
					language = ""

				if x[0] == 0:
					description = "DVB"
					number = "%x" % (x[1])

				elif x[0] == 1:
					description = "teletext"
					number = "%x%02x" %(x[3] and x[3] or 8, x[2])

				elif x[0] == 2:
					types = (_("unknown"), _("embedded"), _("SSA file"), _("ASS file"),
							_("SRT file"), _("VOB file"), _("PGS file"))
					try:
						description = types[x[2]]
					except:
						description = _("unknown") + ": %s" % x[2]
					number = str(int(number) + 1)

				streams.append((x, "", number, description, language, selected))
				idx += 1

			conflist.append(getConfigListEntry(_("To audio selection"), self.settings.menupage))

			if self.infobar.selected_subtitle and self.infobar.selected_subtitle != (0,0,0,0)  and not ".DVDPlayer'>" in `self.infobar`:
				self["key_blue"].setBoolean(True)
				conflist.append(getConfigListEntry(_("Subtitle Quickmenu"), ConfigNothing()))

		self["config"].list = conflist
		self["config"].l.setList(conflist)

		self["streams"].list = streams
		self["streams"].setIndex(selectedidx)

	def __updatedInfo(self):
		self.fillList()

	def getSubtitleList(self):
		service = self.session.nav.getCurrentService()
		subtitle = service and service.subtitle()
		subtitlelist = subtitle and subtitle.getSubtitleList()
		self.selectedSubtitle = None
		if self.subtitlesEnabled():
			self.selectedSubtitle = self.infobar.selected_subtitle
			if self.selectedSubtitle and self.selectedSubtitle[:4] == (0,0,0,0):
				self.selectedSubtitle = None
			elif self.selectedSubtitle and not self.selectedSubtitle[:4] in (x[:4] for x in subtitlelist):
				subtitlelist.append(self.selectedSubtitle)
		return subtitlelist

	def subtitlesEnabled(self):
		try:
			return self.infobar.subtitle_window.shown
		except:
			return False

	def enableSubtitle(self, subtitle):
		if self.infobar.selected_subtitle != subtitle:
			self.infobar.enableSubtitle(subtitle)

	def changeAC3Downmix(self, downmix):
		config.av.downmix_ac3.value = downmix.getValue() == True
		config.av.downmix_ac3.save()
		if SystemInfo["CanDownmixDTS"]:
			config.av.downmix_dts.value = config.av.downmix_ac3.value
			config.av.downmix_dts.save()
		if SystemInfo["CanDownmixAAC"]:
			config.av.downmix_aac.value = config.av.downmix_ac3.value
			config.av.downmix_aac.save()

	def syncTimeshiftDelayConfig(self):
		syncTimeshiftDelayConfigWithState(self.session)

	def getTimeshiftDelayDisplay(self):
		initTimeshiftDelayConfig()
		value = config.plugins.audioselection.timeshift_delay.value
		for choice_value, choice_label in TIMESHIFT_DELAY_CHOICES:
			if choice_value == value:
				return choice_label
		return _("Disabled TimeShift")

	def openTimeshiftDelay(self):
		self.session.openWithCallback(self.timeshiftDelayClosed, TimeshiftDelayConfigMenu, self.infobar)

	def timeshiftDelayClosed(self, applied=False):
		if applied:
			self.close(0)

	def changeMode(self, mode):
		if mode is not None and self.audioChannel:
			self.audioChannel.selectChannel(int(mode.getValue()))

	def changeAudio(self, audio):
		track = int(audio)
		if isinstance(track, int):
			if self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() > track:
				self.audioTracks.selectTrack(track)

	def keyLeft(self):
		if self.focus == FOCUS_CONFIG:
			ConfigListScreen.keyLeft(self)
		elif self.focus == FOCUS_STREAMS:
			self["streams"].setIndex(0)

	def keyRight(self, config = False):
		if config or self.focus == FOCUS_CONFIG:
			currentIndex = self["config"].getCurrentIndex()
			if self.settings.menupage.getValue() == PAGE_AUDIO and hasattr(self, "timeshift_delay_index") and currentIndex == self.timeshift_delay_index:
				self.openTimeshiftDelay()
			elif currentIndex < 3 or currentIndex >= 4:
				ConfigListScreen.keyRight(self)
			elif currentIndex == 3:
				if self.settings.menupage.getValue() == PAGE_AUDIO and hasattr(self, "plugincallfunc"):
					if len(self.Plugins) > 1:
						def runPluginAction(choice):
							if choice:
								choice[1]()
						self.session.openWithCallback(runPluginAction, ChoiceBox, title=_("Audio plugins"), list=self.plugincallfunc)
					else:
						self.plugincallfunc()
				elif self.settings.menupage.getValue() == PAGE_SUBTITLES and self.infobar.selected_subtitle and self.infobar.selected_subtitle != (0,0,0,0):
					self.session.open(QuickSubtitlesConfigMenu, self.infobar)
		if self.focus == FOCUS_STREAMS and self["streams"].count() and config == False:
			self["streams"].setIndex(self["streams"].count()-1)

	def keyRed(self):
		if self["key_red"].getBoolean():
			self.colorkey(0)
		else:
			return 0

	def keyGreen(self):
		if self["key_green"].getBoolean():
			self.colorkey(1)
		else:
			return 0

	def keyYellow(self):
		if self["key_yellow"].getBoolean():
			self.colorkey(2)
		else:
			return 0

	def keyBlue(self):
		if self["key_blue"].getBoolean():
			self.colorkey(3)
		else:
			return 0

	def colorkey(self, idx):
		self["config"].setCurrentIndex(idx)
		self.keyRight(True)

	def keyUp(self):
		if self.focus == FOCUS_CONFIG:
			self["config"].instance.moveSelection(self["config"].instance.moveUp)
		elif self.focus == FOCUS_STREAMS:
			if self["streams"].getIndex() == 0:
				self["config"].instance.setSelectionEnable(True)
				self["streams"].style = "notselected"
				self["config"].setCurrentIndex(len(self["config"].getList())-1)
				self.focus = FOCUS_CONFIG
			else:
				self["streams"].selectPrevious()

	def keyDown(self):
		if self.focus == FOCUS_CONFIG:
			if self["config"].getCurrentIndex() < len(self["config"].getList())-1:
				self["config"].instance.moveSelection(self["config"].instance.moveDown)
			else:
				self["config"].instance.setSelectionEnable(False)
				self["streams"].style = "default"
				self.focus = FOCUS_STREAMS
		elif self.focus == FOCUS_STREAMS:
			self["streams"].selectNext()

	def volumeUp(self):
		VolumeControl.instance and VolumeControl.instance.volUp()

	def volumeDown(self):
		VolumeControl.instance and VolumeControl.instance.volDown()

	def volumeMute(self):
		VolumeControl.instance and VolumeControl.instance.volMute()

	def keyNumberGlobal(self, number):
		if number <= len(self["streams"].list):
			self["streams"].setIndex(number-1)
			self.keyOk()

	def keyOk(self):
		if self.focus == FOCUS_STREAMS and self["streams"].list:
			cur = self["streams"].getCurrent()
			if self.settings.menupage.getValue() == PAGE_AUDIO and cur[0] is not None:
				self.changeAudio(cur[0])
				self.__updatedInfo()
			if self.settings.menupage.getValue() == PAGE_SUBTITLES and cur[0] is not None:
				if self.infobar.selected_subtitle and self.infobar.selected_subtitle[:4] == cur[0][:4]:
					self.enableSubtitle(None)
					selectedidx = self["streams"].getIndex()
					self.__updatedInfo()
					self["streams"].setIndex(selectedidx)
				else:
					self.enableSubtitle(cur[0][:5])
					self.__updatedInfo()
			self.close(0)
		elif self.focus == FOCUS_CONFIG:
			self.keyRight()

	def openAutoLanguageSetup(self):
		if self.protectContextMenu and config.ParentalControl.setuppinactive.value and config.ParentalControl.config_sections.context_menus.value:
			self.session.openWithCallback(self.protectResult, PinInput, pinList=[x.value for x in config.ParentalControl.servicepin], triesEntry=config.ParentalControl.retries.servicepin, title=_("Please enter the correct pin code"), windowTitle=_("Enter pin code"))
		else:
			self.protectResult(True)

	def protectResult(self, answer):
		if answer:
			self.session.open(Setup, "autolanguagesetup")
			self.protectContextMenu = False
		elif answer is not None:
			self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)

	def cancel(self):
		self.close(0)

class TimeshiftDelayConfigMenu(Screen):
	ROW_COUNT = 9

	skin = """
		<screen name="AudioSelectionTimeshiftDelayMenu" position="center,center" size="800,400" title="Timeshift Delay" backgroundColor="black" flags="wfNoBorder">
			<widget name="title_label" position="0,18" size="800,46" font="Regular;36" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row0" position="0,82" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row1" position="0,113" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row2" position="0,144" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row3" position="0,175" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row4" position="0,206" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row5" position="0,237" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row6" position="0,268" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row7" position="0,299" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row8" position="0,330" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
		</screen>
	"""

	def __init__(self, session, infobar=None):
		Screen.__init__(self, session)
		self.skinName = ["AudioSelectionTimeshiftDelayMenu"]
		initTimeshiftDelayConfig()
		self.infobar = infobar or self.session.infobar
		self.delayTimer = eTimer()
		self.delayTimer.timeout.get().append(self.checkTimeshiftDelay)
		self.delayActive = False
		self.delayTarget = 0.0
		self.delayStartedAt = 0.0
		self.delayUsingServicePosition = False
		self.delay_choices = TIMESHIFT_DELAY_CHOICES
		self.selected_index = 0
		self.top_index = 0

		self["title_label"] = Label(_("Timeshift Delay"))
		for row in range(self.ROW_COUNT):
			self["row%d" % row] = Label("")

		self["actions"] = NumberActionMap(["SetupActions", "ColorActions", "DirectionActions", "InfobarSeekActions", "InfobarTimeshiftActions"], {
			"cancel": self.cancel,
			"ok": self.ok,
			"green": self.ok,
			"red": self.cancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"left": self.keyLeft,
			"right": self.keyRight,
			"seekFwd": self.ignoreSeekAction,
			"seekBack": self.ignoreSeekAction,
			"seekFwdManual": self.ignoreSeekAction,
			"seekBackManual": self.ignoreSeekAction,
			"seekFwdUp": self.ignoreSeekAction,
			"seekBackUp": self.ignoreSeekAction,
			"pauseService": self.ignoreSeekAction,
			"unPauseService": self.ignoreSeekAction,
			"timeshiftStart": self.ignoreSeekAction,
			"timeshiftStop": self.stopTimeshiftDelayByUser,
		}, -1)
		self.setTitle(_("Timeshift Delay"))

		current_value = config.plugins.audioselection.timeshift_delay.value
		for index, choice in enumerate(self.delay_choices):
			if choice[0] == current_value:
				self.selected_index = index
				break
		self.centerCurrentSelection()
		self.updateDelayRows()

	def centerCurrentSelection(self):
		self.top_index = self.selected_index - (self.ROW_COUNT // 2)
		if self.top_index < 0:
			self.top_index = 0
		max_top = len(self.delay_choices) - self.ROW_COUNT
		if max_top < 0:
			max_top = 0
		if self.top_index > max_top:
			self.top_index = max_top

	def updateDelayRows(self):
		for row in range(self.ROW_COUNT):
			index = self.top_index + row
			if index < len(self.delay_choices):
				text = self.delay_choices[index][1]
				if index == self.selected_index:
					text = ">  " + text + "  <"
				self["row%d" % row].setText(text)
			else:
				self["row%d" % row].setText("")

	def keyUp(self):
		if self.selected_index > 0:
			self.selected_index -= 1
		else:
			self.selected_index = len(self.delay_choices) - 1
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyDown(self):
		if self.selected_index < len(self.delay_choices) - 1:
			self.selected_index += 1
		else:
			self.selected_index = 0
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyLeft(self):
		self.selected_index = max(0, self.selected_index - 8)
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyRight(self):
		last_index = len(self.delay_choices) - 1
		self.selected_index = min(last_index, self.selected_index + 8)
		self.centerCurrentSelection()
		self.updateDelayRows()

	def ok(self):
		choice_value = self.delay_choices[self.selected_index][0]
		config.plugins.audioselection.timeshift_delay.setValue(choice_value)
		config.plugins.audioselection.timeshift_delay.save()
		if choice_value == "off":
			self.disableTimeshiftDelay()
			self.close(True)
		else:
			self.applyTimeshiftDelay(float(choice_value))

	def ignoreSeekAction(self):
		return 0

	def stopTimeshiftDelayByUser(self):
		# When timeshift is stopped from this screen, also reset the menu value.
		setTimeshiftDelayDisabled()
		stopTimeshiftDelayWatchdog()
		self.delayActive = False
		try:
			self.delayTimer.stop()
		except Exception:
			pass
		try:
			self.stopRunningTimeshift()
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] user stop failed: %s" % error)
		self.close(True)

	def forceSeekStatePlay(self):
		try:
			if self.infobar and hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PLAY"):
				self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)
		except Exception:
			pass

	def getTimeshiftRemainingSeconds(self):
		try:
			service = self.session.nav.getCurrentService()
			seek = service and service.seek()
			if not seek:
				return None
			position = seek.getPlayPosition()
			length = seek.getLength()
			if not position or not length:
				return None
			if position[0] or length[0]:
				return None
			pos = position[1]
			end = length[1]
			if pos is None or end is None or pos < 0 or end < 0:
				return None
			remaining = float(end - pos) / 90000.0
			if remaining < 0:
				remaining = 0.0
			return remaining
		except Exception:
			return None

	def seekTimeshiftRelative(self, seconds):
		if not seconds:
			return False
		try:
			service = self.session.nav.getCurrentService()
			seek = service and service.seek()
			if not seek:
				return False
			direction = 1
			if seconds < 0:
				direction = -1
				seconds = -seconds
			seek.seekRelative(direction, int(seconds * 90000))
			return True
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] seekRelative failed: %s" % error)
			return False

	def normalizeTimeshiftTarget(self):
		# If another audio plugin already changed the live-timeshift position, correct
		# the current position to the selected target instead of relying on a fixed timer.
		remaining = self.getTimeshiftRemainingSeconds()
		if remaining is None:
			return False

		diff = remaining - self.delayTarget
		if diff > TIMESHIFT_DELAY_TOLERANCE:
			# Current delay is larger than requested. Seek towards live by the difference.
			self.seekTimeshiftRelative(diff)
			self.forceSeekStatePlay()
		return True

	def getCurrentPauseableService(self):
		service = self.session.nav.getCurrentService()
		return service and service.pause()

	def pauseServiceForDelay(self):
		# Reset any active FastForward/Rewind state before starting the delay.
		self.forceSeekStatePlay()

		# Start the live-timeshift buffer if available.
		try:
			if self.infobar and hasattr(self.infobar, "startTimeshift") and callable(self.infobar.startTimeshift):
				self.infobar.startTimeshift()
		except Exception:
			pass

		# Prefer direct service pause/unpause because it does not trigger InfoBar trickmode.
		pauseable = self.getCurrentPauseableService()
		if pauseable:
			try:
				pauseable.pause()
				return True
			except Exception:
				pass

		# Fallback for images where direct pause is not available.
		if self.infobar:
			try:
				if hasattr(self.infobar, "pauseService") and callable(self.infobar.pauseService):
					self.infobar.pauseService()
					return True
			except Exception:
				pass
			try:
				if hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PAUSE"):
					self.infobar.setSeekState(self.infobar.SEEK_STATE_PAUSE)
					return True
			except Exception:
				pass
		return False

	def playServiceAfterDelay(self):
		played = False

		pauseable = self.getCurrentPauseableService()
		if pauseable:
			try:
				pauseable.unpause()
				played = True
			except Exception:
				pass

		if not played and self.infobar:
			try:
				if hasattr(self.infobar, "unPauseService") and callable(self.infobar.unPauseService):
					self.infobar.unPauseService()
					played = True
			except Exception:
				pass
			try:
				if hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PLAY"):
					self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)
					played = True
			except Exception:
				pass

		# Final guard: clear any trickmode state left by audio plugins.
		self.forceSeekStatePlay()
		return played

	def stopRunningTimeshift(self):
		# Stop the running timeshift session completely, not only unpause it.
		# Different Enigma2 images expose different APIs, so try the safe methods first.
		stopped = False
		self.forceSeekStatePlay()
		try:
			self.playServiceAfterDelay()
		except Exception:
			pass

		if self.infobar:
			for method_name in ("stopTimeshift", "timeshiftStop"):
				try:
					method = getattr(self.infobar, method_name, None)
					if callable(method):
						method()
						stopped = True
						break
				except Exception as error:
					print("[AudioSelection][TimeshiftDelay] %s failed: %s" % (method_name, error))

		try:
			service = self.session.nav.getCurrentService()
			timeshift = service and service.timeshift()
			if timeshift:
				for method_name in ("stopTimeshift", "stop"):
					try:
						method = getattr(timeshift, method_name, None)
						if callable(method):
							method()
							stopped = True
							break
					except Exception as error:
						print("[AudioSelection][TimeshiftDelay] service.%s failed: %s" % (method_name, error))
		except Exception:
			pass

		# Final professional fallback: if the service still exposes a delayed
		# timeshift position, restart the current service to leave timeshift mode.
		try:
			remaining = self.getTimeshiftRemainingSeconds()
			if remaining is not None and remaining > TIMESHIFT_DELAY_TOLERANCE:
				ref = self.session.nav.getCurrentlyPlayingServiceReference()
				if ref:
					self.session.nav.stopService()
					self.session.nav.playService(ref)
					stopped = True
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] restart service fallback failed: %s" % error)

		self.forceSeekStatePlay()
		return stopped

	def disableTimeshiftDelay(self):
		setTimeshiftDelayDisabled()
		stopTimeshiftDelayWatchdog()
		self.delayActive = False
		self.delayTarget = 0.0
		self.delayStartedAt = 0.0
		self.delayUsingServicePosition = False
		try:
			self.delayTimer.stop()
		except Exception:
			pass
		try:
			self.stopRunningTimeshift()
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] disable failed: %s" % error)

	def applyTimeshiftDelay(self, delay):
		try:
			self.delayTarget = float(delay)
			self.delayStartedAt = time()
			self.delayUsingServicePosition = False
			if self.pauseServiceForDelay():
				self.delayActive = True
				# Poll the real ServicePosition Remaining value. This keeps the selected
				# delay accurate even if AudioPlus/other audio plugins already shifted the
				# timeshift buffer or add their own processing delay.
				self.delayTimer.start(TIMESHIFT_DELAY_POLL_MS, True)
			else:
				setTimeshiftDelayDisabled()
				stopTimeshiftDelayWatchdog()
				self.session.open(MessageBox, _("Timeshift is not available on this service."), MessageBox.TYPE_ERROR, timeout=5)
		except Exception as error:
			setTimeshiftDelayDisabled()
			stopTimeshiftDelayWatchdog()
			print("[AudioSelection][TimeshiftDelay] failed to start delay: %s" % error)
			self.session.open(MessageBox, _("Unable to start timeshift delay."), MessageBox.TYPE_ERROR, timeout=5)

	def checkTimeshiftDelay(self):
		if not self.delayActive:
			return

		remaining = self.getTimeshiftRemainingSeconds()
		if remaining is not None:
			self.delayUsingServicePosition = True
			if remaining + TIMESHIFT_DELAY_TOLERANCE >= self.delayTarget:
				self.finishTimeshiftDelay()
			else:
				diff = self.delayTarget - remaining
				poll_ms = int(diff * 1000)
				if poll_ms < TIMESHIFT_DELAY_POLL_MS:
					poll_ms = TIMESHIFT_DELAY_POLL_MS
				elif poll_ms > 500:
					poll_ms = 500
				self.delayTimer.start(poll_ms, True)
			return

		# Fallback for images that do not expose seek.getPlayPosition/getLength.
		# Keep the old one-second correction only as a fallback, not as the main logic.
		elapsed = time() - self.delayStartedAt
		fallbackTarget = self.delayTarget - TIMESHIFT_DELAY_FALLBACK_CORRECTION
		if fallbackTarget < 0:
			fallbackTarget = 0
		if elapsed >= fallbackTarget:
			self.finishTimeshiftDelay()
		else:
			self.delayTimer.start(TIMESHIFT_DELAY_POLL_MS, True)

	def finishTimeshiftDelay(self):
		self.delayActive = False
		try:
			if self.delayUsingServicePosition:
				self.normalizeTimeshiftTarget()
			self.playServiceAfterDelay()
			self.forceSeekStatePlay()
			if config.plugins.audioselection.timeshift_delay.value != "off":
				startTimeshiftDelayWatchdog(self.session)
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] failed to finish delay: %s" % error)
		self.close(True)

	def cancel(self):
		if self.delayActive:
			self.delayTimer.stop()
			self.finishTimeshiftDelay()
		else:
			self.close(False)

class SubtitleSelection(AudioSelection):
	def __init__(self, session, infobar=None):
		AudioSelection.__init__(self, session, infobar, page=PAGE_SUBTITLES)
		self.skinName = ["AudioSelection"]

class QuickSubtitlesConfigMenu(ConfigListScreen, Screen):
	skin = """
	<screen position="50,50" size="480,305" title="Subtitle settings" backgroundColor="#7f000000" flags="wfNoBorder">
		<widget name="config" position="5,5" size="470,275" font="Regular;18" zPosition="1" transparent="1" selectionPixmap="PLi-HD/buttons/sel.png" valign="center" />
		<widget name="videofps" position="5,280" size="470,20" backgroundColor="secondBG" transparent="1" zPosition="1" font="Regular;16" valign="center" halign="left" foregroundColor="blue"/>
	</screen>"""

	FLAG_CENTER_DVB_SUBS = 2048

	def __init__(self, session, infobar):
		Screen.__init__(self, session)
		self.skin = QuickSubtitlesConfigMenu.skin
		self.infobar = infobar or self.session.infobar
		self.wait = eTimer()
		self.wait.timeout.get().append(self.resyncSubtitles)
		self.service = self.session.nav.getCurrentlyPlayingServiceReference()
		servicepath = self.service and self.service.getPath()
		if servicepath and servicepath.startswith("/") and self.service.toString().startswith("1:"):
			info = eServiceCenter.getInstance().info(self.service)
			self.service_string = info and info.getInfoString(self.service, iServiceInformation.sServiceref)
		else:
			self.service_string = self.service.toString()
		self.center_dvb_subs = ConfigYesNo(default = (eDVBDB.getInstance().getFlag(eServiceReference(self.service_string)) & self.FLAG_CENTER_DVB_SUBS) and True)
		self.center_dvb_subs.addNotifier(self.setCenterDvbSubs)
		self["videofps"] = Label("")

		sub = self.infobar.selected_subtitle
		if sub[0] == 0:  # dvb
			menu = [
				getConfigMenuItem("config.subtitles.dvb_subtitles_yellow"),
				getConfigMenuItem("config.subtitles.dvb_subtitles_backtrans"),
				getConfigMenuItem("config.subtitles.dvb_subtitles_original_position"),
				(_("Center DVB subtitles"), self.center_dvb_subs),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_bad_timing_delay"),
				getConfigMenuItem("config.subtitles.subtitle_noPTSrecordingdelay"),
			]
		elif sub[0] == 1: # teletext
			menu = [
				getConfigMenuItem("config.subtitles.ttx_subtitle_colors"),
				getConfigMenuItem("config.subtitles.ttx_subtitle_original_position"),
				getConfigMenuItem("config.subtitles.subtitle_fontsize"),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_rewrap"),
				getConfigMenuItem("config.subtitles.subtitle_borderwidth"),
				getConfigMenuItem("config.subtitles.showbackground"),
				getConfigMenuItem("config.subtitles.subtitle_alignment"),
				getConfigMenuItem("config.subtitles.subtitle_bad_timing_delay"),
				getConfigMenuItem("config.subtitles.subtitle_noPTSrecordingdelay"),
			]
		else: # pango
			menu = [
				getConfigMenuItem("config.subtitles.pango_subtitles_delay"),
				getConfigMenuItem("config.subtitles.pango_subtitle_colors"),
				getConfigMenuItem("config.subtitles.pango_subtitle_fontswitch"),
				getConfigMenuItem("config.subtitles.colourise_dialogs"),
				getConfigMenuItem("config.subtitles.subtitle_fontsize"),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_alignment"),
				getConfigMenuItem("config.subtitles.subtitle_rewrap"),
				getConfigMenuItem("config.subtitles.pango_subtitle_removehi"),
				getConfigMenuItem("config.subtitles.subtitle_borderwidth"),
				getConfigMenuItem("config.subtitles.showbackground"),
				getConfigMenuItem("config.subtitles.pango_subtitles_fps"),
			]
			self["videofps"].setText(_("Video: %s fps") % (self.getFps().rstrip(".000")))

		ConfigListScreen.__init__(self, menu, self.session, on_change = self.changedEntry)

		self["actions"] = NumberActionMap(["SetupActions"],
		{
			"cancel": self.cancel,
			"ok": self.ok,
		},-2)

		self.onLayoutFinish.append(self.layoutFinished)

	def setCenterDvbSubs(self, configElement):
		if configElement.value:
			eDVBDB.getInstance().addFlag(eServiceReference(self.service_string), self.FLAG_CENTER_DVB_SUBS)
			config.subtitles.dvb_subtitles_centered.value = True
		else:
			eDVBDB.getInstance().removeFlag(eServiceReference(self.service_string), self.FLAG_CENTER_DVB_SUBS)
			config.subtitles.dvb_subtitles_centered.value = False

	def layoutFinished(self):
		if not self["videofps"].text:
			self.instance.resize(eSize(self.instance.size().width(), self["config"].l.getItemSize().height()*len(self["config"].getList()) + 10))

	def changedEntry(self):
		if self["config"].getCurrent() in [getConfigMenuItem("config.subtitles.pango_subtitles_delay"),getConfigMenuItem("config.subtitles.pango_subtitles_fps")]:
			self.wait.start(500, True)

	def resyncSubtitles(self):
		self.infobar.setSeekState(self.infobar.SEEK_STATE_PAUSE)
		self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)

	def getFps(self):
		service = self.session.nav.getCurrentService()
		info = service and service.info()
		if not info:
			return ""
		fps = info.getInfo(iServiceInformation.sFrameRate)
		if fps > 0:
			return "%6.3f" % (fps/1000.)
		return ""

	def cancel(self):
		self.center_dvb_subs.removeNotifier(self.setCenterDvbSubs)
		self.close()

	def ok(self):
		config.subtitles.save()
		self.close()
