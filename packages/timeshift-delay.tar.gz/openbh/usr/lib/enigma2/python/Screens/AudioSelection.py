from enigma import iPlayableService, eTimer, eSize, eDVBDB, eServiceReference, eServiceCenter, iServiceInformation
from Components.ActionMap import NumberActionMap
from Components.config import config, ConfigSubsection, getConfigListEntry, ConfigNothing, ConfigSelection, ConfigOnOff, ConfigYesNo
from Components.ConfigList import ConfigListScreen
from Components.Converter.VAudioInfo import StdAudioDesc
from Components.Label import Label
from Components.PluginComponent import plugins
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.Boolean import Boolean
from Components.Sources.List import List
from Components.SystemInfo import SystemInfo
from Components.UsageConfig import originalAudioTracks, visuallyImpairedCommentary
from Components.VolumeControl import VolumeControl
from time import time

from Plugins.Plugin import PluginDescriptor

from Screens.InputBox import PinInput
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Setup import getConfigMenuItem, Setup

from Tools.ISO639 import LanguageCodes
from Tools.General import isIPTV
from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN
from Tools.LoadPixmap import LoadPixmap

FOCUS_CONFIG, FOCUS_STREAMS = range(2)
[PAGE_AUDIO, PAGE_SUBTITLES] = ["audio", "subtitles"]

selectionpng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "selections/selectioncross.png"))  # for use in the future

TIMESHIFT_DELAY_CHOICES = [("off", "Disabled TimeShift")] + [
	("%.1f" % (x / 2.0), "%.1f seconds" % (x / 2.0)) for x in range(2, 61)
]


def initTimeshiftDelayConfig():
	if not hasattr(config, "plugins"):
		config.plugins = ConfigSubsection()
	if not hasattr(config.plugins, "audioselection"):
		config.plugins.audioselection = ConfigSubsection()
	if not hasattr(config.plugins.audioselection, "timeshift_delay"):
		config.plugins.audioselection.timeshift_delay = ConfigSelection(choices=TIMESHIFT_DELAY_CHOICES, default="off")


initTimeshiftDelayConfig()

# Use the real timeshift position when available so the selected value stays accurate
# even when audio plugins already opened/changed the timeshift buffer.
TIMESHIFT_DELAY_FALLBACK_CORRECTION = 1.0
TIMESHIFT_DELAY_TOLERANCE = 0.10
TIMESHIFT_DELAY_POLL_MS = 100
TIMESHIFT_DELAY_RESET_WATCHDOG_MS = 1000

_timeshift_delay_watchdog_timer = None
_timeshift_delay_watchdog_session = None


def setTimeshiftDelayDisabled(save=True):
	initTimeshiftDelayConfig()
	try:
		if config.plugins.audioselection.timeshift_delay.value != "off":
			config.plugins.audioselection.timeshift_delay.setValue("off")
			if save:
				config.plugins.audioselection.timeshift_delay.save()
			return True
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] reset to Disabled TimeShift failed: %s" % error)
	return False


def getTimeshiftRemainingSecondsFromSession(session):
	try:
		service = session.nav.getCurrentService()
		seek = service and service.seek()
		if not seek:
			return None
		position = seek.getPlayPosition()
		length = seek.getLength()
		if not position or not length:
			return None
		if position[0] or length[0]:
			return None
		pos = position[1]
		end = length[1]
		if pos is None or end is None or pos < 0 or end < 0:
			return None
		remaining = float(end - pos) / 90000.0
		if remaining < 0:
			remaining = 0.0
		return remaining
	except Exception:
		return None


def isTimeshiftDelayRunning(session):
	try:
		service = session.nav.getCurrentService()
		timeshift = service and service.timeshift()
		if not timeshift:
			return False

		# Prefer real timeshift state when the image exposes it.
		for method_name in ("isTimeshiftActive", "isTimeshiftEnabled", "isTimeshiftRunning", "isActive"):
			try:
				method = getattr(timeshift, method_name, None)
				if callable(method):
					if method():
						return True
			except Exception:
				pass

		# Fallback for images without an explicit active flag.
		remaining = getTimeshiftRemainingSecondsFromSession(session)
		return remaining is not None and remaining > TIMESHIFT_DELAY_TOLERANCE
	except Exception:
		return False


def stopTimeshiftDelayWatchdog():
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		if _timeshift_delay_watchdog_timer:
			_timeshift_delay_watchdog_timer.stop()
	except Exception:
		pass
	_timeshift_delay_watchdog_session = None


def _timeshiftDelayWatchdogPoll():
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		initTimeshiftDelayConfig()
		if config.plugins.audioselection.timeshift_delay.value == "off":
			stopTimeshiftDelayWatchdog()
			return
		if not _timeshift_delay_watchdog_session or not isTimeshiftDelayRunning(_timeshift_delay_watchdog_session):
			setTimeshiftDelayDisabled()
			stopTimeshiftDelayWatchdog()
			return
		_timeshift_delay_watchdog_timer.start(TIMESHIFT_DELAY_RESET_WATCHDOG_MS, True)
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] watchdog failed: %s" % error)


def startTimeshiftDelayWatchdog(session):
	global _timeshift_delay_watchdog_timer, _timeshift_delay_watchdog_session
	try:
		if not session:
			return
		_timeshift_delay_watchdog_session = session
		if _timeshift_delay_watchdog_timer is None:
			_timeshift_delay_watchdog_timer = eTimer()
			_timeshift_delay_watchdog_timer.timeout.get().append(_timeshiftDelayWatchdogPoll)
		_timeshift_delay_watchdog_timer.start(TIMESHIFT_DELAY_RESET_WATCHDOG_MS, True)
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] watchdog start failed: %s" % error)


def syncTimeshiftDelayConfigWithState(session):
	initTimeshiftDelayConfig()
	try:
		if config.plugins.audioselection.timeshift_delay.value != "off":
			if isTimeshiftDelayRunning(session):
				startTimeshiftDelayWatchdog(session)
			else:
				setTimeshiftDelayDisabled()
				stopTimeshiftDelayWatchdog()
	except Exception as error:
		print("[AudioSelection][TimeshiftDelay] state sync failed: %s" % error)


class AudioSelection(ConfigListScreen, Screen):
	TYPE_ALL = 0
	TYPE_AUDIO = 1
	TYPE_SUBTITLE = 2
	hooks = []
	audioHooks = []
	subtitleHooks = []
	fillSubtitleExt = None

	def __init__(self, session, infobar=None, page=PAGE_AUDIO):
		Screen.__init__(self, session)
		self["streams"] = List([], enableWrapAround=True)
		self["key_red"] = Boolean(False)
		self["key_green"] = Boolean(False)
		self["key_yellow"] = Boolean(True)
		self["key_blue"] = Boolean(False)
		self.protectContextMenu = True
		ConfigListScreen.__init__(self, [])
		self.infobar = infobar or self.session.infobar
		if not hasattr(self.infobar, "selected_subtitle"):
			self.infobar.selected_subtitle = None

		self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
			iPlayableService.evUpdatedInfo: self.__updatedInfo
		})
		self.cached_subtitle_checked = False
		self.__selected_subtitle = None
		self["actions"] = NumberActionMap(["ColorActions", "OkCancelActions", "DirectionActions", "MenuActions", "InfobarAudioSelectionActions", "InfobarSubtitleSelectionActions"], {
			"red": self.keyRed,
			"green": self.keyGreen,
			"yellow": self.keyYellow,
			"subtitleSelection": self.keyAudioSubtitle,
			"audioSelection": self.keyAudioSubtitle,
			"blue": self.keyBlue,
			"ok": self.keyOk,
			"cancel": self.cancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"volumeUp": self.volumeUp,
			"volumeDown": self.volumeDown,
			"volumeMute": self.volumeMute,
			"menu": self.openAutoLanguageSetup,
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
		}, -2)
		self.settings = ConfigSubsection()
		choicelist = [
			(PAGE_AUDIO, ""),
			(PAGE_SUBTITLES, "")
		]
		self.settings.menupage = ConfigSelection(choices=choicelist, default=page)
		self.onLayoutFinish.append(self.__layoutFinished)

	def runHooks(self, type):
		if type == self.TYPE_ALL:
			for hook in AudioSelection.hooks:
				if callable(hook):
					hook()
		elif type == self.TYPE_AUDIO:
			for hook in AudioSelection.audioHooks:
				if callable(hook):
					hook()
		elif type == self.TYPE_SUBTITLE:
			for hook in AudioSelection.subtitleHooks:
				if callable(hook):
					hook()

	def __layoutFinished(self):
		self["config"].instance.setSelectionEnable(False)
		self.focus = FOCUS_STREAMS
		self.settings.menupage.addNotifier(self.fillList)

	def saveAVDict(self):
		eDVBDB.getInstance().saveIptvServicelist()

	def readChoices(self, procx, choices):
		choice_list = choices
		with open(procx, "r") as myfile:
			procChoices = myfile.read().strip()
		if procChoices:
			choiceslist = procChoices.split(" ")
			choice_list = [(item, _(item)) for item in choiceslist]
		return choice_list

	def fillList(self, arg=None):
		streams = []
		conflist = []
		selectedidx = 0
		self.subtitlelist = []

		self["key_red"].setBoolean(False)
		self["key_green"].setBoolean(False)
		self["key_yellow"].setBoolean(False)
		self["key_blue"].setBoolean(False)

		self.subtitlelist = self.getSubtitleList()
		print("[AudiSelection][fillList] subtitlelist=%s" % (self.subtitlelist))
		if self.settings.menupage.value == PAGE_AUDIO:
			self.setTitle(_("Select Audio Track"))
			service = self.session.nav.getCurrentService()
			self.audioTracks = audio = service and service.audioTracks()
			n = audio and audio.getNumberOfTracks() or 0
			if self.subtitlelist:
				conflist.append(getConfigListEntry(_("To Subtitle Selection"), self.settings.menupage))
			if SystemInfo["CanDownmixAC3"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/ac3_choices", choice_list)
				self.settings.downmix_ac3 = ConfigSelection(choices=choice_list, default=config.av.downmix_ac3.value)
				self.settings.downmix_ac3.addNotifier(self.changeAC3Downmix, initial_call=False)
				if SystemInfo["model"] != "gb7252":
					conflist.append(getConfigListEntry(_("AC3 / AC3+ downmix"), self.settings.downmix_ac3, None))
				else:
					conflist.append(getConfigListEntry(_("AC3 downmix"), self.settings.downmix_ac3, None))

			if SystemInfo["CanDownmixDTS"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/dts_choices", choice_list)
				self.settings.downmix_dts = ConfigSelection(choices=choice_list, default=config.av.downmix_dts.value)
				self.settings.downmix_dts.addNotifier(self.changeDTSDownmix, initial_call=False)
				conflist.append(getConfigListEntry(_("DTS downmix"), self.settings.downmix_dts, None))

			if SystemInfo["CanDownmixAAC"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/aac_choices", choice_list)
				self.settings.downmix_aac = ConfigSelection(choices=choice_list, default=config.av.downmix_aac.value)
				self.settings.downmix_aac.addNotifier(self.changeAACDownmix, initial_call=False)
				conflist.append(getConfigListEntry(_("AAC downmix"), self.settings.downmix_aac, None))

			if SystemInfo["CanDownmixAC3Plus"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/ac3plus_choices", choice_list)
				self.settings.downmix_ac3plus = ConfigSelection(choices=choice_list, default=config.av.downmix_ac3plus.value)
				self.settings.downmix_ac3plus.addNotifier(self.changeAC3DownmixPlus, initial_call=False)
				conflist.append(getConfigListEntry(_("AC3+ downmix"), self.settings.downmix_ac3plus, None))

			if SystemInfo["CanDTSHD"]:
				choice_list = [
					("downmix", _("Downmix")),
					("force_dts", _("Convert to DTS")),
					("use_hdmi_caps", _("Controlled by HDMI")),
					("multichannel", _("Convert to Multi-Channel PCM")),
					("hdmi_best", _("Use best / Controlled by HDMI"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/dtshd_choices", choice_list)
				self.settings.dtshd = ConfigSelection(choices=choice_list, default=config.av.dtshd.value)
				self.settings.dtshd.addNotifier(self.changeDTSHD, initial_call=False)
				conflist.append(getConfigListEntry(_("DTS-HD MA/HR downmix"), self.settings.dtshd, None))

			if SystemInfo["CanDownmixAACPlus"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough")),
					("multichannel", _("Convert to Multi-Channel PCM")),
					("force_ac3", _("convert to AC3")),
					("force_dts", _("convert to DTS")),
					("use_hdmi_caps", _("Use best / Controlled by HDMI"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/aacplus_choices", choice_list)
				self.settings.downmix_aacplus = ConfigSelection(choices=choice_list, default=config.av.downmix_aacplus.value)
				self.settings.downmix_aacplus.addNotifier(self.changeAACDownmixPlus, initial_call=False)
				conflist.append(getConfigListEntry(_("AAC+ downmix"), self.settings.downmix_aacplus, None))

			if SystemInfo["CanWMAPRO"]:
				choice_list = [
					("downmix", _("Downmix")),
					("passthrough", _("Passthrough")),
					("multichannel", _("Convert to Multi-Channel PCM")),
					("hdmi_best", _("Use Best / Controlled by HDMI"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/wmapro_choices", choice_list)
				self.settings.wmapro = ConfigSelection(choices=choice_list, default=config.av.wmapro.value)
				self.settings.wmapro.addNotifier(self.changeWMAPro, initial_call=False)
				conflist.append(getConfigListEntry(_("WMA Pro downmix"), self.settings.wmapro, None))

			if SystemInfo["CanAACTranscode"]:
				choice_list = [
					("off", _("off")),
					("ac3", _("AC3")),
					("dts", _("DTS"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/aac_transcode_choices", choice_list)
				self.settings.transcodeaac = ConfigSelection(choices=choice_list, default=config.av.transcodeaac.value)
				self.settings.transcodeaac.addNotifier(self.setAACTranscode, initial_call=False)
				conflist.append(getConfigListEntry(_("AAC transcoding"), self.settings.transcodeaac, None))

			if SystemInfo["CanPcmMultichannel"]:
				self.settings.pcm_multichannel = ConfigOnOff(default=config.av.pcm_multichannel.value)
				self.settings.pcm_multichannel.addNotifier(self.changePCMMultichannel, initial_call=False)
				conflist.append(getConfigListEntry(_("PCM multichannel"), self.settings.pcm_multichannel, None))

			if SystemInfo["CanBTAudio"]:
				choice_list = [("off", _("Off")), ("on", _("On"))]
				self.settings.btaudio = ConfigSelection(choices=choice_list, default=config.av.btaudio.value)
				self.settings.btaudio.addNotifier(self.changeBTAudio, initial_call=False)
				conflist.append(getConfigListEntry(_("Enable Bluetooth Audio"), self.settings.btaudio, None))


			if SystemInfo["Can3DSurround"]:
				choice_list = [
					("none", _("Off")),
					("hdmi", _("HDMI")),
					("spdif", _("SPDIF")),
					("dac", _("DAC"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/3d_surround_choices", choice_list)
				self.settings.surround_3d = ConfigSelection(choices=choice_list, default=config.av.surround_3d.value)
				self.settings.surround_3d.addNotifier(self.change3DSurround, initial_call=False)
				conflist.append(getConfigListEntry(_("3D surround"), self.settings.surround_3d, None))

			if SystemInfo["Can3DSpeaker"] and config.av.surround_3d.value != "none":
				choice_list = [
					("center", _("Center")),
					("wide", _("Wide")),
					("extrawide", _("Extra Wide"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/3d_surround_speaker_position_choices", choice_list)
				self.settings.surround_3d_speaker = ConfigSelection(choices=choice_list, default=config.av.surround_3d_speaker.value)
				self.settings.surround_3d_speaker.addNotifier(self.change3DSurroundSpeaker, initial_call=False)
				conflist.append(getConfigListEntry(_("3D surround speaker position"), self.settings.surround_3d_speaker, None))

			if SystemInfo["CanAutoVolume"]:
				choice_list = [
					("none", _("Off")),
					("hdmi", _("HDMI")),
					("spdif", _("SPDIF")),
					("dac", _("DAC"))
				]
				if SystemInfo["CanProc"]:
					choice_list = self.readChoices("/proc/stb/audio/avl_choices", choice_list)
				self.settings.autovolume = ConfigSelection(choices=choice_list, default=config.av.autovolume.value)
				self.settings.autovolume.addNotifier(self.changeAutoVolume, initial_call=False)
				conflist.append(getConfigListEntry(_("Auto volume level"), self.settings.autovolume, None))

			if n > 0:
				self.audioChannel = service.audioChannel()
				if self.audioChannel:
					choicelist = [
						("0", _("Left")),
						("1", _("Stereo")),
						("2", _("Right"))
					]
					self.settings.channelmode = ConfigSelection(choices=choicelist, default=str(self.audioChannel.getCurrentChannel()))
					self.settings.channelmode.addNotifier(self.changeMode, initial_call=False)
					conflist.append(getConfigListEntry(_("Audio channel"), self.settings.channelmode, None))
				selectedAudio = self.audioTracks.getCurrentTrack()
				for x in range(n):
					number = str(x + 1)
					i = audio.getTrackInfo(x)
					languages = i.getLanguage().split('/')
					description = StdAudioDesc(i.getDescription())
					selected = ""
					language = ""
					if selectedAudio == x:
						selected = "X"
						selectedidx = x
					cnt = 0
					for lang in languages:
						if cnt:
							language += " / "
						if lang == "":
							language += _("Not Defined")
						elif lang in originalAudioTracks:
							language += _("Original language")
						elif lang in LanguageCodes:
							language += _(LanguageCodes[lang][0])
						elif lang in visuallyImpairedCommentary:
							language += _("Narration")
						else:
							language += lang
						cnt += 1
					streams.append((x, "", number, description, language, selected, selectionpng if selected == "X" else None))
			else:
				conflist.append(("",))
			if SystemInfo["Canedidchecking"]:
				self.settings.bypass_edid_checking = ConfigYesNo(default=config.av.bypass_edid_checking.value)
				self.settings.bypass_edid_checking.addNotifier(self.changeEDIDChecking, initial_call=False)
				conflist.append(getConfigListEntry(_("Bypass HDMI EDID Check"), self.settings.bypass_edid_checking, None))
			if hasattr(self.infobar, "runPlugin"):
				class PluginCaller:
					def __init__(self, fnc, *args):
						self.fnc = fnc
						self.args = args

					def __call__(self, *args, **kwargs):
						self.fnc(*self.args)

				Plugins = [(p.name, PluginCaller(self.infobar.runPlugin, p)) for p in plugins.getPlugins(where=PluginDescriptor.WHERE_AUDIOMENU)]
				if len(Plugins):
					for x in Plugins:
						if x[0] != "AudioEffect":  # Always make AudioEffect Blue button.
							conflist.append(getConfigListEntry(x[0], ConfigNothing(), x[1]))

			# Keep Timeshift Delay as the last item in AudioSelection and show the selected value.
			# If timeshift was stopped outside this menu, reset the saved value to Disabled TimeShift.
			self.syncTimeshiftDelayConfig()
			timeshift_delay_value = config.plugins.audioselection.timeshift_delay.value
			timeshift_delay_label = self.getTimeshiftDelayDisplay()
			self.settings.timeshift_delay = ConfigSelection(choices=[(timeshift_delay_value, timeshift_delay_label)], default=timeshift_delay_value)
			conflist.append(getConfigListEntry(_("Timeshift Delay"), self.settings.timeshift_delay, self.openTimeshiftDelay))

		elif self.settings.menupage.value == PAGE_SUBTITLES:
			self.setTitle(_("Subtitle Selection"))
			idx = 0
			if self.subtitlelist is not None:
				for x in self.subtitlelist:
					number = str(x[1])
					description = "?"
					language = ""
					selected = ""
					if self.selectedSubtitle and x[:4] == self.selectedSubtitle[:4]:
						selected = "X"
						selectedidx = idx
					try:
						if x[4] != "und":
							if x[4] in LanguageCodes:
								language = _(LanguageCodes[x[4]][0])
							else:
								language = x[4]
					except Exception:
						language = ""
					if x[0] == 0:
						description = "DVB"
						number = "%x" % (x[1])
					elif x[0] == 1:
						description = "teletext"
						number = "%x%02x" % (x[3] and x[3] or 8, x[2])
					elif x[0] == 2:
						types = (_("unknown"), _("embedded"), "SSA", "ASS", "SRT", "VOB", "PGS")
						try:
							description = types[x[2]]
						except Exception:
							description = _("unknown") + ": %s" % x[2]
					streams.append((x, "", number, description, language, selected, selectionpng if selected == "X" else None))
					idx += 1
			conflist.append(getConfigListEntry(_("To Audio Selection"), self.settings.menupage))

			if self.infobar.selected_subtitle and self.infobar.selected_subtitle != (0, 0, 0, 0) and ".DVDPlayer'>" not in repr(self.infobar):
				conflist.append(getConfigListEntry(_("Subtitle Quickmenu"), ConfigNothing(), None))

		if len(conflist) > 0 and conflist[0][0]:
			self["key_red"].setBoolean(True)
		if len(conflist) > 1 and conflist[1][0]:
			self["key_green"].setBoolean(True)
		if len(conflist) > 2 and conflist[2][0]:
			self["key_yellow"].setBoolean(True)
		if len(conflist) > 3 and conflist[3][0]:
			self["key_blue"].setBoolean(True)
		self["config"].list = conflist
		self["streams"].list = streams
		self["streams"].setIndex(selectedidx)

	def __updatedInfo(self):
		self.fillList()

	def getSubtitleList(self):
		service = self.session.nav.getCurrentService()
		subtitle = service and service.subtitle()
		subtitlelist = subtitle and subtitle.getSubtitleList()
		self.selectedSubtitle = None
		if callable(AudioSelection.fillSubtitleExt):
			AudioSelection.fillSubtitleExt(subtitlelist)
		if self.subtitlesEnabled():
			self.selectedSubtitle = self.infobar.selected_subtitle
			if self.selectedSubtitle and self.selectedSubtitle[:4] == (0, 0, 0, 0):
				self.selectedSubtitle = None
			elif subtitlelist is not None and self.selectedSubtitle and not self.selectedSubtitle[:4] in (x[:4] for x in subtitlelist):
				subtitlelist.append(self.selectedSubtitle)
		return subtitlelist

	def subtitlesEnabled(self):
		try:
			return self.infobar.subtitle_window.shown or self.infobar.subtitle_window.externalSubtitleStarted
		except Exception:
			return False

	def enableSubtitle(self, subtitle):
		if self.infobar.selected_subtitle != subtitle:
			self.infobar.enableSubtitle(subtitle)

	def change3DSurround(self, surround_3d):
		config.av.surround_3d.value = surround_3d.value
		config.av.surround_3d.save()
		self.fillList()

	def change3DSurroundSpeaker(self, surround_3d_speaker):
		config.av.surround_3d_speaker.value = surround_3d_speaker.value
		config.av.surround_3d_speaker.save()

	def changeAutoVolume(self, autovolume):
		config.av.autovolume.value = autovolume.value
		config.av.autovolume.save()

	def changePCMMultichannel(self, multichan):
		if multichan.value:
			config.av.pcm_multichannel.setValue(multichan.value)
		else:
			config.av.pcm_multichannel.setValue(False)
		config.av.pcm_multichannel.save()
		self.fillList()

	def changeAC3Downmix(self, downmix):
		config.av.downmix_ac3.setValue(downmix.value)
		if SystemInfo["supportPcmMultichannel"]:
			config.av.pcm_multichannel.setValue(False)
		config.av.downmix_ac3.save()
		if SystemInfo["supportPcmMultichannel"]:
			config.av.pcm_multichannel.save()
		self.fillList()

	def changeAC3DownmixPlus(self, downmix):
		config.av.downmix_ac3plus.setValue(downmix.value)
		config.av.downmix_ac3plus.save()

	def changeDTSDownmix(self, downmix):
		config.av.downmix_dts.setValue(downmix.value)
		config.av.downmix_dts.save()

	def changeDTSHD(self, downmix):
		config.av.dtshd.setValue(downmix.value)
		config.av.dtshd.save()

	def changeAACDownmix(self, downmix):
		config.av.downmix_aac.setValue(downmix.value)
		config.av.downmix_aac.save()

	def changeAACDownmixPlus(self, downmix):
		config.av.downmix_aacplus.setValue(downmix.value)
		config.av.downmix_aacplus.save()

	def changeWMAPro(self, downmix):
		config.av.wmapro.setValue(downmix.value)
		config.av.wmapro.save()

	def setAACTranscode(self, transcode):
		config.av.transcodeaac.setValue(transcode.value)
		config.av.transcodeaac.save()

	def changeBTAudio(self, btaudio):
		config.av.btaudio.value = btaudio.value
		config.av.btaudio.save()

	def syncTimeshiftDelayConfig(self):
		syncTimeshiftDelayConfigWithState(self.session)

	def getTimeshiftDelayDisplay(self):
		initTimeshiftDelayConfig()
		value = config.plugins.audioselection.timeshift_delay.value
		for choice_value, choice_label in TIMESHIFT_DELAY_CHOICES:
			if choice_value == value:
				return choice_label
		return _("Disabled TimeShift")

	def openTimeshiftDelay(self):
		self.session.openWithCallback(self.timeshiftDelayClosed, TimeshiftDelayConfigMenu, self.infobar)

	def timeshiftDelayClosed(self, applied=False):
		if applied:
			self.close(0)

	def changeEDIDChecking(self, edidchecking):
		config.av.bypass_edid_checking.value = edidchecking.value
		config.av.bypass_edid_checking.save()

	def changeMode(self, mode):
		if mode is not None and self.audioChannel:
			self.audioChannel.selectChannel(int(mode.value))

	def changeAudio(self, audio):
		track = int(audio)
		if isinstance(track, int):
			service = self.session.nav.getCurrentService()
			ref = self.session.nav.getCurrentServiceReferenceOriginal()
			ref = ref and eServiceReference(ref)
			if service.audioTracks().getNumberOfTracks() > track:
				self.audioTracks.selectTrack(track)
				if isIPTV(ref):
					self.saveAVDict()

	def keyLeft(self):
		if self.focus == FOCUS_CONFIG:
			ConfigListScreen.keyLeft(self)
		elif self.focus == FOCUS_STREAMS:
			self["streams"].setIndex(0)

	def keyRight(self, config=False):
		if config or self.focus == FOCUS_CONFIG:
			index = self["config"].getCurrentIndex()
			if self.settings.menupage.value == PAGE_AUDIO:
				if self.subtitlelist and index == 0:  # Subtitle selection screen
					self.keyAudioSubtitle()
					self.__updatedInfo()
				elif self["config"].getCurrent()[2]:
					self["config"].getCurrent()[2]()
				else:
					ConfigListScreen.keyRight(self)
			elif self.settings.menupage.value == PAGE_SUBTITLES and self.infobar.selected_subtitle and self.infobar.selected_subtitle != (0, 0, 0, 0):
				if index == 0:  # Audio selection screen
					self.keyAudioSubtitle()
					self.__updatedInfo()
				else:
					self.session.open(QuickSubtitlesConfigMenu, self.infobar)  # sub title config screen
			else:
				ConfigListScreen.keyRight(self)
		if self.focus == FOCUS_STREAMS and self["streams"].count() and config is False:
			self["streams"].setIndex(self["streams"].count() - 1)

	def keyRed(self):
		if self["key_red"].getBoolean():
			self.colorkey(0)
		else:
			return 0

	def keyGreen(self):
		if self["key_green"].getBoolean():
			self.colorkey(1)
		else:
			return 0

	def keyYellow(self):
		if self["key_yellow"].getBoolean():
			self.colorkey(2)
		else:
			return 0

	def keyBlue(self):
		if self["key_blue"].getBoolean():
			self.colorkey(3)
		else:
			return 0

	def keyAudioSubtitle(self):
		if self.settings.menupage.value == PAGE_AUDIO:
			self.settings.menupage.setValue("subtitles")
		else:
			self.settings.menupage.setValue("audio")

	def colorkey(self, idx):
		self["config"].setCurrentIndex(idx)
		self.keyRight(True)

	def keyUp(self):
		if self.focus == FOCUS_CONFIG:
			self["config"].instance.moveSelection(self["config"].instance.moveUp)
		elif self.focus == FOCUS_STREAMS:
			if self["streams"].getIndex() == 0:
				self["config"].instance.setSelectionEnable(True)
				self["streams"].style = "notselected"
				self["config"].setCurrentIndex(len(self["config"].getList()) - 1)
				self.focus = FOCUS_CONFIG
			else:
				self["streams"].selectPrevious()

	def keyDown(self):
		if self.focus == FOCUS_CONFIG:
			if self["config"].getCurrentIndex() < len(self["config"].getList()) - 1:
				self["config"].instance.moveSelection(self["config"].instance.moveDown)
			else:
				self["config"].instance.setSelectionEnable(False)
				self["streams"].style = "default"
				self.focus = FOCUS_STREAMS
		elif self.focus == FOCUS_STREAMS:
			self["streams"].selectNext()

	def volumeUp(self):
		VolumeControl.instance and VolumeControl.instance.volUp()

	def volumeDown(self):
		VolumeControl.instance and VolumeControl.instance.volDown()

	def volumeMute(self):
		VolumeControl.instance and VolumeControl.instance.volMute()

	def keyNumberGlobal(self, number):
		if number <= len(self["streams"].list):
			self["streams"].setIndex(number - 1)
			self.keyOk()

	def keyOk(self):
		if self.focus == FOCUS_STREAMS and self["streams"].list:
			cur = self["streams"].getCurrent()
			ref = self.session.nav.getCurrentServiceReferenceOriginal()
			ref = ref and eServiceReference(ref)
			if self.settings.menupage.value == PAGE_AUDIO and cur[0] is not None:
				self.changeAudio(cur[0])
				self.__updatedInfo()
				self.runHooks(self.TYPE_AUDIO)
			if self.settings.menupage.value == PAGE_SUBTITLES and cur[0] is not None:
				if self.infobar.selected_subtitle and self.infobar.selected_subtitle[:4] == cur[0][:4]:
					if len(cur[0]) > 5 and callable(cur[0][5]):
						cur[0][5](None)
					else:
						self.enableSubtitle(None)
					selectedidx = self["streams"].getIndex()
					self.__updatedInfo()
					self["streams"].setIndex(selectedidx)
					self.runHooks(self.TYPE_SUBTITLE)
				else:
					if len(cur[0]) > 5 and callable(cur[0][5]):
						cur[0][5](cur[0])
					else:
						if self.infobar.selected_subtitle and len(self.infobar.selected_subtitle) > 5:
							self.infobar.selected_subtitle[5](None)
						self.enableSubtitle(cur[0][:5])
					self.__updatedInfo()
				if isIPTV(ref):
					self.saveAVDict()
			self.runHooks(self.TYPE_ALL)
			self.close(0)
		elif self.focus == FOCUS_CONFIG:
			self.keyRight()

	def openAutoLanguageSetup(self):
		if self.protectContextMenu and config.ParentalControl.setuppinactive.value and config.ParentalControl.config_sections.context_menus.value:
			self.session.openWithCallback(self.protectResult, PinInput, pinList=[x.value for x in config.ParentalControl.servicepin], triesEntry=config.ParentalControl.retries.servicepin, title=_("Please enter the correct pin code"), windowTitle=_("Enter pin code"))
		else:
			self.protectResult(True)

	def protectResult(self, answer):
		if answer:
			self.session.open(Setup, "autolanguagesetup")
			self.protectContextMenu = False
		elif answer is not None:
			self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)

	def cancel(self):
		self.close(0)


class TimeshiftDelayConfigMenu(Screen):
	ROW_COUNT = 9

	skin = """
		<screen name="AudioSelectionTimeshiftDelayMenu" position="center,center" size="800,400" title="Timeshift Delay" backgroundColor="black" flags="wfNoBorder">
			<widget name="title_label" position="0,18" size="800,46" font="Regular;36" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row0" position="0,82" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row1" position="0,113" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row2" position="0,144" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row3" position="0,175" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row4" position="0,206" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row5" position="0,237" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row6" position="0,268" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row7" position="0,299" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
			<widget name="row8" position="0,330" size="800,31" font="Regular;29" foregroundColor="white" backgroundColor="black" transparent="1" halign="center" valign="center" />
		</screen>
	"""

	def __init__(self, session, infobar=None):
		Screen.__init__(self, session)
		self.skinName = ["AudioSelectionTimeshiftDelayMenu"]
		initTimeshiftDelayConfig()
		self.infobar = infobar or self.session.infobar
		self.delayTimer = eTimer()
		self.delayTimer.timeout.get().append(self.checkTimeshiftDelay)
		self.delayActive = False
		self.delayTarget = 0.0
		self.delayStartedAt = 0.0
		self.delayUsingServicePosition = False
		self.delay_choices = TIMESHIFT_DELAY_CHOICES
		self.selected_index = 0
		self.top_index = 0

		self["title_label"] = Label(_("Timeshift Delay"))
		for row in range(self.ROW_COUNT):
			self["row%d" % row] = Label("")

		self["actions"] = NumberActionMap(["SetupActions", "ColorActions", "DirectionActions", "InfobarSeekActions", "InfobarTimeshiftActions"], {
			"cancel": self.cancel,
			"ok": self.ok,
			"green": self.ok,
			"red": self.cancel,
			"up": self.keyUp,
			"down": self.keyDown,
			"left": self.keyLeft,
			"right": self.keyRight,
			"seekFwd": self.ignoreSeekAction,
			"seekBack": self.ignoreSeekAction,
			"seekFwdManual": self.ignoreSeekAction,
			"seekBackManual": self.ignoreSeekAction,
			"seekFwdUp": self.ignoreSeekAction,
			"seekBackUp": self.ignoreSeekAction,
			"pauseService": self.ignoreSeekAction,
			"unPauseService": self.ignoreSeekAction,
			"timeshiftStart": self.ignoreSeekAction,
			"timeshiftStop": self.stopTimeshiftDelayByUser,
		}, -1)
		self.setTitle(_("Timeshift Delay"))

		current_value = config.plugins.audioselection.timeshift_delay.value
		for index, choice in enumerate(self.delay_choices):
			if choice[0] == current_value:
				self.selected_index = index
				break
		self.centerCurrentSelection()
		self.updateDelayRows()

	def centerCurrentSelection(self):
		self.top_index = self.selected_index - (self.ROW_COUNT // 2)
		if self.top_index < 0:
			self.top_index = 0
		max_top = len(self.delay_choices) - self.ROW_COUNT
		if max_top < 0:
			max_top = 0
		if self.top_index > max_top:
			self.top_index = max_top

	def updateDelayRows(self):
		for row in range(self.ROW_COUNT):
			index = self.top_index + row
			if index < len(self.delay_choices):
				text = self.delay_choices[index][1]
				if index == self.selected_index:
					text = ">  " + text + "  <"
				self["row%d" % row].setText(text)
			else:
				self["row%d" % row].setText("")

	def keyUp(self):
		if self.selected_index > 0:
			self.selected_index -= 1
		else:
			self.selected_index = len(self.delay_choices) - 1
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyDown(self):
		if self.selected_index < len(self.delay_choices) - 1:
			self.selected_index += 1
		else:
			self.selected_index = 0
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyLeft(self):
		self.selected_index = max(0, self.selected_index - 8)
		self.centerCurrentSelection()
		self.updateDelayRows()

	def keyRight(self):
		last_index = len(self.delay_choices) - 1
		self.selected_index = min(last_index, self.selected_index + 8)
		self.centerCurrentSelection()
		self.updateDelayRows()

	def ok(self):
		choice_value = self.delay_choices[self.selected_index][0]
		config.plugins.audioselection.timeshift_delay.setValue(choice_value)
		config.plugins.audioselection.timeshift_delay.save()
		if choice_value == "off":
			self.disableTimeshiftDelay()
			self.close(True)
		else:
			self.applyTimeshiftDelay(float(choice_value))


	def ignoreSeekAction(self):
		return 0

	def stopTimeshiftDelayByUser(self):
		# When timeshift is stopped from this screen, also reset the menu value.
		setTimeshiftDelayDisabled()
		stopTimeshiftDelayWatchdog()
		self.delayActive = False
		try:
			self.delayTimer.stop()
		except Exception:
			pass
		try:
			self.stopRunningTimeshift()
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] user stop failed: %s" % error)
		self.close(True)

	def forceSeekStatePlay(self):
		try:
			if self.infobar and hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PLAY"):
				self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)
		except Exception:
			pass


	def getTimeshiftRemainingSeconds(self):
		return getTimeshiftRemainingSecondsFromSession(self.session)

	def seekTimeshiftRelative(self, seconds):
		if not seconds:
			return False
		try:
			service = self.session.nav.getCurrentService()
			seek = service and service.seek()
			if not seek:
				return False
			direction = 1
			if seconds < 0:
				direction = -1
				seconds = -seconds
			seek.seekRelative(direction, int(seconds * 90000))
			return True
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] seekRelative failed: %s" % error)
			return False

	def normalizeTimeshiftTarget(self):
		# If another audio plugin already changed the live-timeshift position, correct
		# the current position to the selected target instead of relying on a fixed timer.
		remaining = self.getTimeshiftRemainingSeconds()
		if remaining is None:
			return False

		diff = remaining - self.delayTarget
		if diff > TIMESHIFT_DELAY_TOLERANCE:
			# Current delay is larger than requested. Seek towards live by the difference.
			self.seekTimeshiftRelative(diff)
			self.forceSeekStatePlay()
		return True

	def getCurrentPauseableService(self):
		service = self.session.nav.getCurrentService()
		return service and service.pause()

	def pauseServiceForDelay(self):
		# Reset any active FastForward/Rewind state before starting the delay.
		self.forceSeekStatePlay()

		# Start the live-timeshift buffer if available.
		try:
			if self.infobar and hasattr(self.infobar, "startTimeshift") and callable(self.infobar.startTimeshift):
				self.infobar.startTimeshift()
		except Exception:
			pass

		# Prefer direct service pause/unpause because it does not trigger InfoBar trickmode.
		pauseable = self.getCurrentPauseableService()
		if pauseable:
			try:
				pauseable.pause()
				return True
			except Exception:
				pass

		# Fallback for images where direct pause is not available.
		if self.infobar:
			try:
				if hasattr(self.infobar, "pauseService") and callable(self.infobar.pauseService):
					self.infobar.pauseService()
					return True
			except Exception:
				pass
			try:
				if hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PAUSE"):
					self.infobar.setSeekState(self.infobar.SEEK_STATE_PAUSE)
					return True
			except Exception:
				pass
		return False

	def playServiceAfterDelay(self):
		played = False

		pauseable = self.getCurrentPauseableService()
		if pauseable:
			try:
				pauseable.unpause()
				played = True
			except Exception:
				pass

		if not played and self.infobar:
			try:
				if hasattr(self.infobar, "unPauseService") and callable(self.infobar.unPauseService):
					self.infobar.unPauseService()
					played = True
			except Exception:
				pass
			try:
				if hasattr(self.infobar, "setSeekState") and hasattr(self.infobar, "SEEK_STATE_PLAY"):
					self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)
					played = True
			except Exception:
				pass

		# Final guard: clear any trickmode state left by audio plugins.
		self.forceSeekStatePlay()
		return played

	def stopRunningTimeshift(self):
		# Stop the running timeshift session completely, not only unpause it.
		# Different Enigma2 images expose different APIs, so try the safe methods first.
		stopped = False
		self.forceSeekStatePlay()
		try:
			self.playServiceAfterDelay()
		except Exception:
			pass

		if self.infobar:
			for method_name in ("stopTimeshift", "timeshiftStop"):
				try:
					method = getattr(self.infobar, method_name, None)
					if callable(method):
						method()
						stopped = True
						break
				except Exception as error:
					print("[AudioSelection][TimeshiftDelay] %s failed: %s" % (method_name, error))

		try:
			service = self.session.nav.getCurrentService()
			timeshift = service and service.timeshift()
			if timeshift:
				for method_name in ("stopTimeshift", "stop"):
					try:
						method = getattr(timeshift, method_name, None)
						if callable(method):
							method()
							stopped = True
							break
					except Exception as error:
						print("[AudioSelection][TimeshiftDelay] service.%s failed: %s" % (method_name, error))
		except Exception:
			pass

		# Final professional fallback: if the service still exposes a delayed
		# timeshift position, restart the current service to leave timeshift mode.
		try:
			remaining = self.getTimeshiftRemainingSeconds()
			if remaining is not None and remaining > TIMESHIFT_DELAY_TOLERANCE:
				ref = self.session.nav.getCurrentlyPlayingServiceReference()
				if ref:
					self.session.nav.stopService()
					self.session.nav.playService(ref)
					stopped = True
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] restart service fallback failed: %s" % error)

		self.forceSeekStatePlay()
		return stopped

	def disableTimeshiftDelay(self):
		setTimeshiftDelayDisabled()
		stopTimeshiftDelayWatchdog()
		self.delayActive = False
		self.delayTarget = 0.0
		self.delayStartedAt = 0.0
		self.delayUsingServicePosition = False
		try:
			self.delayTimer.stop()
		except Exception:
			pass
		try:
			self.stopRunningTimeshift()
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] disable failed: %s" % error)

	def applyTimeshiftDelay(self, delay):
		try:
			self.delayTarget = float(delay)
			self.delayStartedAt = time()
			self.delayUsingServicePosition = False
			if self.pauseServiceForDelay():
				self.delayActive = True
				# Poll the real ServicePosition Remaining value. This keeps the selected
				# delay accurate even if AudioPlus/other audio plugins already shifted the
				# timeshift buffer or add their own processing delay.
				self.delayTimer.start(TIMESHIFT_DELAY_POLL_MS, True)
			else:
				setTimeshiftDelayDisabled()
				stopTimeshiftDelayWatchdog()
				self.session.open(MessageBox, _("Timeshift is not available on this service."), MessageBox.TYPE_ERROR, timeout=5)
		except Exception as error:
			setTimeshiftDelayDisabled()
			stopTimeshiftDelayWatchdog()
			print("[AudioSelection][TimeshiftDelay] failed to start delay: %s" % error)
			self.session.open(MessageBox, _("Unable to start timeshift delay."), MessageBox.TYPE_ERROR, timeout=5)

	def checkTimeshiftDelay(self):
		if not self.delayActive:
			return

		remaining = self.getTimeshiftRemainingSeconds()
		if remaining is not None:
			self.delayUsingServicePosition = True
			if remaining + TIMESHIFT_DELAY_TOLERANCE >= self.delayTarget:
				self.finishTimeshiftDelay()
			else:
				diff = self.delayTarget - remaining
				poll_ms = int(diff * 1000)
				if poll_ms < TIMESHIFT_DELAY_POLL_MS:
					poll_ms = TIMESHIFT_DELAY_POLL_MS
				elif poll_ms > 500:
					poll_ms = 500
				self.delayTimer.start(poll_ms, True)
			return

		# Fallback for images that do not expose seek.getPlayPosition/getLength.
		# Keep the old one-second correction only as a fallback, not as the main logic.
		elapsed = time() - self.delayStartedAt
		fallbackTarget = self.delayTarget - TIMESHIFT_DELAY_FALLBACK_CORRECTION
		if fallbackTarget < 0:
			fallbackTarget = 0
		if elapsed >= fallbackTarget:
			self.finishTimeshiftDelay()
		else:
			self.delayTimer.start(TIMESHIFT_DELAY_POLL_MS, True)

	def finishTimeshiftDelay(self):
		self.delayActive = False
		try:
			if self.delayUsingServicePosition:
				self.normalizeTimeshiftTarget()
			self.playServiceAfterDelay()
			self.forceSeekStatePlay()
			if config.plugins.audioselection.timeshift_delay.value != "off":
				startTimeshiftDelayWatchdog(self.session)
		except Exception as error:
			print("[AudioSelection][TimeshiftDelay] failed to finish delay: %s" % error)
		self.close(True)

	def cancel(self):
		if self.delayActive:
			self.delayTimer.stop()
			self.finishTimeshiftDelay()
		else:
			self.close(False)


class SubtitleSelection(AudioSelection):
	def __init__(self, session, infobar=None):
		AudioSelection.__init__(self, session, infobar, page=PAGE_SUBTITLES)
		self.skinName = ["AudioSelection"]


class QuickSubtitlesConfigMenu(ConfigListScreen, Screen):
	FLAG_CENTER_DVB_SUBS = 2048

	def __init__(self, session, infobar):
		Screen.__init__(self, session)
		self.infobar = infobar or self.session.infobar
		self.wait = eTimer()
		self.wait.timeout.get().append(self.resyncSubtitles)
		self.service = self.session.nav.getCurrentlyPlayingServiceReference()
		servicepath = self.service and self.service.getPath()
		if servicepath and servicepath.startswith("/") and self.service.toString().startswith("1:"):
			info = eServiceCenter.getInstance().info(self.service)
			self.service_string = info and info.getInfoString(self.service, iServiceInformation.sServiceref)
		else:
			self.service_string = self.service.toString()
		self.center_dvb_subs = ConfigYesNo(default=(eDVBDB.getInstance().getFlag(eServiceReference(self.service_string)) & self.FLAG_CENTER_DVB_SUBS) and True)
		self.center_dvb_subs.addNotifier(self.setCenterDvbSubs, initial_call=False)
		self["videofps"] = Label("")
		sub = self.infobar.selected_subtitle
		if sub[0] == 0:  # dvb
			menu = [
				getConfigMenuItem("config.subtitles.dvb_subtitles_color"),
				getConfigMenuItem("config.subtitles.dvb_subtitles_backtrans"),
				getConfigMenuItem("config.subtitles.dvb_subtitles_original_position"),
				(_("Center DVB subtitles"), self.center_dvb_subs),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_bad_timing_delay"),
				getConfigMenuItem("config.subtitles.subtitle_noPTSrecordingdelay"),
			]
		elif sub[0] == 1:  # teletext
			menu = [
				getConfigMenuItem("config.subtitles.ttx_subtitle_colors"),
				getConfigMenuItem("config.subtitles.ttx_subtitle_original_position"),
				getConfigMenuItem("config.subtitles.subtitle_fontsize"),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_rewrap"),
				getConfigMenuItem("config.subtitles.subtitle_borderwidth"),
				getConfigMenuItem("config.subtitles.showbackground"),
				getConfigMenuItem("config.subtitles.subtitle_alignment"),
				getConfigMenuItem("config.subtitles.subtitle_bad_timing_delay"),
				getConfigMenuItem("config.subtitles.subtitle_noPTSrecordingdelay"),
			]
		else: 		# pango
			menu = [
				getConfigMenuItem("config.subtitles.pango_subtitles_delay"),
				getConfigMenuItem("config.subtitles.pango_subtitle_colors"),
				getConfigMenuItem("config.subtitles.pango_subtitle_fontswitch"),
				getConfigMenuItem("config.subtitles.colourise_dialogs"),
				getConfigMenuItem("config.subtitles.subtitle_fontsize"),
				getConfigMenuItem("config.subtitles.subtitle_position"),
				getConfigMenuItem("config.subtitles.subtitle_alignment"),
				getConfigMenuItem("config.subtitles.subtitle_rewrap"),
				getConfigMenuItem("config.subtitles.subtitle_borderwidth"),
				getConfigMenuItem("config.subtitles.showbackground"),
				getConfigMenuItem("config.subtitles.pango_subtitle_removehi"),
				getConfigMenuItem("config.subtitles.pango_subtitles_fps"),
			]
			self["videofps"].setText(_("Video: %s fps") % (self.getFps().rstrip(".000")))
		ConfigListScreen.__init__(self, menu, self.session, on_change=self.changedEntry)
		self["actions"] = NumberActionMap(["SetupActions"], {
			"cancel": self.cancel,
			"ok": self.ok,
		}, -2)
		self.onLayoutFinish.append(self.layoutFinished)

	def setCenterDvbSubs(self, configElement):
		if configElement.value:
			eDVBDB.getInstance().addFlag(eServiceReference(self.service_string), self.FLAG_CENTER_DVB_SUBS)
			config.subtitles.dvb_subtitles_centered.value = True
		else:
			eDVBDB.getInstance().removeFlag(eServiceReference(self.service_string), self.FLAG_CENTER_DVB_SUBS)
			config.subtitles.dvb_subtitles_centered.value = False

	def layoutFinished(self):
		if not self["videofps"].text:
			self.instance.resize(eSize(self.instance.size().width(), self["config"].l.getItemSize().height() * len(self["config"].getList()) + 10))

	def changedEntry(self):
		if self["config"].getCurrent() in [getConfigMenuItem("config.subtitles.pango_subtitles_delay"), getConfigMenuItem("config.subtitles.pango_subtitles_fps")]:
			self.wait.start(500, True)

	def resyncSubtitles(self):
		self.infobar.setSeekState(self.infobar.SEEK_STATE_PAUSE)
		self.infobar.setSeekState(self.infobar.SEEK_STATE_PLAY)

	def getFps(self):
		service = self.session.nav.getCurrentService()
		info = service and service.info()
		if not info:
			return ""
		fps = info.getInfo(iServiceInformation.sFrameRate)
		if fps > 0:
			return "%6.3f" % (fps / 1000.0)
		return ""

	def cancel(self):
		self.center_dvb_subs.removeNotifier(self.setCenterDvbSubs)
		self.close()

	def ok(self):
		config.subtitles.save()
		self.close()
