# -*- coding: utf-8 -*-
# Last Modified: 2026-11-04 - custom skins: name="key_green" gets a Label; poster grid grows into a description box right below the list.
# 2026-10-31 - LCD: the layout follows the display size, shows the host's display name and the marked row.
# 2026-07-26 - Updated blue_pressed() and blue_pressed_next(), added YouTube user links actions in the blue menu, and fixed deleteFavouriteItem(); fixed missing key_green label display by correcting the Halidri1080p1 playlist.xml key_green binding and set default green button text to "Download".
# 2026-10-17 - MENU "Select action" follows "Force internal skin" (openChoiceBox): the box skin's ChoiceBox with it off;
#              "Main menu" row of paged lists (OK = EXIT, no INFO); a host's iptv_download_title names the GREEN download.
# 2026-10-12 - CH- after a jump opens the page before (78 -> 77) over the Jump row; EXIT goes a whole list level back over all paged pages.
# 2026-10-10 - batch download: BLUE menu "Download all items of this page" / "Select items to download" (OK marks rows);
#              playVideo()'s folder / free space check moved into _checkDestinationDir(), shared with it.
# 2026-10-10 - list selection + playlist functions (tools/listselection.py): BLUE menu "Play all from here",
#              "Select" / "Select all" (OK marks rows; play / download / add to favourites the marked rows),
#              shuffle / reverse as toggles that can be undone, shown in the header.
# 2026-10-11 - playlist of a run of the sequencer in the movie player (_takePlaylistForPlayer: info line, MENU
#              "Show playlist"; an entry chosen there comes back as ('zap_to', ...) -> zapToRow()).
# IplaPlayer based on SHOUTcast
#
#  $Id$
#
#

from os import path as os_path
import re
import sys
import time
import traceback

####################################################
#                   E2 components
####################################################
from skin import parseColor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, configfile
from Components.Sources.StaticText import StaticText
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Plugins.Extensions.IPTVPlayer.components.iptvlcd import listSummaryIfWanted
from Tools.Directories import fileExists
from Tools.NumericalTextInput import NumericalTextInput
from enigma import eTimer, ePoint, eSize, gFont

####################################################
#                   IPTV components
####################################################
from Plugins.Extensions.IPTVPlayer.components.iptvconfigmenu import ConfigMenu, GetMoviePlayer, GetAvailableMoviePlayers, GetMoviePlayerName, GetListOfHostsNames, GetConfigExpectedPin
from Plugins.Extensions.IPTVPlayer.components.confighost import ConfigHostMenu, ConfigHostsMenu
from Plugins.Extensions.IPTVPlayer.components.iptvdirbrowser import IPTVDirectorySelectorWidget
from Plugins.Extensions.IPTVPlayer.components.configgroups import ConfigGroupsMenu, ConfigGroupFolderMenu

from Plugins.Extensions.IPTVPlayer.components.iptvfavouriteswidgets import IPTVFavouritesAddItemWidget, IPTVFavouritesMainWidget

from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdownloadercreator import IsUrlDownloadable
from Plugins.Extensions.IPTVPlayer.libs.pCommon import CParsingHelper, DescribeImageFile
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs.urlparser import urlparser
from Plugins.Extensions.IPTVPlayer.tools.iptvfavourites import IPTVFavourites, getFavouritesIdentityKeys
from Plugins.Extensions.IPTVPlayer.tools import iptvdownloaded
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import FreeSpace as iptvtools_FreeSpace, \
                                                          mkdirs as iptvtools_mkdirs, IsRealStoragePresent as iptvtools_IsRealStoragePresent, \
                                                          IsPathWritable as iptvtools_IsPathWritable, \
                                                          IsSameDir as iptvtools_IsSameDir, IsSameOrSubDir as iptvtools_IsSameOrSubDir, \
                                                          CleanOldFilesInDir as iptvtools_CleanOldFilesInDir, StartStorageMigrations as iptvtools_StartStorageMigrations, \
                                                          GetIPTVPlayerVersion, GetShortSystemInfo, StripColorCodes, GetHostListTitle, \
                                                          printDBG, printExc, GetHostsList, IsHostEnabled, GetHostTitle, \
                                                          eConnectCallback, GetSkinsDir, GetIconDir, GetPluginDir, \
                                                          SortHostsList, GetHostsOrderList, CSearchHistoryHelper, \
                                                          CMoviePlayerPerHost, GetFavouritesDir, CFakeMoviePlayerOption, GetAvailableIconSize, \
                                                          GetCookieDir, GetJSCacheDir, GetSubtitlesDir, GetMovieMetaDataDir, \
                                                          GetE2VideoMode, SetE2VideoMode, TestTmpCookieDir, TestTmpJSCacheDir, \
                                                          ClearTmpCookieDir, ClearTmpJSCacheDir, SetTmpCookieDir, SetTmpJSCacheDir, \
                                                          GetEnabledHostsList, SaveHostsOrderList, formatBytes, getExcMSG, \
                                                          findT9JumpIndex
from Plugins.Extensions.IPTVPlayer.tools.iptvhostgroups import IPTVHostsGroups, IsFolderKey
from Plugins.Extensions.IPTVPlayer.components.iptvhostpin import AskHostPin, ClearUnlockedHosts, HostNeedsPin, IsHostUnlocked
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvbuffui import E2iPlayerBufferingWidget
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdmapi import IPTVDMApi, DMItem
from Plugins.Extensions.IPTVPlayer.iptvdm import batchdownload
from Plugins.Extensions.IPTVPlayer.tools import listselection
from Plugins.Extensions.IPTVPlayer.tools import linkpicker
from Plugins.Extensions.IPTVPlayer.tools import iptvpaging

from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _, GetIPTVPlayerLastHostError, GetIPTVNotify, GetIPTVSleep

from Plugins.Extensions.IPTVPlayer.components.iptvplayer import IPTVStandardMoviePlayer, IPTVMiniMoviePlayer
from Plugins.Extensions.IPTVPlayer.components.iptvextmovieplayer import IPTVExtMoviePlayer
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinfopanel import fitLabelText, hostDisplayName, linkDisplayName
from Plugins.Extensions.IPTVPlayer.components.iptvpictureplayer import IPTVPicturePlayerWidget
from Plugins.Extensions.IPTVPlayer.components.iptvlist import IPTVLinkChoiceBoxList, IPTVMoviePlayerChoiceBoxList, IPTVActionChoiceBoxList, IPTVPlayerSelectOptionChoiceBoxList
from Plugins.Extensions.IPTVPlayer.components.iptvpostergrid import IPTVPosterGridList
from Plugins.Extensions.IPTVPlayer.components import skinchrome
from Plugins.Extensions.IPTVPlayer.components.iptvarticleview import IPTVArticleView
from Plugins.Extensions.IPTVPlayer.components.ihost import IHost, CDisplayListItem, RetHost, CUrlItem, ArticleContent, CFavItem
from Plugins.Extensions.IPTVPlayer.components.searchhistoryeditor import SearchHistoryEditor
from Plugins.Extensions.IPTVPlayer.components.iconmenager import IconMenager, IconLogName
from Plugins.Extensions.IPTVPlayer.components.cover import Cover, Cover3
from Plugins.Extensions.IPTVPlayer.components.iptvchoicebox import IPTVChoiceBoxWidget, IPTVChoiceBoxItem, openChoiceBox
import Plugins.Extensions.IPTVPlayer.components.asynccall as asynccall
from Plugins.Extensions.IPTVPlayer.components.playerselector import PlayerSelectorWidget
from Plugins.Extensions.IPTVPlayer.components.e2ivkselector import GetVirtualKeyboard
from Plugins.Extensions.IPTVPlayer.components.e2ivk import E2iVKOptionsList, GetKeyHelpItem
from Plugins.Extensions.IPTVPlayer.__init__ import GRIDSUPPORT
######################################################
gDownloadManager = None

# list entries that only page through the list they sit in
PAGER_TYPES = (CDisplayListItem.TYPE_NEXT, CDisplayListItem.TYPE_JUMP, CDisplayListItem.TYPE_FIRST,
               CDisplayListItem.TYPE_PREVIOUS, CDisplayListItem.TYPE_LAST)


class CategoryPathEntry(str):
    # one step of the header path. A pager step (next page, jump, first page ...) adds no name of its own,
    # it only changes the page shown at the end of the path: "Search results > Page: 12", not
    # "Search results > Next page (x3) > Jump > Next page".
    pagerKind = ''
    item = None  # the pager entry chosen - hostxxx sets the page of a jump on it while it lists
    page = None
    last = False
    lastPage = None  # the highest page of the list when the host knows it: "Page: 2/12"


def PagerKind(item):
    # the pager type of a list entry ('' when it is none): the generic hosts use the item type, hostxxx
    # keeps TYPE_CATEGORY and marks its pager entries with the imageType
    kind = getattr(item, 'type', '')
    if kind not in PAGER_TYPES:
        kind = getattr(item, 'imageType', '')
    return kind if kind in PAGER_TYPES else ''


def ListPage(entry, previousPage, items):
    # (page number or None, last page, highest page or None) of a list that was just opened through entry;
    # a list reached by paging that has no "Next page" entry any more is the last page. The highest page
    # comes from the "Next page" entry (lastPage), set only by hosts that know it
    page = _ListPageNumber(entry, previousPage, items)
    nexts = [item for item in items if PagerKind(item) == CDisplayListItem.TYPE_NEXT]
    last = bool(getattr(entry, 'pagerKind', '')) and not nexts
    lastPage = getattr(nexts[0], 'lastPage', None) if nexts else None
    if not (isinstance(lastPage, int) and page and page < lastPage):
        lastPage = None
    return page, last, lastPage


def _ListPageNumber(entry, previousPage, items):
    nextPage = None
    hasNext = False
    for item in items:
        if PagerKind(item) == CDisplayListItem.TYPE_NEXT:
            hasNext = True
            # hostxxx's "Next page" entry knows the page it leads to - also after a jump
            nextPage = getattr(item, 'listPage', None)
            break
    if isinstance(nextPage, int) and 1 < nextPage:
        return nextPage - 1
    kind = getattr(entry, 'pagerKind', '')
    if not kind:
        return 1 if hasNext else None
    target = getattr(getattr(entry, 'item', None), 'listPage', None)
    if isinstance(target, int) and 0 < target:
        return target
    for item in items:
        # a list without "Next page" (its last page, reached by a jump): its own Jump row knows the page
        if PagerKind(item) == CDisplayListItem.TYPE_JUMP and isinstance(getattr(item, 'currentPage', None), int):
            return item.currentPage
    if kind == CDisplayListItem.TYPE_FIRST:
        return 1
    if previousPage and kind == CDisplayListItem.TYPE_NEXT:
        return previousPage + 1
    if previousPage and kind == CDisplayListItem.TYPE_PREVIOUS and 1 < previousPage:
        return previousPage - 1
    return None


def CategoryPath(title, categoryList, pageLabel, lastLabel, maxLen=0, skip=0):
    # the header path: repeated names as "(xN)", pager steps left out, the current page at the end;
    # maxLen > 0 shortens every longer name to maxLen characters, skip > 0 replaces the first skip names
    # with one "…" (the last name always stays)
    def _getCat(cat, num):
        if 0 < maxLen < len(cat):
            cat = cat[:maxLen - 1].rstrip() + '…'
        cat = ' > ' + cat
        if 1 < num:
            cat += (' (x%d)' % num)
        return cat

    cats = []
    for cat in categoryList:
        if getattr(cat, 'pagerKind', '') or '' == cat:
            continue
        if cats and cats[-1][0] == cat:
            cats[-1][1] += 1
        else:
            cats.append([cat, 1])
    skip = min(skip, len(cats) - 1)
    path = title + (' > …' if 0 < skip else '')
    for cat, num in cats[max(skip, 0):]:
        path += _getCat(cat, num)
    entry = categoryList[-1] if categoryList else None
    page = getattr(entry, 'page', None)
    if getattr(entry, 'last', False):
        path += ' > %s %s' % (pageLabel, ('%s (%d)' % (lastLabel, page)) if page else lastLabel)
    elif page and getattr(entry, 'lastPage', None):
        path += ' > %s %d/%d' % (pageLabel, page, entry.lastPage)
    elif page:
        path += ' > %s %d' % (pageLabel, page)
    return path


class E2iPlayerWidget(Screen):
    IPTV_VERSION = GetIPTVPlayerVersion()
    # Stays 720, not grown to match the footer's own height - unlike
    # skinchrome.footer_height()'s own comment describes for its OTHER
    # callers (popups that derive their own window height from this),
    # E2iPlayerWidget is a true fullscreen screen: 720 tiles exactly into
    # every tier's real display height (720x1.0=720, x1.5=1080, x2.0=1440
    # - HD/FHD/WQHD). A fullscreen screen can't just get taller than the
    # physical display - at WQHD a taller declared size scales past the
    # real 1440px-tall screen, and position="center,center" centers with
    # a NEGATIVE offset when oversized, silently clipping pixels off both
    # the top AND the bottom since nothing clamps a Screen to stay within
    # the display. "console" below is sized to end flush with footerY
    # instead of overlapping it.
    HEIGHT = 720
    # item types that are structurally never real host content (pure
    # pagination/action controls, no underlying item to describe) - used
    # by updateDownloadButton()'s INFO visibility check. Deliberately an
    # EXCLUDE list, not an include list of "types that have info" -
    # info_pressed() itself never restricted by type, and which content
    # types actually return article data is host-specific and unknowable
    # without the (real, network) getArticleContent() call itself.
    INFO_NEVER_TYPES = (
        CDisplayListItem.TYPE_MARKER,
        CDisplayListItem.TYPE_MORE,
        CDisplayListItem.TYPE_FIRST,
        CDisplayListItem.TYPE_PREVIOUS,
        CDisplayListItem.TYPE_LAST,
        CDisplayListItem.TYPE_NEXT,
        CDisplayListItem.TYPE_JUMP,
        CDisplayListItem.TYPE_SEARCH_HISTORY_EDITOR,
        CDisplayListItem.TYPE_SEARCH_HISTORY_DELETE,
        CDisplayListItem.TYPE_MMC,
        CDisplayListItem.TYPE_USB,
    )

    @staticmethod
    def _footerSlots(hasMenu, hasPrevNext, hasPlay, hasInfo, downloadable, hasText=False):
        # Single source of truth for the footer's slot-assignment math -
        # shared by __prepareSkin() (build-time initial position) and
        # _repositionFooterKeys() (runtime, on every selection/list
        # change) so the two can never drift into disagreement.
        # Sequence: menu?, nav, num, prevnext?, play?, info?, text?, ok,
        # exit, then red, green?, yellow, blue.
        navSlot = 1 if hasMenu else 0
        numSlot = navSlot + 1
        prevNextSlot = numSlot + 1
        playSlot = prevNextSlot + (1 if hasPrevNext else 0)
        infoSlot = playSlot + (1 if hasPlay else 0)
        textSlot = infoSlot + (1 if hasInfo else 0)
        okSlot = textSlot + (1 if hasText else 0)
        exitSlot = okSlot + 1
        yellowSlot = 1 + (1 if downloadable else 0)
        return {
            'nav': navSlot, 'num': numSlot, 'prevNext': prevNextSlot, 'play': playSlot,
            'info': infoSlot, 'text': textSlot, 'ok': okSlot, 'exit': exitSlot, 'leftIconCount': exitSlot + 1,
            'yellow': yellowSlot, 'blue': yellowSlot + 1,
        }

    def __prepareSkin(self):
        # computed fresh per instance, not at class/module level - a
        # cached "is this FHD" flag would go stale across sessions on
        # different hardware
        iconBase = skinchrome.getIconBase()
        # ALL FOUR color keys are plain name= widgets now (not through
        # build_footer()'s keys=, which only supports a fixed skin-build-
        # time position) - the whole row's start shifts left whenever
        # menu/info are hidden (see _repositionFooterKeys()), on top of
        # yellow/blue's own existing shift when green is hidden.
        # nav/num/prevnext/play/info/ok/exit are plain name= widgets for
        # the same reason - build_footer() below only ever handles MENU
        # itself (showMenu=True, everything else False); every icon after
        # it potentially shifts left depending on which OTHER optional
        # ones (prevnext/play/info) are currently hidden - see
        # _repositionFooterKeys().
        #
        # Built via _footerSlots(False, False, False, False, False) -
        # the screen's TRUE just-constructed state (menu/prevnext/play/
        # info/green all start hidden, see __init__ below), not
        # "everything visible" - so this initial layout already matches
        # what _repositionFooterKeys() would compute for that same state,
        # and nothing looks broken/gapped before the first real
        # updateDownloadButton() call corrects it. Slots for the
        # still-hidden icons (prevnext/play/info/green) are placeholders
        # - any value is fine since updateDownloadButton() always
        # repositions an icon in the same call that first shows it,
        # before the next frame is drawn.
        slots = self._footerSlots(False, False, False, False, False)
        geomRed = skinchrome.colorKeyGeometry(self.HEIGHT, slots['leftIconCount'], 0, 1.0)
        geomGreen = skinchrome.colorKeyGeometry(self.HEIGHT, slots['leftIconCount'], 1, 1.0)
        geomYellow = skinchrome.colorKeyGeometry(self.HEIGHT, slots['leftIconCount'], slots['yellow'], 1.0)
        geomBlue = skinchrome.colorKeyGeometry(self.HEIGHT, slots['leftIconCount'], slots['blue'], 1.0)
        geomNav = skinchrome.leftIconGeometry(self.HEIGHT, slots['nav'], 1.0)
        geomNum = skinchrome.leftIconGeometry(self.HEIGHT, slots['num'], 1.0)
        geomPrevNext = skinchrome.leftIconGeometry(self.HEIGHT, slots['prevNext'], 1.0)
        geomPlay = skinchrome.leftIconGeometry(self.HEIGHT, slots['prevNext'], 1.0)
        geomInfo = skinchrome.leftIconGeometry(self.HEIGHT, slots['prevNext'], 1.0)
        geomText = skinchrome.leftIconGeometry(self.HEIGHT, slots['prevNext'], 1.0)
        geomOk = skinchrome.leftIconGeometry(self.HEIGHT, slots['ok'], 1.0)
        geomExit = skinchrome.leftIconGeometry(self.HEIGHT, slots['exit'], 1.0)
        # header clock/date is an opt-out via
        # config.plugins.iptvplayer.show_header_clock (Skin configuration
        # section) instead of always-on - same toggle covers this screen,
        # PlayerSelectorWidget and IPTVFavouritesMainWidget's own header
        # clocks.
        clockPart = """<widget source="global.CurrentTime" render="Label" position="1100,10" size="150,40" foregroundColor="white" backgroundColor="black" borderWidth="1" borderColor="black" transparent="1" zPosition="2" font="Regular;24" valign="center" halign="right">
                    <convert type="ClockToText">Format:%H:%M</convert>
                </widget>
                <widget source="global.CurrentTime" render="Label" position="860,20" size="300,24" foregroundColor="white" backgroundColor="black" borderWidth="1" borderColor="black" transparent="1" zPosition="2" font="Regular;16" valign="center" halign="right">
                    <convert type="ClockToText">Date</convert>
                </widget>""" if config.plugins.iptvplayer.show_header_clock.value else ""
        return """
        <screen position="center,center" size="1280,%d" resolution="1280,720" backgroundColor="#34111112" flags="wfNoBorder">
                %s
                <widget name="headertext" position="320,70" zPosition="1" size="940,40" font="Regular; 20" transparent="1" halign="left" valign="center" backgroundColor="black" foregroundColor="#178ef5" borderWidth="1" borderColor="black" />
                <widget name="statustext" position="320,230" zPosition="1" size="940,250" font="Regular;30" halign="center" valign="top" transparent="1" backgroundColor="black" foregroundColor="white" />
                <widget name="list" position="320,110" zPosition="2" size="940,384" itemHeight="32" font="Regular;20" scrollbarMode="showOnDemand" scrollbarSliderBorderWidth="1" scrollbarForegroundColor="#1b5a91" scrollbarBorderColor="#00b6b6b6" enableWrapAround="1" transparent="1" foregroundColor="white" backgroundColor="black" foregroundColorSelected="white" backgroundColorSelected="#1b5a91" borderWidth="1" borderColor="black" />
                <widget name="console" position="20,500" zPosition="1" size="1240,154" font="Regular;20" transparent="1" foregroundColor="white" backgroundColor="black" borderWidth="1" borderColor="black" halign="left" valign="center" />
                <widget name="sequencer" position="0,0" zPosition="6" size="1280,%d" font="Regular;160" halign="center" valign="center" transparent="1" backgroundColor="#00000000" />
                <widget name="cover" position="20,70" size="288,420" zPosition="3" alphatest="blend" />
                <widget name="spinner"   zPosition="2" position="758,200" size="16,16" transparent="1" alphatest="blend" />
                <widget name="spinner_1" zPosition="1" position="758,200" size="16,16" transparent="1" alphatest="blend" />
                <widget name="spinner_2" zPosition="1" position="774,200" size="16,16" transparent="1" alphatest="blend" />
                <widget name="spinner_3" zPosition="1" position="790,200" size="16,16" transparent="1" alphatest="blend" />
                <widget name="spinner_4" zPosition="1" position="806,200" size="16,16" transparent="1" alphatest="blend" />
                <!-- a named widget: it moves down together with the poster grid (_onListModeChanged) -->
                <widget name="separator" pixmap="%s/smallshadowline.png" position="20,494" size="1240,2" zPosition="2" />
                <!-- zPosition 2, above the header's own Title label (1) -
                     that label's black background now spans much wider
                     than the old hand-written title box did, and would
                     otherwise sit on top of these clocks -->
                %s
                <widget name="key_red_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_red" position="%d,%d" size="%d,%d" backgroundColor="#000000" font="Regular;%d" foregroundColor="#ffffff" zPosition="2" valign="center" halign="left" transparent="1" />
                <widget name="key_green_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_green" position="%d,%d" size="%d,%d" backgroundColor="#000000" font="Regular;%d" foregroundColor="#ffffff" zPosition="2" valign="center" halign="left" transparent="1" />
                <widget name="key_yellow_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_yellow" position="%d,%d" size="%d,%d" backgroundColor="#000000" font="Regular;%d" foregroundColor="#ffffff" zPosition="2" valign="center" halign="left" transparent="1" />
                <widget name="key_blue_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_blue" position="%d,%d" size="%d,%d" backgroundColor="#000000" font="Regular;%d" foregroundColor="#ffffff" zPosition="2" valign="center" halign="left" transparent="1" />
                <widget name="key_nav_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_num_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_prevnext_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_play_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_info_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_text_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_ok_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                <widget name="key_exit_icon" position="%d,%d" size="%d,%d" zPosition="1" transparent="1" alphatest="blend" />
                %s
        </screen>
        """ % (
            self.HEIGHT,
            skinchrome.build_header_auto(iconBase=iconBase, logoWidgetName="playerlogo"),
            self.HEIGHT,
            iconBase,
            clockPart,
            geomRed['iconX'], geomRed['iconY'], geomRed['iconSize'], geomRed['iconSize'],
            geomRed['labelX'], geomRed['labelY'], geomRed['labelW'], geomRed['labelH'], geomRed['font'],
            geomGreen['iconX'], geomGreen['iconY'], geomGreen['iconSize'], geomGreen['iconSize'],
            geomGreen['labelX'], geomGreen['labelY'], geomGreen['labelW'], geomGreen['labelH'], geomGreen['font'],
            geomYellow['iconX'], geomYellow['iconY'], geomYellow['iconSize'], geomYellow['iconSize'],
            geomYellow['labelX'], geomYellow['labelY'], geomYellow['labelW'], geomYellow['labelH'], geomYellow['font'],
            geomBlue['iconX'], geomBlue['iconY'], geomBlue['iconSize'], geomBlue['iconSize'],
            geomBlue['labelX'], geomBlue['labelY'], geomBlue['labelW'], geomBlue['labelH'], geomBlue['font'],
            geomNav['x'], geomNav['y'], geomNav['w'], geomNav['h'],
            geomNum['x'], geomNum['y'], geomNum['w'], geomNum['h'],
            geomPrevNext['x'], geomPrevNext['y'], geomPrevNext['w'], geomPrevNext['h'],
            geomPlay['x'], geomPlay['y'], geomPlay['w'], geomPlay['h'],
            geomInfo['x'], geomInfo['y'], geomInfo['w'], geomInfo['h'],
            geomText['x'], geomText['y'], geomText['w'], geomText['h'],
            geomOk['x'], geomOk['y'], geomOk['w'], geomOk['h'],
            geomExit['x'], geomExit['y'], geomExit['w'], geomExit['h'],
            # build_footer() directly, not build_footer_auto() - the auto
            # variant hardcodes showMenu=False (none of its other callers
            # bind a menu key), but this screen's own "menu" action is
            # always live and needs its own icon. keys=() - all 4 color
            # keys are the plain name= widgets declared above instead
            # now, so the whole row can slide. Only showMenu left True
            # here - nav/num/prevnext/play/info/ok/exit are all plain
            # name= widgets declared above instead, repositioned (and,
            # for prevnext/play/info, shown/hidden) by
            # _repositionFooterKeys() (num=T9 jump hint, always shown;
            # prevnext=page up/down hint, shown only when either would
            # actually do something; play=auto-play sequencer hint,
            # shown only if a playable item follows in the list).
            skinchrome.build_footer(self.HEIGHT, scale=1.0, iconBase=iconBase, keys=(), showMenu=True, showNav=False, showOk=False, showExit=False),
        )

    def __init__(self, session):
        printDBG("E2iPlayerWidget.__init__ desktop IPTV_VERSION[%s] %s\n" % (E2iPlayerWidget.IPTV_VERSION, GetShortSystemInfo()))
        self.session = session

        self.skin = self.__prepareSkin()
        # tracks whether our own built-in skin above is actually what
        # gets used, or a custom skin folder overwrote it below - the new
        # plain-widget key_yellow/key_blue (see below) only work with our
        # own skin; every shipped custom playlist.xml still expects the
        # older source="key_yellow"/"key_blue" + StaticText binding
        self._usingBuiltinSkin = True
        customSkinXml = ""
        selSkin = config.plugins.iptvplayer.skin.value
        if selSkin:
            path = GetSkinsDir(selSkin) + "/playlist.xml"
            printDBG("Playlist skin path [%s]" % path)
            if fileExists(path):
                try:
                    with open(path, "r") as f:
                        self.skin = f.read()
                    self._usingBuiltinSkin = False
                    # without its comments: a commented-out widget declares nothing
                    customSkinXml = re.sub(r"<!--.*?-->", "", self.skin, flags=re.S)
                except Exception:
                    printExc("Skin read error: " + path)

        Screen.__init__(self, session)
        self.skinName = skinchrome.forceInternalSkinName(["E2iPlayerWidgetScreen", "E2iPlayerWidget"])
        if config.plugins.iptvplayer.skinforceinternal.value:
            self.skinName = "_E2iPlayerWidgetScreen"
        # an active Enigma2 skin shipping its own E2iPlayerWidgetScreen needs
        # the StaticText / no-runtime-.move() footer path (it draws the color
        # keys itself, no key_*_icon widgets for _repositionFooterKeys()).
        # After the force-internal rewrites above so a "_"-prefixed name
        # (which no external skin defines) is correctly seen as internal.
        if self._usingBuiltinSkin and skinchrome.isExternalSkin(self.skinName):
            self._usingBuiltinSkin = False

        self.recorderMode = False  # j00zek
        # selection mode: OK marks / unmarks rows instead of opening them (BLUE menu "Select" / "Select all")
        self.selectMode = False
        # shuffle / reverse of the playable rows (tools/listselection.arrangeRows): the list as the host gave it
        # while the order is changed (None: the order is the original one), the shuffle and the reverse step
        self.listOrderOriginal = None
        self.listShuffleOrder = None
        self.listReversed = False
        self.hostLogoPath = None

        self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()
        if config.plugins.iptvplayer.disable_live.value:
            self.session.nav.stopService()

        if self._usingBuiltinSkin:
            # plain name= widgets, not source="key_red"/"key_green"/
            # "key_yellow"/"key_blue" + ConditionalShowHide - the whole
            # row needs to actually MOVE at runtime (see
            # _repositionFooterKeys()): yellow/blue when green appears/
            # disappears, and the whole row's start when menu/info do
            # too. A Source-bound Renderer isn't addressable by name for
            # .instance.move() the way a plain Label/Cover3 is. Icon
            # pixmaps are set once in onStart() - they're static, never
            # conditionally hidden themselves. Only for our own skin
            # above - every shipped custom playlist.xml still declares
            # source="key_red"/etc, which needs the original StaticText
            # binding below instead.
            self["key_red_icon"] = Cover3()
            self["key_red"] = Label(_("Close"))
            self["key_green_icon"] = Cover3()
            self["key_green"] = Label(_("Download"))
            # starts hidden - self.downloadable starts False (set further
            # below, before any selection exists), updateDownloadButton()
            # shows it once the current item is actually downloadable,
            # consistent with prevnext/play/info below
            self["key_green_icon"].hide()
            self["key_green"].hide()
            self["key_yellow_icon"] = Cover3()
            self["key_yellow"] = Label(_("Refresh"))
            self["key_blue_icon"] = Cover3()
            self["key_blue"] = Label(_("More"))
            # nav/info/ok/exit - same plain name=/Cover3 treatment, so
            # _repositionFooterKeys() can slide them when menu/info are
            # hidden. info starts hidden (.hide()) - updateDownloadButton()
            # shows it once there's a real selection to judge; unlike the
            # others it's not always visible.
            self["key_nav_icon"] = Cover3()
            # T9 jump hint - always shown, same reasoning as nav (browsing
            # a list always makes jump-to-letter potentially useful)
            self["key_num_icon"] = Cover3()
            # page up/down hint - conditional like info, shown only when
            # either key would actually do something
            self["key_prevnext_icon"] = Cover3()
            self["key_prevnext_icon"].hide()
            # auto-play sequencer hint - conditional, shown only if a
            # playable item follows in the list
            self["key_play_icon"] = Cover3()
            self["key_play_icon"].hide()
            self["key_info_icon"] = Cover3()
            self["key_info_icon"].hide()
            # TEXT = poster grid on / off - conditional, shown only for a list that can show as grid
            self["key_text_icon"] = Cover3()
            self["key_text_icon"].hide()
            self["key_ok_icon"] = Cover3()
            self["key_exit_icon"] = Cover3()
            # the line above the description, moved with the poster grid
            self["separator"] = Cover3()
        else:
            # a custom playlist.xml declares a colour key as source="key_x" render="Label" (needs a StaticText)
            # or as a plain name="key_x" widget (needs a Label - a StaticText there is never drawn)
            for key, text in (("key_red", _("Close")), ("key_green", _("Download")), ("key_yellow", _("Refresh")), ("key_blue", _("More"))):
                isNamed = customSkinXml and re.search(r"""<widget\b[^>]*\sname\s*=\s*["']%s["']""" % key, customSkinXml)
                self[key] = Label(text) if isNamed else StaticText(text)
        # menu_pressed() is always bound in self["actions"] below and does
        # something real (per-item context menu) distinct from "Mehr"/blue
        # - needs its own StaticText for the footer's ConditionalShowHide.
        # Starts blank, same as key_green - updateDownloadButton() (called
        # once the list actually has a selection) fills in the real
        # state; not meaningful before that. INFO's own visibility is
        # handled via key_info_icon's .show()/.hide() above instead (it's
        # a plain widget, not a ConditionalShowHide Source, since its
        # position - unlike menu's - also depends on menu's visibility).
        self["key_menu"] = StaticText("")

        self["list"] = IPTVPosterGridList()
        self["list"].connectSelChanged(self.onSelectionChanged)
        self["list"].onModeChanged.append(self._onListModeChanged)
        # the skin's geometry of list, description and the line between them, while the poster grid also uses the
        # cover's place and part of the description's
        self._gridGeometry = None
        # another skin: the description box is shorter while the poster grid grew into it
        self._gridConsoleShortened = False
        self["statustext"] = Label(_("Loading..."))

        self["actions"] = ActionMap(["IPTVPlayerListActions", "ColorActions", "NumberActions"],
        {
            "red": self.red_pressed,
            "green": self.green_pressed,
            "yellow": self.yellow_pressed,
            "blue": self.blue_pressed,
            "ok": self.ok_pressed,
            "back": self.back_pressed,
            "info": self.info_pressed,
            "0": self.ok_pressed0,
            "1": self.keyT9_1,
            "2": self.keyT9_2,
            "3": self.keyT9_3,
            "4": self.keyT9_4,
            "5": self.keyT9_5,
            "6": self.keyT9_6,
            "7": self.keyT9_7,
            "8": self.keyT9_8,
            "9": self.keyT9_9,
            "play": self.startAutoPlaySequencer,
            "menu": self.menu_pressed,
            "tools": self.blue_pressed,
            "record": self.green_pressed,
            "pageUp": self.pageup_pressed,
            "pageDown": self.pagedown_pressed,
            "postergrid": self.togglePosterGrid,
        }, -1)
        # the arrow keys in the poster grid (before the listbox's own ones), only on while a list shows as grid
        # (xxxRepeated: OpenPLi maps the held key to its own action)
        gridList = self["list"]
        self["gridActions"] = ActionMap(["DirectionActions"],
        {
            "up": boundFunction(gridList.moveRow, -1),
            "upRepeated": boundFunction(gridList.moveRow, -1),
            "down": boundFunction(gridList.moveRow, 1),
            "downRepeated": boundFunction(gridList.moveRow, 1),
            "left": boundFunction(gridList.moveColumn, -1),
            "leftRepeated": boundFunction(gridList.moveColumn, -1),
            "right": boundFunction(gridList.moveColumn, 1),
            "rightRepeated": boundFunction(gridList.moveColumn, 1),
        }, -2)
        self["gridActions"].setEnabled(False)

        self["headertext"] = Label()
        self._headerFontsCache = None
        self["console"] = Label()
        self["sequencer"] = Label()

        self["cover"] = Cover()
        self["cover"].hide()
        self["playerlogo"] = Cover()

        try:
            for idx in range(5):
                spinnerName = "spinner"
                if idx:
                    spinnerName += '_%d' % idx
                self[spinnerName] = Cover3()
        except Exception:
            printExc()

        # Check for plugin update
        self.lastPluginVersion = ''
        self.checkUpdateConsole = None

        # per-tier assets (icons/HD|FHD|WQHD), not the flat icons/ root -
        # this spinner's declared "16,16" box gets auto-scaled to
        # 16/24/32 by this screen's own resolution="1280,720", but plain
        # Pixmap widgets never scale their pixmap CONTENT to that box, so
        # the source file itself has to already be the right size (same
        # bug/fix as the legacy grid's page markers in playerselector.py)
        _spinnerIconBase = skinchrome.getIconBase()
        self.spinnerPixmap = [LoadPixmap(_spinnerIconBase + '/radio_button_on.png'), LoadPixmap(_spinnerIconBase + '/radio_button_off.png')]
        self.useAlternativePlayer = False

        # CacheDir on missing storage -> the plugin's own cache/ (with a notice); skipped once already there.
        # Enigma2 refuses session.open() inside __init__: the dialogs are queued and shown from onStart().
        self.startupStorageSteps = []
        storagePathsRerouted = False
        pluginCacheDir = GetPluginDir('cache/')

        # a folder rerouted at an earlier start (storage missing, e.g. the HDD was not mounted yet) goes back to where it
        # was as soon as that storage is there again - unless another folder has been chosen in the meantime
        for pathCfg, wantedCfg, fallbackDir in ((config.plugins.iptvplayer.CacheDir, config.plugins.iptvplayer.CacheDirWanted, pluginCacheDir),
                                                (config.plugins.iptvplayer.bufferingPath, config.plugins.iptvplayer.bufferingPathWanted, config.plugins.iptvplayer.TmpDir.value)):
            wantedDir = wantedCfg.value
            if not wantedDir:
                continue
            if not iptvtools_IsSameDir(pathCfg.value, fallbackDir) and iptvtools_IsRealStoragePresent(pathCfg.value):
                printDBG('Storage: [%s] was chosen after the reroute, [%s] is not restored' % (pathCfg.value, wantedDir))
            elif iptvtools_IsRealStoragePresent(wantedDir):
                printDBG('Storage: storage for [%s] is back -> restored (was [%s])' % (wantedDir, pathCfg.value))
                pathCfg.value = wantedDir
                pathCfg.save()
            else:
                continue
            wantedCfg.value = ''
            wantedCfg.save()
            storagePathsRerouted = True

        if not iptvtools_IsSameDir(config.plugins.iptvplayer.CacheDir.value, pluginCacheDir) and not iptvtools_IsRealStoragePresent(config.plugins.iptvplayer.CacheDir.value):
            self.startupStorageSteps.append(lambda nextStep: self.session.openWithCallback(nextStep, MessageBox, _("No storage found for the cache folder. The cache folder will be switched to the plugin's own cache directory."), type=MessageBox.TYPE_INFO, timeout=10))
            if not os_path.exists(pluginCacheDir):
                iptvtools_mkdirs(pluginCacheDir)
            printDBG('Storage: CacheDir [%s] has no real storage -> rerouted to plugin cache [%s]' % (config.plugins.iptvplayer.CacheDir.value, pluginCacheDir))
            if not config.plugins.iptvplayer.CacheDirWanted.value:
                config.plugins.iptvplayer.CacheDirWanted.value = config.plugins.iptvplayer.CacheDir.value
                config.plugins.iptvplayer.CacheDirWanted.save()
            config.plugins.iptvplayer.CacheDir.value = pluginCacheDir
            config.plugins.iptvplayer.CacheDir.save()
            storagePathsRerouted = True

        # bufferingPath is scratch space: silently fall back to TmpDir
        if not iptvtools_IsSameDir(config.plugins.iptvplayer.bufferingPath.value, config.plugins.iptvplayer.TmpDir.value) and not iptvtools_IsRealStoragePresent(config.plugins.iptvplayer.bufferingPath.value):
            printDBG('Storage: bufferingPath [%s] has no real storage -> rerouted to TmpDir [%s]' % (config.plugins.iptvplayer.bufferingPath.value, config.plugins.iptvplayer.TmpDir.value))
            # a folder in RAM (/tmp or below) is no place to come back to
            if not config.plugins.iptvplayer.bufferingPathWanted.value and not iptvtools_IsSameOrSubDir(config.plugins.iptvplayer.bufferingPath.value, '/tmp/'):
                config.plugins.iptvplayer.bufferingPathWanted.value = config.plugins.iptvplayer.bufferingPath.value
                config.plugins.iptvplayer.bufferingPathWanted.save()
            config.plugins.iptvplayer.bufferingPath.value = config.plugins.iptvplayer.TmpDir.value
            config.plugins.iptvplayer.bufferingPath.save()
            storagePathsRerouted = True

        if storagePathsRerouted:
            configfile.save()

        # DownloadsDir holds real downloads: never guess a new place, ask. Once the user has chosen one, only require it to be writable
        downloadsDir = config.plugins.iptvplayer.DownloadsDir.value
        if downloadsDir == config.plugins.iptvplayer.NaszaSciezka.value:
            downloadsDirOk = iptvtools_IsRealStoragePresent(downloadsDir)
        else:
            downloadsDirOk = iptvtools_IsPathWritable(downloadsDir)
        printDBG('Storage: DownloadsDir [%s] usable=%s' % (downloadsDir, downloadsDirOk))
        if not downloadsDirOk:
            def _askDownloadsDir(nextStep):
                def _setDownloadsDir(newPath):
                    printDBG('Storage: downloads directory picker returned [%s]' % newPath)
                    if newPath is not None:
                        config.plugins.iptvplayer.DownloadsDir.value = newPath
                        config.plugins.iptvplayer.DownloadsDir.save()
                        configfile.save()
                    nextStep()

                def _openPicker(ret=None):
                    # no real storage left at the configured place: start where the mounted disks are
                    startDir = config.plugins.iptvplayer.DownloadsDir.value
                    if not iptvtools_IsRealStoragePresent(startDir):
                        startDir = '/media/' if os_path.isdir('/media/') else '/'
                    self.session.openWithCallback(_setDownloadsDir, IPTVDirectorySelectorWidget, currDir=startDir, title=_("Select directory"))

                self.session.openWithCallback(_openPicker, MessageBox, _("No storage found for the downloads location. Where would you like to save your downloads?"), type=MessageBox.TYPE_INFO)

            self.startupStorageSteps.append(_askDownloadsDir)

        printDBG('Storage: effective folders CacheDir[%s] ConfigDir[%s] TmpDir[%s] DownloadsDir[%s] bufferingPath[%s]' % (
            config.plugins.iptvplayer.CacheDir.value, config.plugins.iptvplayer.ConfigDir.value, config.plugins.iptvplayer.TmpDir.value,
            config.plugins.iptvplayer.DownloadsDir.value, config.plugins.iptvplayer.bufferingPath.value))
        # user data still in the old folders is moved in the background; until it is done the old folders are used
        iptvtools_StartStorageMigrations()

        for cacheDirFunc, deleteAfterDays in (
            (GetCookieDir, config.plugins.iptvplayer.cookiesCacheDeleteAfterDays.value),
            (GetJSCacheDir, config.plugins.iptvplayer.jsCacheDeleteAfterDays.value),
            (GetSubtitlesDir, config.plugins.iptvplayer.subtitlesCacheDeleteAfterDays.value),
            (GetMovieMetaDataDir, config.plugins.iptvplayer.movieMetaDataCacheDeleteAfterDays.value),
        ):
            if deleteAfterDays > 0:
                cleanDir = cacheDirFunc()
                printDBG('Storage: auto-cleanup of [%s] files older than %s day(s)' % (cleanDir, deleteAfterDays))
                asynccall.AsyncMethod(iptvtools_CleanOldFilesInDir)(cleanDir, deleteAfterDays)

        self.showMessageNoFreeSpaceForIcon = False
        self.iconMenager = None
        if config.plugins.iptvplayer.showcover.value:
            if not os_path.exists(config.plugins.iptvplayer.CacheDir.value):
                iptvtools_mkdirs(config.plugins.iptvplayer.CacheDir.value)

            if iptvtools_FreeSpace(config.plugins.iptvplayer.CacheDir.value, 10):
                self.iconMenager = IconMenager(downloadNew=True)
            else:
                self.showMessageNoFreeSpaceForIcon = True
                self.iconMenager = IconMenager(downloadNew=False)
            self.iconMenager.setUpdateCallBack(self.checkIconCallBack)
            self["list"].setPosterSource(self.getCoverPathOfUrl, self.posterNotShown, Cover.getErrorCoverPath())
        self.showHostsErrorMessage = True

        self.onClose.append(self.__onClose)
        # self.onLayoutFinish.append(self.onStart)
        self.onShow.append(self.onStart)
        self.onShown.append(self.updateLcdItem)

        # Defs
        self.searchPattern = CSearchHistoryHelper.loadLastPattern()[1]
        self.searchType = None
        self.workThread = None
        self.group = None
        self.groupDisplayName = None
        # own folder of the group that is open ("folder:<id>", iptvhostgroups.py), None: the group itself
        self.folder = None
        self.groupObj = None
        self.host = None
        self.hostName = ''
        self.hostTitle = ''
        self.hostFavTypes = []

        self.nextSelIndex = 0
        self.currSelIndex = 0

        self.prevSelList = []
        self.categoryList = []

        self.currList = []
        self.currItem = CDisplayListItem()
        self.favouritesCurrentGroupId = ''

        # global (not per-host) memory of the last selected search-history entry,
        # see _rememberHistorySelection()/_restoreHistorySelection()
        self._lastHistorySelection = None
        self._isLoadingList = False

        self.visible = True
        self.bufferSize = config.plugins.iptvplayer.requestedBuffSize.value * 1024 * 1024

        #################################################################
        #                      Inits for Proxy Queue
        #################################################################

        # register function in main Queue
        if None is asynccall.gMainFunctionsQueueTab[0]:
            asynccall.gMainFunctionsQueueTab[0] = asynccall.CFunctionProxyQueue(self.session)
        asynccall.gMainFunctionsQueueTab[0].clearQueue()
        asynccall.gMainFunctionsQueueTab[0].setProcFun(self.doProcessProxyQueueItem)

        # main Queue
        self.mainTimer = eTimer()
        self.mainTimer_conn = eConnectCallback(self.mainTimer.timeout, self.processProxyQueue)
        # every 100ms Proxy Queue will be checked
        self.mainTimer_interval = 100
        self.mainTimer.start(self.mainTimer_interval, True)

        # delayed decode cover timer
        self.decodeCoverTimer = eTimer()
        self.decodeCoverTimer_conn = eConnectCallback(self.decodeCoverTimer.timeout, self.doStartCoverDecode)
        self.decodeCoverTimer_interval = 100
        # a local (file://) picture the loader could not show: its red X is not in the IconMenager's failed list,
        # so updateCover() needs to know which item asked for it
        self.localCoverErrorIcon = None

        # delayed footer-keys timer - same debounce idea as decodeCoverTimer
        # above: onSelectionChanged()
        # calls updateDownloadButton() on every single up/down keypress,
        # which calls _getMenuOptions() -> host.getCustomActions() (a
        # real host method call, documented "NON BLOCKING" but not "free")
        # for every intermediate row scrolled past, not just the one the
        # user actually stops on - noticeable lag on a host whose
        # getCustomActions() does real work. Restarting a single-shot
        # timer on every selection change (same pattern as
        # decodeCoverTimer) coalesces a fast scroll into one real
        # updateDownloadButton() call once the selection settles, instead
        # of once per row passed over.
        self.footerKeysTimer = eTimer()
        self.footerKeysTimer_conn = eConnectCallback(self.footerKeysTimer.timeout, self.updateDownloadButton)
        self.footerKeysTimer_interval = 100
        # _repositionFooterKeys() memoization guard - see that method's
        # own comment
        self._lastFooterKeyFlags = None

        # spinner timer
        self.spinnerTimer = eTimer()
        self.spinnerTimer_conn = eConnectCallback(self.spinnerTimer.timeout, self.updateSpinner)
        self.spinnerTimer_interval = 200
        self.spinnerEnabled = False

        #################################################################

        #################################################################
        #                      Inits for IPTV Download Manager
        #################################################################
        global gDownloadManager
        if None is gDownloadManager:
            from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdmui import GetIPTVDMNotification
            GetIPTVDMNotification().dialogInit(session)
            printDBG('============Initialize Download Menager============')
            gDownloadManager = IPTVDMApi(2, int(config.plugins.iptvplayer.IPTVDMMaxDownloadItem.value), GetIPTVDMNotification)
            if config.plugins.iptvplayer.IPTVDMRunAtStart.value:
                gDownloadManager.runWorkThread()
        # transient state for the "Select link" screen: the full list of mirrors
        # currently shown (so a resolve failure can reopen it with the failed one
        # marked) and the mirror currently being resolved. Both reset naturally
        # whenever a fresh mirror list is fetched from the host.
        self._currentLinkOptions = None
        self._resolvingLinkItem = None
        # what INFO in the player names: the mirror being resolved, the name of the link played
        self._playLinkMirror = ''
        self._playLinkName = ''
        # "Select link automatically": the mirrors still to try when resolving or playing the current
        # one fails, how many the run started with (status line "Trying link 2 of 5"), the whole mirror
        # list and its video key (the quality list of a resolved mirror replaces both) and the mirror
        # being tried. _autoLinkQuietPlayer: the open player hides an error before playback starts.
        self._autoLinkQueue = []
        self._autoLinkTotal = 0
        self._autoLinkMirrors = None
        self._autoLinkVideoKey = ''
        self._autoLinkCurrent = None
        self._autoLinkQuietPlayer = False
        # keys of the mirrors chosen / failed to resolve since the host was opened (the
        # list is fetched anew each time): the picker shows them with a check badge and
        # dimmed text / red with the error badge. Cleared in loadHost(). See _linkMarkKeys().
        self._usedLinkUrls = set()
        self._failedLinkUrls = set()
        self._currentLinkVideoKey = ''
        # Auto playing sequencer
        self.autoPlaySeqStarted = False
        # "Play marked items": the sequencer plays only the rows marked in the selection mode
        self.autoPlayMarkedOnly = False
        # rows (_getRowIdentity) the running sequencer has played: ticked in the player's playlist overlay
        self.autoPlayPlayedKeys = set()
        # zap waiting for the MarkItemAsViewed answer (leaveMoviePlayer): zapToItem() direction or the
        # player's ('zap_to', ...) answer of its playlist overlay (zapToRow)
        self.pendingZap = 0
        # a zapped item is starting while live TV is off (restoreLiveAfterZap)
        self.zapLivePending = False
        # idle screensaver over every E2iPlayer screen (iptvscreensaver.py), started in onStart()
        self.menuScreenSaver = None
        self.autoPlaySeqTimer = eTimer()
        self.autoPlaySeqTimer_conn = eConnectCallback(self.autoPlaySeqTimer.timeout, self.autoPlaySeqTimerCallBack)
        self.autoPlaySeqTimerValue = 0

        self.activePlayer = None
        self.canRandomizeList = False

        self.prevVideoMode = None
        # with the 1 s timeout (like PlayerSelector and Enigma2's movie list):
        # every press still jumps at once, the timer only restarts the key at
        # "a" after a pause - so 2, pause, 2 steps through the entries with A.
        # Without it the key just cycles a b c ... 2 A B C and never gets past
        # the first match of a letter.
        # Separate instances per list context: before the timeout
        # NumericalTextInput only resets its letter-cycle position when a
        # DIFFERENT digit is pressed, so sharing one instance between the
        # search-history and main-list T9 jump would leak cycle state across
        # a quick list switch (e.g. pressing '2' in the history list, then
        # '2' again in the main list, would resume the cycle at 'b' instead
        # of restarting at 'a').
        self.t9HistoryInput = NumericalTextInput()
        self.t9MainListInput = NumericalTextInput()

        # before the cache dir test: its warning popup must know it runs on the main thread
        asynccall.SetMainThreadId()

        # test if path for js and cookies temporary files
        # is writable, without this plugin can not works
        try:
            TestTmpCookieDir()
            TestTmpJSCacheDir()
            ClearTmpCookieDir()
            ClearTmpJSCacheDir()
        except Exception as e:
            SetTmpCookieDir()
            SetTmpJSCacheDir()
            msg1 = _("Critical Error - cookie can't be saved!")
            msg2 = _("Last error:\n%s") % str(e)
            msg3 = _("Please make sure that the folder for cache data (set in the configuration) is writable.")
            GetIPTVNotify().push('%s\n\n%s\n\n%s' % (msg1, msg2, msg3), 'error', 20)

        self.statusTextValue = ""
        self.enabledHostsListOld = []

        self.downloadable = False
        self.colorEnabled = parseColor("#FFFFFF")
        self.colorDisabled = parseColor("#808080")

    # end def __init__(self, session):

    def updateDownloadButton(self):
        # despite the name, this now keeps every footer key that depends
        # on the currently selected item in sync - green/info/menu are
        # only ever meaningful for some items, same idea, called from the
        # same set of "selection or list content changed" call sites
        self.downloadable = False
        item = None
        try:
            if self["list"].visible:
                item = self.getSelItem()
                # empty list (e.g. host group selector open): nothing selected
                self.downloadable = item is not None and self.isDownloadableType(item.type)
                if self.downloadable and item.urlItems and item.urlItems[0].url.startswith('file://'):  # workaround for LocalMedia
                    self.downloadable = False
        except Exception:
            printExc()

        if self._usingBuiltinSkin:
            if self.downloadable:
                self["key_green_icon"].show()
                self["key_green"].show()
            else:
                self["key_green_icon"].hide()
                self["key_green"].hide()
        else:
            self["key_green"].setText(_("Download") if self.downloadable else "")

        # INFO: cheap, local item-type check only, no network request -
        # getArticleContent() (what INFO actually triggers) does one, so
        # it can't be test-called here the way MENU's getCustomActions()
        # can (that one's explicitly documented "NON BLOCKING" in
        # ihost.py). info_pressed() itself never restricted by type
        # either - a category folder CAN return real article content on
        # some hosts, so this only excludes
        # types that are structurally never real content at all (pure
        # pagination/action controls, no underlying host item) rather
        # than guessing which content types have article support.
        hasInfo = item is not None and item.type not in self.INFO_NEVER_TYPES and getattr(item, 'imageType', '') != iptvpaging.MENU_IMAGE_TYPE
        if self._usingBuiltinSkin:
            # plain widget, not a ConditionalShowHide Source - its own
            # position depends on MENU too, so it's shown/hidden and
            # positioned together in _repositionFooterKeys() below
            if hasInfo:
                self["key_info_icon"].show()
            else:
                self["key_info_icon"].hide()

        # PAGE UP/DOWN (CH+ next page, CH- page back): same exact
        # conditions pageup_pressed()/pagedown_pressed() themselves check
        # - cheap, local, no network. Both no-op while the list itself is
        # hidden - without that check here the icon could stay shown
        # while the key would silently do nothing, e.g. mid-spinner.
        hasPrevNext = self._canPage() and bool(self.currList) and (
            -1 < self._pagerIndex(CDisplayListItem.TYPE_NEXT) or self._previousPageStep()[0] is not None
        )
        if self._usingBuiltinSkin:
            if hasPrevNext:
                self["key_prevnext_icon"].show()
            else:
                self["key_prevnext_icon"].hide()

        # PLAY: same scan autoPlaySequencerNext(False) itself does when
        # startAutoPlaySequencer() calls it (from the current selection
        # forward, inclusive, for the first playable type) - cheap,
        # local, no network
        hasPlay = False
        idx = self.getSelIndex()
        if -1 != idx:
            for i in range(idx, len(self.currList)):
                if self.currList[i].type in (CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_PICTURE, CDisplayListItem.TYPE_MORE):
                    hasPlay = True
                    break
        if self._usingBuiltinSkin:
            if hasPlay:
                self["key_play_icon"].show()
            else:
                self["key_play_icon"].hide()

        # MENU: safe to actually build the real option list here (see
        # _getMenuOptions()'s own comment) - guarantees this can never
        # show/hide differently than what pressing the key would do
        hasMenu = len(self._getMenuOptions()) > 0
        self["key_menu"].setText(_("Menu") if hasMenu else "")

        # TEXT: poster grid on / off - only where it changes something (thumbnails on, a list with pictures)
        hasText = self.iconMenager is not None and self["list"].postersInList
        if self._usingBuiltinSkin:
            if hasText:
                self["key_text_icon"].show()
            else:
                self["key_text_icon"].hide()

        self._repositionFooterKeys(hasMenu, hasPrevNext, hasPlay, hasInfo, hasText)

    def _repositionFooterKeys(self, hasMenu, hasPrevNext, hasPlay, hasInfo, hasText=False):
        # ConditionalShowHide only hides a widget in place, it never
        # reflows the others - covers both clusters that can shrink here:
        # gray menu/nav/num/prevnext/play/info/ok/exit and the red/green/
        # yellow/blue color keys, which start right after the gray
        # cluster ends and ALSO shift on their own when green is hidden.
        # Only MENU can stay a fixed-slot
        # ConditionalShowHide widget (build_footer()'s showMenu=True) -
        # nothing ever appears before it, so it never needs to move; NUM
        # is always shown too, but its own slot still depends on MENU, so
        # it still needs repositioning like everything after it. Real
        # (already-scaled) height/scale needed here,
        # unlike __prepareSkin()'s HD-reference numbers - resolution=
        # auto-scaling only ever applies to declared skin XML, never to a
        # later .move() call. Only applies to our own skin - a custom
        # skin folder's key_* widgets are the original StaticText/
        # ConditionalShowHide ones, with no key_*_icon at all.
        if not self._usingBuiltinSkin:
            return
        if None is self["key_nav_icon"].instance:
            # not laid out yet - updateDownloadButton() can run before
            # onLayoutFinish via the initial list population; the skin's
            # own declared position already matches the "everything
            # visible" default, so there's nothing to correct yet
            return
        # memoization guard: self.downloadable affects this layout too
        # (green key slot/color-key start offset below), not just the 4
        # parameters - cache all 5 together and
        # skip the geometry recompute + ~10 .move() calls entirely when
        # none of them actually changed since the last call. Scrolling
        # through a run of same-type items (e.g. one folder) otherwise
        # redid this on every row for no visible effect.
        flags = (hasMenu, hasPrevNext, hasPlay, hasInfo, hasText, self.downloadable)
        if flags == self._lastFooterKeyFlags:
            return
        self._lastFooterKeyFlags = flags
        scale = skinchrome.getScale()
        height = skinchrome.scalePixels(self.HEIGHT, scale)

        # gray cluster: menu(fixed) / nav / num(always) / prevnext
        # (optional) / play(optional) / info(optional) / ok / exit -
        # slot math shared with __prepareSkin() via _footerSlots(), see
        # its own comment
        slots = self._footerSlots(hasMenu, hasPrevNext, hasPlay, hasInfo, self.downloadable, hasText)
        geomNav = skinchrome.leftIconGeometry(height, slots['nav'], scale)
        geomNum = skinchrome.leftIconGeometry(height, slots['num'], scale)
        geomOk = skinchrome.leftIconGeometry(height, slots['ok'], scale)
        geomExit = skinchrome.leftIconGeometry(height, slots['exit'], scale)
        self["key_nav_icon"].instance.move(ePoint(geomNav['x'], geomNav['y']))
        self["key_num_icon"].instance.move(ePoint(geomNum['x'], geomNum['y']))
        self["key_ok_icon"].instance.move(ePoint(geomOk['x'], geomOk['y']))
        self["key_exit_icon"].instance.move(ePoint(geomExit['x'], geomExit['y']))
        if hasPrevNext:
            geomPrevNext = skinchrome.leftIconGeometry(height, slots['prevNext'], scale)
            self["key_prevnext_icon"].instance.move(ePoint(geomPrevNext['x'], geomPrevNext['y']))
        if hasPlay:
            geomPlay = skinchrome.leftIconGeometry(height, slots['play'], scale)
            self["key_play_icon"].instance.move(ePoint(geomPlay['x'], geomPlay['y']))
        if hasInfo:
            geomInfo = skinchrome.leftIconGeometry(height, slots['info'], scale)
            self["key_info_icon"].instance.move(ePoint(geomInfo['x'], geomInfo['y']))
        if hasText:
            geomText = skinchrome.leftIconGeometry(height, slots['text'], scale)
            self["key_text_icon"].instance.move(ePoint(geomText['x'], geomText['y']))

        # color keys: how many gray icons actually precede them (4 fixed
        # - nav/num/ok/exit - plus menu/prevnext/play/info if currently
        # shown) decides where the whole row starts; red/yellow/blue
        # always show, green only if downloadable - same "slide into the
        # gap" idea as the gray cluster above, one level further right
        leftIconCount = slots['leftIconCount']
        geomRed = skinchrome.colorKeyGeometry(height, leftIconCount, 0, scale)
        geomYellow = skinchrome.colorKeyGeometry(height, leftIconCount, slots['yellow'], scale)
        geomBlue = skinchrome.colorKeyGeometry(height, leftIconCount, slots['blue'], scale)
        self["key_red_icon"].instance.move(ePoint(geomRed['iconX'], geomRed['iconY']))
        self["key_red"].instance.move(ePoint(geomRed['labelX'], geomRed['labelY']))
        self["key_yellow_icon"].instance.move(ePoint(geomYellow['iconX'], geomYellow['iconY']))
        self["key_yellow"].instance.move(ePoint(geomYellow['labelX'], geomYellow['labelY']))
        self["key_blue_icon"].instance.move(ePoint(geomBlue['iconX'], geomBlue['iconY']))
        self["key_blue"].instance.move(ePoint(geomBlue['labelX'], geomBlue['labelY']))
        if self.downloadable:
            geomGreen = skinchrome.colorKeyGeometry(height, leftIconCount, 1, scale)
            self["key_green_icon"].instance.move(ePoint(geomGreen['iconX'], geomGreen['iconY']))
            self["key_green"].instance.move(ePoint(geomGreen['labelX'], geomGreen['labelY']))

    def setStatusTex(self, msg):
        self.statusTextValue = msg
        self["statustext"].setText(msg)

    def __del__(self):
        printDBG("E2iPlayerWidget.__del__")

    def __onClose(self):
        # a PIN protected host asks again on the next start
        ClearUnlockedHosts()
        if self.menuScreenSaver is not None:
            self.menuScreenSaver.close()
            self.menuScreenSaver = None
        self.session.nav.playService(self.currentService)
        self["list"].disconnectSelChanged(self.onSelectionChanged)
        if None is not self.checkUpdateConsole:
            self.checkUpdateConsole.terminate()
        if None is not self.iconMenager:
            self.iconMenager.setUpdateCallBack(None)
            self.iconMenager.clearDQueue()
            self.iconMenager = None
        self.mainTimer_conn = None
        self.mainTimer = None
        self.decodeCoverTimer_conn = None
        self.decodeCoverTimer = None
        self.spinnerTimer_conn = None
        self.spinnerTimer = None
        self.footerKeysTimer_conn = None
        self.footerKeysTimer = None

        try:
            self.stopAutoPlaySequencer()
            self.autoPlaySeqTimer_conn = None
            self.autoPlaySeqTimer = None
        except Exception:
            printExc()

        try:
            asynccall.gMainFunctionsQueueTab[0].setProcFun(None)
            asynccall.gMainFunctionsQueueTab[0].clearQueue()
            with open("/proc/sys/vm/drop_caches", "w") as f:
                f.write("1")
        except Exception:
            printExc()
        self.activePlayer = None
        self.stopTorrServer()

    def stopTorrServer(self):
        # only the TorrServer E2iPlayer started, and not while the download manager still fetches from it
        if not config.plugins.iptvplayer.torrserver_stop_on_exit.value:
            return
        try:
            from Plugins.Extensions.IPTVPlayer.libs import torrserver
            baseUrl = torrserver.getBaseUrl()
            if gDownloadManager is not None and any(str(item.url).startswith(baseUrl) for item in gDownloadManager.queueUD + gDownloadManager.queueDQ):
                return
            torrserver.stopOwnServer()
        except Exception:
            printExc()

    def isPlayableType(self, type):
        if type in [CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_ARTICLE, CDisplayListItem.TYPE_PICTURE]:
            return True
        else:
            return False

    def isDownloadableType(self, type):
        if type in [CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_DATA]:
            return True
        else:
            return False

    def loadSpinner(self):
        try:
            if "spinner" in self:
                self["spinner"].setPixmap(self.spinnerPixmap[0])
                for idx in range(4):
                    spinnerName = 'spinner_%d' % (idx + 1)
                    self[spinnerName].setPixmap(self.spinnerPixmap[1])
        except Exception:
            printExc()

    def showSpinner(self):
        if None is not self.spinnerTimer:
            self._setSpinnerVisibility(True)
            self.spinnerTimer.start(self.spinnerTimer_interval, True)

    def hideSpinner(self):
        self._setSpinnerVisibility(False)

    def _setSpinnerVisibility(self, visible=True):
        self.spinnerEnabled = visible
        try:
            if "spinner" in self:
                for idx in range(5):
                    spinnerName = "spinner"
                    if idx:
                        spinnerName += '_%d' % idx
                    self[spinnerName].visible = visible
        except Exception:
            printExc()

    def updateSpinner(self):
        try:
            if self.spinnerEnabled and None is not self.workThread:
                if self.workThread.isAlive():
                    timeout = GetIPTVSleep().getTimeout()
                    if timeout > 0:
                        if timeout > 1:
                            msg = _("wait %s seconds") % timeout
                        else:
                            msg = _("wait %s second") % timeout
                        msg = '%s (%s)' % (self.statusTextValue, msg)
                        self["statustext"].setText(msg)
                    else:
                        self["statustext"].setText(self.statusTextValue)

                    if "spinner" in self:
                        x, y = self["spinner"].getPosition()
                        x += self["spinner"].getWidth()
                        if x > self["spinner_4"].getPosition()[0]:
                            x = self["spinner_1"].getPosition()[0]
                        self["spinner"].setPosition(x, y)
                    if None is not self.spinnerTimer:
                        self.spinnerTimer.start(self.spinnerTimer_interval, True)
                        return
                elif not self.workThread.isFinished():
                    # marks the spot in the debug log: the host's traceback is right above this line
                    printDBG('=' * 60 + '\nEXCEPTION ABOVE - host "%s" crashed\n' % self.hostName + '=' * 60)
                    self.handleHostError()
            self.hideSpinner()
        except Exception:
            printExc()

    def handleHostError(self):
        # A failed host must not leave the UI busy or open a dialog during a screen transition.
        self.workThread = None
        self._isLoadingList = False
        self.hideSpinner()
        self.stopAutoPlaySequencer()
        iptvpaging.presetJumpPage(None)
        self["list"].hide()
        message = _('It seems that the host "%s" has crashed.') % self.hostName
        message += "\n" + _("Press EXIT to return to the previous menu.")
        self.setStatusTex(message)
        self.updateDownloadButton()

    def leaveCrashedHost(self, ret=None):
        # the old report server is gone - the dialog only points to the issue tracker
        try:
            self.workThread = None
            self.prevSelList = []
            self.back_pressed()
        except Exception:
            printExc()

    def processIPTVNotify(self, callbackArg1=None, callbackArg2=None):
        if not getattr(self.session, "in_exec", True):
            self.processProxyQueue()
            return
        try:
            notifyObj = GetIPTVNotify()
            if not notifyObj.isEmpty():
                notification = notifyObj.pop()
                if notification:
                    typeMap = {
                        'info': MessageBox.TYPE_INFO,
                        'error': MessageBox.TYPE_ERROR,
                        'warning': MessageBox.TYPE_WARNING,
                    }
                    self.session.openWithCallback(self.processIPTVNotify, MessageBox, notification.message, type=typeMap.get(notification.type, MessageBox.TYPE_INFO), timeout=notification.timeout)
                    return
        except Exception:
            printExc()
        self.processProxyQueue()

    def processProxyQueue(self):
        if None is not self.mainTimer:
            if not getattr(self.session, "in_exec", True):
                self.mainTimer.start(self.mainTimer_interval, True)
                return
            status = GetIPTVNotify().popStatus()
            if status and self.isInWorkThread():
                self.setStatusTex(status)
            funName = asynccall.gMainFunctionsQueueTab[0].peekClientFunName()
            notifyObj = GetIPTVNotify()
            if funName is not None and notifyObj is not None and not notifyObj.isEmpty() and funName in ['showArticleContent', 'selectMainVideoLinks', 'selectResolvedVideoLinks', 'reloadList']:
                self.processIPTVNotify()
            else:
                try:
                    asynccall.gMainFunctionsQueueTab[0].processQueue()
                except Exception:
                    printExc()
                finally:
                    # without the restart no further host list would ever arrive
                    if None is not self.mainTimer:
                        self.mainTimer.start(self.mainTimer_interval, True)
        return

    def doProcessProxyQueueItem(self, item):
        hostResult = False
        try:
            hostResult = item.retValue[0] is not None and self.workThread == item.retValue[0]
            if None is item.retValue[0] or self.workThread == item.retValue[0]:
                if isinstance(item.retValue[1], asynccall.CPQParamsWrapper):
                    getattr(self, item.clientFunName)(*item.retValue[1])
                else:
                    getattr(self, item.clientFunName)(item.retValue[1])
            else:
                printDBG('doProcessProxyQueueItem callback from old workThread[%r][%s]' % (self.workThread, item.retValue))
        except Exception:
            printExc()
            if hostResult:
                self.handleHostError()

    def getArticleContentCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("showArticleContent", [thread, ret])

    def selectHostVideoLinksCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("selectMainVideoLinks", [thread, ret])

    def getResolvedURLCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("selectResolvedVideoLinks", [thread, ret])

    def callbackGetList(self, addParam, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("reloadList", [thread, {'add_param': addParam, 'ret': ret}])

    def _requestAbortedList(self):
        # EXIT cut a list call off: a host with getAbortedList() (hostxxx: the global search over many sites) may list
        # what it found until then; nothing to show (ERROR) keeps "Operation aborted!" and the hidden list as before
        getAbortedList = getattr(self.host, 'getAbortedList', None)
        if callable(getAbortedList):
            self.workThread = asynccall.AsyncMethod(getAbortedList, self._abortedListCallback, True)()

    def _abortedListCallback(self, thread, ret):
        if ret is not None and ret.status == RetHost.OK and ret.value:
            self.callbackGetList({}, thread, ret)

    # method called from IconMenager when a new icon has been dowlnoaded
    def checkIconCallBack(self, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("displayIcon", [None, ret])

    def isInWorkThread(self):
        return None is not self.workThread and (not self.workThread.isFinished() or self.workThread.isAlive())

    def red_pressed(self):
        self.stopAutoPlaySequencer()
        self.selectHost()
        return

    def green_pressed(self):
        self.stopAutoPlaySequencer()
        self.updateDownloadButton()
        self.recorderMode = self.downloadable
        if self.downloadable:
            self.ok_pressed('green')

    def yellow_pressed(self):
        self.stopAutoPlaySequencer()
        self.getRefreshedCurrList()
        return

    def blue_pressed(self):
        # For Keyboard test
        # if False:
        # from Plugins.Extensions.IPTVPlayer.components.e2ivksuggestion import AutocompleteSearch
        # from Plugins.Extensions.IPTVPlayer.suggestions.google import SuggestionsProvider
        # self.session.open(GetVirtualKeyboard(), additionalParams={'autocomplete':AutocompleteSearch(SuggestionsProvider(True))})
        # return

        # For subtitles test
        if False:
            from Plugins.Extensions.IPTVPlayer.components.iptvsubdownloader import IPTVSubDownloaderWidget
            self.session.open(IPTVSubDownloaderWidget, params={'movie_title': 'elementary s02e03'})
            return

        self.stopAutoPlaySequencer()
        if self.host is None or self.activePlayer is None:  # no host loaded (loadHost() failed)
            return
        options = []

        canAddUserLink = False
        try:
            currSelIndex = self._getSelHostIndex()
            if currSelIndex > -1 and hasattr(self.host, 'canAddToUserLinks') and self.host.canAddToUserLinks(currSelIndex):
                canAddUserLink = True
        except Exception:
            printExc()

        if canAddUserLink:
            options.append((_("Add to User Links"), "ADD_USER_LINK"))
            if hasattr(self.host, 'editUserLinks'):
                options.append((_("Edit User Links"), "EDIT_USER_LINKS"))

        if -1 < self.canByAddedToFavourites()[0]:
            options.append((_("Add item to favorites"), "ADD_FAV"))
            options.append((_("Edit favorites"), "EDIT_FAV"))
        elif 'favourites' == self.hostName:
            options.append((_("Edit favorites"), "EDIT_FAV"))
            options.append((_("Remove from favorites"), "DELETE_FAV"))

        if not canAddUserLink:
            try:
                if hasattr(self.host, 'editUserLinks'):
                    options.append((_("Edit User Links"), "EDIT_USER_LINKS"))
            except Exception:
                printExc()

        if None is not self.activePlayer.get('player', None):
            title = _('Change active movie player')
        else:
            title = _('Set active movie player')
        options.append((title, "SetActiveMoviePlayer"))

        # list functions: play from here, selection mode (OK marks rows) and what to do with the marked rows,
        # shuffle / reverse (toggles), batch download
        try:
            options.extend(self._getListFunctionOptions())
        except Exception:
            printExc()

        # the poster grid on / off for every list (also the TEXT key) - only with thumbnails
        if self.iconMenager is not None:
            gridOn = config.plugins.iptvplayer.poster_grid.value
            options.append((_("Poster grid off") if gridOn else _("Poster grid on"), "POSTER_GRID"))

        self._hostActions = []
        # every host has settings: at least its PIN protection
        options.append((_("Configure host"), "HostConfig"))
        try:
            host = __import__('Plugins.Extensions.IPTVPlayer.hosts.host' + self.hostName, globals(), locals(), ['GetHostActions'], 0)
            if hasattr(host, 'GetHostActions'):
                self._hostActions = host.GetHostActions()
                for i, action in enumerate(self._hostActions):
                    options.append((action[0], f"HostAction:{i}"))
        except Exception:
            printExc()
        if hasattr(self.host.host, 'history'):
            options.append((_("Edit search history"), "EditSearchHistory"))
        options.append((_("Download manager"), "IPTVDM"))
        # free-text jump inside the list currently on screen (a browsing aid
        # like the T9 letter-jump, but matches anywhere in the title) - never
        # re-queries the host, just moves the selection
        if self.visible and len(self.currList) > 1 and not self.isInWorkThread() and self["list"].getVisible():
            options.append((_("Find item"), "FIND_ENTRY"))
        # only reachable through here - INFO (what keyHelp() binds
        # directly to on e2ivk.py's on-screen keyboard) already opens the
        # article view on this screen, so Help has no other entry point
        options.append((_("Help"), "HELP"))
        options.append((_("Exit"), "CLOSE"))
        # Reuses _getMoviePlayerPickerHeight()/footerMargin=136, the exact
        # same pair this class's own sibling popups
        # (SetActiveMoviePlayer/"Select link"/"Select action") already use
        # for a plain, un-iconed options list of varying length.
        # list_class=IPTVPlayerSelectOptionChoiceBoxList - see that
        # class's own comment - most rows now get an icon instead of
        # plain text.
        choiceItems = [IPTVChoiceBoxItem(name=opt[0], privateData=opt[1]) for opt in options]
        height = self._getMoviePlayerPickerHeight(len(choiceItems))
        openChoiceBox(self.session, {'width': 600, 'height': height, 'current_idx': 0, 'title': _("Select option"), 'options': choiceItems, 'list_class': IPTVPlayerSelectOptionChoiceBoxList, 'chrome': True, 'footerMargin': 136}, self.blue_pressed_next)

    def pause_pressed(self):
        printDBG('pause_pressed')
        self.stopAutoPlaySequencer()

    def startAutoPlaySequencer(self, markedOnly=False):
        # markedOnly: "Play marked items" - only the rows marked in the selection mode, in the list order
        if not self.autoPlaySeqStarted:
            self.autoPlaySeqStarted = True
            self.autoPlayMarkedOnly = markedOnly
            self.autoPlayPlayedKeys = set()
            self.autoPlaySequencerNext(False)

    def stopAutoPlaySequencer(self):
        if self.autoPlaySeqStarted:
            if not config.plugins.iptvplayer.disable_live.value:
                self.session.nav.playService(self.currentService)

            if config.plugins.iptvplayer.autoplay_start_delay.value == 0:
                self.showWindow()

            self.autoPlaySeqTimer.stop()
            self["sequencer"].setText("")
            self.autoPlaySeqStarted = False
            self.autoPlayMarkedOnly = False
            self.autoPlayPlayedKeys = set()
            return True
        return False

    def autoPlaySequencerNext(self, goToNext=True):
        if not self.autoPlaySeqStarted:
            printDBG("ERROR in autoPlaySequencerNext - sequencer stopped")
            return

        idx = self.getSelIndex()
        if -1 != idx:
            # find next playable item
            if goToNext:
                idx += 1
                if config.plugins.iptvplayer.autoplay_start_delay.value == 0:
                    self.hideWindow()

            idx = listselection.nextPlayRow(self.currList, idx, self._canSequencerPlay, self.autoPlayMarkedOnly)
            if -1 != idx:
                self["list"].moveToIndex(idx)
                self.sequencerPressOK()
                return
        self.stopAutoPlaySequencer()

    def _canSequencerPlay(self, item):
        # a row the sequencer opens (MORE: it loads the next items and goes on with them)
        return item.type in (CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_PICTURE, CDisplayListItem.TYPE_MORE) and not self._itemNeedsPin(item)

    def _isPlaylistRow(self, item):
        # a row of the player's playlist: what the sequencer plays on this page (MORE only loads the next one)
        return item.type != CDisplayListItem.TYPE_MORE and self._canSequencerPlay(item)

    def _takePlaylistForPlayer(self):
        # during a run of the sequencer: the playlist the movie player shows (info line, playlist overlay -
        # tools/listselection.buildPlaylist), and the row starting now counts as played from here on.
        # None outside a run: the player looks as without the sequencer.
        if not self.autoPlaySeqStarted:
            return None
        playlist = None
        idx = self.getSelIndex()
        if -1 < idx:
            try:
                playlist = listselection.buildPlaylist(self.currList, idx, self._isPlaylistRow, self._getRowIdentity, self.autoPlayMarkedOnly, self.listShuffleOrder is not None, self.listReversed, self.autoPlayPlayedKeys)
                self.autoPlayPlayedKeys.add(self._getRowIdentity(self.currList[idx]))
            except Exception:
                printExc()
        return playlist

    def sequencerPressOK(self):
        self.autoPlaySeqTimerValue = config.plugins.iptvplayer.autoplay_start_delay.value

        if self.autoPlaySeqTimerValue == 0:
            self.ok_pressed('sequencer')
        else:
            self["sequencer"].setText(str(self.autoPlaySeqTimerValue))
            self.autoPlaySeqTimer.start(1000)

    def autoPlaySeqTimerCallBack(self):
        self.autoPlaySeqTimerValue -= 1
        if self.autoPlaySeqTimerValue > 0:
            self["sequencer"].setText(str(self.autoPlaySeqTimerValue))
        else:
            self["sequencer"].setText("")
            self.autoPlaySeqTimer.stop()
            self.ok_pressed('sequencer')

    def checkAutoPlaySequencer(self):
        if self.autoPlaySeqStarted:
            self.autoPlaySequencerNext()
            return True
        return False

    def blue_pressed_next(self, ret):
        # ret is an IPTVChoiceBoxItem (not a plain (label, id) tuple) -
        # adapted back into the same (label, id) shape right here instead
        # of touching every ret[1] reference below (this method never
        # reads ret[0]/the label).
        if ret:
            ret = (None, ret.privateData)
            if ret[1] == "IPTVDM":
                self.runIPTVDM()
            elif ret[1] == "HELP":
                self.keyHelp()
            elif ret[1] == "POSTER_GRID":
                self.togglePosterGrid()
            elif ret[1] == "CLOSE":
                self.close()
            elif ret[1] == "HostConfig":
                self.runConfigHostIfAllowed()
            elif ret[1] == "SetActiveMoviePlayer":
                options = []
                options.append(IPTVChoiceBoxItem(_("Auto selection based on the settings"), "", {}))
                if config.plugins.iptvplayer.moviePlayerPickerMode.value == 'extended':
                    # every actually available player directly, not just
                    # whatever the two configured "default"/"alternative"
                    # slots resolve to - those often both land on the two
                    # external players (auto always prefers them when
                    # present), so mini/standard were never reachable here
                    # without changing Settings first
                    for buffering in (True, False):
                        for playerKey in GetAvailableMoviePlayers():
                            player = CFakeMoviePlayerOption(playerKey, GetMoviePlayerName(playerKey))
                            # keep the original combined msgid ("[%s] with/
                            # without buffering"), not a split "with
                            # buffering" + "[%s] %s" - 14 locales already
                            # have real translations for this exact string,
                            # splitting it would silently orphan every one
                            label = _("[%s] with buffering") % player.getText() if buffering else _("[%s] without buffering") % player.getText()
                            options.append(IPTVChoiceBoxItem(label, "", {'buffering': buffering, 'player': player}))
                else:
                    # "standard": only the 4 configured default/alternative
                    # slots, same as before the "extended" mode existed
                    for buffering, useAlternativePlayer in ((True, False), (True, True), (False, False), (False, True)):
                        player = self.getMoviePlayer(buffering, useAlternativePlayer)
                        label = _("[%s] with buffering") % player.getText() if buffering else _("[%s] without buffering") % player.getText()
                        options.append(IPTVChoiceBoxItem(label, "", {'buffering': buffering, 'player': player}))

                currIdx = -1
                for idx in range(len(options)):
                    try:
                        if options[idx].privateData.get('buffering', None) == self.activePlayer.activePlayer.get('buffering', None) and options[idx].privateData.get('player', CFakeMoviePlayerOption('', '')).value == self.activePlayer.activePlayer.get('player', CFakeMoviePlayerOption('', '')).value:
                            currIdx = idx
                    except Exception:
                        printExc()
                    if idx == currIdx:
                        options[idx].type = IPTVChoiceBoxItem.TYPE_ON
                    else:
                        options[idx].type = IPTVChoiceBoxItem.TYPE_OFF

                height = self._getMoviePlayerPickerHeight(len(options))
                # 136: same derivation as the keyboard's language picker -
                # the list starts at y=66 in the chrome skin's reference
                # space, and "e-N" sizes against the full container height,
                # not reduced by that 66 first, so footerMargin needs to be
                # >= 66 + 64 (footer height, see skinchrome.py's
                # build_footer() 2-line-wrap comment) = 130
                # just to end flush with the footer; the chrome default of
                # 166 leaves a visible ~36px reference-space gap above it
                openChoiceBox(self.session, {'width': self.MOVIE_PLAYER_PICKER_WIDTH, 'height': height, 'current_idx': currIdx, 'title': _("Select movie player"), 'options': options, 'list_class': IPTVMoviePlayerChoiceBoxList, 'chrome': True, 'footerMargin': 136}, self.setActiveMoviePlayer)
            elif ret[1] == 'ADD_FAV':
                currSelIndex = self.canByAddedToFavourites()[0]
                self.requestListFromHost('ForFavItem', currSelIndex, '')
            elif ret[1] == 'EDIT_FAV':
                self.session.openWithCallback(self.editFavouritesCallback, IPTVFavouritesMainWidget)
            elif ret[1] == 'DELETE_FAV':
                self.session.openWithCallback(self.deleteFavouriteItem, MessageBox, _('Definitely remove from favorites?'), type=MessageBox.TYPE_YESNO, timeout=10)
            elif ret[1] == 'ADD_USER_LINK':
                try:
                    currSelIndex = self._getSelHostIndex()
                    if currSelIndex > -1 and hasattr(self.host, 'addToUserLinks'):
                        self.host.addToUserLinks(self.session, currSelIndex)
                except Exception:
                    printExc()
            elif ret[1] == 'EDIT_USER_LINKS':
                try:
                    if hasattr(self.host, 'editUserLinks'):
                        self.host.editUserLinks(self.session)
                except Exception:
                    printExc()
            elif ret[1] in self.LIST_FUNCTION_IDS:
                self._runListFunction(ret[1])
            elif ret[1] == 'EditSearchHistory':
                try:
                    historyFile = self.host.host.history.PATH_FILE
                except Exception:
                    printExc()
                    historyFile = ''
                if historyFile:
                    self.session.open(SearchHistoryEditor, historyFile=historyFile, reverseForDisplay=True, reverseForWrite=True)
                else:
                    self.session.open(MessageBox, _('Search history is not available for this host.'), type=MessageBox.TYPE_ERROR, timeout=5)
            elif ret[1] == 'FIND_ENTRY':
                self._openFindEntry()
            elif ret[1].startswith("HostAction:"):
                try:
                    idx = int(ret[1].split(":")[1])
                    if hasattr(self, '_hostActions') and idx < len(self._hostActions):
                        self._hostActions[idx][1](self.session)
                except Exception:
                    printExc()

    def _openFindEntry(self):
        # local filter over self.currList - opens the virtual keyboard, then
        # jumps straight to the hit (or shows a picker when several match)
        if not (self.visible and len(self.currList) > 1 and not self.isInWorkThread() and self["list"].getVisible()):
            return
        caps = {}
        virtualKeyboard = GetVirtualKeyboard(caps)
        if caps.get('has_additional_params'):
            self.session.openWithCallback(self._findEntryCallback, virtualKeyboard, title=_("Find item"), text='', additionalParams={'is_search': True})
        else:
            self.session.openWithCallback(self._findEntryCallback, virtualKeyboard, title=_("Find item"), text='')

    def _findEntryCallback(self, text=None):
        if not text:
            return
        query = text.strip().lower()
        if not query:
            return
        matches = []
        for idx, item in enumerate(self.currList):
            name = getattr(item, 'name', '') or ''
            if query in name.lower():
                matches.append((name, idx))
        if not matches:
            self.session.open(MessageBox, _("No matching entries found."), type=MessageBox.TYPE_INFO, timeout=5)
            return
        if len(matches) == 1:
            self["list"].moveToIndex(matches[0][1])
            return
        choiceItems = [IPTVChoiceBoxItem(name=name, privateData=idx) for name, idx in matches]
        height = self._getMoviePlayerPickerHeight(len(choiceItems))
        openChoiceBox(self.session, {'width': 600, 'height': height, 'current_idx': 0, 'title': _("Matching entries"), 'options': choiceItems, 'list_class': IPTVPlayerSelectOptionChoiceBoxList, 'chrome': True, 'footerMargin': 136}, self._findEntryResultCallback)

    def _findEntryResultCallback(self, ret):
        if ret is None:
            return
        try:
            idx = ret.privateData
            if isinstance(idx, int) and 0 <= idx < len(self.currList):
                self["list"].moveToIndex(idx)
        except Exception:
            printExc()

    def keyHelp(self):
        # same read-only icon+explanation list pattern as e2ivk.py's own
        # keyHelp() - only reachable via Mehr/BLUE here, not bound directly
        # to INFO like e2ivk.py does, since INFO already opens the
        # article view on this screen.
        iconBase = skinchrome.getIconBase()

        def icon(name):
            return LoadPixmap(iconBase + '/%s.png' % name)

        options = [
            GetKeyHelpItem('ok', _("open / play the selected item"), icon('ok')),
            GetKeyHelpItem('exit', _("go back / close"), icon('exit')),
            GetKeyHelpItem('red', _("back to host/group selection"), icon('red')),
            GetKeyHelpItem('green', _("download the selected item"), icon('green')),
            GetKeyHelpItem('yellow', _("refresh the current list"), icon('yellow')),
            GetKeyHelpItem('blue', _("more options (this menu)"), icon('blue')),
            GetKeyHelpItem('menu', _("item actions (favorites, host-specific actions)"), icon('menu')),
            GetKeyHelpItem('info', _("show more details about the selected item"), icon('info')),
            GetKeyHelpItem('num', _("jump to items starting with that letter, or launch a specific player directly"), icon('key_0-9')),
            GetKeyHelpItem('updown', _("next page / previous page"), icon('key_updown')),
            GetKeyHelpItem('play', _("start auto-play (plays through the list automatically)"), icon('play')),
        ]
        if self.iconMenager is not None:
            options.append(GetKeyHelpItem('text', _("poster grid on / off"), LoadPixmap(GetIconDir('PictureItem.png'))))
        height = self._getOptionsPickerHeight(len(options))
        self.session.open(IPTVChoiceBoxWidget, {'width': 900, 'height': height, 'current_idx': 0, 'title': _("Help"), 'options': options, 'list_class': E2iVKOptionsList, 'selectable': False, 'chrome': True})

    def deleteFavouriteItem(self, confirmed=False):
        printDBG("E2iPlayerWidget.deleteFavouriteItem")
        if confirmed is False:
            return

        if self.visible and not self.isInWorkThread() and 'favourites' == self.hostName:
            currSelIndex = self.getSelIndex()
            if currSelIndex < 0:
                return

            groupId = self.favouritesCurrentGroupId
            printDBG("deleteFavouriteItem groupId[%s] currSelIndex[%d]" % (groupId, currSelIndex))

            try:
                helper = IPTVFavourites(GetFavouritesDir())
                if not helper.load():
                    self.session.open(MessageBox, _('Error loading favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
                    return

                groups = helper.getGroups()
                _norm = self._normFavouriteGroupName

                if not groupId:
                    selItem = self.getSelItem()
                    selTitle = ''
                    try:
                        selTitle = selItem.name
                    except Exception:
                        printExc()

                    groupIdx = -1
                    for idx in range(len(groups)):
                        group = groups[idx]
                        if not isinstance(group, dict):
                            continue
                        if group.get('title', '') == selTitle or _norm(group.get('title', '')) == _norm(selTitle):
                            groupId = group.get('group_id', '')
                            groupIdx = idx
                            break

                    if not groupId or groupIdx < 0:
                        self.session.open(MessageBox, _('Favorite group not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
                        return

                    if not helper.delGroup(groupId):
                        self.session.open(MessageBox, helper.getLastError(), type=MessageBox.TYPE_ERROR, timeout=5)
                        return

                    if not helper.save():
                        self.session.open(MessageBox, _('Error saving favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
                        return

                    # the active host object (Favourites in hostfavourites.py) keeps its own
                    # helper instance loaded once at entry - reload it too, otherwise it still
                    # shows the old state after leaving/re-entering the screen (getPrevList()
                    # only pops a cached list, it never re-reads from disk)
                    try:
                        if hasattr(self.host, 'host') and hasattr(self.host.host, 'helper'):
                            self.host.host.helper.load()
                    except Exception:
                        printExc()

                    del self.currList[currSelIndex]
                    self["list"].setList([(x,) for x in self.currList])

                    if len(self.currList) <= currSelIndex:
                        currSelIndex = len(self.currList) - 1
                    if currSelIndex >= 0:
                        self["list"].moveToIndex(currSelIndex)

                    self.changeBottomPanel()
                    self.updateDownloadButton()
                    return

                realGroupId = self._getFavouritesGroupId(groups, groupId)
                if not realGroupId:
                    self.session.open(MessageBox, _('Favorite group not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
                    return

                self._deleteFavouriteRows(helper, realGroupId, [self.currList[currSelIndex]])
            except Exception:
                printExc()
                self.session.open(MessageBox, _('Error deleting favorite item.'), type=MessageBox.TYPE_ERROR, timeout=5)

    @staticmethod
    def _normFavouriteGroupName(txt):
        try:
            txt = str(txt).strip().lower()
        except Exception:
            return ''
        txt = txt.replace('_', ' ')
        txt = ' '.join(txt.split())
        return txt

    @classmethod
    def _getFavouritesGroupId(cls, groups, groupId):
        # the stored group id of the group that is open (favouritesCurrentGroupId may be its title), '' if unknown
        _norm = cls._normFavouriteGroupName
        for group in groups:
            if not isinstance(group, dict):
                continue

            tmpGroupId = group.get('group_id', '')
            tmpTitle = group.get('title', '')

            if tmpGroupId == groupId or tmpTitle == groupId:
                return tmpGroupId
            if _norm(tmpTitle) == _norm(groupId) or _norm(tmpGroupId) == _norm(groupId):
                return tmpGroupId
        return ''

    def _getRowHostIndex(self, row, pos):
        # the row's index in the host list - not its place pos in a shuffled / reversed list
        hostIdx = getattr(row, 'itemIdx', -1)
        return hostIdx if -1 < hostIdx else pos

    def _deleteFavouriteRows(self, helper, realGroupId, rows):
        # removes the stored favourites of rows (rows of the current list inside a favourites group) from the
        # group realGroupId of the loaded helper, saves and drops the rows from the list.
        # "Remove from favorites" (one row) and "Remove marked items from favourites". -> number removed, -1 on error
        sts, groupItems = helper.getGroupItems(realGroupId)
        if not sts:
            self.session.open(MessageBox, _('Favorite group not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1

        # the row position is not the storage position once the group is shown sorted or
        # carries the virtual "newest videos" row - ask the host which stored favourite it is
        favHost = getattr(self.host, 'host', None)
        entries = []  # (storage position, row)
        for row in rows:
            pos = self._getListPos(row)
            if pos < 0:
                continue
            storageIdx = self._getRowHostIndex(row, pos)
            if hasattr(favHost, 'getGroupItemIdx'):
                storageIdx = favHost.getGroupItemIdx(storageIdx)
            if 0 <= storageIdx < len(groupItems) and storageIdx not in [entry[0] for entry in entries]:
                entries.append((storageIdx, row))
        if not entries:
            self.session.open(MessageBox, _('Favorite item not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1

        # highest storage position first: the positions of the others stay valid (in the file and in the host's rows)
        entries.sort(key=lambda entry: entry[0], reverse=True)
        helper.delGroupItems([(realGroupId, entry[0]) for entry in entries])

        if not helper.save():
            self.session.open(MessageBox, _('Error saving favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1

        # the active host object (Favourites in hostfavourites.py) keeps its own helper instance loaded once at
        # entry - keep its state in sync with the file
        try:
            if hasattr(self.host, 'host') and hasattr(self.host.host, 'helper'):
                self.host.host.helper.load()
        except Exception:
            printExc()

        selPos = self.getSelIndex()
        selRow = self.currList[selPos] if 0 <= selPos < len(self.currList) else None
        for storageIdx, row in entries:
            pos = self._getListPos(row)
            if pos < 0:
                continue
            # keep the host's raw rows (row position + storage position) in step with the display list; the
            # host index is read again for every row: _removeListRow() moves up the rows behind a removed one
            if hasattr(favHost, 'onGroupItemDeleted'):
                favHost.onGroupItemDeleted(self._getRowHostIndex(row, pos), storageIdx)
            self._removeListRow(pos)
        self["list"].setList([(x,) for x in self.currList])

        # the selected row where it still is, else the row that took its place
        newPos = selPos
        if selRow is not None:
            selRowPos = self._getListPos(selRow)
            if -1 < selRowPos:
                newPos = selRowPos
        if len(self.currList) <= newPos:
            newPos = len(self.currList) - 1
        if newPos >= 0:
            self["list"].moveToIndex(newPos)

        self.changeBottomPanel()
        self.updateDownloadButton()
        return len(entries)

    def _getListPos(self, row):
        # place of the row object in the current list, -1 when it is not there (any more)
        for pos, item in enumerate(self.currList):
            if item is row:
                return pos
        return -1

    def editFavouritesCallback(self, ret=False):
        if ret and 'favourites' == self.hostName:  # we must reload host
            self.loadHost()

    def setActiveMoviePlayer(self, ret):
        if not isinstance(ret, IPTVChoiceBoxItem):
            return
        self.activePlayer.set(ret.privateData)

    def runIPTVDM(self, callback=None):
        if None is not gDownloadManager:
            from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdmui import IPTVDMWidget
            if None is callback:
                self.session.open(IPTVDMWidget, gDownloadManager)
            else:
                self.session.openWithCallback(callback, IPTVDMWidget, gDownloadManager)
        elif None is not callback:
            callback()
        return

    def displayIcon(self, ret=None, doDecodeCover=False):
        # check if displays icon is enabled in options
        if not config.plugins.iptvplayer.showcover.value or None is self.iconMenager:
            return
        if self["list"].gridMode:
            # the grid shows the pictures itself
            if ret is not None:
                self["list"].posterChanged(ret)
            if self._usingBuiltinSkin:
                # the grid has the cover's place; another skin keeps its cover box: the selected tile's picture
                self["cover"].hide()
                return

        selItem = self.getSelItem()
        # when ret is != None the method is called from IconMenager
        # and in this variable the url for icon which was downloaded
        # is returned
        # if icon for other than selected item has been downloaded
        # the displayed icon will not be changed
        if ret is not None and selItem is not None and ret != selItem.iconimage:
            return

        # Display icon
        if selItem and '' != selItem.iconimage:
            self.iconMenager.addToDQueue([selItem.iconimage])
            # check if we have this icon and get the path to this icon on disk
            iconPath = self.getCoverPath(selItem)
            printDBG('displayIcon -> getCoverPath: %s' % IconLogName(selItem.iconimage))
            if '' != iconPath and not self["cover"].checkDecodeNeeded(iconPath):
                self["cover"].show()
                return
            else:
                if doDecodeCover:
                    if -1 == self["cover"].decodeCover(iconPath, self.updateCover, "cover") \
                            and iconPath != Cover.getErrorCoverPath() and os_path.isfile(iconPath):
                        # the picture loader does not even start on it (AVIF, TIFF, JPEG2000, html, empty ...)
                        self.showCoverFailed(selItem.iconimage, iconPath)
                        return
                else:
                    self.decodeCoverTimer.start(self.decodeCoverTimer_interval, True)
        self["cover"].hide()

    def doStartCoverDecode(self):
        if self.decodeCoverTimer:
            self.displayIcon(None, doDecodeCover=True)

    def updateCover(self, retDict):
        # retDict - return dictionary  {Ident, Pixmap, FileName, Changed}
        printDBG('updateCover')
        if retDict:
            printDBG("updateCover retDict for Ident: %s " % retDict["Ident"])
            updateIcon = False
            if 'cover' == retDict["Ident"] and self["list"].gridMode and self._usingBuiltinSkin:
                # a decode started before the list became a grid (that has the cover's place)
                self["cover"].hide()
                return
            if 'cover' == retDict["Ident"]:
                # check if we have icon for right item on list
                selItem = self.getSelItem()
                if selItem and '' != selItem.iconimage:
                    # check if we have this icon and get the path to this icon on disk
                    iconPath = self.getCoverPath(selItem)

                    if iconPath == retDict["FileName"] or (retDict["FileName"] == Cover.getErrorCoverPath()
                                                           and selItem.iconimage == self.localCoverErrorIcon):
                        # now we are sure that we have right icon
                        updateIcon = True
                        self.decodeCoverTimer_interval = 100
                    else:
                        self.decodeCoverTimer_interval = 1000
            else:
                updateIcon = True
            if updateIcon:
                if None is not retDict["Pixmap"]:
                    self[retDict["Ident"]].updatePixmap(retDict["Pixmap"], retDict["FileName"])
                    self[retDict["Ident"]].show()
                elif 'cover' == retDict["Ident"] and retDict["FileName"] != Cover.getErrorCoverPath():
                    # decoded, but the picture loader could not make a picture of it
                    self.showCoverFailed(self.getSelItem().iconimage, retDict["FileName"])
                else:
                    self[retDict["Ident"]].hide()
        else:
            printDBG("updateCover retDict empty")
    # end updateCover(self, retDict):

    def showCoverFailed(self, iconUrl, fileName):
        # the picture loader can't show the file: red X, and the log says what the file is
        info = "can not be shown, %s" % DescribeImageFile(fileName)
        if iconUrl.startswith('file://'):
            # a local picture is not downloaded (nothing to retry, nothing to remove from the cache)
            printDBG("updateCover local picture %s" % info)
            self.localCoverErrorIcon = iconUrl
        else:
            self.iconMenager.markIconFailed(iconUrl, info, removeFile=True)
        ret = self["cover"].decodeErrorCover(self.updateCover, "cover")
        if -1 == ret:
            self["cover"].hide()
        elif ret is False:
            # the X is decoded already (the item before failed too) - there is no callback, just show it
            self["cover"].show()

    def getCoverPath(self, selItem):
        # the item's picture on disk; a picture that exists at the source but failed (download error, not a
        # picture, can't be decoded - IconMenager logs why) shows a red X. No picture at all stays empty.
        if self.iconMenager.isIconFailed(selItem.iconimage):
            return Cover.getErrorCoverPath()
        return self.iconMenager.getIconPathFromAAueue(selItem.iconimage)

    def getCoverPathOfUrl(self, url):
        # a poster of the grid: like getCoverPath(); a picture that is not on disk yet is downloaded, the
        # IconMenager's callback then reaches the grid through displayIcon()
        if self.iconMenager.isIconFailed(url):
            return Cover.getErrorCoverPath()
        path = self.iconMenager.getIconPathFromAAueue(url)
        if not path:
            self.iconMenager.addToDQueue([url])
        return path

    def posterNotShown(self, url, fileName):
        # a poster of the grid the picture loader can't show: like showCoverFailed() the red X, the file is
        # dropped so a later try downloads it again. A local picture or the X itself stays as it is
        if url.startswith('file://') or fileName == Cover.getErrorCoverPath():
            return False
        self.iconMenager.markIconFailed(url, "can not be shown, %s" % DescribeImageFile(fileName), removeFile=True)
        return True

    # share of the description's height the poster grid takes (about three lines of description stay)
    GRID_CONSOLE_SHARE = 0.45

    def _onListModeChanged(self, grid):
        # poster grid on / off: the arrow keys and - with the built-in skin - the grid also takes the cover's
        # place on the left and part of the description below (with the line between them); another skin keeps
        # its cover box, only a description right below the list gives the grid the same share of its height
        self["gridActions"].setEnabled(grid)
        if grid and self._usingBuiltinSkin:
            self["cover"].hide()
        elif self.decodeCoverTimer:
            # back to a list: its cover once the new list and its selection are set (the switch runs inside setList)
            self.decodeCoverTimer.start(self.decodeCoverTimer_interval, True)
        if not self._usingBuiltinSkin:
            self._growGridIntoConsole(grid)
            return
        try:
            listInstance = self["list"].instance
            consoleInstance = self["console"].instance
            separatorInstance = self["separator"].instance
            if self._gridGeometry is None:
                self._gridGeometry = [(widget.position().x(), widget.position().y(),
                                       widget.size().width(), widget.size().height())
                                      for widget in (listInstance, consoleInstance, separatorInstance)]
            (x, y, w, h), (consoleX, consoleY, consoleW, consoleH), (lineX, lineY, _, _) = self._gridGeometry
            extra = 0
            if grid:
                coverX = self["cover"].instance.position().x()
                if coverX < x:
                    w += x - coverX
                    x = coverX
                extra = int(consoleH * self.GRID_CONSOLE_SHARE)
            listInstance.move(ePoint(x, y))
            listInstance.resize(eSize(w, h + extra))
            consoleInstance.move(ePoint(consoleX, consoleY + extra))
            consoleInstance.resize(eSize(consoleW, consoleH - extra))
            separatorInstance.move(ePoint(lineX, lineY + extra))
        except Exception:
            printExc()

    @staticmethod
    def _consoleBelowList(listGeo, consoleGeo):
        # another skin's description box lies right below the list (a gap smaller than the box itself) and spans
        # most of the list's width - only then the grid can grow into it without covering anything else
        (x, y, w, h), (consoleX, consoleY, consoleW, consoleH) = listGeo, consoleGeo
        if w <= 0 or consoleH <= 0:
            return False
        gap = consoleY - (y + h)
        overlap = min(x + w, consoleX + consoleW) - max(x, consoleX)
        return 0 <= gap < consoleH and overlap >= w * 0.8

    def _growGridIntoConsole(self, grid):
        # another skin: the poster grid takes GRID_CONSOLE_SHARE of a description box right below the list (one
        # poster row more in e.g. MetrixHD); the cover box and every other widget stay where the skin put them
        try:
            listInstance = self["list"].instance
            consoleInstance = self["console"].instance
            if listInstance is None or consoleInstance is None:
                return
            if self._gridGeometry is None:
                self._gridGeometry = [(widget.position().x(), widget.position().y(),
                                       widget.size().width(), widget.size().height())
                                      for widget in (listInstance, consoleInstance)]
            listGeo, consoleGeo = self._gridGeometry[0], self._gridGeometry[1]
            if not self._consoleBelowList(listGeo, consoleGeo):
                return
            (x, y, w, h), (consoleX, consoleY, consoleW, consoleH) = listGeo, consoleGeo
            extra = int(consoleH * self.GRID_CONSOLE_SHARE) if grid else 0
            listInstance.resize(eSize(w, h + extra))
            consoleInstance.move(ePoint(consoleX, consoleY + extra))
            consoleInstance.resize(eSize(consoleW, consoleH - extra))
            self._gridConsoleShortened = bool(extra)
        except Exception:
            printExc()

    def togglePosterGrid(self):
        # TEXT / BLUE "Poster grid on|off": the option itself, the list on screen follows at once
        if self.iconMenager is None or not self.visible:
            return
        option = config.plugins.iptvplayer.poster_grid
        option.value = not option.value
        option.save()
        configfile.save()
        printDBG("togglePosterGrid -> %s" % option.value)
        self["list"].setList([(x,) for x in self.currList])
        self.changeBottomPanel()
        # a short hint in the description until the selection moves - no message box: a queued one would pop up
        # only after the next key (two quick TEXT presses showed both, one after the other)
        self["console"].setText(_("Poster grid on") if option.value else _("Poster grid off"))

    def updateLcdItem(self):
        # the summary of the top screen: only this screen's own, not the one of a screen above it
        if self.session.current_dialog is self:
            selItem = self.getSelItem() if self.currList else None
            self.lcdSummaryCall('setItem', StripColorCodes(getattr(selItem, 'name', '')))

    def changeBottomPanel(self):
        self.displayIcon()
        self.updateLcdItem()
        selItem = self.getSelItem()
        if selItem and selItem.description != '':
            data = selItem.description
            sData = data.replace('[/br]', '\n')
            self["console"].setText(sData)
            if self["list"].gridMode and (self._usingBuiltinSkin or self._gridConsoleShortened):
                self._fitConsoleText(sData)
        else:
            self["console"].setText('')

    def _fitConsoleText(self, text):
        # the shorter description below the poster grid: a label higher than its text draws half a line at the bottom
        try:
            label = self["console"].instance
            self["console"].setText(fitLabelText(label, text, label.size().height()))
        except Exception:
            printExc()

    def onSelectionChanged(self):
        # debounced - see footerKeysTimer's own comment in __init__.
        # changeBottomPanel()/_rememberHistorySelection()
        # stay immediate - both are cheap, local, no host call
        self.footerKeysTimer.start(self.footerKeysTimer_interval, True)
        self.changeBottomPanel()
        self._rememberHistorySelection()

    def back_pressed(self):
        if self.stopAutoPlaySequencer() and self.autoPlaySeqTimerValue:
            return
        if self.selectMode and self.visible:
            # EXIT leaves the selection mode first (the marks are dropped)
            self._endSelectMode()
            return
        try:
            if self.isInWorkThread():
                if self.workThread.kill():
                    self.workThread = None
                    self.setStatusTex(_("Operation aborted!"))
                    # a page CH- preset for a Jump that was cut off must not reach a later jump
                    iptvpaging.presetJumpPage(None)
                    self._requestAbortedList()
                return
        except Exception:
            return
        if self.visible:
            if len(self.prevSelList) > 0:
                steps = self._levelBackSteps()
                for _step in range(steps):
                    self.nextSelIndex = self.prevSelList.pop()
                    self.categoryList.pop()
                if 'favourites' == self.hostName and len(self.categoryList) == 0:
                    self.favouritesCurrentGroupId = ''
                printDBG("back_pressed prev sel index %s, %d list(s) back" % (self.nextSelIndex, steps))
                self.requestListFromHost('Previous', -1, steps)
            else:
                # There is no prev categories, so exit
                # self.close()
                if self.group is None:
                    self.selectHost()
                else:
                    self.selectHostFromGroup()
        else:
            self.showWindow()
    # end back_pressed(self):

    def info_pressed(self):
        printDBG('info_pressed')
        if self.visible and not self.isInWorkThread():
            try:
                item = self.getSelItem()
            except Exception:
                printExc()
                item = None
            if None is not item and getattr(item, 'imageType', '') != iptvpaging.MENU_IMAGE_TYPE:
                self.stopAutoPlaySequencer()
                if self._itemNeedsPin(item):
                    # the article of a favourite comes from its (locked) host
                    AskHostPin(self.session, item.pinHost, self.info_pressed)
                    return
                self.currSelIndex = currSelIndex = self["list"].getCurrentIndex()
                self.requestListFromHost('ForArticleContent', currSelIndex)
    # end info_pressed(self):

    def isSearchHistoryList(self):
        """True only for the actual list of past search entries, not the
        Search category menu (which also contains one TYPE_SEARCH_HISTORY
        item - the link that navigates into that list)."""
        try:
            if not self.currList:
                return False

            hasHistoryEntry = False
            for item in self.currList:
                itemType = getattr(item, 'type', None)
                if itemType == CDisplayListItem.TYPE_SEARCH:
                    # the Search category menu always has exactly one such
                    # item; the actual history-entries list never does
                    return False
                if itemType == CDisplayListItem.TYPE_SEARCH_HISTORY:
                    hasHistoryEntry = True
            return hasHistoryEntry
        except Exception:
            printExc()

        return False

    def _rememberHistorySelection(self):
        # global (not per-host) memory of the last selected search-history
        # entry, restored by _restoreHistorySelection() in reloadList() so
        # reopening the history list lands back on it instead of index 0.
        # Skipped while a list is being (re)loaded, since moveToIndex() below
        # fires this same callback and would otherwise overwrite the value
        # we are about to restore with whatever index/name it lands on first.
        try:
            if not config.plugins.iptvplayer.rememberHistorySelection.value:
                return
            if self._isLoadingList or not self.isSearchHistoryList():
                return
            item = self.getSelItem()
            name = getattr(item, 'name', None) if item is not None else None
            if name:
                self._lastHistorySelection = name
        except Exception:
            printExc()

    def _restoreHistorySelection(self):
        # name-based, not index-based: new searches insert at the front of
        # the history list and shift every existing entry's index
        try:
            if not config.plugins.iptvplayer.rememberHistorySelection.value:
                return
            if not self.isSearchHistoryList():
                return
            wanted = self._lastHistorySelection
            if not wanted:
                return
            for idx, it in enumerate(self.currList):
                if getattr(it, 'name', None) == wanted:
                    self["list"].moveToIndex(idx)
                    break
        except Exception:
            printExc()

    def keyT9Jump(self, digit):
        # single global switch for the whole T9 letter-jump feature (this
        # method's search-history AND main-list branch alike, plus the
        # independent keyNumberJump() copies in iptvfavouriteswidgets.py and
        # searchhistoryeditor.py) - off gives keyT9_1-4/8 their own functions
        # (ok_pressed1-4, startAutoPlaySequencer); on, the digits only jump
        if not config.plugins.iptvplayer.enableT9MainList.value:
            return False

        # search-history list: every digit press is consumed by the T9 jump
        # (always returns True), digits have no other meaning in this list
        if self.isSearchHistoryList():
            letter = self.t9HistoryInput.getKey(int(digit))
            if not letter:
                return True

            try:
                currentIdx = self['list'].getCurrentIndex()
                idx = findT9JumpIndex(len(self.currList), currentIdx, letter, lambda i: getattr(self.currList[i], 'name', ''))
                if idx >= 0:
                    self['list'].moveToIndex(idx)
                    printDBG('T9 history jump key[%s] letter[%s] index[%d]' % (digit, letter, idx))
                else:
                    printDBG('T9 history jump key[%s] letter[%s] no match' % (digit, letter))
            except Exception:
                printExc()

            return True

        # any other list (main menu, categories, series, favourites, ...): the digit
        # belongs to the T9 jump as well, also without a match - a letter typed
        # with several presses of one key (4 4 = "h") must not start a video
        # (ok_pressed1-4) or the sequencer (8) on the way when nothing starts
        # with one of the letters before
        if not self.currList:
            return True

        try:
            letter = self.t9MainListInput.getKey(int(digit))
            if not letter:
                return True

            currentIdx = self['list'].getCurrentIndex()
            idx = findT9JumpIndex(len(self.currList), currentIdx, letter, lambda i: getattr(self.currList[i], 'name', ''))
            if idx >= 0:
                self['list'].moveToIndex(idx)
                printDBG('T9 main list jump key[%s] letter[%s] index[%d]' % (digit, letter, idx))
            else:
                printDBG('T9 main list jump key[%s] letter[%s] no match' % (digit, letter))
        except Exception:
            printExc()
        return True

    def keyT9_1(self):
        if not self.keyT9Jump('1'):
            self.ok_pressed1()

    def keyT9_2(self):
        if not self.keyT9Jump('2'):
            self.ok_pressed2()

    def keyT9_3(self):
        if not self.keyT9Jump('3'):
            self.ok_pressed3()

    def keyT9_4(self):
        if not self.keyT9Jump('4'):
            self.ok_pressed4()

    def keyT9_5(self):
        self.keyT9Jump('5')

    def keyT9_6(self):
        self.keyT9Jump('6')

    def keyT9_7(self):
        self.keyT9Jump('7')

    def keyT9_8(self):
        if not self.keyT9Jump('8'):
            self.startAutoPlaySequencer()

    def keyT9_9(self):
        self.keyT9Jump('9')

    def ok_pressed0(self):
        if self.activePlayer is None:  # no host loaded (loadHost() failed)
            return
        self.activePlayer.set({})
        self.ok_pressed(useAlternativePlayer=False)

    def ok_pressed1(self):
        if self.activePlayer is None:
            return
        player = self.getMoviePlayer(True, False)
        self.activePlayer.set({'buffering': True, 'player': player})
        self.ok_pressed(useAlternativePlayer=True)

    def ok_pressed2(self):
        if self.activePlayer is None:
            return
        player = self.getMoviePlayer(True, True)
        self.activePlayer.set({'buffering': True, 'player': player})
        self.ok_pressed(useAlternativePlayer=True)

    def ok_pressed3(self):
        if self.activePlayer is None:
            return
        player = self.getMoviePlayer(False, False)
        self.activePlayer.set({'buffering': False, 'player': player})
        self.ok_pressed(useAlternativePlayer=False)

    def ok_pressed4(self):
        if self.activePlayer is None:
            return
        player = self.getMoviePlayer(False, True)
        self.activePlayer.set({'buffering': False, 'player': player})
        self.ok_pressed(useAlternativePlayer=True)

    def ok_pressed(self, eventFrom='remote', useAlternativePlayer=False):
        if self.selectMode and 'remote' == eventFrom and self.visible:
            # selection mode: OK marks / unmarks the row (and stops a waiting sequencer, like every OK)
            self.stopAutoPlaySequencer()
            self._toggleSelectMark()
            return
        self.useAlternativePlayer = useAlternativePlayer
        if eventFrom != 'green':
            self.recorderMode = False

        # 'zap': CH+/CH- in the player (zapToItem) - a running sequencer goes on from the new item
        if eventFrom not in ('sequencer', 'zap'):
            self.stopAutoPlaySequencer()

        if self.visible or eventFrom in ('sequencer', 'zap'):
            sel = None
            try:
                if len(self.currList) > 0 and (not self["list"].getVisible() and eventFrom not in ('sequencer', 'zap')):
                    printDBG("ok_pressed -> ignored /\\")
                    return
            except Exception:
                printExc()

            try:
                sel = self["list"].getCurrent()
            except Exception:
                printExc()
                self.getRefreshedCurrList()
                return
            if sel is None:
                printDBG("ok_pressed sel is None")
                self.stopAutoPlaySequencer()
                self.getInitialList()
                return
            elif len(self.currList) <= 0:
                printDBG("ok_pressed list is empty")
                self.stopAutoPlaySequencer()
                self.getRefreshedCurrList()
                return
            else:
                printDBG("ok_pressed selected item: %s" % (sel.name))

                item = self.getSelItem()
                self.currItem = item
                if getattr(item, 'imageType', '') == iptvpaging.MENU_IMAGE_TYPE:
                    # "Main menu" row of a paged list: OK does what EXIT does, back to the list its first page was opened
                    # from - not on the host's first list (EXIT would leave the host) and not for green, the autoplay
                    # sequencer or zapping (they call ok_pressed with another eventFrom)
                    if 'remote' == eventFrom and self.prevSelList:
                        self.back_pressed()
                    return

                # Get current selection
                currSelIndex = self["list"].getCurrentIndex()
                # remember only prev categories
                if item.type in [CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_PICTURE, CDisplayListItem.TYPE_DATA]:
                    if self._itemNeedsPin(item):
                        # zap and sequencer skip such items, so only OK/GREEN get here
                        AskHostPin(self.session, item.pinHost, boundFunction(self.ok_pressed, eventFrom, useAlternativePlayer))
                        return
                    if CDisplayListItem.TYPE_AUDIO == item.type:
                        self.bufferSize = config.plugins.iptvplayer.requestedAudioBuffSize.value * 1024
                    else:
                        self.bufferSize = config.plugins.iptvplayer.requestedBuffSize.value * 1024 * 1024
                    # check if separete host request is needed to get links to VIDEO
                    if item.urlSeparateRequest == 1:
                        printDBG("ok_pressed selected TYPE_VIDEO.urlSeparateRequest")
                        self.requestListFromHost('ForVideoLinks', currSelIndex)
                    else:
                        printDBG("ok_pressed selected TYPE_VIDEO.selectLinkForCurrVideo")
                        self.selectLinkForCurrVideo()
                elif item.type == CDisplayListItem.TYPE_SEARCH_HISTORY_DELETE:
                    printDBG("ok_pressed selected TYPE_SEARCH_HISTORY_DELETE")
                    self.host.host.delHistory(self.session)
                elif item.type in [CDisplayListItem.TYPE_CATEGORY, CDisplayListItem.TYPE_SEARCH_HISTORY, CDisplayListItem.TYPE_SEARCH_HISTORY_EDITOR, CDisplayListItem.TYPE_NEXT, CDisplayListItem.TYPE_JUMP, CDisplayListItem.TYPE_FIRST, CDisplayListItem.TYPE_PREVIOUS, CDisplayListItem.TYPE_LAST]:
                    printDBG("ok_pressed selected TYPE_CATEGORY")
                    self.stopAutoPlaySequencer()
                    self.currSelIndex = currSelIndex
                    if 'favourites' == self.hostName and len(self.categoryList) == 0:
                        try:
                            self.favouritesCurrentGroupId = ''
                            try:
                                groupTitle = item.name
                            except Exception:
                                groupTitle = ''

                            if groupTitle:
                                self.favouritesCurrentGroupId = groupTitle.strip().lower()

                            printDBG("ok_pressed favouritesCurrentGroupId[%s]" % self.favouritesCurrentGroupId)
                        except Exception:
                            printExc()

                    if self._itemNeedsPin(item):
                        AskHostPin(self.session, item.pinHost, boundFunction(self.requestListFromHost, 'ForItem', currSelIndex, ''))
                    elif getattr(item, 'pinHost', ''):
                        # favourite of an unlocked host
                        self.requestListFromHost('ForItem', currSelIndex, '')
                    elif item.pinLocked:
                        from Plugins.Extensions.IPTVPlayer.components.iptvpin import IPTVPinWidget
                        pinTitle = _("Enter pin") + (" - " + item.name if getattr(item, 'name', '') else '')
                        self.session.openWithCallback(boundFunction(self.checkDirPin, self.requestListFromHost, 'ForItem', currSelIndex, '', item.pinCode), IPTVPinWidget, title=pinTitle)
                    else:
                        self.requestListFromHost('ForItem', currSelIndex, '')
                elif item.type == CDisplayListItem.TYPE_MORE:
                    printDBG("ok_pressed selected TYPE_MORE")
                    self.currSelIndex = currSelIndex
                    self.requestListFromHost('ForMore', currSelIndex, '')
                elif item.type == CDisplayListItem.TYPE_ARTICLE:
                    printDBG("ok_pressed selected TYPE_ARTICLE")
                    self.info_pressed()
                elif item.type == CDisplayListItem.TYPE_SEARCH:
                    printDBG("ok_pressed selected TYPE_SEARCH")
                    self.stopAutoPlaySequencer()
                    self.currSelIndex = currSelIndex
                    self.startSearchProcedure(item.possibleTypesOfSearch)
        else:
            self.showWindow()
    # end ok_pressed(self):

    def _pagerIndex(self, kind):
        # index of the list's pager entry of this kind (-1 when there is none) - the generic hosts use the
        # item type, hostxxx a TYPE_CATEGORY entry with the imageType (PagerKind); "Next page" is the last one
        indexes = [idx for idx, item in enumerate(self.currList) if PagerKind(item) == kind]
        if not indexes:
            return -1
        return indexes[-1] if kind == CDisplayListItem.TYPE_NEXT else indexes[0]

    def _canPage(self):
        # the list is shown - not while a list is loading (spinner) or the window is hidden
        if not self.visible:
            return False
        try:
            return not (self.currList and not self["list"].getVisible())
        except Exception:
            printExc()
            return False

    def _previousPageStep(self):
        # how CH- goes one page back, to the page number before this one: ('history', -1) back to the page this
        # one was paged to with "Next page" (or any page step that came from the page before), ('item', idx) the
        # list's own "Previous page" entry, ('jump', idx) after a jump (78 -> page 77, not back to the page the
        # jump came from) the list's Jump row with the page before preset; ('history', -1) when the page number is
        # unknown; (None, -1) on page 1 and when the list was not paged at all - EXIT goes a level up
        kind = getattr(self.categoryList[-1], 'pagerKind', '') if self.categoryList and self.prevSelList else ''
        if kind == CDisplayListItem.TYPE_NEXT:
            return 'history', -1
        idx = self._pagerIndex(CDisplayListItem.TYPE_PREVIOUS)
        if -1 < idx:
            return 'item', idx
        if not kind:
            return None, -1
        page = getattr(self.categoryList[-1], 'page', None)
        if not isinstance(page, int):
            return 'history', -1
        if page <= 1:
            return None, -1
        previousPage = getattr(self.categoryList[-2], 'page', None) if 1 < len(self.categoryList) else None
        idx = self._pagerIndex(CDisplayListItem.TYPE_JUMP)
        if previousPage == page - 1 or idx < 0:
            return 'history', -1
        return 'jump', idx

    def _levelBackSteps(self):
        # EXIT goes a whole list level back: over every page the list was paged to (next page, jump, first page,
        # CH+ / CH-) to the list its first page was opened from - CH- is the key for one page back
        steps = 1
        while steps < min(len(self.categoryList), len(self.prevSelList)) and getattr(self.categoryList[-steps], 'pagerKind', ''):
            steps += 1
        return steps

    def _getPrevLists(self, steps):
        # work thread: the host goes back several of its list levels (its cached lists, no page request). Not
        # killable meanwhile, the widget has popped all levels already; a step that fails (the host's stack ended
        # earlier) keeps the list of the last good one
        asynccall.SetThreadKillable(False)
        try:
            ret = None
            for step in range(steps):
                stepRet = self.host.getPrevList()
                if stepRet.status != RetHost.OK:
                    printDBG("_getPrevLists: the host went back %d of %d lists" % (step, steps))
                    return ret if ret is not None else stepRet
                ret = stepRet
            return ret
        finally:
            asynccall.SetThreadKillable(True)

    def _openPagerItem(self, idx):
        # opens a pager entry like OK on its row
        item = self.currList[idx]
        self.currItem = item
        self.currSelIndex = idx
        if self._itemNeedsPin(item):
            AskHostPin(self.session, item.pinHost, boundFunction(self.requestListFromHost, 'ForItem', idx, ''))
        else:
            self.requestListFromHost('ForItem', idx, '')

    def pageup_pressed(self):
        # CH+: next page (not while a list loads, the key would be lost anyway)
        self.stopAutoPlaySequencer()
        if self._canPage() and not self.isInWorkThread():
            idx = self._pagerIndex(CDisplayListItem.TYPE_NEXT)
            if -1 < idx:
                self._openPagerItem(idx)

    def pagedown_pressed(self):
        # CH-: one page back - not while a list loads: a second CH- then (an empty page shows no spinner check)
        # would pop the path once more than the host's list stack, which ignores the request meanwhile
        self.stopAutoPlaySequencer()
        if not self._canPage() or self.isInWorkThread():
            return
        step, idx = self._previousPageStep()
        if step == 'history':
            self.prevSelList.pop()
            self.categoryList.pop()
            self.nextSelIndex = 0
            printDBG("pagedown_pressed -> previous page")
            self.requestListFromHost('Previous')
        elif step == 'item':
            self._openPagerItem(idx)
        elif step == 'jump':
            page = self.categoryList[-1].page - 1
            printDBG("pagedown_pressed -> jump to page %d" % page)
            iptvpaging.presetJumpPage(page)
            self._openPagerItem(idx)

    @staticmethod
    def _itemNeedsPin(item):
        # a favourite of a PIN protected host that was not unlocked yet in this E2iPlayer session
        pinHost = getattr(item, 'pinHost', '')
        return bool(pinHost) and HostNeedsPin(pinHost)

    def checkDirPin(self, callbackFun, arg1, arg2, arg3, pinCode, pin=None):
        if pin is not None:
            if 4 != len(pinCode):
                pinCode = config.plugins.iptvplayer.pin.value  # use default pin code if custom has wrong length
            if pin == pinCode:
                callbackFun(arg1, arg2, arg3)
            else:
                self.session.open(MessageBox, _("Pin incorrect!"), type=MessageBox.TYPE_INFO, timeout=5)

    def leaveArticleView(self):
        printDBG("leaveArticleView")
        pass

    def showArticleContent(self, ret):
        printDBG("showArticleContent")
        self.setStatusTex("")
        self["list"].show()

        artItem = None
        if ret.status != RetHost.OK or 0 == len(ret.value):
            item = self.currList[self.currSelIndex]
            if len(item.description):
                artItem = ArticleContent(title=item.name, text=item.description, images=[{'title': _('Image'), 'url': item.iconimage}])  # richDescParams={"alternate_title":"***alternate_title", "year":"year", "rating":"rating",  "duration":"duration",  "genre":"genre",  "director":"director",  "actors":"actors",  "awards":"awards"}
        else:
            artItem = ret.value[0]
        if None is not artItem:
            self.session.openWithCallback(self.leaveArticleView, IPTVArticleView, artItem, {'buffering_path': config.plugins.iptvplayer.bufferingPath.value, 'host_name': self._getRowsHostName(), 'logo_path': self.hostLogoPath, 'download_dir': self.iconMenager.currDownloadDir if self.iconMenager else None})

    def selectMainVideoLinks(self, ret):
        printDBG("selectMainVideoLinks")
        self.setStatusTex("")
        self["list"].show()

        # ToDo: check ret.status if not OK do something :P
        if ret.status != RetHost.OK:
            printDBG("++++++++++++++++++++++ selectHostVideoLinksCallback ret.status = %s" % ret.status)
        else:
            # update links in List
            currSelIndex = self.getSelIndex()
            if -1 == currSelIndex:
                return
            self.currList[currSelIndex].urlItems = ret.value
        self.selectLinkForCurrVideo()
    # end selectMainVideoLinks(self, ret):

    def selectResolvedVideoLinks(self, ret):
        printDBG("selectResolvedVideoLinks")
        self.setStatusTex("")
        self["list"].show()
        linkList = []
        if ret.status == RetHost.OK and isinstance(ret.value, list):
            for item in ret.value:
                if isinstance(item, CUrlItem):
                    item.urlNeedsResolve = 0  # protection from recursion
                    linkList.append(item)
                elif isinstance(item, str):
                    linkList.append(CUrlItem(item, item, 0))
                else:
                    printExc("selectResolvedVideoLinks: wrong resolved url type!")
        else:
            printExc()

        resolvingLink = self._resolvingLinkItem
        self._resolvingLinkItem = None
        if 0 == len(linkList) and resolvingLink is not None and self._autoLinkQueue:
            # "Select link automatically": mark this mirror and quietly go on with the next one
            self._markAutoLinkFailed(resolvingLink)
            self._startAutoLink(self._autoLinkQueue.pop(0))
            return
        # only reopen the picker on failure when there was genuinely a choice of
        # several mirrors to begin with - for a single mirror reopening would just
        # re-select and re-resolve the very same failing link again; the autoplay
        # sequencer (no questions) goes on with the next row instead
        if (0 == len(linkList) and resolvingLink is not None and self._currentLinkOptions is not None and
                len(self._currentLinkOptions) > 1 and not self.autoPlaySeqStarted):
            # resolving this particular mirror failed - mark it, tell the user, then
            # reopen the full mirror list (instead of dead-ending on "no valid links")
            # so they can see it highlighted and try another one
            self._markLinkFailed(resolvingLink)
            message = _("No valid links available.")
            lastErrorMsg = GetIPTVPlayerLastHostError()
            if '' != lastErrorMsg:
                message += "\n" + _('Last error: "%s"') % lastErrorMsg
            self.session.openWithCallback(self._reopenLinkPickerAfterFailure, MessageBox, message, type=MessageBox.TYPE_INFO, timeout=10)
            return
        # the qualities of this mirror: their marks are kept apart from another mirror's "720p" etc.
        parentKey = self._linkMarkKeys(resolvingLink)[1] if resolvingLink is not None else ''
        self.selectLinkForCurrVideo(linkList, parentKey)

    def _isAutoLinkChoice(self):
        # links are chosen without the "Select link" list: the option, or the autoplay sequencer
        return config.plugins.iptvplayer.auto_select_link.value or self.autoPlaySeqStarted

    def _isLinkFailed(self, link):
        return link.failed or not self._failedLinkUrls.isdisjoint(self._linkMarkKeys(link))

    def _restoreAutoLinkMirrors(self):
        # back on the mirror list after a quality list of a mirror replaced it
        self._currentLinkOptions = self._autoLinkMirrors
        self._currentLinkVideoKey = self._autoLinkVideoKey

    def _markLinkFailed(self, link):
        link.failed = True
        self._failedLinkUrls.update(self._linkMarkKeys(link))

    def _markAutoLinkFailed(self, link):
        self._restoreAutoLinkMirrors()
        self._markLinkFailed(link)

    def _playLink(self, link):
        # as if chosen in the "Select link" list (the item name is not displayed)
        self.selectLinksCallback(IPTVChoiceBoxItem(" ", "", link))

    def _startAutoLink(self, link):
        self._restoreAutoLinkMirrors()
        self._autoLinkCurrent = link
        self._playLinkMirror = ''
        self._playLink(link)
        if self._autoLinkTotal > 1 and str(link.urlNeedsResolve) == '1':
            # replaces the "Loading" of the resolve request just started
            self.setStatusTex(_("Trying link %d of %d") % (self._autoLinkTotal - len(self._autoLinkQueue), self._autoLinkTotal))

    def _reopenLinkPickerAfterFailure(self, ret=None):
        # all mirrors failed: the list for a choice by hand, not another automatic run
        self.selectLinkForCurrVideo(self._currentLinkOptions, allowAuto=False)

    def getSelIndex(self):
        currSelIndex = self["list"].getCurrentIndex()
        if len(self.currList) > currSelIndex:
            return currSelIndex
        return -1

    def getSelItem(self):
        currSelIndex = self["list"].getCurrentIndex()
        if len(self.currList) <= currSelIndex:
            printDBG("ERROR: getSelItem there is no item with index: %d, listOfItems.len: %d" % (currSelIndex, len(self.currList)))
            return None
        return self.currList[currSelIndex]

    def getSelectedItem(self):
        sel = None
        try:
            sel = self["list"].getCurrent()
        except Exception:
            return None
        return sel

    def onStart(self):
        self.onShow.remove(self.onStart)
        # self.onLayoutFinish.remove(self.onStart)
        self.setTitle('E2iPlayer ' + GetIPTVPlayerVersion())
        try:
            from Plugins.Extensions.IPTVPlayer.components.iptvscreensaver import IPTVMenuScreenSaver
            self.menuScreenSaver = IPTVMenuScreenSaver(self.session, self, self.getScreenSaverInfo)
            self.menuScreenSaver.start()
        except Exception:
            printExc()
        self.loadSpinner()
        self.hideSpinner()
        if self._usingBuiltinSkin:
            # static icons, set once - the icon pixmaps never change,
            # unlike these widgets' positions (see
            # _repositionFooterKeys())
            _footerIconBase = skinchrome.getIconBase()
            self["key_red_icon"].setPixmap(LoadPixmap(_footerIconBase + '/red.png'))
            self["key_green_icon"].setPixmap(LoadPixmap(_footerIconBase + '/green.png'))
            self["key_yellow_icon"].setPixmap(LoadPixmap(_footerIconBase + '/yellow.png'))
            self["key_blue_icon"].setPixmap(LoadPixmap(_footerIconBase + '/blue.png'))
            self["key_nav_icon"].setPixmap(LoadPixmap(_footerIconBase + '/key_steuerkreuz.png'))
            self["key_num_icon"].setPixmap(LoadPixmap(_footerIconBase + '/key_0-9.png'))
            # key_updown.png (up/down arrows), NOT key_prevnext.png (left/
            # right arrows, already covered by key_steuerkreuz.png's own
            # d-pad) - this hints PAGE UP/PAGE DOWN specifically
            self["key_prevnext_icon"].setPixmap(LoadPixmap(_footerIconBase + '/key_updown.png'))
            self["key_play_icon"].setPixmap(LoadPixmap(_footerIconBase + '/play.png'))
            self["key_info_icon"].setPixmap(LoadPixmap(_footerIconBase + '/info.png'))
            self["key_text_icon"].setPixmap(LoadPixmap(_footerIconBase + '/text.png'))
            self["key_ok_icon"].setPixmap(LoadPixmap(_footerIconBase + '/ok.png'))
            self["key_exit_icon"].setPixmap(LoadPixmap(_footerIconBase + '/exit.png'))
        self._runStartupStorageSteps()

    def _runStartupStorageSteps(self, ret=None):
        if self.startupStorageSteps:
            step = self.startupStorageSteps.pop(0)
            printDBG('Storage: showing startup dialog, %d more queued' % len(self.startupStorageSteps))
            step(self._runStartupStorageSteps)
        else:
            self.selectHost()

    def selectHost(self, arg1=None):
        printDBG(">> selectHost")
        # self.groupObj = None
        self.groupDisplayName = None
        self.group = None
        self.folder = None
        self.host = None
        self.hostName = ''
        self.nextSelIndex = 0
        self.prevSelList = []
        self.categoryList = []
        self.currList = []
        self.currItem = CDisplayListItem()

        if (config.plugins.iptvplayer.group_hosts.value is False or 0 == GetAvailableIconSize()):
            self.selectHostFromSingleList()
        else:
            self.selectGroup()

    def selectGroup(self):
        printDBG(">> selectGroup")
        self.groupObj = IPTVHostsGroups()
        self.displayGroupsList = []
        groupsList = self.groupObj.getGroupsList()
        for item in groupsList:
            self.displayGroupsList.append((self._groupTitleWithCount(item.title, item.name), item.name))
        if not GRIDSUPPORT:
            self.displayGroupsList.append((self._groupTitleWithCount(_('All'), 'all'), 'all'))
            self.displayGroupsList.append((_("Configuration"), "config"))

        self.newDisplayGroupsList = []
        self.session.openWithCallback(self.selectGroupCallback, PlayerSelectorWidget, inList=self.displayGroupsList, outList=self.newDisplayGroupsList, numOfLockedItems=self.getNumOfSpecialItems(self.displayGroupsList), groupName='selectgroup')

    @staticmethod
    def _getAllGroupHosts():
        # the hosts of the "All" group: every enabled host in the host folder (unsorted)
        return [hostName for hostName in GetHostsList(fromList=False, fromHostFolder=True) if IsHostEnabled(hostName)]

    def _groupTitleWithCount(self, title, groupName):
        # "German (12)", "All (200)": the hosts the group shows when it is opened (selectHostFromGroup) - read from
        # the group files and the host folder only, no host is loaded; getHostsList() caches the group for opening it
        try:
            count = len(self._getAllGroupHosts() if groupName == 'all' else self.groupObj.getHostsList(groupName))
        except Exception:
            printExc()
            return title
        return '%s (%d)' % (title, count)

    def selectGroupCallback(self, ret):
        printDBG(">> selectGroupCallback")
        # save groups order if user change it at player selection
        if self.newDisplayGroupsList != self.displayGroupsList:
            # filters by key rather than assuming "everything except the
            # last N items are real groups" (positional) - the reserved
            # keys can end up anywhere but the very end of the list (e.g.
            # after "Sort by name" in PlayerSelectorWidget's own BLUE
            # menu, which has no guard keeping them pinned in place), and
            # a positional cut would then persist them into
            # iptvplayerhostsgroups.json as if they were real group names.
            #
            # Which keys are reserved depends on GRIDSUPPORT, matching
            # exactly what selectGroup() appended and what
            # getGroupsList()/getNumOfSpecialItems() treat as special:
            # Legacy appends BOTH "all" and "config"; GRIDSUPPORT appends
            # neither and "all" is one of its real PREDEFINED_GROUPS.
            # Filtering "all" out here on GRIDSUPPORT made setGroupList()
            # mark the "All" group disabled on every group-list reorder.
            reservedKeys = ('config',) if GRIDSUPPORT else ('config', 'all')
            groupList = [item[1] for item in self.newDisplayGroupsList if item[1] not in reservedKeys]
            self.groupObj.setGroupList(groupList)

        self.selectItemCallback(ret, 'selectgroup')

    def selectHostFromGroup(self):
        printDBG(">> selectHostFromGroup")
        self.host = None
        self.hostName = ''
        self.nextSelIndex = 0
        self.prevSelList = []
        self.categoryList = []
        self.currList = []
        self.currItem = CDisplayListItem()

        self.displayHostsList = []
        startTime = time.time()
        if self.folder is not None and (self.group == 'all' or self.groupObj.getFolder(self.group, self.folder) is None or not self.groupObj.getFolderHosts(self.group, self.folder)):
            # the folder is gone or empty: the group itself
            self.folder = None
        if self.group == 'all':
            hostsList = SortHostsList(self._getAllGroupHosts())
        elif self.folder is not None:
            hostsList = self.groupObj.getFolderHosts(self.group, self.folder)
        else:
            # the group's own hosts and its folders
            hostsList = self.groupObj.getGroupLayout(self.group)

        brokenHostList = []
        for hostName in hostsList:
            if IsFolderKey(hostName):
                folder = self.groupObj.getFolder(self.group, hostName)
                if folder is not None:
                    self.displayHostsList.append(('%s (%d)' % (folder['title'], len(self.groupObj.getFolderHosts(self.group, hostName))), hostName))
                continue
            # read from the host file: the host itself is only loaded when it is opened
            title = GetHostTitle(hostName)
            if title is None:
                brokenHostList.append('host' + hostName)
                continue
            self.displayHostsList.append((title, hostName))
        self._logHostListBuilt(startTime, self.group)

        # if there is no order hosts list use old behavior for all group
        if self.group == 'all' and 0 == len(GetHostsOrderList()):
            try:
                self.displayHostsList.sort(key=lambda t: tuple(str(t[1]).lower()))
            except Exception:
                self.displayHostsList.sort()

        # prepare info message when some host or update cannot be used
        errorMessage = ""
        if len(brokenHostList) > 0:
            errorMessage = _("Following host are broken or additional python modules are needed.") + '\n' + '\n'.join(brokenHostList)

        if "" != errorMessage and True is self.showHostsErrorMessage:
            self.showHostsErrorMessage = False
            self.session.openWithCallback(self.displayListOfHostsFromGroup, MessageBox, errorMessage, type=MessageBox.TYPE_INFO, timeout=10)
        else:
            self.displayListOfHostsFromGroup()
        return

    def displayListOfHostsFromGroup(self, arg=None):
        printDBG(">> displayListOfHostsFromGroup")
        self.newDisplayHostsList = []
        if len(self.displayHostsList):
            displayName = self.groupDisplayName
            if self.folder is not None:
                # "Arabic (42) / Sport"
                folder = self.groupObj.getFolder(self.group, self.folder)
                if folder is not None:
                    displayName = '%s / %s' % (displayName, folder['title']) if displayName else folder['title']
            self.session.openWithCallback(self.selectHostFromGroupCallback, PlayerSelectorWidget, inList=self.displayHostsList, outList=self.newDisplayHostsList, numOfLockedItems=0, groupName=self.group, groupObj=self.groupObj, groupDisplayName=displayName, folderKey=self.folder)
        else:
            msg = _('There is no hosts in this group.')
            self.session.openWithCallback(self.selectHost, MessageBox, msg, type=MessageBox.TYPE_INFO, timeout=10)

    def selectHostFromGroupCallback(self, ret):
        printDBG(">> selectHostFromGroupCallback")

        # save hosts order if user change it at player selection
        if self.newDisplayHostsList != self.displayHostsList:
            hostsList = []
            for idx in range(len(self.newDisplayHostsList)):
                hostsList.append(self.newDisplayHostsList[idx][1])
            if self.group == 'all':
                SaveHostsOrderList(hostsList)
            elif self.folder is not None:
                self.groupObj.setFolderHostsList(self.group, self.folder, hostsList)
            else:
                self.groupObj.setHostsList(self.group, hostsList)
        self.groupObj.flushAddedHosts()
        if ret and len(ret) > 2 and ret[1] == 'FOLDER_ACTION':
            self.runFolderAction(ret[2])
        elif ret and IsFolderKey(ret[1]):
            # OK on a folder: its hosts, an empty one opens "Select hosts for this folder..." straight away
            if self.groupObj.getFolderHosts(self.group, ret[1]):
                self.folder = ret[1]
                self.selectHostFromGroup()
            else:
                self.openFolderHostsMenu(ret[1], True)
        elif not ret and self.folder is not None:
            # EXIT in a folder: back to the group
            self.folder = None
            self.selectHostFromGroup()
        else:
            self.selectItemCallback(ret, 'selecthostfromgroup')

    def runFolderAction(self, action):
        # a change of the group's own folders asked in PlayerSelectorWidget (_closeWithFolderAction())
        printDBG(">> runFolderAction %s" % action)
        op = action.get('op')
        key = action.get('key')
        try:
            if op == 'new':
                key = self.groupObj.createFolder(self.group, action['title'], action.get('hosts'))
                if key and not action.get('hosts'):
                    # a new empty folder: choose its hosts right away
                    self.openFolderHostsMenu(key, True)
                    return
            elif op == 'rename':
                self.groupObj.renameFolder(self.group, key, action['title'])
            elif op == 'icon':
                self.groupObj.setFolderIcon(self.group, key, action['icon'])
            elif op == 'delete':
                self.groupObj.deleteFolder(self.group, key)
            elif op == 'move':
                self.groupObj.moveHostsToFolder(self.group, action['hosts'], key)
            elif op == 'select':
                self.openFolderHostsMenu(key)
                return
        except Exception:
            printExc()
        self.selectHostFromGroup()

    def openFolderHostsMenu(self, key, openFolder=False):
        # "Select hosts for this folder...": tick the hosts of the group that belong into the folder
        folder = self.groupObj.getFolder(self.group, key)
        if folder is None:
            self.selectHostFromGroup()
            return
        title = '%s / %s' % (self.groupDisplayName, folder['title']) if self.groupDisplayName else folder['title']
        self.session.openWithCallback(boundFunction(self.folderHostsMenuCallback, key, openFolder), ConfigGroupFolderMenu, self.groupObj, self.group, key, title)

    def folderHostsMenuCallback(self, key, openFolder, arg=None):
        # openFolder: opened from OK on the empty folder / a new folder - show it now it has hosts
        if openFolder and self.groupObj.getFolderHosts(self.group, key):
            self.folder = key
        self.selectHostFromGroup()

    def _logHostListBuilt(self, startTime, listName):
        # how long a host list took and how many hosts are loaded so far (debug log):
        # the lists only read the titles, so only hosts opened before are loaded
        prefix = 'Plugins.Extensions.IPTVPlayer.hosts.host'
        loaded = len([name for name in list(sys.modules) if name.startswith(prefix)])
        printDBG("Host list [%s]: %d hosts in %d ms, %d host modules loaded" % (listName, len(self.displayHostsList), int((time.time() - startTime) * 1000), loaded))

    def selectHostFromSingleList(self):
        self.displayHostsList = []
        startTime = time.time()
        sortedList = SortHostsList(GetHostsList(fromList=False, fromHostFolder=True))
        brokenHostList = []
        for hostName in sortedList:
            if IsHostEnabled(hostName):
                # read from the host file: the host itself is only loaded when it is opened
                title = GetHostTitle(hostName)
                if title is None:
                    brokenHostList.append('host' + hostName)
                    continue

                # The 'http...' in host titles is annoying on regular choiceBox and impacts sorting.
                # To simplify choiceBox usage and clearly show service is a webpage, list is build using the "<service name> (<service URL>)" schema.
                """
                if (config.plugins.iptvplayer.ListaGraficzna.value is False or 0 == GetAvailableIconSize()) and title[:4] == 'http':
                    try:
                        title = ('%s   (%s)') % ('.'.join(title.replace('://', '.').replace('www.', '').split('.')[1:-1]), title)
                    except Exception:
                        pass
                """
                self.displayHostsList.append((title, hostName))
        self._logHostListBuilt(startTime, 'single list')
        # if there is no order hosts list use old behavior
        if 0 == len(GetHostsOrderList()):
            try:
                self.displayHostsList.sort(key=lambda t: tuple(str(t[0]).lower()))
            except Exception:
                self.displayHostsList.sort()
        if not GRIDSUPPORT:
            self.displayHostsList.append((_("Configuration"), "config"))

        # prepare info message when some host or update cannot be used
        errorMessage = ""
        if len(brokenHostList) > 0:
            errorMessage = _("Following host are broken or additional python modules are needed.") + '\n' + '\n'.join(brokenHostList)

        if "" != errorMessage and True is self.showHostsErrorMessage:
            self.showHostsErrorMessage = False
            self.session.openWithCallback(self.displayListOfHosts, MessageBox, errorMessage, type=MessageBox.TYPE_INFO, timeout=10)
        else:
            self.displayListOfHosts()
        return

    def displayListOfHosts(self, arg=None):
        # always falls through to the PlayerSelectorWidget call below
        self.newDisplayHostsList = []
        self.session.openWithCallback(self.selectHostCallback, PlayerSelectorWidget, inList=self.displayHostsList, outList=self.newDisplayHostsList, numOfLockedItems=self.getNumOfSpecialItems(self.displayHostsList), groupName='selecthost')

    def getNumOfSpecialItems(self, inList, filters=['config', 'all']):
        if GRIDSUPPORT:
            return 0
        numOfSpecialItems = 0
        for item in inList:
            if item[1] in filters:
                numOfSpecialItems += 1
        return numOfSpecialItems

    def selectHostCallback(self, ret):
        printDBG(">> selectHostCallback")
        # save hosts order if user change it at player selection
        if self.newDisplayHostsList is not None and self.newDisplayHostsList != self.displayHostsList:
            # same positional-slicing bug as selectGroupCallback()'s own
            # groupList build (see its own comment) - "config" is the only
            # reserved key ever appended to the host list, but the same
            # "everything except the last item" assumption broke the same
            # way once it could end up anywhere but the tail (e.g. via
            # "Sort by name"). Filtered by key instead, regardless of
            # position.
            hostsList = [item[1] for item in self.newDisplayHostsList if item[1] != 'config']
            SaveHostsOrderList(hostsList)

        self.selectHostCallback2(ret)

    def selectHostCallback2(self, ret):
        printDBG(">> selectHostCallback2")
        self.selectItemCallback(ret, 'selecthost')

    def selectItemCallback(self, ret, type):
        printDBG(">> selectItemCallback ret[%s] type[%s]" % (ret, type))
        nextFunction = None
        prevFunction = None
        protectedByPin = False
        if ret:
            if ret[1] == "config":
                nextFunction = self.runConfig
                prevFunction = self.selectHost
                protectedByPin = config.plugins.iptvplayer.configProtectedByPin.value
            elif ret[1] == "reset_group":
                grp = ret[2] if len(ret) > 2 else ''
                try:
                    if grp == 'selectgroup':
                        self.groupObj.resetGroupList()
                    elif grp in ('selecthost', 'all'):
                        self.groupObj.resetHostsOrder()
                    elif grp:
                        self.groupObj.resetHostList(grp)
                except Exception:
                    printExc()
                self.selectHost()
            elif ret[1] == "config_hosts":
                nextFunction = self.runConfigHosts
                if type == 'selecthost':
                    prevFunction = self.selectHost
                else:
                    prevFunction = self.selectHostFromGroup
                protectedByPin = config.plugins.iptvplayer.configProtectedByPin.value
            elif ret[1] == "config_groups":
                nextFunction = self.runConfigGroupsMenu
                prevFunction = self.selectHost
                protectedByPin = config.plugins.iptvplayer.configProtectedByPin.value
            elif ret[1] == "IPTVDM":
                if type in ['selecthost', 'selectgroup']:
                    self.runIPTVDM(self.selectHost)
                elif type == 'selecthostfromgroup':
                    self.runIPTVDM(self.selectHostFromGroup)
                return
            elif type in ['selecthost', 'selecthostfromgroup']:
                self.hostTitle = ret[0]
                self.hostName = ret[1]
                self.loadHost()
            elif type == 'selectgroup':
                self.group = ret[1]
                self.groupDisplayName = ret[0]
                self.selectHostFromGroup()
                return
        elif type in ['selecthost', 'selectgroup']:
            self.close()
            return
        else:
            self.selectHost()
            return

        if nextFunction and prevFunction:
            if True is protectedByPin:
                from .iptvpin import IPTVPinWidget
                self.session.openWithCallback(boundFunction(self.checkPin, nextFunction, prevFunction, expectedPin=GetConfigExpectedPin()), IPTVPinWidget, title=_("Enter pin") + " - " + _("Configuration"))
            else:
                nextFunction()

    def runConfigHosts(self):
        self.enabledHostsListOld = GetEnabledHostsList()
        self.session.openWithCallback(self.configHostsCallback, ConfigHostsMenu, GetListOfHostsNames())

    def configHostsCallback(self, arg1=None):
        if self.group is not None:
            self.selectHostFromGroup()
        else:
            self.selectHost()

    def runConfigGroupsMenu(self):
        self.session.openWithCallback(self.selectHost, ConfigGroupsMenu)

    def runConfig(self):
        self.session.openWithCallback(self.configCallback, ConfigMenu)

    def runConfigHostIfAllowed(self):
        if config.plugins.iptvplayer.configProtectedByPin.value:
            from .iptvpin import IPTVPinWidget
            self.session.openWithCallback(boundFunction(self.checkPin, self.runConfigHost, None, expectedPin=GetConfigExpectedPin()), IPTVPinWidget, title=_("Enter pin") + " - " + _("Configuration"))
        else:
            self.runConfigHost()

    def runConfigHost(self):
        self.session.openWithCallback(self.runConfigHostCallBack, ConfigHostMenu, hostName=self.hostName)

    def runConfigHostCallBack(self, confgiChanged=False):
        if confgiChanged:
            self.loadHost()

    def checkPin(self, callbackFun, failCallBackFun, pin=None, expectedPin=''):
        # expectedPin: an own PIN (the configuration's) instead of the global
        # player one - same fallback as checkDirPin()'s custom pinCode: an
        # invalid (non-4-digit) value means "use the global player PIN".
        # A host's PIN is asked by iptvhostpin.AskHostPin (loadHost() below).
        if pin is not None:
            if 4 != len(expectedPin):
                expectedPin = config.plugins.iptvplayer.pin.value
            if pin == expectedPin:
                callbackFun()
            else:
                self.session.openWithCallback(self.close, MessageBox, _("Pin incorrect!"), type=MessageBox.TYPE_INFO, timeout=5)
        else:
            if failCallBackFun:
                failCallBackFun()

    def loadHost(self, ret=None):
        self.hostFavTypes = []
        # used / failed link marks only live as long as the host stays open
        self._usedLinkUrls = set()
        self._failedLinkUrls = set()
        try:
            _temp = __import__('Plugins.Extensions.IPTVPlayer.hosts.host' + self.hostName, globals(), locals(), ['IPTVHost'], 0)
            self.host = _temp.IPTVHost()
            if not isinstance(self.host, IHost):
                printDBG("Host [%r] does not inherit from IHost" % self.hostName)
                self.close()
                return
        except Exception as e:
            printExc('Cannot import class IPTVHost for host [%r]' % self.hostName)
            errorMessage = [_('Loading %s failed due to following error:') % self.hostName]
            elines = traceback.format_exc().splitlines()
            errorMessage.append("%s" % '\n'.join(elines[-3:]))
            self.session.open(MessageBox, '\n'.join(errorMessage), type=MessageBox.TYPE_ERROR, timeout=10)
            self.setStatusTex(_("Failed: %s") % e)
            return

        try:
            protectedByPin = self.host.isProtectedByPinCode() and not IsHostUnlocked(self.hostName)
        except Exception:
            printExc()
            protectedByPin = False

        if protectedByPin:
            # the right PIN unlocks the host until E2iPlayer is closed (also its favourites); a wrong one shows
            # "Pin incorrect!" and goes back to the host selection, like leaving the PIN dialog
            AskHostPin(self.session, self.hostName, self.loadHostData, onWrong=self.selectHost, onCancel=self.selectHost)
        else:
            self.loadHostData()

    def lcdSummaryCall(self, method, *args):
        # session.summary belongs to the top screen: while a MessageBox is open
        # it is a MessageBoxSummary without the E2iPlayer LCD methods
        func = getattr(self.session.summary, method, None)
        if func is not None:
            try:
                func(*args)
            except Exception:
                printExc()

    def loadHostData(self):
        self.lcdSummaryCall('setText', GetHostListTitle(self.hostTitle) or self.hostName)
        self.activePlayer = CMoviePlayerPerHost(self.hostName)
        # once per session, after the first host has loaded
        if self.showMessageNoFreeSpaceForIcon:
            self.showMessageNoFreeSpaceForIcon = False
            self.session.open(MessageBox, (_("There is no free space on the drive [%s].") % config.plugins.iptvplayer.CacheDir.value) + "\n" + _("New icons will not be available."), type=MessageBox.TYPE_INFO, timeout=10)

        # change logo for player
        self["playerlogo"].hide()
        self.lcdSummaryCall('LCD_hide', 'LCDlogo')
        self.hostLogoPath = None
        try:
            hRet = self.host.getLogoPath()
            if hRet.status == RetHost.OK and len(hRet.value):
                logoPath = hRet.value[0]
                if logoPath != '':
                    printDBG('Logo Path: ' + logoPath)
                    self.hostLogoPath = logoPath
                    if not self["playerlogo"].checkDecodeNeeded(logoPath):
                        self["playerlogo"].show()
                    else:
                        self["playerlogo"].decodeCover(logoPath, self.updateCover, "playerlogo")
                    self.lcdSummaryCall('LCD_showPic', 'LCDlogo', logoPath)
        except Exception:
            printExc()

        # get types of items which can be added as favourites
        self.hostFavTypes = []
        try:
            hRet = self.host.getSupportedFavoritesTypes()
            if hRet.status == RetHost.OK:
                self.hostFavTypes = hRet.value
        except Exception:
            printExc('The current host crashed')

        # request initial list from host
        self.getInitialList()
    # end selectHostCallback(self, ret):

    def selectLinkForCurrVideo(self, customUrlItems=None, parentLinkKey='', allowAuto=True):
        if not self.visible and not (self.autoPlaySeqStarted and
           config.plugins.iptvplayer.autoplay_start_delay.value == 0):
            self.setStatusTex("")
            self.showWindow()

        item = self.getSelItem()
        if item.type not in [CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO,
                             CDisplayListItem.TYPE_PICTURE, CDisplayListItem.TYPE_DATA]:
            printDBG("Incorrect item type[%s]" % item.type)
            return
        # mirror list: the video title; quality list of a resolved mirror: that mirror's key
        self._currentLinkVideoKey = parentLinkKey or item.name

        if None is customUrlItems:
            links = item.urlItems
        else:
            links = customUrlItems

        # There is no free links for current video
        numOfLinks = len(links)
        # mirror list (not the quality list of a resolved mirror): a new choice, a run before is over
        mirrorLevel = not parentLinkKey
        if mirrorLevel:
            self._autoLinkQueue = []
            self._autoLinkCurrent = None
            self._playLinkMirror = ''
        elif allowAuto and self._isAutoLinkChoice():
            # the qualities of a mirror chosen automatically: H.264 wider than the receiver decodes is left
            # out; with nothing else left the next mirror is tried (the last one plays it anyway)
            playable = [link for link in links if not linkpicker.isTooWideH264(link.name)]
            if not playable and self._autoLinkQueue and self._autoLinkCurrent is not None:
                printDBG("selectLinkForCurrVideo: link [%s] only has H.264 wider than 1920, trying the next one" % self._autoLinkCurrent.name)
                self._markAutoLinkFailed(self._autoLinkCurrent)
                self._startAutoLink(self._autoLinkQueue.pop(0))
                return
            links = playable or links
            numOfLinks = len(links)
        if 0 == numOfLinks:
            self._currentLinkOptions = None
            if not self.checkAutoPlaySequencer():
                message = _("No valid links available.")
                lastErrorMsg = GetIPTVPlayerLastHostError()
                if '' != lastErrorMsg:
                    message += "\n" + _('Last error: "%s"') % lastErrorMsg
                lastExcMSG = getExcMSG(True)
                if lastExcMSG != '':
                    message += "\n" + _("Last Exception error: '%s'") % lastExcMSG
                self.restoreLiveAfterZap()
                self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=10)
            return
        elif 1 == numOfLinks:
            # start VIDEO without links selection
            self._currentLinkOptions = links
            self._playLink(links[0])
            return

        self._currentLinkOptions = links
        if allowAuto:
            preferred = config.plugins.iptvplayer.preferred_quality.value
            if self._isAutoLinkChoice():
                # the sequencer never asks either; a mirror that fails to resolve or to play hands over to the next one
                queue = linkpicker.autoOrder(links, preferred, self._isLinkFailed)
                if mirrorLevel:
                    self._autoLinkMirrors = links
                    self._autoLinkVideoKey = self._currentLinkVideoKey
                    self._autoLinkTotal = len(queue)
                    self._autoLinkQueue = queue[1:]
                    self._startAutoLink(queue[0])
                else:
                    self._playLink(queue[0])
                return
            # "Default video quality" alone: H.264 the receiver cannot show only when nothing else is there
            playable = [link for link in links if not linkpicker.isTooWideH264(link.name)]
            link = linkpicker.pickByQuality(playable if len(playable) > 1 else links, preferred)
            if link is not None:
                self._playLink(link)
                return

        options = []
        for link in links:
            printDBG("selectLinkForCurrVideo: |%s| |%s|" % (link.name, link.url))
            keys = self._linkMarkKeys(link)
            options.append(IPTVChoiceBoxItem(link.name, "", link, failed=link.failed or not self._failedLinkUrls.isdisjoint(keys),
                                             used=not self._usedLinkUrls.isdisjoint(keys)))

        openChoiceBox(self.session, {'width': 600, 'height': self._getLinkPickerHeight(len(options)), 'current_idx': 0, 'title': _("Select link"), 'options': options, 'list_class': IPTVLinkChoiceBoxList, 'chrome': True, 'footerMargin': 136}, self.selectLinksCallback)

    # IPTVChoiceBoxWidget's screen declares resolution="1280,720", so the
    # skin engine already scales width/size per axis to the real screen
    # (1x HD, 1.5x FHD, 2x WQHD) - this has to be a single reference-space
    # constant, not stepped up per tier like the old code did, or it gets
    # scaled twice (which is exactly why WQHD ended up nearly full-screen)
    MOVIE_PLAYER_PICKER_WIDTH = 550

    def _getMoviePlayerPickerHeight(self, numItems):
        # same reference-space-vs-real-pixels reasoning as _getLinkPickerHeight,
        # but using IPTVRadioButtonList's (IPTVMainNavigatorList's) own real
        # per-tier item heights (35/40/55) instead of guessed constants.
        # +146 = the footerMargin passed below (136, itself derived from the
        # list's fixed y=66 + the 64px footer bar, see skinchrome.py's
        # build_footer() 2-line-wrap comment) plus a small 10px breathing
        # buffer - not the keyboard's
        # own +176, which assumes the chrome default footerMargin (166)
        # instead of this screen's 136
        itemH, scale = skinchrome.tierRowHeight(35, 40, 55)
        return int(numItems * itemH / scale) + 146

    def _getOptionsPickerHeight(self, numItems):
        # same reference-space-vs-real-pixels reasoning as
        # _getMoviePlayerPickerHeight(), but for keyHelp()'s
        # E2iVKOptionsList rows instead of IPTVMainNavigatorList ones -
        # mirrors e2ivk.py's own _getOptionsPickerHeight() formula exactly
        # (itemH 44/62/83, +176 assuming the chrome default footerMargin
        # of 166) since keyHelp() below never overrides footerMargin.
        itemH, scale = skinchrome.tierRowHeight(44, 62, 83)
        return int(numItems * itemH / scale) + 176

    def _getLinkPickerHeight(self, numItems):
        # unlike self.getSkinResolutionType()'s coarser 'sd'/'hd_ready'/'hd'
        # split (tuned for the pre-chrome skin's fixed 50px footer margin,
        # not the chrome footer's 136+, and lumping FHD/WQHD together
        # under 'hd' with the same fixed height), this uses the same
        # formula as _getMoviePlayerPickerHeight(): IPTVLinkChoiceBoxList
        # inherits IPTVMainNavigatorList's real per-tier item heights
        # (35/40/55), +146 = the footerMargin passed below (136) + a small
        # 10px breathing buffer
        itemH, scale = skinchrome.tierRowHeight(35, 40, 55)
        return int(numItems * itemH / scale) + 146

    def _linkMarkKeys(self, link):
        # a mirror is recognised again by its url, or - for hosts whose links carry a fresh
        # token on every fetch (e.g. shahid44u /m/<hash>) - by video title + mirror name
        # (+ its position among mirrors of the same name). The url key carries the name too:
        # hosts that list several mirrors under one url (data in the name / meta) keep them apart
        same = 0
        for other in self._currentLinkOptions or []:
            if other is link:
                break
            if other.name == link.name:
                same += 1
        return ["%s\t%s" % (link.url, link.name), "%s\t%s#%d" % (self._currentLinkVideoKey, link.name, same)]

    def selectLinksCallback(self, retArg):
        if retArg is None:
            # user cancelled the picker without trying any link - there's nothing
            # wrong, so don't show a "No valid links" error for it
            return
        if isinstance(retArg, IPTVChoiceBoxItem) and isinstance(retArg.privateData, CUrlItem):
            link = retArg.privateData
            videoUrl = link.url
            # remembered for this session: the picker marks the mirrors already chosen
            self._usedLinkUrls.update(self._linkMarkKeys(link))
            if isinstance(videoUrl, str) and len(videoUrl) > 3:
                # check if we need to resolve this URL (strict '1' check, same as the
                # original ChoiceBox-based code - some hosts store this as a string,
                # and a plain truthiness check would wrongly treat "0" as needing resolve)
                if str(link.urlNeedsResolve) == '1':
                    # call resolve link from host
                    self._resolvingLinkItem = link
                    self._playLinkMirror = link.name
                    self.requestListFromHost('ResolveURL', -1, videoUrl)
                else:
                    self._playLinkName = linkDisplayName(self._playLinkMirror, link.name)
                    list = []
                    list.append(videoUrl)
                    self.playVideo(RetHost(status=RetHost.OK, value=list))
                return
        self.playVideo(RetHost(status=RetHost.ERROR, value=[]))
    # end selectLinksCallback(self, retArg):

    def checkBuffering(self, url):
        # check flag forcing of the using/not using buffering
        if 'iptv_buffering' in url.meta:
            if "required" == url.meta['iptv_buffering']:
                # the stream only plays through a downloader, e.g. HLS segments the players' demuxer refuses
                return True
            elif "forbidden" == url.meta['iptv_buffering']:
                return False
            elif "remux" == url.meta['iptv_buffering']:
                # the players cannot play the source container itself: the downloader repacks it
                # while buffering (iptv_use_ffmpeg + ff_out_container), for every player
                return True
        if "|" in url:
            return True

        # check based on protocol
        protocol = url.meta.get('iptv_proto', '')
        if protocol in ['f4m', 'uds']:
            return True  # supported only in buffering mode
        elif protocol in ['http', 'https']:
            return config.plugins.iptvplayer.buforowanie.value
        elif 'rtmp' == protocol:
            return config.plugins.iptvplayer.buforowanie_rtmp.value
        elif protocol in ['m3u8', 'em3u8']:
            return config.plugins.iptvplayer.buforowanie_m3u8.value

    def isUrlBlocked(self, url, type):
        # shared with the batch download, which looks up its links outside of this screen
        return batchdownload.isUrlBlocked(url, type)

    def getFileExt(self, url, type):
        return batchdownload.getFileExt(url, type)

    def getMoviePlayer(self, buffering=False, useAlternativePlayer=False):
        printDBG("getMoviePlayer")
        return GetMoviePlayer(buffering, useAlternativePlayer)

    def writeCurrentTitleToFile(self, title):
        titleFilePath = config.plugins.iptvplayer.curr_title_file.value
        if "" != titleFilePath:
            try:
                with open(titleFilePath, 'w') as titleFile:
                    titleFile.write(title)
            except Exception:
                printExc()
        """
        if config.plugins.iptvplayer.set_curr_title.value:
            try:
                from enigma import evfd
                title = CParsingHelper.getNormalizeStr(title)
                evfd.getInstance().vfd_write_string(title[0:17])
            except Exception:
                printExc()
        """

    def _checkDestinationDir(self, destinationPath, recorderMode, url=None):
        # the folder a download (recorderMode) or the buffering goes to: created when missing, enough free
        # space -> lines of the message for the user, [] when all is fine. url: the decorated url (the host may
        # say how much space it needs), None for a batch download (checked once before its items are queued).
        errorTab = []
        if not os_path.exists(destinationPath):
            iptvtools_mkdirs(destinationPath)

        if not os_path.isdir(destinationPath):
            errorTab.append(_("Directory \"%s\" does not exists.") % destinationPath)
            errorTab.append(_("Please set valid %s in the %s configuration.") % (_("downloads location") if recorderMode else _("buffering location"), 'E2iPlayer'))
        else:
            requiredSpace = 3 * 512 * 1024 * 1024  # 1,5 GB
            if url is not None:
                try:
                    # a host that knows the size (e.g. a short clip) may ask for less, never for more
                    hostSpace = int(url.meta.get('iptv_buffering_space', 0))
                    if 0 < hostSpace < requiredSpace:
                        requiredSpace = hostSpace
                except (TypeError, ValueError):
                    printExc()
            availableSpace = iptvtools_FreeSpace(destinationPath, requiredSpace=None, unitDiv=1)
            if requiredSpace > availableSpace:
                errorTab.append(_("There is no enough free space in the folder \"%s\".") % destinationPath)
                errorTab.append(_("\tDisk space required: %s") % formatBytes(requiredSpace))
                errorTab.append(_("\tDisk space available: %s") % formatBytes(availableSpace))

        if errorTab:
            errorTab.append("\n")
            errorTab.append(_("Tip! You can connect USB flash drive to fix this problem."))
        return errorTab

    def playVideo(self, ret):
        printDBG("playVideo")
        url = ''
        if RetHost.OK == ret.status:
            if len(ret.value) > 0:
                url = ret.value[0]

        self.setStatusTex("")
        self["list"].show()

        if url != '' and CDisplayListItem.TYPE_PICTURE == self.currItem.type:
            # the picture player shows no playlist, the picture is ticked as played in the next player's one
            self._takePlaylistForPlayer()
            self.session.openWithCallback(self.leavePicturePlayer, IPTVPicturePlayerWidget, url, config.plugins.iptvplayer.bufferingPath.value, self.currItem.name, {'seq_mode': self.autoPlaySeqStarted})
        elif url != '' and self.isDownloadableType(self.currItem.type):
            printDBG("playVideo url[%s]" % url)
            if self.currItem.type == CDisplayListItem.TYPE_DATA:
                recorderMode = True
            else:
                recorderMode = self.recorderMode
            url = urlparser.decorateUrl(url)
            # a host may name the downloaded file differently from the row (hostxxx HQPORNER: "<performers> - <title>")
            titleOfMovie = batchdownload.cleanFileTitle((url.meta.get('iptv_download_title', '') if recorderMode else '') or self.currItem.name)
            fileExtension = self.getFileExt(url, self.currItem.type)

            blocked, reaseon = self.isUrlBlocked(url, self.currItem.type)
            if blocked:
                self.session.open(MessageBox, reaseon, type=MessageBox.TYPE_INFO, timeout=10)
                return

            if url.startswith('file://'):
                isBufferingMode = False
            elif url.meta.get('iptv_buffering', '') in ('required', 'forbidden'):
                # the stream itself demands it, this overrides the player chosen for the host
                isBufferingMode = self.checkBuffering(url)
            else:
                isBufferingMode = self.activePlayer.get('buffering', self.checkBuffering(url))
                if not isBufferingMode and "remux" == url.meta.get('iptv_buffering', ''):
                    # a player chosen "without buffering" for this host could not play it at all
                    isBufferingMode = True
            bufferingPath = config.plugins.iptvplayer.bufferingPath.value
            downloadingPath = config.plugins.iptvplayer.DownloadsDir.value
            destinationPath = downloadingPath if recorderMode else bufferingPath

            if recorderMode or isBufferingMode:
                errorTab = self._checkDestinationDir(destinationPath, recorderMode, url)
                if errorTab:
                    self.stopAutoPlaySequencer()
                    self.session.open(MessageBox, '\n'.join(errorTab), type=MessageBox.TYPE_INFO, timeout=10)
                    return

            if recorderMode:
                if None is not gDownloadManager:
                    if IsUrlDownloadable(url):
                        fullFilePath = downloadingPath + '/' + titleOfMovie + fileExtension
                        dmItem = DMItem(url, fullFilePath)
                        try:
                            hostName, itemUrl = self._getRowSource(self.currItem.itemIdx, self.currItem)
                            # a live row (M4 Sport live, a radio station ...) gets no downloaded marker
                            dmItem.itemKey = batchdownload.recordingMarkerKey(self._getBatchRawRow(self.currItem), getattr(url, 'meta', {}), iptvdownloaded.getItemKey(hostName, itemUrl, self.currItem.name))
                        except Exception:
                            printExc()
                        ret = gDownloadManager.addToDQueue(dmItem)
                        if ret:
                            self.refreshRowMarkers()
                        else:
                            self.session.open(MessageBox, _("File [%s] is already in the downloading queue.") % titleOfMovie, type=MessageBox.TYPE_INFO, timeout=10)
                    else:
                        ret = False
                        self.session.open(MessageBox, _("File can not be downloaded. Protocol [%s] is unsupported") % url.meta.get('iptv_proto', ''), type=MessageBox.TYPE_INFO, timeout=10)
                    if ret:
                        if not self.checkAutoPlaySequencer():
                            if config.plugins.iptvplayer.IPTVDMShowAfterAdd.value:
                                self.runIPTVDM()
                            else:
                                self.session.open(MessageBox, _("File [%s] was added to downloading queue.") % titleOfMovie, type=MessageBox.TYPE_INFO, timeout=10)
                    else:
                        self.stopAutoPlaySequencer()
                else:
                    self.stopAutoPlaySequencer()
                    self.session.open(MessageBox, _("File can not be downloaded. Download manager is not available."), type=MessageBox.TYPE_ERROR, timeout=10)
            else:
                # genuinely about to stream (not download) and every earlier check
                # (blocked url, missing directory, low disk space) already passed -
                # this is the only place that marks the item "started"
                try:
                    if hasattr(self.host, 'markItemAsStarted'):
                        # the index in the host list (a shuffled / reversed list shows the rows in another order)
                        self.host.markItemAsStarted(self._getSelHostIndex())
                except Exception:
                    printExc()

                self.prevVideoMode = GetE2VideoMode()
                printDBG("Current video mode [%s]" % self.prevVideoMode)
                gstAdditionalParams = {'defaul_videomode': self.prevVideoMode, 'host_name': self._getRowsHostName(), 'external_sub_tracks': url.meta.get('external_sub_tracks', []), 'iptv_refresh_cmd': url.meta.get('iptv_refresh_cmd', '')}  # default_player_videooptions
                # CH+/CH- in the player -> leaveMoviePlayer('zap_next'/'zap_prev'); cover/logo for its screensaver
                gstAdditionalParams['zap_enabled'] = True
                gstAdditionalParams['audio_item'] = self.currItem.type == CDisplayListItem.TYPE_AUDIO
                gstAdditionalParams['logo_path'] = self.hostLogoPath or ''
                try:
                    iconUrl = self.currItem.iconimage
                    if iconUrl and self.iconMenager and not self.iconMenager.isIconFailed(iconUrl):  # no red X, the logo instead
                        gstAdditionalParams['cover_path'] = self.iconMenager.getIconPathFromAAueue(iconUrl)
                except Exception:
                    printExc()
                if self.currItem.type == CDisplayListItem.TYPE_AUDIO:
                    gstAdditionalParams['show_iframe'] = config.plugins.iptvplayer.show_iframe.value
                    gstAdditionalParams['iframe_file_start'] = config.plugins.iptvplayer.iframe_file.value
                    gstAdditionalParams['iframe_file_end'] = config.plugins.iptvplayer.clear_iframe_file.value
                    gstAdditionalParams['iframe_continue'] = False
                # a run of the sequencer: info line + playlist overlay in the player (also through the buffering
                # widget, which hands these params on); the mini / standard player get none of these params
                playlist = self._takePlaylistForPlayer()
                if playlist:
                    gstAdditionalParams['playlist'] = playlist

                # INFO in the player: where the video comes from and the texts of the host's INFO page
                gstAdditionalParams['link_name'] = self._playLinkName
                gstAdditionalParams['info_provider'] = boundFunction(self._requestPlayerArticle, self._getSelHostIndex())
                try:
                    gstAdditionalParams['host_title'] = self._getPlayerHostTitle()
                    gstAdditionalParams['info_description'] = self.currItem.description
                except Exception:
                    printExc()

                self.writeCurrentTitleToFile(titleOfMovie)
                self.zapLivePending = False
                self._autoLinkQuietPlayer = False
                if isBufferingMode:
                    self.session.nav.stopService()
                    player = self.activePlayer.get('player', self.getMoviePlayer(True, self.useAlternativePlayer))
                    self.session.openWithCallback(self.leaveMoviePlayer, E2iPlayerBufferingWidget, url, bufferingPath, downloadingPath, titleOfMovie, player.value, self.bufferSize, gstAdditionalParams, gDownloadManager, fileExtension)
                else:
                    self.session.nav.stopService()
                    player = self.activePlayer.get('player', self.getMoviePlayer(False, self.useAlternativePlayer))
                    if "mini" == player.value:
                        self.session.openWithCallback(self.leaveMoviePlayer, IPTVMiniMoviePlayer, url, titleOfMovie)
                    elif "standard" == player.value:
                        self.session.openWithCallback(self.leaveMoviePlayer, IPTVStandardMoviePlayer, url, titleOfMovie)
                    else:
                        if "extgstplayer" == player.value:
                            playerVal = 'gstplayer'
                            gstAdditionalParams['download-buffer-path'] = ''
                            gstAdditionalParams['ring-buffer-max-size'] = 0
                            gstAdditionalParams['buffer-duration'] = 18000  # 300min
                            gstAdditionalParams['buffer-size'] = 10240  # 10MB
                        else:
                            assert ("exteplayer" == player.value)
                            playerVal = 'eplayer'
                        if self._autoLinkQueue:
                            # further mirrors left: a stream that does not start comes back without a message
                            self._autoLinkQuietPlayer = True
                            gstAdditionalParams['quiet_start_errors'] = True
                        self.session.openWithCallback(self.leaveMoviePlayer, IPTVExtMoviePlayer, url, titleOfMovie, None, playerVal, gstAdditionalParams)
        else:
            # There was problem in resolving direct link for video
            if not self.checkAutoPlaySequencer():
                self.restoreLiveAfterZap()
                self.session.open(MessageBox, _("No valid links available."), type=MessageBox.TYPE_INFO, timeout=10)
    # end playVideo(self, ret):

    def _getPlayerHostTitle(self):
        # a row of another host (result of hostgroupsearch) only has that host's name
        name = self._getRowsHostName()
        if name != self.hostName or not self.hostTitle:
            return name
        site = ''
        if 'xxx' == name and self.categoryList:
            # its main menu lists the sites; the watchlist (+++ ... +++) and a search result are none
            first = self.categoryList[0]
            if not first.startswith('+++') and first != _("Search results"):
                site = StripColorCodes(first)
        return hostDisplayName(self.hostTitle, site)

    def _requestPlayerArticle(self, hostIndex, callback):
        # not as self.workThread: while it runs, CH+/CH- in the player could not start the next item
        return asynccall.AsyncMethod(self.host.getArticleContent, callback)(hostIndex)

    def leaveMoviePlayer(self, answer=None, lastPosition=None, clipLength=None, *args, **kwargs):
        self.writeCurrentTitleToFile("")
        videoMode = GetE2VideoMode()
        printDBG("Current video mode [%s], previus video mode [%s]" % (videoMode, self.prevVideoMode))
        if None not in [self.prevVideoMode, videoMode] and self.prevVideoMode != videoMode:
            printDBG("Restore previus video mode")
            SetE2VideoMode(self.prevVideoMode)

        quietPlayer = self._autoLinkQuietPlayer
        self._autoLinkQuietPlayer = False
        if quietPlayer and answer is None and not lastPosition and self._autoLinkQueue and self._autoLinkCurrent is not None:
            # "Select link automatically": the stream stopped before playback started (player closed on its
            # own, position 0) - mark the mirror and go on with the next one
            printDBG("leaveMoviePlayer: link [%s] did not start, trying the next one" % self._autoLinkCurrent.name)
            self._markAutoLinkFailed(self._autoLinkCurrent)
            self._startAutoLink(self._autoLinkQueue.pop(0))
            return
        # played (or left by the user): the automatic run is over
        self._autoLinkQueue = []

        # CH+/CH- in the player: go on with the next/previous playable item of this list; an entry chosen in the
        # playlist overlay of a run of the sequencer: ('zap_to', row, key), go on with that row (zapToRow)
        if listselection.isZapToAnswer(answer):
            zap = answer
        else:
            zap = {'zap_next': 1, 'zap_prev': -1}.get(answer, 0)
        try:
            if answer is not None and not zap:
                self.stopAutoPlaySequencer()
        except Exception:
            printExc()

        if not config.plugins.iptvplayer.disable_live.value and not self.autoPlaySeqStarted and not zap:
            self.session.nav.playService(self.currentService)

        if lastPosition is not None and clipLength is not None and clipLength > 0:
            try:
                if config.plugins.iptvplayer.favourites_use_watched_flag.value and (lastPosition * 100 / clipLength) > 95 and hasattr(self.host, 'markItemAsViewed'):
                    currSelIndex = self["list"].getCurrentIndex()
                    self.pendingZap = zap
                    self.requestListFromHost('MarkItemAsViewed', currSelIndex)
                    return
            except Exception:
                printExc()

        if zap:
            self._zapFromPlayer(zap)
        else:
            self.checkAutoPlaySequencer()

    def _zapFromPlayer(self, zap):
        if listselection.isZapToAnswer(zap):
            self.zapToRow(zap)
        else:
            self.zapToItem(zap)

    def getScreenSaverInfo(self):
        # title and pictures of the black menu screensaver: the open host, else E2iPlayer itself
        e2iLogo = skinchrome.getIconBase() + '/iptvlogo.png'
        if self.hostName:
            return self.hostTitle or self.hostName, [self.hostLogoPath or '', e2iLogo]
        return 'E2iPlayer', [e2iLogo]

    def zapToItem(self, direction):
        idx = self.getSelIndex()
        if -1 != idx:
            idx += direction
            while 0 <= idx < len(self.currList):
                row = self.currList[idx]
                # a run of "Play marked items" zaps only between the marked rows
                if row.type in [CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO] and not self._itemNeedsPin(row) and (not self.autoPlayMarkedOnly or listselection.isMarked(row)):
                    self["list"].moveToIndex(idx)
                    # live TV stays off between the items; restoreLiveAfterZap() if this one does not start
                    self.zapLivePending = True
                    self.ok_pressed('zap')
                    return
                idx += direction
        # first/last playable item of the list: back to the list as after a normal stop
        if not self.stopAutoPlaySequencer() and not config.plugins.iptvplayer.disable_live.value:
            self.session.nav.playService(self.currentService)
        self.showWindow()
        message = _("There is no next item in this list.") if direction > 0 else _("There is no previous item in this list.")
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=5)

    def zapToRow(self, answer):
        # an entry chosen in the playlist overlay of the player (only offered in a run of the sequencer): that row
        # starts like a zap (zapToItem), the sequencer keeps running (also "Play marked items") and goes on from it
        idx = listselection.findZapToRow(self.currList, answer, self._getRowIdentity)
        if -1 != idx:
            self["list"].moveToIndex(idx)
            self.zapLivePending = True
            self.ok_pressed('zap')
            return
        # the row is not in the list any more: back to the list as after a normal stop
        if not self.stopAutoPlaySequencer() and not config.plugins.iptvplayer.disable_live.value:
            self.session.nav.playService(self.currentService)
        self.showWindow()

    def restoreLiveAfterZap(self):
        # the zapped item did not start (no valid link, link selection left): live TV back as after a normal stop
        if self.zapLivePending:
            self.zapLivePending = False
            if not self.autoPlaySeqStarted and not config.plugins.iptvplayer.disable_live.value:
                self.session.nav.playService(self.currentService)

    def leavePicturePlayer(self, answer=None, lastPosition=None, *args, **kwargs):
        self.checkAutoPlaySequencer()

    def requestListFromHost(self, type, currSelIndex=-1, privateData=''):

        if not self.isInWorkThread():
            self["list"].hide()
            GetIPTVSleep().Reset()

            if type not in ['ForVideoLinks', 'ResolveURL', 'ForArticleContent', 'ForFavItem', 'PerformCustomAction']:
                # hide bottom panel
                self["cover"].hide()
                self["console"].setText('')

            if (type == 'ForItem' or type == 'ForSearch') and getattr(self.currItem, 'type', None) not in CDisplayListItem.NON_NAVIGATING_TYPES:
                self.prevSelList.append(self.currSelIndex)
                if type == 'ForSearch':
                    self.categoryList.append(CategoryPathEntry(_("Search results")))
                else:
                    entry = CategoryPathEntry(self.currItem.name)
                    entry.pagerKind = PagerKind(self.currItem)
                    if entry.pagerKind:
                        entry.item = self.currItem
                    self.categoryList.append(entry)
                # new list, so select first index
                self.nextSelIndex = 0

            selItem = None
            if currSelIndex > -1 and len(self.currList) > currSelIndex:
                selItem = self.currList[currSelIndex]
                if self.isPlayableType(selItem.type) and selItem.itemIdx > -1 and len(self.currList) > selItem.itemIdx:
                    currSelIndex = selItem.itemIdx

            dots = ""  # _("...............")
            IDS_DOWNLOADING = _("Downloading") + dots
            IDS_LOADING = _("Loading") + dots
            IDS_REFRESHING = _("Refreshing") + dots
            try:
                if type == 'Refresh':
                    self.setStatusTex(IDS_REFRESHING)
                    self.workThread = asynccall.AsyncMethod(self.host.getCurrentList, boundFunction(self.callbackGetList, {'refresh': 1, 'selIndex': currSelIndex}), True)(1)
                elif type == 'ForMore':
                    self.setStatusTex(IDS_DOWNLOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getMoreForItem, boundFunction(self.callbackGetList, {'refresh': 2, 'selIndex': currSelIndex}), True)(currSelIndex)
                elif type == 'Initial':
                    self.setStatusTex(IDS_DOWNLOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getInitList, boundFunction(self.callbackGetList, {}), True)()
                elif type == 'Previous':
                    self.setStatusTex(IDS_DOWNLOADING)
                    if isinstance(privateData, int) and 1 < privateData:
                        # EXIT over paged lists: several host levels back at once (back_pressed)
                        self.workThread = asynccall.AsyncMethod(self._getPrevLists, boundFunction(self.callbackGetList, {}), True)(privateData)
                    else:
                        self.workThread = asynccall.AsyncMethod(self.host.getPrevList, boundFunction(self.callbackGetList, {}), True)()
                elif type == 'ForItem':
                    self.setStatusTex(IDS_DOWNLOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getListForItem, boundFunction(self.callbackGetList, {}), True)(currSelIndex, 0, selItem)
                elif type == 'ForVideoLinks':
                    self.setStatusTex(IDS_LOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getLinksForVideo, self.selectHostVideoLinksCallback, True)(currSelIndex, selItem)
                elif type == 'ResolveURL':
                    self.setStatusTex(IDS_LOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getResolvedURL, self.getResolvedURLCallback, True)(privateData)
                elif type == 'ForSearch':
                    self.setStatusTex(IDS_LOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getSearchResults, boundFunction(self.callbackGetList, {}), True)(self.searchPattern, self.searchType)
                elif type == 'ForArticleContent':
                    self.setStatusTex(IDS_DOWNLOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getArticleContent, self.getArticleContentCallback, True)(currSelIndex)
                elif type == 'ForFavItem':
                    self.setStatusTex(IDS_LOADING)
                    self.workThread = asynccall.AsyncMethod(self.host.getFavouriteItem, self.getFavouriteItemCallback, True)(currSelIndex)
                elif type == 'PerformCustomAction':
                    self.workThread = asynccall.AsyncMethod(self.host.performCustomAction, self.performCustomActionCallback, True)(privateData)
                elif type == 'MarkItemAsViewed':
                    self.workThread = asynccall.AsyncMethod(self.host.markItemAsViewed, self.markItemAsViewedCallback, True)(currSelIndex)
                else:
                    printDBG('requestListFromHost unknown list type: ' + type)
                self.showSpinner()
            except Exception:
                printExc('The current host crashed')
                self.handleHostError()
    # end requestListFromHost(self, type, currSelIndex = -1, privateData = ''):

    def startSearchProcedure(self, searchTypes):
        if config.plugins.iptvplayer.osk_remember_last_search.value:
            sts, prevPattern = CSearchHistoryHelper.loadLastPattern()
            if sts:
                self.searchPattern = prevPattern
        else:
            self.searchPattern = ''
        if searchTypes:
            # dormant in practice: every real host that ever sets
            # `possibleTypesOfSearch` (hosturllist.py/hosttvjworg.py)
            # initializes its own options list to an
            # always-empty `[]` - hosturllist.py even still has its
            # intended real entries ("Filmy"/"Seriale") commented out -
            # so this branch never actually fires today, but it's real,
            # reachable code a host could turn back on, unlike
            # displayListOfHosts()'s dead "Select service" ChoiceBox
            # above (removed, that one was unreachable text, not code).
            choiceItems = [IPTVChoiceBoxItem(name=opt[0], privateData=opt[1]) for opt in searchTypes]
            height = self._getMoviePlayerPickerHeight(len(choiceItems))
            openChoiceBox(self.session, {'width': 600, 'height': height, 'current_idx': 0, 'title': _("Search type"), 'options': choiceItems, 'chrome': True, 'footerMargin': 136}, self.selectSearchTypeCallback)
        else:
            self.searchType = None
            self.doSearchWithVirtualKeyboard()

    def selectSearchTypeCallback(self, ret=None):
        if ret:
            self.searchType = ret.privateData
            self.doSearchWithVirtualKeyboard()
        else:
            pass

    def _resolveSuggestionsProvider(self):
        # !!! NON BLOCKING !!! host suggestions call method directly on the
        # host, so it must never block. Used both for the keyboard's initial
        # provider and, via additionalParams['resolve_suggestions_provider'],
        # to re-resolve live when "Default suggestions provider" / "Allow
        # host to override suggestions provider" change while the keyboard
        # is already open (e2ivk.py calls it again from its Settings-closed
        # callback). None: no suggestions ("Show suggestions" off, provider
        # "None").
        if not config.plugins.iptvplayer.osk_allow_suggestions.value:
            return None
        suggestionsProvider = None
        try:
            if config.plugins.iptvplayer.osk_allow_host_suggestions.value and self.visible and not self.isInWorkThread():
                currSelIndex = self.getSelItem().itemIdx
                hRet = self.host.getSuggestionsProvider(currSelIndex)
                if hRet.status == RetHost.OK and hRet.value and hRet.value[0]:
                    suggestionsProvider = hRet.value[0] if hRet.value[0] is not None else False
        except Exception:
            printExc()

        if suggestionsProvider is None:
            providerAlias = config.plugins.iptvplayer.osk_default_suggestions.value
            if not providerAlias:
                if not self.groupObj:
                    self.groupObj = IPTVHostsGroups()
                if self.hostName in self.groupObj.PREDEFINED_HOSTS['moviesandseries']:
                    if self.hostName in self.groupObj.PREDEFINED_HOSTS['polish']:
                        providerAlias = 'filmweb'
                    else:
                        providerAlias = 'imdb'
                else:
                    providerAlias = 'google'

            if providerAlias == 'filmweb':
                from Plugins.Extensions.IPTVPlayer.suggestions.filmweb import SuggestionsProvider as filmweb_Provider
                suggestionsProvider = filmweb_Provider()
            elif providerAlias == 'imdb':
                from Plugins.Extensions.IPTVPlayer.suggestions.imdb import SuggestionsProvider as imdb_Provider
                suggestionsProvider = imdb_Provider()
            elif providerAlias == 'google':
                from Plugins.Extensions.IPTVPlayer.suggestions.google import SuggestionsProvider as google_Provider
                suggestionsProvider = google_Provider()
            elif providerAlias == 'bing':
                from Plugins.Extensions.IPTVPlayer.suggestions.bing import SuggestionsProvider as bing_Provider
                suggestionsProvider = bing_Provider()
            elif providerAlias == 'duckduckgo':
                from Plugins.Extensions.IPTVPlayer.suggestions.duckduckgo import SuggestionsProvider as duckduckgo_Provider
                suggestionsProvider = duckduckgo_Provider()
        return suggestionsProvider

    def doSearchWithVirtualKeyboard(self):
        printDBG("doSearchWithVirtualKeyboard")
        caps = {}
        virtualKeyboard = GetVirtualKeyboard(caps)

        if caps.get('has_additional_params'):
            try:
                # is_search: the keyboard adds the text to its search history
                additionalParams = {'is_search': True}
                if caps.get('has_suggestions'):
                    suggestionsProvider = self._resolveSuggestionsProvider()
                    if suggestionsProvider:
                        from Plugins.Extensions.IPTVPlayer.components.e2ivksuggestion import AutocompleteSearch
                        additionalParams['autocomplete'] = AutocompleteSearch(suggestionsProvider)
                        # only offered when the suggestions panel exists from
                        # the start - e2ivk.py's skin decides whether to lay
                        # out right_list/right_header once, at open time,
                        # based on additionalParams['autocomplete'] being set
                        additionalParams['resolve_suggestions_provider'] = self._resolveSuggestionsProvider

                self.session.openWithCallback(self.enterPatternCallBack, virtualKeyboard, title=(_("Your search entry")), text=self.searchPattern, additionalParams=additionalParams)
                return
            except Exception:
                printExc()
        self.session.openWithCallback(self.enterPatternCallBack, virtualKeyboard, title=(_("Your search entry")), text=self.searchPattern)

    def enterPatternCallBack(self, callback=None):
        if callback is not None and len(callback):
            self.searchPattern = callback
            if config.plugins.iptvplayer.osk_remember_last_search.value:
                CSearchHistoryHelper.saveLastPattern(self.searchPattern)
            self.requestListFromHost('ForSearch')

    def configCallback(self):
        self.selectHost()

    # shuffle / reverse of the playable rows: toggles ("Undo shuffle" / "Undo reverse"), both can be on at once.
    # The list as the host gave it is kept at the first change and the order is always built from it
    # (tools/listselection.arrangeRows), so undoing one keeps the other; marks are attributes of the rows and move
    # with them. A new list (reloadList) starts in the original order again.
    def _isOrderMovableRow(self, item):
        return isinstance(item, CDisplayListItem) and self.isPlayableType(item.type)

    def _canChangeListOrder(self):
        return self.visible and len(self.currList) > 1 and not self.isInWorkThread()

    def randomizePlayableItems(self):
        printDBG("randomizePlayableItems")
        self.stopAutoPlaySequencer()
        if not self._canChangeListOrder():
            return
        if self.listShuffleOrder is None:
            original = self.currList if self.listOrderOriginal is None else self.listOrderOriginal
            self.listShuffleOrder = listselection.newShuffleOrder(len([item for item in original if self._isOrderMovableRow(item)]))
        else:
            self.listShuffleOrder = None
        self._applyListOrder()

    def reversePlayableItems(self):
        printDBG("reversePlayableItems")
        self.stopAutoPlaySequencer()
        if not self._canChangeListOrder():
            return
        self.listReversed = not self.listReversed
        self._applyListOrder()

    def _applyListOrder(self):
        if self.listOrderOriginal is None:
            self.listOrderOriginal = self.currList
        self.currList = listselection.arrangeRows(self.listOrderOriginal, self._isOrderMovableRow, self.listShuffleOrder, self.listReversed)
        if self.listShuffleOrder is None and not self.listReversed:
            self.listOrderOriginal = None
        self["list"].setList([(x,) for x in self.currList])
        self.setHeaderText()

    def _resetListOrder(self):
        self.listOrderOriginal = None
        self.listShuffleOrder = None
        self.listReversed = False

    def _getListOrderMarker(self):
        # shown at the end of the header while the order of the list is changed
        labels = []
        if self.listShuffleOrder is not None:
            labels.append(_('shuffled'))
        if self.listReversed:
            labels.append(_('reversed'))
        if labels:
            return '  (%s)' % ', '.join(labels)
        return ''

    def _restoreListState(self, keptState):
        # the sequencer's refresh brought the same rows again (in the host's order): marks, selection mode and
        # the changed order go over to them, and the row the sequencer goes on from is looked up in that order
        oldRows, selectMode, shuffleOrder, reverse = keptState
        if not listselection.carryMarks(oldRows, self.currList, self._getRowIdentity):
            return
        self.selectMode = selectMode
        if shuffleOrder is None and not reverse:
            return
        self.listOrderOriginal = self.currList
        self.listShuffleOrder = shuffleOrder
        self.listReversed = reverse
        self.currList = listselection.arrangeRows(self.listOrderOriginal, self._isOrderMovableRow, shuffleOrder, reverse)
        # nextSelIndex is the row's index in the host list (requestListFromHost('Refresh'))
        for pos, item in enumerate(self.currList):
            if getattr(item, 'itemIdx', -1) == self.nextSelIndex:
                self.nextSelIndex = pos
                break

    def _getSelHostIndex(self):
        # the selected row's index in the host list - not its place in a shuffled / reversed list
        idx = self.getSelIndex()
        if -1 < idx and -1 < getattr(self.currList[idx], 'itemIdx', -1):
            return self.currList[idx].itemIdx
        return idx

    def _removeListRow(self, pos):
        # a row the host dropped from its list as well (a removed favourite): also out of the remembered original
        # order of a shuffled / reversed list, the rows behind it get their new index in the host list. In place:
        # the original list is the host's own one (the favourites' cachedRet), it must lose the row too.
        row = self.currList[pos]
        if self.listOrderOriginal is None:
            listselection.removeRow(self.currList, row, self._isOrderMovableRow)
        else:
            self.listOrderOriginal, self.listShuffleOrder = listselection.removeRow(self.listOrderOriginal, row, self._isOrderMovableRow, self.listShuffleOrder)
            del self.currList[pos]

    @staticmethod
    def _getRowIdentity(item):
        # what a row is for _restoreListState(): its place in the host list alone would let a refreshed list of
        # other rows with the same length take the marks and the order
        return (getattr(item, 'itemIdx', -1), str(getattr(item, 'type', '')), str(getattr(item, 'name', '')))

    def reloadList(self, params):
        printDBG("reloadList")
        # a page CH- preset for a Jump row is used once - a host whose Jump did not take it must not pass it on
        iptvpaging.presetJumpPage(None)
        # suppresses _rememberHistorySelection() while the list below is being
        # (re)built and its selection moved around programmatically
        self._isLoadingList = True
        refresh = params['add_param'].get('refresh', 0)
        selIndex = params['add_param'].get('selIndex', -1)
        ret = params['ret']
        printDBG("> E2iPlayerWidget.reloadList refresh[%s], selIndex[%s]" % (refresh, selIndex))
        # the marks and the changed order belong to the rows of the list that is replaced now - only a refresh
        # in the middle of a run of the sequencer (e.g. the watched flag of a favourite) keeps them, see below
        keptState = None
        if 1 == refresh and self.autoPlaySeqStarted and ret.status == RetHost.OK:
            keptState = (self.currList if self.listOrderOriginal is None else self.listOrderOriginal, self.selectMode, self.listShuffleOrder, self.listReversed)
        self.selectMode = False
        self._resetListOrder()
        if 0 < refresh and -1 < selIndex:
            self.nextSelIndex = selIndex
        # ToDo: check ret.status if not OK do something :P
        if ret.status != RetHost.OK:
            printDBG("+ reloadList ret.status = %s" % ret.status)
            self.stopAutoPlaySequencer()

        self.canRandomizeList = False
        numPlayableItems = 0
        for idx in range(len(ret.value)):
            if isinstance(ret.value[idx], CDisplayListItem):
                ret.value[idx].itemIdx = idx
                if self.isPlayableType(ret.value[idx].type):
                    numPlayableItems += 1

        if numPlayableItems > 1:
            self.canRandomizeList = True

        self.currList = ret.value
        if keptState is not None:
            self._restoreListState(keptState)
        else:
            # a host may hand out its cached rows again (WatchedFlagHostMixin.getCurrentList): no old marks on them
            listselection.clearMarks(self.currList)
        self._updateRowMarkers()
        self["list"].setList([(x,) for x in self.currList])

        if self.categoryList and isinstance(self.categoryList[-1], CategoryPathEntry):
            previousPage = getattr(self.categoryList[-2], 'page', None) if 1 < len(self.categoryList) else None
            self.categoryList[-1].page, self.categoryList[-1].last, self.categoryList[-1].lastPage = ListPage(self.categoryList[-1], previousPage, self.currList)
        self.setHeaderText()
        if len(self.currList) <= 0:
            # one line per part, no empty line between them: the host's reason was the 4th line and fell off
            # the status box (2 lines high in most skins)
            lines = [_("No item to display. \nPress OK to refresh.\n").strip()]
            if ret.message and ret.message.strip():
                lines.append(ret.message.strip())
            lastErrorMsg = GetIPTVPlayerLastHostError()
            if lastErrorMsg != '':
                lines.append(_('Last error: "%s"') % lastErrorMsg)
            lastExcMSG = getExcMSG(True)
            if lastExcMSG != '':
                lines.append(_('Last Exception error: "%s"') % lastExcMSG)

            self.setStatusTex("\n".join(lines))
            self["list"].hide()
        else:
            # restor previus selection
            if len(self.currList) > self.nextSelIndex:
                self["list"].moveToIndex(self.nextSelIndex)
            # else:
            # selection will not be change so manualy call
            self.changeBottomPanel()

            self.setStatusTex("")
            self["list"].show()
        self._isLoadingList = False
        self._restoreHistorySelection()
        self.updateDownloadButton()
        if 2 == refresh:
            self.autoPlaySequencerNext(False)
        elif 1 == refresh:
            self.autoPlaySequencerNext()
    # end reloadList(self, ret):

    def getCategoryPath(self, maxLen=0, skip=0):
        return CategoryPath(self.hostTitle, self.categoryList, _('Page:'), _('Last'), maxLen, skip)

    def _headerFonts(self):
        # the skin font of the header and two smaller ones that fit a path in two lines into the same height
        # (the list below keeps its place); the skin font is rebuilt from the label's font attribute with the
        # skin's own parseFont and this screen's scale, exactly as Enigma2 applied it (a short path keeps the
        # full size) - [] when a skin gives nothing to go by (the header then stays one line)
        label = self["headertext"]
        if label.instance is None:  # before the skin is applied
            return []
        if self._headerFontsCache is None:
            self._headerFontsCache = []
            # a skin without a font attribute on the header (Enigma2's default font): nothing to go by, and no
            # KeyError in the log - printExc made it the "Last Exception error" of every later host message
            fontAttr = dict(label.skinAttributes or []).get('font')
            if not fontAttr:
                return self._headerFontsCache
            try:
                from skin import parseFont
                font = parseFont(fontAttr, getattr(self, 'scale', ((1, 1), (1, 1))))
                self._headerFontsCache = [font] + [gFont(font.family, int(font.pointSize * factor)) for factor in (0.8, 0.7)]
            except Exception:
                printExc()
        return self._headerFontsCache

    def setHeaderText(self):
        # the header path in the skin font; too long for one line: in two lines with a smaller font, then
        # long names (a video title, a search phrase) are shortened and a deep path loses its first levels
        # ("Host > … > last levels") until it fits - measured on the label so it works with every skin.
        # A shuffled / reversed list says so at the end (_getListOrderMarker).
        label = self["headertext"]
        marker = self._getListOrderMarker()
        fonts = self._headerFonts()
        small = fonts[-1] if fonts else None
        steps = [(font, 0, 0) for font in (fonts or [None])]
        steps += [(small, maxLen, 0) for maxLen in (60, 40, 25, 15)]
        steps += [(small, 15, skip) for skip in range(1, len(self.categoryList))]
        for font, maxLen, skip in steps:
            try:
                if font is not None:
                    label.instance.setFont(font)
            except Exception:
                printExc()
            label.setText(self.getCategoryPath(maxLen, skip) + marker)
            try:
                if label.instance.calculateSize().height() <= label.instance.size().height():
                    break
            except Exception:
                break

    def getRefreshedCurrList(self):
        currSelIndex = self["list"].getCurrentIndex()
        self.requestListFromHost('Refresh', currSelIndex)

    def getInitialList(self):
        self.nextSelIndex = 0
        self.prevSelList = []
        self.categoryList = []
        self.currList = []
        self.currItem = CDisplayListItem()
        self.favouritesCurrentGroupId = ''
        self.selectMode = False
        self._resetListOrder()
        self.setHeaderText()
        self.requestListFromHost('Initial')

    def hideWindow(self):
        self.visible = False
        self.hide()

    def showWindow(self):
        self.visible = True
        self.show()
        self.restoreLiveAfterZap()

    def createSummary(self):
        return listSummaryIfWanted()

    def canByAddedToFavourites(self):
        cItem = None
        index = -1
        # we need to check if fav is available
        if not self.isInWorkThread() and self.visible:
            cItem = self.getSelItem()
            if self._canAddRowToFavourites(cItem):
                index = self.getSelIndex()
            else:
                cItem = None
        return index, cItem

    def getFavouriteItemCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("handleFavouriteItemCallback", [thread, ret])

    def handleFavouriteItemCallback(self, ret):
        printDBG("E2iPlayerWidget.handleFavouriteItemCallback")
        self.setStatusTex("")
        self["list"].show()
        if ret.status == RetHost.OK and isinstance(ret.value, list) and 1 == len(ret.value) and isinstance(ret.value[0], CFavItem):
            favItem = ret.value[0]
            self._completeFavItem(favItem)
            self.session.openWithCallback(self.refreshRowMarkers, IPTVFavouritesAddItemWidget, favItem)
        else:
            self.session.open(MessageBox, _("No valid links available."), type=MessageBox.TYPE_INFO, timeout=10)

    def _getRowsHostName(self):
        # the host the rows of the current list belong to: another one than the open host in a result of hostgroupsearch
        getName = getattr(self.host, 'getGuestHostName', None)
        return (getName() if callable(getName) else '') or self.hostName

    def _completeFavItem(self, favItem):
        # a favourite of the current host: its own name where the host left it open
        if CFavItem.RESOLVER_SELF == favItem.resolver:
            favItem.resolver = self._getRowsHostName()
        if '' == favItem.hostName:
            favItem.hostName = self._getRowsHostName()

    def _getMenuOptions(self):
        # shared by menu_pressed() and the footer's key_menu visibility
        # check (updateContextualFooterKeys()) so the two can never drift
        # apart - whatever this says is available is exactly what
        # pressing MENU will show
        options = []
        if self.visible and not self.isInWorkThread():
            try:
                item = self.getSelItem()
            except Exception:
                printExc()
                item = None
            if None is not item:
                currSelIndex = item.itemIdx  # self["list"].getCurrentIndex()
            else:
                currSelIndex = -1
            try:
                # no host loaded yet (group / host selector still open)
                hRet = self.host.getCustomActions(currSelIndex) if self.host is not None else None
                if hRet is not None and hRet.status == RetHost.OK and len(hRet.value):
                    for item in hRet.value:
                        if isinstance(item, IPTVChoiceBoxItem):
                            options.append(item)
            except Exception:
                # getCustomActions() is documented "!!! NON BLOCKING !!!"
                # in ihost.py but not "never raises" - this now also runs
                # on every list-selection change (updateDownloadButton(),
                # not just an actual MENU press), so a host whose
                # implementation raises here must not abort the whole
                # selection-change callback.
                printExc()

            try:
                if -1 < self.canByAddedToFavourites()[0]:
                    options.append(IPTVChoiceBoxItem(_("Add item to favorites"), "", {'e2i_menu_action': 'ADD_FAV'}))
                elif 'favourites' == self.hostName and self._canDeleteFavourite():
                    options.append(IPTVChoiceBoxItem(_("Remove from favorites"), "", {'e2i_menu_action': 'DELETE_FAV'}))
            except Exception:
                printExc()
        return options

    def _addRemoveFavouriteOption(self, options):
        # an item that is already in the favourites gets a "remove" entry right below "add" - it may
        # still be added to another group. Not part of _getMenuOptions(): that one runs on every
        # selection change and this reads the favourites from disk.
        try:
            addIdx = -1
            for idx in range(len(options)):
                if isinstance(options[idx].privateData, dict) and options[idx].privateData.get('e2i_menu_action') == 'ADD_FAV':
                    addIdx = idx
                    break
            index = self.canByAddedToFavourites()[0]
            if addIdx < 0 or index < 0:
                return
            # the same identity the star at the end of the row is looked up with (_updateRowMarkers)
            data = self.host.getFavouriteDataOfRow(index)
            if data is None:
                return
            itemInfo = {'host_name': self._getRowsHostName(), 'resolver': self._getRowsHostName(), 'data': data}
            found = self._findFavouriteItems(itemInfo)
            if found:
                groupNames = []
                for entry in found:  # (group id, group title, item index)
                    if entry[1] not in groupNames:
                        groupNames.append(entry[1])
                itemInfo['e2i_menu_action'] = 'REMOVE_FAV_HOST'
                options.insert(addIdx + 1, IPTVChoiceBoxItem(_("Remove from favorites") + ' (' + ', '.join(groupNames) + ')', "", itemInfo))
        except Exception:
            printExc()

    def _findFavouriteItems(self, itemInfo):
        helper = IPTVFavourites(GetFavouritesDir())
        if not helper.load():
            return []
        return helper.findItems(itemInfo['host_name'], itemInfo['resolver'], itemInfo['data'])

    def removeFavouriteOfHostItem(self, itemInfo, confirmed=False):
        if confirmed is False:
            return
        try:
            helper = IPTVFavourites(GetFavouritesDir())
            if not helper.load():
                self.session.open(MessageBox, _('Error loading favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
                return
            # again from the current files (they may have changed since the menu was built), highest index first
            found = helper.findItems(itemInfo['host_name'], itemInfo['resolver'], itemInfo['data'])
            if not found:
                self.session.open(MessageBox, _('Favorite item not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
                return
            for entry in sorted(found, key=lambda entry: entry[2], reverse=True):  # (group id, group title, item index)
                helper.delGroupItem(entry[2], entry[0])
            if not helper.save():
                self.session.open(MessageBox, _('Error saving favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
            self.refreshRowMarkers()
        except Exception:
            printExc()
            self.session.open(MessageBox, _('Error deleting favorite item.'), type=MessageBox.TYPE_ERROR, timeout=5)

    def _getRowSource(self, idx, item):
        # (host name, url) an item of the current list is recognised by for the download marker
        # (tools/iptvdownloaded.py) - the same in the host's own list, in the favourites and inside a favourite.
        # The url comes from the host's own list: item.urlItems is replaced by the resolved links once
        # the links of the item were requested, so it differs between the moment of the download and a later listing.
        hostName = self._getRowsHostName()
        url = ''
        try:
            if 'favourites' == self.hostName:
                favHost = self.host.host
                if favHost.isQuestMode():
                    hostName = favHost.getCurrentGuestHostName()
                    url = favHost.getCurrentGuestHost().getRowUrl(idx)
                elif 0 <= idx < len(favHost.currList):
                    params = favHost.currList[idx]
                    hostName = params.get('host') or hostName
                    url = params.get('fav_url', '')
            else:
                url = self.host.getRowUrl(idx)
        except Exception:
            printExc()
        return hostName, url

    def _updateRowMarkers(self):
        # sets the markers at the end of the rows of the current list: item is already in the
        # favourites, download state. Cheap: the favourites are read again only when they changed.
        # "Mark favourite items" / "Mark downloaded items" off: no marker and no colour of that kind.
        try:
            favKeys = frozenset()
            if 'favourites' != self.hostName and config.plugins.iptvplayer.hostfavourites.value and config.plugins.iptvplayer.mark_favourite_items.value:
                favKeys = getFavouritesIdentityKeys(GetFavouritesDir())
            markFavourites = config.plugins.iptvplayer.mark_favourite_items.value
            markDownloads = config.plugins.iptvplayer.mark_downloaded_items.value
            activeKeys = gDownloadManager.getActiveItemKeys() if None is not gDownloadManager else set()
            for pos, item in enumerate(self.currList):
                if not isinstance(item, CDisplayListItem):
                    continue
                # the row's index in the host list: a shuffled / reversed list shows the rows in another order
                idx = item.itemIdx if -1 < item.itemIdx else pos
                # a host with favourites of its own (hostxxx: favourite sites) sets hostFavourite on the row
                item.isFavourite = bool(markFavourites and getattr(item, 'hostFavourite', False))
                item.downloadState = ''
                if favKeys and (item.isGoodForFavourites or item.type in self.hostFavTypes):
                    data = self.host.getFavouriteDataOfRow(idx)
                    if data is not None:
                        item.isFavourite = item.isFavourite or IPTVFavourites.getItemIdentityKey(self._getRowsHostName(), self._getRowsHostName(), data) in favKeys
                if markDownloads and self.isDownloadableType(item.type):
                    hostName, url = self._getRowSource(idx, item)
                    item.downloadState = iptvdownloaded.getState(iptvdownloaded.getItemKey(hostName, url, item.name), activeKeys)
        except Exception:
            printExc()

    def refreshRowMarkers(self, *args):
        # after something changed that the markers show (favourite added/removed, download queued)
        self._updateRowMarkers()
        try:
            self["list"].l.invalidate()
        except Exception:
            printExc()

    ###################################################
    # batch download (iptvdm/batchdownload.py): the rows of the page go into the download manager at once,
    # each with what it takes to reopen it like a favourite; the links are looked up when its turn comes
    ###################################################
    def _getBatchRawRow(self, item):
        # the host's own item dict of a row (only read here: is it live?), None if unknown
        try:
            host = self.host
            if 'favourites' == self.hostName:
                favHost = self.host.host
                if not favHost.isQuestMode():
                    if 0 <= item.itemIdx < len(favHost.currList):
                        params = favHost.currList[item.itemIdx]
                        return params.get('yt_item') or params.get('fav_item')
                    return None
                host = favHost.getCurrentGuestHost()
            getRaw = getattr(host, '_getRawRow', None)
            if callable(getRaw):
                return getRaw(item.itemIdx)
        except Exception:
            printExc()
        return None

    def _getBatchRowSource(self, item):
        # (host name, favourite data) the download manager reopens the row with later - the data a favourite
        # of the row stores (getFavouriteDataOfRow); None when the row can not be reopened that way
        try:
            idx = item.itemIdx
            if 'favourites' == self.hostName:
                favHost = self.host.host
                if favHost.isQuestMode():
                    return self._getBatchHostRowSource(favHost.getCurrentGuestHostName(), favHost.getCurrentGuestHost(), idx)
                if not (0 <= idx < len(favHost.currList)):
                    return None
                params = favHost.currList[idx]
                if params.get('yt_video'):
                    # a video of the merged "newest videos" list: no stored favourite, the YouTube host opens it
                    # (hosts/hostfavourites.py getLinksForVideo, YouTube's getFavouriteData is its json)
                    return 'youtube', json_dumps(params['yt_item'])
                sts, data = favHost.helper.getGroupItems(params.get('group_id', ''))
                storageIdx = params.get('item_idx', -1)
                if not sts or not (0 <= storageIdx < len(data)):
                    return None
                favItem = data[storageIdx]
                # the host that opens the favourite (Favourites.getLinksForVideo); a direct link / urlparser
                # favourite has none to reopen it
                resolver = favItem.hostName if CFavItem.RESOLVER_SELF == favItem.resolver else favItem.resolver
                if not resolver or resolver in (CFavItem.RESOLVER_DIRECT_LINK, CFavItem.RESOLVER_URLLPARSER) or not favItem.data:
                    return None
                return resolver, favItem.data
            return self._getBatchHostRowSource(self._getRowsHostName(), self.host, idx)
        except Exception:
            printExc()
        return None

    @staticmethod
    def _getBatchHostRowSource(hostName, host, idx):
        # hosts built on IHost alone (old API, e.g. hostxxx) have no favourite data of a row
        getData = getattr(host, 'getFavouriteDataOfRow', None)
        if not hostName or not callable(getData):
            return None
        data = getData(idx)
        if not data:
            return None
        return hostName, data

    def _canBatchDownload(self):
        # the current list can be offered for a batch download at all
        if None is gDownloadManager or not self._canSelectRows():
            return False
        if 'favourites' == self.hostName:
            return True
        return callable(getattr(self.host, 'getFavouriteDataOfRow', None))

    def _isBatchRow(self, item):
        # a video / audio row of this page that is not live (cheap: no network, no disk)
        if not isinstance(item, CDisplayListItem) or item.type not in batchdownload.BATCH_TYPES:
            return False
        if item.urlItems and item.urlItems[0].url.startswith('file://'):  # LocalMedia, like updateDownloadButton()
            return False
        return self._isBatchFavouriteRow(item) and not batchdownload.isLiveRow(self._getBatchRawRow(item))

    def _isBatchFavouriteRow(self, item):
        # only a row that can be a favourite reopens without the list it comes from - the check of "Add item to
        # favorites" (canByAddedToFavourites); a row of the favourites list itself is a stored favourite
        try:
            if item.isGoodForFavourites:
                return True
            if 'favourites' != self.hostName:
                return item.type in self.hostFavTypes
            favHost = self.host.host
            if not favHost.isQuestMode():
                return True
            hRet = favHost.getCurrentGuestHost().getSupportedFavoritesTypes()
            return RetHost.OK == hRet.status and item.type in hRet.value
        except Exception:
            printExc()
        return False

    def _getBatchCandidateRows(self):
        # rows of the current page the batch download takes (the current page only, not the following ones)
        if not self._canBatchDownload():
            return []
        return [item for item in self.currList if self._isBatchRow(item)]

    def _getBatchMarkedRows(self):
        # the marked rows the batch download takes (only these are checked, not the whole page)
        if not self._canBatchDownload():
            return []
        return [item for item in self.currList if listselection.isMarked(item) and self._isBatchRow(item)]

    ###################################################
    # list functions of the BLUE menu: play from here, selection mode (OK marks rows; play / download / add to
    # or remove from the favourites the marked rows), shuffle / reverse. Each action takes the marked rows it can handle.
    ###################################################
    LIST_FUNCTION_IDS = ('PLAY_FROM_HERE', 'SELECT_START', 'SELECT_ALL', 'SELECT_CLEAR', 'PLAY_MARKED', 'BATCH_MARKED',
                         'FAV_MARKED', 'FAV_REMOVE_MARKED', 'BATCH_ALL', 'RandomizePlayableItems', 'ReversePlayableItems', 'UndoRandomize',
                         'UndoReverse')
    # rows the selection mode marks: what the sequencer plays
    SELECTABLE_TYPES = (CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_PICTURE)

    def _getListFunctionOptions(self):
        options = []
        if self.selectMode:
            marked = self._getMarkedRows() if self._canSelectRows() else []
            numPlay = len([item for item in marked if self._canSequencerPlay(item)])
            if numPlay:
                options.append((_("Play marked items (%d)") % numPlay, "PLAY_MARKED"))
            numDownload = len(self._getBatchMarkedRows())
            if numDownload:
                options.append((_("Download marked items (%d)") % numDownload, "BATCH_MARKED"))
            numFavourites = len([item for item in marked if self._canAddRowToFavourites(item)])
            if numFavourites:
                options.append((_("Add marked items to favourites (%d)") % numFavourites, "FAV_MARKED"))
            numRemove = len(self._getMarkedFavouriteRows(marked))
            if numRemove:
                options.append((_("Remove marked items from favourites (%d)") % numRemove, "FAV_REMOVE_MARKED"))
            options.append((_("Unselect all"), "SELECT_CLEAR"))
        elif len(self._getSelectableRows()) > 1:
            options.append((_("Play all from here"), "PLAY_FROM_HERE"))
            options.append((_("Select"), "SELECT_START"))
            options.append((_("Select all"), "SELECT_ALL"))
        if self.canRandomizeList and self._canChangeListOrder():
            # toggles: the "Undo" ids only pick the undo icon (IPTVPlayerSelectOptionChoiceBoxList)
            if self.listShuffleOrder is None:
                options.append((_('Randomize a playlist'), "RandomizePlayableItems"))
            else:
                options.append((_('Undo shuffle'), "UndoRandomize"))
            if not self.listReversed:
                options.append((_('Reverse a playlist'), "ReversePlayableItems"))
            else:
                options.append((_('Undo reverse'), "UndoReverse"))
        # batch download: all downloadable rows of the page at once
        if not self.selectMode and len(self._getBatchCandidateRows()) > 1:
            options.append((_("Download all items of this page"), "BATCH_ALL"))
        return options

    def _runListFunction(self, action):
        if action == 'PLAY_FROM_HERE':
            self.startAutoPlaySequencer()
        elif action == 'SELECT_START':
            self.selectMode = True
            self.session.open(MessageBox, _("OK marks an item, BLUE shows what can be done with the marked items."), type=MessageBox.TYPE_INFO, timeout=5)
        elif action == 'SELECT_ALL':
            for item in self._getSelectableRows():
                listselection.setMarked(item, True)
            self.selectMode = True
            self._redrawSelectMarks()
        elif action == 'SELECT_CLEAR':
            self._endSelectMode()
        elif action == 'PLAY_MARKED':
            # from the first marked row in the current order; the marks stay for the run
            self["list"].moveToIndex(0)
            self.startAutoPlaySequencer(True)
        elif action == 'BATCH_MARKED':
            marked = self._getMarkedRows()
            rows = self._getBatchMarkedRows()
            self._endSelectMode()
            self.startBatchDownload(rows, len(marked) - len(rows))
        elif action == 'FAV_MARKED':
            self.addMarkedToFavourites()
        elif action == 'FAV_REMOVE_MARKED':
            self.removeMarkedFromFavourites()
        elif action == 'BATCH_ALL':
            rows = self._getBatchCandidateRows()
            if rows:
                self.session.openWithCallback(boundFunction(self._startBatchDownloadConfirmed, rows), MessageBox, _("Add %d items to the download queue?") % len(rows), type=MessageBox.TYPE_YESNO)
        elif action in ('RandomizePlayableItems', 'UndoRandomize'):
            self.randomizePlayableItems()
        elif action in ('ReversePlayableItems', 'UndoReverse'):
            self.reversePlayableItems()

    def _canSelectRows(self):
        if None is self.host or not self.visible or self.isInWorkThread():
            return False
        try:
            return self["list"].getVisible()
        except Exception:
            printExc()
        return False

    def _isSelectableRow(self, item):
        # cheap: no network, no disk; a live row is never marked
        return isinstance(item, CDisplayListItem) and item.type in self.SELECTABLE_TYPES and not batchdownload.isLiveRow(self._getBatchRawRow(item))

    def _getSelectableRows(self):
        if not self._canSelectRows():
            return []
        return [item for item in self.currList if self._isSelectableRow(item)]

    def _getMarkedRows(self):
        # in the current order of the list
        return [item for item in self.currList if listselection.isMarked(item)]

    def _toggleSelectMark(self):
        idx = self.getSelIndex()
        item = self.getSelItem()
        if item is None or not self._isSelectableRow(item):
            printDBG("select mark: row %d can not be marked" % idx)
            return
        listselection.setMarked(item, not listselection.isMarked(item))
        printDBG("select mark: row %d [%s] -> %s, %d marked" % (idx, item.name, listselection.isMarked(item), len(self._getMarkedRows())))
        self._redrawSelectMarks(idx)
        # next row, so a run of episodes is marked with OK, OK, OK
        try:
            if -1 < idx < len(self.currList) - 1:
                self["list"].moveToIndex(idx + 1)
        except Exception:
            printExc()

    def _redrawSelectMarks(self, idx=-1):
        # the row markers are drawn by the list's build function: the changed row is redrawn on its own, the
        # whole list as well (an image whose invalidate() does not rebuild the visible entries gets them anyway)
        try:
            if -1 < idx:
                self["list"].invalidateItem(idx)
        except Exception:
            printExc()
        try:
            self["list"].l.invalidate()
        except Exception:
            printExc()

    def _endSelectMode(self):
        self.selectMode = False
        listselection.clearMarks(self.currList)
        self._redrawSelectMarks()

    def _canAddRowToFavourites(self, item):
        # a row "Add item to favorites" (canByAddedToFavourites) and "Add marked items to favourites" take
        try:
            if not config.plugins.iptvplayer.hostfavourites.value:
                return False
        except Exception:
            return False
        return isinstance(item, CDisplayListItem) and (item.isGoodForFavourites or item.type in self.hostFavTypes)

    def addMarkedToFavourites(self):
        # the CFavItem of each marked row comes from the host in a worker thread (like the single add), then the
        # favourites group is asked once for all of them
        marked = self._getMarkedRows()
        rows = [item for item in marked if self._canAddRowToFavourites(item)]
        if not rows or self.isInWorkThread():
            return
        self["list"].hide()
        self.setStatusTex(_("Loading"))
        try:
            self.workThread = asynccall.AsyncMethod(self._getFavouriteItemsOfRows, boundFunction(self._markedFavouriteItemsCallback, len(marked)), True)([item.itemIdx for item in rows])
            self.showSpinner()
        except Exception:
            printExc()
            self.setStatusTex("")
            self["list"].show()

    def _getFavouriteItemsOfRows(self, indexes):
        # worker thread: host.getFavouriteItem() of each row (index in the host list); a row without one is left out
        favItems = []
        for idx in indexes:
            try:
                ret = self.host.getFavouriteItem(idx)
                if ret.status == RetHost.OK and isinstance(ret.value, list) and 1 == len(ret.value) and isinstance(ret.value[0], CFavItem):
                    favItems.append(ret.value[0])
            except Exception:
                printExc()
        return favItems

    def _markedFavouriteItemsCallback(self, numMarked, thread, favItems):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("handleMarkedFavouriteItems", [thread, (numMarked, favItems)])

    def handleMarkedFavouriteItems(self, ret):
        numMarked, favItems = ret
        self.setStatusTex("")
        self["list"].show()
        if not favItems:
            self.session.open(MessageBox, _("%d added, %d skipped.") % (0, numMarked), type=MessageBox.TYPE_INFO, timeout=5)
            return
        for favItem in favItems:
            self._completeFavItem(favItem)
        self.session.openWithCallback(boundFunction(self._markedFavouritesAdded, numMarked), IPTVFavouritesAddItemWidget, favItems)

    def _markedFavouritesAdded(self, numMarked, added=None):
        # added: how many went into the picked group (the others were there already), None: no group picked
        if added is None:
            return
        self.refreshRowMarkers()
        self.session.open(MessageBox, _("%d added, %d skipped.") % (added, numMarked - added), type=MessageBox.TYPE_INFO, timeout=5)

    def _getRowFavouriteKey(self, item):
        # identity key of a row of a host list in the favourites - the one the favourite marker is looked up with
        # (_updateRowMarkers) -, None for a row that can not be a favourite
        if not self._canAddRowToFavourites(item):
            return None
        data = self.host.getFavouriteDataOfRow(self._getRowHostIndex(item, self._getListPos(item)))
        if data is None:
            return None
        return IPTVFavourites.getItemIdentityKey(self._getRowsHostName(), self._getRowsHostName(), data)

    def _getMarkedFavouriteRows(self, marked=None):
        # the marked rows "Remove marked items from favourites" takes: inside a favourites group its stored
        # favourites, in a host list the rows that are in the favourites (in any group, like the favourite marker)
        if marked is None:
            marked = self._getMarkedRows()
        if not marked:
            return []
        try:
            if 'favourites' == self.hostName:
                # not the virtual "newest videos" rows and not the lists of a guest host (see _canDeleteFavourite)
                favHost = getattr(self.host, 'host', None)
                if not self.favouritesCurrentGroupId or not hasattr(favHost, 'getGroupItemIdx'):
                    return []
                return [item for item in marked if favHost.getGroupItemIdx(self._getRowHostIndex(item, self._getListPos(item))) >= 0]
            if not config.plugins.iptvplayer.hostfavourites.value:
                return []
            favKeys = getFavouritesIdentityKeys(GetFavouritesDir())
            if not favKeys:
                return []
            return [item for item in marked if self._getRowFavouriteKey(item) in favKeys]
        except Exception:
            printExc()
        return []

    def removeMarkedFromFavourites(self):
        rows = self._getMarkedFavouriteRows()
        if rows and not self.isInWorkThread():
            self.session.openWithCallback(boundFunction(self._removeMarkedFavouritesConfirmed, rows), MessageBox, _("Remove %d items from the favourites?") % len(rows), type=MessageBox.TYPE_YESNO)

    def _removeMarkedFavouritesConfirmed(self, rows, confirmed=False):
        if not confirmed or not self.visible or self.isInWorkThread():
            return
        # the list may have been replaced while the question was open
        rows = [item for item in rows if -1 < self._getListPos(item)]
        if not rows:
            return
        try:
            if 'favourites' == self.hostName:
                removed = self._removeMarkedGroupFavourites(rows)
            else:
                removed = self._removeMarkedHostFavourites(rows)
        except Exception:
            printExc()
            self.session.open(MessageBox, _('Error deleting favorite item.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return
        if removed < 0:
            return  # the error was shown
        # the selection mode stays; the marks of rows removed from the list are gone with them
        self.session.open(MessageBox, _("%d removed, %d skipped.") % (removed, len(rows) - removed), type=MessageBox.TYPE_INFO, timeout=5)

    def _removeMarkedGroupFavourites(self, rows):
        # inside a favourites group: the same way as "Remove from favorites" of one row -> number removed, -1 on error
        helper = IPTVFavourites(GetFavouritesDir())
        if not helper.load():
            self.session.open(MessageBox, _('Error loading favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1
        realGroupId = self._getFavouritesGroupId(helper.getGroups(), self.favouritesCurrentGroupId)
        if not realGroupId:
            self.session.open(MessageBox, _('Favorite group not found.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1
        return self._deleteFavouriteRows(helper, realGroupId, rows)

    def _removeMarkedHostFavourites(self, rows):
        # in a host list: every stored favourite of the rows, in every group it is in (looked up again in the
        # current files, like removeFavouriteOfHostItem) -> number of rows removed, -1 on error
        rowKeys = [self._getRowFavouriteKey(item) for item in rows]
        helper = IPTVFavourites(GetFavouritesDir())
        if not helper.load():
            self.session.open(MessageBox, _('Error loading favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
            return -1
        found = helper.findItemsOfKeys(set(key for key in rowKeys if key is not None))
        if found:
            helper.delGroupItems([(entry[0], entry[1]) for entry in found])
            if not helper.save():
                self.session.open(MessageBox, _('Error saving favorites.'), type=MessageBox.TYPE_ERROR, timeout=5)
                return -1
        foundKeys = set(entry[2] for entry in found)
        self.refreshRowMarkers()
        return len([key for key in rowKeys if key in foundKeys])

    def _startBatchDownloadConfirmed(self, rows, confirmed=False):
        if confirmed:
            self.startBatchDownload(rows)

    def startBatchDownload(self, rows, skipped=0):
        # rows: CDisplayListItems of the current list -> deferred items in the download manager;
        # skipped: marked rows that can not be downloaded at all, counted in the message
        if None is gDownloadManager:
            self.session.open(MessageBox, _("File can not be downloaded. Download manager is not available."), type=MessageBox.TYPE_ERROR, timeout=10)
            return
        # the list may have been replaced while a question was open
        rows = [item for item in rows if any(item is other for other in self.currList)]
        if not rows:
            return
        downloadsDir = config.plugins.iptvplayer.DownloadsDir.value
        # free space / folder once for the whole batch, before anything is queued
        errorTab = self._checkDestinationDir(downloadsDir, True)
        if errorTab:
            self.session.open(MessageBox, '\n'.join(errorTab), type=MessageBox.TYPE_INFO, timeout=10)
            return

        entries = []
        for item in rows:
            # the key of the "downloaded" marker exactly like playVideo()
            hostName, itemUrl = self._getRowSource(item.itemIdx, item)
            entries.append({'title': item.name, 'type': item.type,
                            'key': iptvdownloaded.getItemKey(hostName, itemUrl, item.name),
                            'source': self._getBatchRowSource(item),
                            'pin': self._itemNeedsPin(item),
                            'live': batchdownload.isLiveRow(self._getBatchRawRow(item))})
        activeKeys = gDownloadManager.getActiveItemKeys()
        accepted, skippedRows = batchdownload.selectBatchRows(entries, activeKeys, lambda key: iptvdownloaded.getState(key) == iptvdownloaded.STATE_DONE)
        skipped += skippedRows

        dmItems = []
        for entry in accepted:
            source = batchdownload.makeBatchSource(entry, downloadsDir)
            dmItem = DMItem('', source['file'])
            dmItem.batchSource = source
            dmItem.itemKey = entry['key']
            dmItems.append(dmItem)
        added = gDownloadManager.addBatchToDQueue(dmItems) if dmItems else 0
        skipped += len(dmItems) - added
        printDBG("startBatchDownload host[%s] rows[%d] added[%d] skipped[%d]" % (self.hostName, len(rows), added, skipped))
        if added:
            self.refreshRowMarkers()
        message = _("%d items added to the download queue, %d skipped.") % (added, skipped)
        if added and config.plugins.iptvplayer.IPTVDMShowAfterAdd.value:
            self.session.openWithCallback(self._batchAddedCallback, MessageBox, message, type=MessageBox.TYPE_INFO, timeout=5)
        else:
            self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=10)

    def _batchAddedCallback(self, *args):
        self.runIPTVDM(self.refreshRowMarkers)

    def _canDeleteFavourite(self):
        # inside a favourites group only a stored favourite can be removed - not the virtual
        # "newest videos" rows and not the lists of a guest host; the group list itself is unchanged
        favHost = getattr(self.host, 'host', None)
        if not self.favouritesCurrentGroupId or not hasattr(favHost, 'getGroupItemIdx'):
            return True
        return favHost.getGroupItemIdx(self._getSelHostIndex()) >= 0

    def menu_pressed(self):
        printDBG("E2iPlayerWidget.menu_pressed")
        # we have to be careful here as we will call method
        # directly from host
        try:
            options = self._getMenuOptions()
            self._addRemoveFavouriteOption(options)
            if len(options):
                self.stopAutoPlaySequencer()
                # _getMoviePlayerPickerHeight() (below) is just the generic
                # IPTVRadioButtonList item-height formula despite its name -
                # reused as-is instead of a third near-identical copy in
                # this same class. openChoiceBox: like the other pickers the box skin's ChoiceBox with
                # "Force internal skin" off
                openChoiceBox(self.session, {'width': 600, 'height': self._getMoviePlayerPickerHeight(len(options)), 'current_idx': 0, 'title': _("Select action"), 'options': options, 'list_class': IPTVActionChoiceBoxList, 'chrome': True, 'footerMargin': 136}, self.requestCustomActionFromHost)
        except Exception:
            printExc()

    def requestCustomActionFromHost(self, ret):
        printDBG("E2iPlayerWidget.requestCustomActionFromHost ret[%r]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            menuAction = ret.privateData.get('e2i_menu_action') if isinstance(ret.privateData, dict) else None
            if menuAction == 'ADD_FAV':
                currSelIndex = self.canByAddedToFavourites()[0]
                self.requestListFromHost('ForFavItem', currSelIndex, '')
                return
            elif menuAction == 'REMOVE_FAV_HOST':
                self.session.openWithCallback(boundFunction(self.removeFavouriteOfHostItem, ret.privateData), MessageBox, _('Definitely remove from favorites?'), type=MessageBox.TYPE_YESNO, timeout=10)
                return
            elif menuAction == 'DELETE_FAV':
                self.session.openWithCallback(self.deleteFavouriteItem, MessageBox, _('Definitely remove from favorites?'), type=MessageBox.TYPE_YESNO, timeout=10)
                return
            self.requestListFromHost('PerformCustomAction', -1, ret.privateData)

    def performCustomActionCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("handlePerformCustomActionCallback", [thread, ret])

    def handlePerformCustomActionCallback(self, ret):
        printDBG("E2iPlayerWidget.handlePerformCustomActionCallback")
        self.setStatusTex("")
        self["list"].show()
        if ret.status == RetHost.OK and isinstance(ret.value, list) and 1 == len(ret.value):
            self.yellow_pressed()
        elif ret.status == RetHost.ERROR and isinstance(ret.value, list) and 1 == len(ret.value) and isinstance(ret.value[0], str):
            self.session.open(MessageBox, ret.value[0], type=MessageBox.TYPE_ERROR)

    def markItemAsViewedCallback(self, thread, ret):
        asynccall.gMainFunctionsQueueTab[0].addToQueue("handleMarkItemAsViewedCallback", [thread, ret])

    def handleMarkItemAsViewedCallback(self, ret):
        printDBG("E2iPlayerWidget.handleMarkItemAsViewedCallback")
        self.setStatusTex("")
        self["list"].show()
        zap, self.pendingZap = self.pendingZap, 0
        if zap:
            # the watched marker shows when the list is loaded again; a refresh now would lose the zap
            self._zapFromPlayer(zap)
        elif ret.status == RetHost.OK and isinstance(ret.value, list) and 1 == len(ret.value) and 'refresh' in ret.value:
            self.getRefreshedCurrList()
        elif ret.status == RetHost.ERROR and isinstance(ret.value, list) and 1 == len(ret.value) and isinstance(ret.value[0], str):
            self.session.open(MessageBox, ret.value[0], type=MessageBox.TYPE_ERROR)
        else:
            self.checkAutoPlaySequencer()

# class E2iPlayerWidget
