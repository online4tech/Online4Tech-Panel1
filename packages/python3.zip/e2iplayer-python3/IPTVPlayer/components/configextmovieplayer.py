# -*- coding: utf-8 -*-
#
#  Konfigurator dla iptv 2013
#  autorzy: j00zek, samsamsam
#

###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, \
                                                          GetE2VideoAspectChoices, GetE2VideoPolicyChoices, \
                                                          GetE2VideoPolicy, GetE2AudioCodecMixChoices
from Plugins.Extensions.IPTVPlayer.components.configbase import ConfigBaseWidget
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
###################################################

###################################################
# FOREIGN import
###################################################
import skin
from enigma import eLabel, getDesktop
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSelection, getConfigListEntry, configfile
###################################################


class ConfigExtMoviePlayerBase():

    def __init__(self):

        # fill aac_mix option
        options = [(None, _("From E2 settings"))]
        tmp = GetE2AudioCodecMixChoices('aac')
        for item in tmp:
            options.append((item, _(item)))
        if config.plugins.iptvplayer.aac_mix.value not in tmp:
            config.plugins.iptvplayer.aac_mix.value = None
        if len(tmp):
            self.aac_mix_avaliable = True
        else:
            self.aac_mix_avaliable = False
        config.plugins.iptvplayer.aac_mix = ConfigSelection(default=None, choices=options)

        # fill ac3_mix option
        options = [(None, _("From E2 settings"))]
        tmp = GetE2AudioCodecMixChoices('ac3')
        for item in tmp:
            options.append((item, _(item)))
        if config.plugins.iptvplayer.ac3_mix.value not in tmp:
            config.plugins.iptvplayer.ac3_mix.value = None
        if len(tmp):
            self.ac3_mix_avaliable = True
        else:
            self.ac3_mix_avaliable = False
        config.plugins.iptvplayer.ac3_mix = ConfigSelection(default=None, choices=options)

        # fill aspect option
        options = [(None, _("From E2 settings"))]
        tmp = GetE2VideoAspectChoices()
        for item in tmp:
            options.append((item, _(item)))
        if config.plugins.iptvplayer.extplayer_aspect.value not in tmp:
            config.plugins.iptvplayer.extplayer_aspect.value = None
        if len(tmp):
            self.aspect_avaliable = True
        else:
            self.aspect_avaliable = False
        config.plugins.iptvplayer.extplayer_aspect = ConfigSelection(default=None, choices=options)

        # fill policy option
        options = [(None, _("From E2 settings"))]
        tmp = GetE2VideoPolicyChoices()
        for item in tmp:
            options.append((item, _(item)))
        if config.plugins.iptvplayer.extplayer_policy.value not in tmp:
            config.plugins.iptvplayer.extplayer_policy.value = None
        if len(tmp):
            self.policy_avaliable = True
        else:
            self.policy_avaliable = False
        config.plugins.iptvplayer.extplayer_policy = ConfigSelection(default=None, choices=options)

        # fill policy 2 option
        options = [(None, _("From E2 settings"))]
        if None is not GetE2VideoPolicy('2'):
            tmp = GetE2VideoPolicyChoices()
            for item in tmp:
                options.append((item, _(item)))
        else:
            tmp = []
        if config.plugins.iptvplayer.extplayer_policy2.value not in tmp:
            config.plugins.iptvplayer.extplayer_policy2.value = None
        if len(tmp):
            self.policy2_avaliable = True
        else:
            self.policy2_avaliable = False
        config.plugins.iptvplayer.extplayer_policy2 = ConfigSelection(default=None, choices=options)

        # fill fonts option
        options = [("Regular", "Regular")]
        fonts = ["Regular"]
        try:
            for key in skin.fonts:
                font = skin.fonts[key][0]
                if font not in fonts:
                    fonts.append(font)
                    options.append((font, font))
        except Exception:
            printExc()
        config.plugins.iptvplayer.extplayer_subtitle_font = ConfigSelection(default="Regular", choices=options)

        # check if border is avaliable
        self.subtitle_border_avaliable = False
        try:
            tmp = dir(eLabel)
            if 'setBorderColor' in tmp:
                self.subtitle_border_avaliable = True
        except Exception:
            printExc()
        if not self.subtitle_border_avaliable:
            config.plugins.iptvplayer.extplayer_subtitle_border_enabled.value = False

    def getSubtitleFontSettings(self):
        settings = {}
        settings['auto_enable'] = config.plugins.iptvplayer.extplayer_subtitle_auto_enable.value
        settings['wrapping_enabled'] = config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled.value
        settings['font'] = config.plugins.iptvplayer.extplayer_subtitle_font.value
        settings['font_size'] = config.plugins.iptvplayer.extplayer_subtitle_font_size.value
        settings['font_color'] = config.plugins.iptvplayer.extplayer_subtitle_font_color.value
        settings['background'] = config.plugins.iptvplayer.extplayer_subtitle_background.value
        settings['line_height'] = config.plugins.iptvplayer.extplayer_subtitle_line_height.value
        settings['line_spacing'] = config.plugins.iptvplayer.extplayer_subtitle_line_spacing.value

        if self.subtitle_border_avaliable and config.plugins.iptvplayer.extplayer_subtitle_border_enabled.value:
            settings['border'] = {}
            settings['border']['color'] = config.plugins.iptvplayer.extplayer_subtitle_border_color.value
            settings['border']['width'] = config.plugins.iptvplayer.extplayer_subtitle_border_width.value

        if config.plugins.iptvplayer.extplayer_subtitle_shadow_enabled.value:
            settings['shadow'] = {}
            settings['shadow']['color'] = config.plugins.iptvplayer.extplayer_subtitle_shadow_color.value
            settings['shadow']['xoffset'] = config.plugins.iptvplayer.extplayer_subtitle_shadow_xoffset.value
            settings['shadow']['yoffset'] = config.plugins.iptvplayer.extplayer_subtitle_shadow_yoffset.value
        settings['pos'] = config.plugins.iptvplayer.extplayer_subtitle_pos.value
        settings['box_valign'] = config.plugins.iptvplayer.extplayer_subtitle_box_valign.value
        settings['box_height'] = config.plugins.iptvplayer.extplayer_subtitle_box_height.value
        return settings

    def setSubtitleFontSettings(self, objConfig):
        try:
            if config.plugins.iptvplayer.extplayer_subtitle_pos.value != objConfig['pos']:
                config.plugins.iptvplayer.extplayer_subtitle_pos.value = objConfig['pos']
                config.plugins.iptvplayer.extplayer_subtitle_pos.save()
                configfile.save()
        except Exception:
            printExc()

    def getDefaultPlayerVideoOptions(self):
        defVideoOptions = {
            'aspect': config.plugins.iptvplayer.extplayer_aspect.value,
            'policy': config.plugins.iptvplayer.extplayer_policy.value,
            'policy2': config.plugins.iptvplayer.extplayer_policy2.value
        }
        printDBG(">>>>>>>>>>>>>>>>>>>>> getE2VideoOptions[%s]" % defVideoOptions)
        return defVideoOptions

    def getDefaultAudioOptions(self):
        defAudioOptions = {
            'aac': config.plugins.iptvplayer.aac_mix.value,
            'ac3': config.plugins.iptvplayer.ac3_mix.value,
        }
        printDBG(">>>>>>>>>>>>>>>>>>>>> getDefaultAudioOptions[%s]" % defAudioOptions)
        return defAudioOptions

    def getInfoBarTimeout(self):
        return config.plugins.iptvplayer.extplayer_infobar_timeout.value

    def clearVideoByIframeInjection(self):
        return config.plugins.iptvplayer.use_clear_iframe.value

    def getBlankIframeFilePath(self):
        return config.plugins.iptvplayer.clear_iframe_file.value

    def getInfoBannerrClockFormat(self):
        if getDesktop(0).size().width() < 800:
            return ''
        return config.plugins.iptvplayer.extplayer_infobanner_clockformat.value

    def getPlayerSkinFolder(self):
        printDBG("configextmovieplayer.getPlayerSkinFolder")
        skin = config.plugins.iptvplayer.extplayer_skin.value
        if not skin:
            return "default"
        else:
            return skin


class ConfigExtMoviePlayer(ConfigBaseWidget, ConfigExtMoviePlayerBase):

    def __init__(self, session, operatingPlayer=False):
        printDBG("ConfigExtMoviePlayer.__init__ -------------------------------")
        self.list = []
        ConfigBaseWidget.__init__(self, session)
        ConfigExtMoviePlayerBase.__init__(self)
        self.setup_title = _("Configuring an external movie player")
        self.operatingPlayer = operatingPlayer
        self.runtimeOptionsValues = self.getRuntimeOptionsValues()

    def __del__(self):
        printDBG("ConfigExtMoviePlayer.__del__ -------------------------------")

    def __onClose(self):
        printDBG("ConfigExtMoviePlayer.__onClose -----------------------------")
        ConfigBaseWidget.__onClose(self)

    def saveAndClose(self):
        self.save()
        message = self.getMessageAfterSave()
        if message == '':
            if self.operatingPlayer:
                self.close(True)
            else:
                self.close()
        else:
            self.session.openWithCallback(self.closeAfterMessage, MessageBox, text=message, type=MessageBox.TYPE_INFO)

    def closeAfterMessage(self, arg=None):
        if self.operatingPlayer:
            self.close(True)
        else:
            self.close()

    def getMessageAfterSave(self):
        if self.operatingPlayer and self.runtimeOptionsValues != self.getRuntimeOptionsValues():
            return _('Some changes will be applied only after movie player restart.')
        else:
            return ''

    def layoutFinished(self):
        ConfigBaseWidget.layoutFinished(self)
        self.setTitle("E2iPlayer " + (_("Configuring an external movie player")))

    def getRuntimeOptionsValues(self):
        valTab = []
        valTab.append(config.plugins.iptvplayer.rambuffer_sizemb_network_proto.value)
        valTab.append(config.plugins.iptvplayer.rambuffer_sizemb_files.value)
        valTab.append(config.plugins.iptvplayer.aac_software_decode.value)
        valTab.append(config.plugins.iptvplayer.dts_software_decode.value)
        valTab.append(config.plugins.iptvplayer.wma_software_decode.value)
        valTab.append(config.plugins.iptvplayer.ac3_software_decode.value)
        valTab.append(config.plugins.iptvplayer.eac3_software_decode.value)
        valTab.append(config.plugins.iptvplayer.mp3_software_decode.value)
        valTab.append(config.plugins.iptvplayer.software_decode_as.value)
        valTab.append(config.plugins.iptvplayer.stereo_software_decode.value)
        valTab.append(config.plugins.iptvplayer.ac3_mix.value)
        valTab.append(config.plugins.iptvplayer.aac_mix.value)
        valTab.append(config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled.value)
        valTab.append(config.plugins.iptvplayer.show_iframe.value)
        # handed to the player at start for audio items (use_clear_iframe is read when the player closes)
        valTab.append(config.plugins.iptvplayer.iframe_file.value)
        valTab.append(config.plugins.iptvplayer.clear_iframe_file.value)
        return valTab

    def runSetup(self):
        list = []

        list.append(getConfigListEntry(_("Remember last watched position"), config.plugins.iptvplayer.remember_last_position))
        if config.plugins.iptvplayer.remember_last_position.value:
            list.append(getConfigListEntry("    " + _("Skip video shorter than [min]"), config.plugins.iptvplayer.remember_last_position_time))
        list.append(getConfigListEntry(_("----------------- External exteplayer3 options -----------------"), config.plugins.iptvplayer.fakeExtePlayer3))
        list.append(getConfigListEntry("    " + _("RAM buffer size [MB] for network protocols"), config.plugins.iptvplayer.rambuffer_sizemb_network_proto))
        list.append(getConfigListEntry("    " + _("RAM buffer size [MB] for local files"), config.plugins.iptvplayer.rambuffer_sizemb_files))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'AAC', config.plugins.iptvplayer.aac_software_decode))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'AC3', config.plugins.iptvplayer.ac3_software_decode))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'EAC3', config.plugins.iptvplayer.eac3_software_decode))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'DTS', config.plugins.iptvplayer.dts_software_decode))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'WMA', config.plugins.iptvplayer.wma_software_decode))
        list.append(getConfigListEntry("    " + _("Use software decoder for the %s") % 'MP3', config.plugins.iptvplayer.mp3_software_decode))
        list.append(getConfigListEntry("    " + _("Software decoding as"), config.plugins.iptvplayer.software_decode_as))
        list.append(getConfigListEntry("    " + _("Stereo downmix mode for software decoder"), config.plugins.iptvplayer.stereo_software_decode))
        if self.ac3_mix_avaliable:
            list.append(getConfigListEntry(_("AC3 downmix mode"), config.plugins.iptvplayer.ac3_mix))
        if self.aac_mix_avaliable:
            list.append(getConfigListEntry(_("AAC downmix mode"), config.plugins.iptvplayer.aac_mix))

        list.append(getConfigListEntry(_("Info bar timeout"), config.plugins.iptvplayer.extplayer_infobar_timeout))

        if self.aspect_avaliable:
            list.append(getConfigListEntry(_("Default video aspect ratio"), config.plugins.iptvplayer.extplayer_aspect))
        if self.policy_avaliable:
            list.append(getConfigListEntry(_("Default video policy for 16:9"), config.plugins.iptvplayer.extplayer_policy))
        if self.policy2_avaliable:
            list.append(getConfigListEntry(_("Default video policy for 4:3"), config.plugins.iptvplayer.extplayer_policy2))

        list.append(getConfigListEntry(_("Automatically turn on external subtitles"), config.plugins.iptvplayer.extplayer_subtitle_auto_enable))
        list.append(getConfigListEntry(_("Subtitle line wrapping"), config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled))
        list.append(getConfigListEntry(_("Subtitle font"), config.plugins.iptvplayer.extplayer_subtitle_font))
        list.append(getConfigListEntry(_("Subtitle font size"), config.plugins.iptvplayer.extplayer_subtitle_font_size))
        if not config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled.value:
            list.append(getConfigListEntry(_("Subtitle line height"), config.plugins.iptvplayer.extplayer_subtitle_line_height))
            list.append(getConfigListEntry(_("Line Spacing"), config.plugins.iptvplayer.extplayer_subtitle_line_spacing))
        elif 'transparent' != config.plugins.iptvplayer.extplayer_subtitle_background.value:
            list.append(getConfigListEntry(_("Subtitle line height"), config.plugins.iptvplayer.extplayer_subtitle_line_height))

        list.append(getConfigListEntry(_("Subtitle font color"), config.plugins.iptvplayer.extplayer_subtitle_font_color))
        list.append(getConfigListEntry(_("Subtitle background"), config.plugins.iptvplayer.extplayer_subtitle_background))

        list.append(getConfigListEntry(_("Subtitle box position"), config.plugins.iptvplayer.extplayer_subtitle_pos))
        if config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled.value:
            if 'transparent' == config.plugins.iptvplayer.extplayer_subtitle_background.value:
                list.append(getConfigListEntry(_("Subtitle box height"), config.plugins.iptvplayer.extplayer_subtitle_box_height))
                list.append(getConfigListEntry(_("Subtitle vertical alignment"), config.plugins.iptvplayer.extplayer_subtitle_box_valign))

        if self.subtitle_border_avaliable:
            list.append(getConfigListEntry(_("Subtitle border enabled"), config.plugins.iptvplayer.extplayer_subtitle_border_enabled))
            if config.plugins.iptvplayer.extplayer_subtitle_border_enabled.value:
                list.append(getConfigListEntry(_("Subtitle border color"), config.plugins.iptvplayer.extplayer_subtitle_border_color))
                list.append(getConfigListEntry(_("Subtitle border width"), config.plugins.iptvplayer.extplayer_subtitle_border_width))

        list.append(getConfigListEntry(_("Subtitle shadow enabled"), config.plugins.iptvplayer.extplayer_subtitle_shadow_enabled))
        if config.plugins.iptvplayer.extplayer_subtitle_shadow_enabled.value:
            list.append(getConfigListEntry(_("Subtitle shadow color"), config.plugins.iptvplayer.extplayer_subtitle_shadow_color))
            list.append(getConfigListEntry(_("Subtitle shadow X offset"), config.plugins.iptvplayer.extplayer_subtitle_shadow_xoffset))
            list.append(getConfigListEntry(_("Subtitle shadow Y offset"), config.plugins.iptvplayer.extplayer_subtitle_shadow_yoffset))

        list.append(getConfigListEntry(_("Inject black iframe at video playback finish"), config.plugins.iptvplayer.use_clear_iframe))
        list.append(getConfigListEntry(_("Show iframe during audio playback"), config.plugins.iptvplayer.show_iframe))
        if config.plugins.iptvplayer.show_iframe.value:
            list.append(getConfigListEntry("    " + _("Radio iframe file"), config.plugins.iptvplayer.iframe_file))
        if config.plugins.iptvplayer.show_iframe.value or config.plugins.iptvplayer.use_clear_iframe.value:
            list.append(getConfigListEntry("    " + _("Black iframe file"), config.plugins.iptvplayer.clear_iframe_file))
        self.list = list
        ConfigBaseWidget.runSetup(self)

    def getSubOptionsList(self):
        tab = [
            config.plugins.iptvplayer.extplayer_subtitle_border_enabled,
            config.plugins.iptvplayer.extplayer_subtitle_shadow_enabled,
            config.plugins.iptvplayer.extplayer_subtitle_wrapping_enabled,
            config.plugins.iptvplayer.extplayer_subtitle_background,
            config.plugins.iptvplayer.show_iframe,
            config.plugins.iptvplayer.use_clear_iframe,
        ]
        return tab

    def changeSubOptions(self):
        self.runSetup()
