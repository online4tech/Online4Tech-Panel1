# -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import GetDefaultLang

from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_9kw import UnCaptchaReCaptcha as UnCaptchaReCaptcha_9kw
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_2captcha import UnCaptchaReCaptcha as UnCaptchaReCaptcha_2captcha
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_mye2i import UnCaptchaReCaptcha as UnCaptchaReCaptcha_mye2i
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2_myjd import UnCaptchaReCaptcha as UnCaptchaReCaptcha_myjd
from Plugins.Extensions.IPTVPlayer.libs.recaptcha_v2 import UnCaptchaReCaptcha as UnCaptchaReCaptcha_fallback
from Plugins.Extensions.IPTVPlayer.libs.captcha_deathbycaptcha import UnCaptchaReCaptcha as UnCaptchaReCaptcha_dbc

from Plugins.Extensions.IPTVPlayer.libs.hcaptcha_2captcha import UnCaptchahCaptcha as UnCaptchahCaptcha_2captcha

from Screens.MessageBox import MessageBox
from Components.config import config


class CaptchaHelper():

    def processCaptcha(self, sitekey, refUrl, bypassCaptchaService=None, userAgent=None, baseErrMsgTab=None, beQuaiet=False, captchaType='', captchaAction='', captchaData=''):
        if isinstance(baseErrMsgTab, list):
            errorMsgTab = list(baseErrMsgTab)
        else:
            errorMsgTab = [_('Link protected with Google ReCaptcha v2')]

        if userAgent is None:
            try:
                userAgent = self.USER_AGENT
            except Exception:
                pass

        if userAgent is None:
            try:
                userAgent = self.defaultParams['header']['User-Agent']
            except Exception:
                pass

        token = ''
        # the Google fallback page only knows reCAPTCHA keys ("6L..."); for a Cloudflare Turnstile key ("0x...") it answers 400
        if not str(sitekey or '').startswith('0x'):
            recaptcha = UnCaptchaReCaptcha_fallback(lang=GetDefaultLang())
            recaptcha.HTTP_HEADER['Referer'] = refUrl
            if userAgent is not None:
                recaptcha.HTTP_HEADER['User-Agent'] = userAgent
            token = recaptcha.processCaptcha(sitekey)

        if token == '':
            recaptcha = None
            if config.plugins.iptvplayer.captcha_bypass.value != '' and bypassCaptchaService is None:
                bypassCaptchaService = config.plugins.iptvplayer.captcha_bypass.value
            if bypassCaptchaService == '9kw.eu':
                recaptcha = UnCaptchaReCaptcha_9kw()
            elif bypassCaptchaService == '2captcha.com':
                if captchaType == 'h1':
                    recaptcha = UnCaptchahCaptcha_2captcha()
                else:
                    recaptcha = UnCaptchaReCaptcha_2captcha()
            elif bypassCaptchaService == 'deathbycaptcha.com':
                recaptcha = UnCaptchaReCaptcha_dbc()
            elif bypassCaptchaService == 'mye2i':
                recaptcha = UnCaptchaReCaptcha_mye2i()
            elif config.plugins.iptvplayer.myjd_login.value != '' and config.plugins.iptvplayer.myjd_password.value != '':
                recaptcha = UnCaptchaReCaptcha_myjd()

            if recaptcha is not None:
                if isinstance(recaptcha, UnCaptchaReCaptcha_mye2i):
                    # only MyE2i can run score based reCAPTCHA (v3 / Enterprise, needs the action) and Turnstile with action/cdata
                    token = recaptcha.processCaptcha(sitekey, refUrl, captchaType, captchaAction, captchaData)
                elif isinstance(recaptcha, UnCaptchaReCaptcha_dbc):
                    # DeathByCaptcha: reCAPTCHA v2 / v3 (with the action) / Enterprise and Turnstile, no hCaptcha
                    token = recaptcha.processCaptcha(sitekey, refUrl, captchaType, captchaAction)
                else:
                    token = recaptcha.processCaptcha(sitekey, refUrl, captchaType)
            else:
                errorMsgTab.append(_('Please visit %s to learn how to redirect this task to the external device.') % 'https://github.com/oe-mirrors/e2iplayer/wiki/Solve-Cloudflare-hCaptcha-reCAPTCHA-with-MyE2i')
                if not beQuaiet:
                    self.sessionEx.waitForFinishOpen(MessageBox, '\n'.join(errorMsgTab), type=MessageBox.TYPE_ERROR, timeout=20)
                if bypassCaptchaService is not None:
                    errorMsgTab.append(_('or'))
                    errorMsgTab.append(_('You can use \"%s\" or \"%s\" services for automatic solution.') % ("https://2captcha.com/", "https://9kw.eu/", ) + ' ' + _('Go to the host configuration available under blue button.'))
        return token, errorMsgTab
