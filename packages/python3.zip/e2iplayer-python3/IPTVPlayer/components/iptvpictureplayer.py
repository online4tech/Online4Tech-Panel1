# -*- coding: utf-8 -*-
#
#  IPTV download manager UI
#
#  $Id$
#
#
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.cover import SimpleAnimatedCover, Cover
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components import skinchrome
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, eConnectCallback, GetNice, E2PrioFix, GetGstPlayerPath
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdh import DMHelper
from Plugins.Extensions.IPTVPlayer.iptvdm.downloaderhelpers import shellQuote
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdownloadercreator import DownloaderCreator
from Plugins.Extensions.IPTVPlayer.libs.pCommon import DescribeImageFile
from Plugins.Extensions.IPTVPlayer.components.iptvlcd import infoSummaryIfWanted, lcdSetInfo
###################################################

###################################################
# FOREIGN import
###################################################
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from enigma import getDesktop, eTimer, eConsoleAppContainer
from Components.ActionMap import ActionMap
from Components.Label import Label
from Tools.Directories import fileExists
import os
import time
from urllib.parse import urlparse
###################################################


class IPTVSimpleAudioPlayer():
    def __init__(self):
        additionalParams = {}
        self.gstAdditionalParams = {'buffer-duration': 2}
        self.gstAdditionalParams['download-buffer-path'] = additionalParams.get('download-buffer-path', '')  # File template to store temporary files in, should contain directory and XXXXXX
        self.gstAdditionalParams['ring-buffer-max-size'] = additionalParams.get('ring-buffer-max-size', 0)  # in MB
        self.gstAdditionalParams['buffer-duration'] = additionalParams.get('buffer-duration', -1)  # in s
        self.gstAdditionalParams['buffer-size'] = additionalParams.get('buffer-size', 0)

        self.uri = ""
        self.playMode = ""
        self.console = None

        self.isClosing = False
        self.stopped = True

    def start(self, uri, mode='loop'):
        self.uri = uri
        self.playMode = mode

        gstplayerPath = GetGstPlayerPath()
        # 'export GST_DEBUG="*:6" &&' +
        cmd = gstplayerPath + ' "%s"' % shellQuote(self.uri)
        if "://" in self.uri:
            # http headers + proxy, gstplayer takes both as "key=value" fields
            httpFields = []
            tmp = strwithmeta(self.uri)
            url, httpParams = DMHelper.getDownloaderParamFromUrl(tmp)
            for key in httpParams:
                if key == 'http_proxy':
                    # the proxy fields below, not an "http_proxy:" request header
                    continue
                httpFields.append((key, httpParams[key]))
            if 'http_proxy' in tmp.meta:
                tmp = tmp.meta['http_proxy']
                if '://' in tmp:
                    parsed = urlparse(tmp)
                    if parsed.username and parsed.password:
                        httpFields.extend([("proxy", "%s://%s" % (parsed.scheme, parsed.netloc.rsplit("@", 1)[-1])), ('proxy-id', parsed.username), ('proxy-pw', parsed.password)])
                    else:
                        httpFields.append(('proxy', tmp))
            if gstplayerPath.endswith('gstplayer2'):
                # getopt command line; no buffer options are set here and
                # gstplayer2 keeps its defaults for those it does not get
                for key, value in httpFields:
                    cmd += ' -H "%s=%s"' % (key, shellQuote(value))
            else:
                # positional command line of the original gstplayer: audio track,
                # download timeout and live come before the buffer options
                cmd += ' -1 0 0 "%s" "%s" "%s" "%s" ' % (shellQuote(self.gstAdditionalParams['download-buffer-path']), self.gstAdditionalParams['ring-buffer-max-size'], self.gstAdditionalParams['buffer-duration'], self.gstAdditionalParams['buffer-size'])
                for key, value in httpFields:
                    cmd += ' "%s=%s" ' % (key, shellQuote(value))
        else:
            cmd = 'exteplayer3 "%s"' % shellQuote(self.uri) + " > /dev/null"
        self.console = eConsoleAppContainer()
        self.console_appClosed_conn = eConnectCallback(self.console.appClosed, self._playerFinished)
        printDBG("IPTVSimpleAudioPlayer.start cmd[%s]" % cmd)
        if hasattr(self.console, "setNice"):
            self.console.setNice(GetNice() + 2)
            self.console.execute(cmd)
        else:
            self.console.execute(E2PrioFix(cmd))
        self.stopped = False

    def _playerFinished(self, code):
        printDBG("IPTVSimpleAudioPlayer.eplayer3Finished code[%r]" % code)
        if self.isClosing:
            return
        if self.playMode == 'loop' and not self.stopped:
            self.start(self.uri, self.playMode)

    def stop(self):
        if None is self.console:
            return
        self.stopped = True
        self.console.write("q\n")

    def close(self):
        self.isClosing = True
        if None is not self.console:
            self.stop()
            time.sleep(1)  # YES I know this is bad, but for now must be enough ;) Some, day I will fix this
            self.console.sendCtrlC()
            self.console_appClosed_conn = None
            self.console = None

# class IPTVSimpleAudioPlayer


class IPTVPicturePlayerWidget(Screen):
    NUM_OF_ICON_FRAMES = 8
    #######################
    #       SIZES
    #######################
    # percentage
    s_w = 120
    s_h = 120
    # icon
    i_w = 128
    i_h = 128
    # console
    c_h = 80

    def __prepareSkin(self):
        # per-instance, not class-level - a class-level getDesktop(0).size()
        # would only ever be evaluated once, at module import time, and
        # could go stale if the real GUI resolution changes later without
        # a plugin restart.
        #
        # Fullscreen picture viewer, not a dialog - the window itself
        # always fills the entire real screen (not resized to the photo's
        # own dimensions); Cover's own ePicLoad aspect-preserving
        # scale-to-fit is what makes the actual photo appear as large as
        # possible within its box, letterboxed as needed.
        sz_w = getDesktop(0).size().width()
        sz_h = getDesktop(0).size().height()
        scale = skinchrome.getScale(sz_w)
        iconBase = skinchrome.getIconBase(sz_w)
        headerH = skinchrome.header_height(scale)
        footerH = skinchrome.footer_height(scale)
        # content area is the full screen minus the chrome header/footer -
        # every position below is the same relative layout the old
        # full-screen version used (icon+console stacked and centered,
        # picture filling the rest with a 10px margin), just confined to
        # that area instead of the whole screen
        contentY0 = headerH
        contentH = sz_h - headerH - footerH
        s_w, s_h, i_w, i_h, c_h = self.s_w, self.s_h, self.i_w, self.i_h, self.c_h
        c_w = sz_w
        p_w = sz_w - 20
        p_h = contentH - 20
        start_y = contentY0 + (contentH - (i_h + c_h)) // 2
        s_x = (sz_w - s_w) // 2
        s_y = start_y + (i_h - s_h) // 2
        i_x = (sz_w - i_w) // 2
        i_y = start_y
        c_x = 0
        c_y = i_y + i_h
        p_x = 10
        p_y = contentY0 + 10
        printDBG("[IPTVPicturePlayerWidget] desktop size %dx%d" % (sz_w, sz_h))
        return """
        <screen name="IPTVPicturePlayerWidget" position="center,center" size="%d,%d" backgroundColor="#34111112" flags="wfNoBorder">
            %s
            <widget name="status" size="%d,%d" position="%d,%d" zPosition="5" valign="center" halign="center" font="Regular;21" backgroundColor="black" transparent="1" />
            <widget name="console" size="%d,%d" position="%d,%d" zPosition="5" valign="center" halign="center" font="Regular;21" backgroundColor="black" transparent="1" />
            <widget name="icon" size="%d,%d" position="%d,%d" zPosition="4" transparent="1" alphatest="blend" />
            <widget name="picture" size="%d,%d" position="%d,%d" zPosition="6" transparent="1" alphatest="blend" />
            %s
        </screen>
        """ % (
            sz_w, sz_h,                                              # screen size
            skinchrome.build_header(scale=scale, iconBase=iconBase),  # header
            s_w, s_h, s_x, s_y,                                       # status widget
            c_w, c_h, c_x, c_y,                                       # console widget
            i_w, i_h, i_x, i_y,                                       # icon widget
            p_w, p_h, p_x, p_y,                                       # picture widget
            skinchrome.build_footer(sz_h, scale=scale, iconBase=iconBase, keys=(), showMenu=False, showNav=False, showOk=True, showExit=True),  # footer
        )

    def __init__(self, session, url, pathForRecordings, pictureTitle, addParams={}):
        self.session = session

        self.skin = self.__prepareSkin()
        Screen.__init__(self, session)
        self.skinName = skinchrome.forceInternalSkinName(["IPTVPicturePlayerWidget"])
        self.setTitle(pictureTitle)
        self.onStartCalled = False

        self.recordingPath = pathForRecordings
        try:
            self.filePath = os.path.join(pathForRecordings, '.iptv_buffering.jpg')
        except Exception:
            self.filePath = ''
            printExc()

        self.addParams = {'seq_mode': False}
        self.addParams.update(addParams)

        self.url = url
        self.pictureTitle = pictureTitle
        self.audioUrl = strwithmeta(url).meta.get("iptv_audio_url", '')

        self["actions"] = ActionMap(['IPTVAlternateVideoPlayer', 'MoviePlayerActions', 'MediaPlayerActions', 'WizardActions', 'DirectionActions'],
        {
            'leavePlayer': self.key_exit,
            'play': self.key_play,
            'pause': self.key_pause,
            'exit': self.key_exit,
            'back': self.key_exit,
            'ok': self.key_ok,
        }, -1)

        self["status"] = Label()
        self["console"] = Label()
        self["icon"] = SimpleAnimatedCover()
        self["picture"] = Cover()

        # prepare icon frames path - icons/HD|FHD|WQHD/buffering/buffering_N.png, like iptvbuffui.py
        _iconBase = skinchrome.getIconBase()
        frames = []
        for idx in range(1, self.NUM_OF_ICON_FRAMES + 1):
            frames.append(_iconBase + '/buffering/buffering_%d.png' % idx)
        self["icon"].loadFrames(frames)

        # main Timer
        self.mainTimer = eTimer()
        self.mainTimerEnabled = False

        if self.addParams['seq_mode']:
            self.canAutoClose = True
            self.mainTimer_conn = eConnectCallback(self.mainTimer.timeout, self.closeAfterTimeout)
            self.mainTimerInterval = 1000 * 10  # 10s
        else:
            self.mainTimer_conn = eConnectCallback(self.mainTimer.timeout, self.updateDisplay)
            self.mainTimerInterval = 100  # by default 0,1s
        # download - a local picture (file://) is read where it is; a downloader for it only logged a traceback
        self.downloader = None if self.url.startswith('file://') else DownloaderCreator(self.url)

        self.onClose.append(self.__onClose)
        self.onShow.append(self.doStart)
        # self.onLayoutFinish.append(self.doStart)

        self.autoRefresh = False
        self.refreshPostfixes = ['_0', '_1']
        self.refreshCount = 0
        self.refreshing = False

        if len(self.audioUrl):
            self.audioPlayer = IPTVSimpleAudioPlayer()
        else:
            self.audioPlayer = None

    # end def __init__(self, session):

    def createSummary(self):
        return infoSummaryIfWanted()

    def __del__(self):
        printDBG('IPTVPicturePlayerWidget.__del__ --------------------------------------')

    def __onClose(self):
        printDBG('IPTVPicturePlayerWidget.__onClose ------------------------------------')
        if None is not self.audioPlayer:
            self.audioPlayer.close()
        self.onEnd()
        if None is not self.mainTimer:
            try:
                self.mainTimer.stop()
            except Exception:
                pass
        self.mainTimer_conn = None
        self.mainTimer = None

        self.onClose.remove(self.__onClose)
        # self.onLayoutFinish.remove(self.doStart)

    def _getDownloadFilePath(self):
        return self.filePath + self.refreshPostfixes[self.refreshCount % len(self.refreshPostfixes)]

    def closeAfterTimeout(self):
        # an error MessageBox on top closes this screen through its own callback
        if self.canAutoClose and getattr(self.session, 'current_dialog', self) is self:
            self.close()

    def onStart(self):
        '''
            this method is called once like __init__ but in __init__ we cannot display MessageBox
        '''
        self["picture"].hide()
        self["console"].setText(self.pictureTitle)
        self["status"].setText(_("--"))
        self._cleanedUp()

        if self.url.startswith('file://'):
            self["status"].setText(_("++"))
            # WebP / AVIF / gzip are converted in a copy (the buffering file, removed on close), the user's own
            # picture stays as it is; anything else is decoded straight from it
            if self.filePath:
                ret = self["picture"].decodePreparedCover(self._getDownloadFilePath(), self.decodePictureEnd, ' ', self.url[7:])
            else:
                ret = self["picture"].decodeCover(self.url[7:], self.decodePictureEnd, ' ')
            if -1 == ret:
                self.decodePictureEnd()
        else:
            if self.downloader:
                self.downloader.isWorkingCorrectly(self._startDownloader)
            else:
                self.session.openWithCallback(self.close, MessageBox, _("Downloading cannot be started.\n Invalid URI[%s].") % self.url, type=MessageBox.TYPE_ERROR, timeout=10)

    def _doStart(self, force=False):
        # seq_mode: a forced start (the first one, from _startDownloader) still downloads the picture; the
        # auto-close timer starts after it has been decoded (decodePictureEnd -> _doStart())
        if self.addParams['seq_mode'] and not force:
            self.mainTimer.start(self.mainTimerInterval, True)  # single shot
            return
        if self.autoRefresh or force:
            self.refreshing = True
            self.downloader = DownloaderCreator(self.url)

            url, downloaderParams = DMHelper.getDownloaderParamFromUrl(self.url)
            self.downloader.subscribeFor_Finish(self.downloaderEnd)
            self.downloader.start(url, self._getDownloadFilePath(), downloaderParams)
            # in seq_mode the main timer is the auto-close timer, not the buffering animation
            if not self.addParams['seq_mode']:
                self.setMainTimerSts(True)
        else:
            self.refreshing = False

    def _startDownloader(self, sts, reason):
        if sts:
            self._doStart(True)
        else:
            self.session.openWithCallback(self.close, MessageBox, _("Downloading cannot be started.\n Downloader [%s] not working properly.\n Status[%s]") % (self.downloader.getName(), reason.strip()), type=MessageBox.TYPE_ERROR, timeout=10)

    def onEnd(self, withCleanUp=True):
        self.setMainTimerSts(False)
        if self.downloader:
            self.downloader.unsubscribeFor_Finish(self.downloaderEnd)
            downloader = self.downloader
            self.downloader = None
            downloader.terminate()
            downloader = None
        if withCleanUp:
            self._cleanedUp()

    def key_exit(self):
        self.close('key_exit')

    def key_play(self):
        if self.addParams['seq_mode']:
            self.canAutoClose = False
            return

        if not self.autoRefresh and not self.url.startswith('file://'):
            if None is not self.audioPlayer:
                self.audioPlayer.start(self.audioUrl)
            self.autoRefresh = True
            if not self.refreshing:
                self._doStart()

    def key_pause(self):
        if self.addParams['seq_mode']:
            self.canAutoClose = False
            return
        if self.autoRefresh:
            if None is not self.audioPlayer:
                self.audioPlayer.stop()
            self.autoRefresh = False

    def key_ok(self):
        if self.addParams['seq_mode']:
            self.canAutoClose = False
            return
        if self.autoRefresh:
            self.key_pause()
        else:
            self.key_play()

    def downloaderEnd(self, status):
        if None is not self.downloader:
            self.onEnd(False)
            if DMHelper.STS.DOWNLOADED == status:
                self["status"].setText(_("++"))
                # a downloaded picture: gzip / WebP / AVIF are made showable first (local file:// pictures are not
                # touched, that conversion works in place)
                if -1 == self["picture"].decodePreparedCover(self._getDownloadFilePath(), self.decodePictureEnd, ' '):
                    self.decodePictureEnd()
            else:
                if 0 == self.refreshCount:
                    self.session.openWithCallback(self.close, MessageBox, (_("Downloading file [%s] problem.") % self.url) + (" sts[%r]" % status), type=MessageBox.TYPE_ERROR, timeout=10)
                self._doStart()

    def decodePictureEnd(self, ret={}):
        printDBG('IPTVPicturePlayerWidget.decodePictureEnd')
        if None is ret.get('Pixmap', None):
            if 0 == self.refreshCount:
                shownPath = self.url[7:] if self.url.startswith('file://') else self.filePath
                printDBG("IPTVPicturePlayerWidget picture can not be shown, %s" % DescribeImageFile(ret.get('FileName', shownPath)))
                self.session.openWithCallback(self.close, MessageBox, _("Decode file [%s] problem.") % shownPath, type=MessageBox.TYPE_ERROR, timeout=10)
        else:
            self.refreshCount += 1
            self["status"].hide()
            self["console"].hide()
            self["icon"].hide()
            self["picture"].updatePixmap(ret.get('Pixmap', None), ret.get('FileName', self.filePath))
            self["picture"].show()
            # LCD: the title and the picture, again with every refresh
            lcdSetInfo(self, picture=ret.get('FileName', self.filePath), refresh=True)
        self.setMainTimerSts(False)
        self._doStart()

    def setMainTimerSts(self, start):
        try:
            if start:
                if not self.mainTimerEnabled:
                    self.mainTimer.start(self.mainTimerInterval)
                    self.mainTimerEnabled = True
                    self.updateDisplay()
            else:
                if self.mainTimerEnabled:
                    self.mainTimer.stop()
                    self.mainTimerEnabled = False
        except Exception:
            printExc("IPTVPicturePlayerWidget.setMainTimerSts status[%r] EXCEPTION" % start)

    def updateDisplay(self):
        printDBG("updateDisplay")
        if not self.mainTimerEnabled:
            printDBG("updateDisplay aborted - timer stopped")
            return
        self["icon"].nextFrame()
        return

    def _cleanedUp(self):
        for item in self.refreshPostfixes:
            filePath = self.filePath + item
            if fileExists(filePath):
                try:
                    os.remove(filePath)
                except Exception:
                    printDBG('Problem with removing old buffering file')

    def doStart(self):
        self.onShow.remove(self.doStart)
        if not self.onStartCalled:
            self.onStartCalled = True
            self.onStart()
