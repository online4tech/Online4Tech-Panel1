# -*- coding: utf-8 -*-
# Last Modified: 2026-11-02 - LCD skins get remaining minutes and times without seconds; playback tells
#              other plugins whether the player is open, the title, the cover and whether it is live.
# 2026-11-01 - INFO shows a panel over the running video (iptvplayerinfopanel.py).
# 2026-10-31 - colour front displays (LCD) show title, progress bar and times during playback;
#              the same screen serves the buffering screen and the download manager.
# 2026-10-28 - a remembered subtitle file that is gone (put into the MKV by the download manager) is
#              dropped without an error message, the search next to the video runs instead.
# 2026-10-25 - image subtitles (PGS / DVB / XSUB) of exteplayer3 with the exteplayer3png.so plugin.
#            - DASH links of getMPDLinksWithMeta (iptv_dash_sel) play the local filtered MPD of libs/dashmpd.py
#              (only the chosen video / audio); exteplayer3's -0 / -1 needed an ffmpeg patch OE-A dropped.
# 2026-10-17 - buffering: the skip keys stop at the end of the part downloaded so far (bufferedEnd()), the
#              watched mark takes the clip length only from a finished download.
# 2026-10-12 - a downloaded file also finds its subtitles saved as name.de.srt (box language, then English).
# 2026-07-26 Updated to ignore non-subtitle sidecar text files during automatic subtitle detection
# and to safely handle PLAYBACK_STOP when the exteplayer3 control socket is already gone. - Kamikaze24
#
#  IPTVExtMoviePlayer
#
#  $Id$
#
#

###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.iptvdm.iptvdh import DMHelper
from Plugins.Extensions.IPTVPlayer.iptvdm.downloaderhelpers import shellQuote, subtitleSidecarFiles
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.components.cover import Cover3
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, GetSubtitlesDir, eConnectCallback, \
                                                          GetE2VideoAspectChoices, GetE2VideoAspect, SetE2VideoAspect, GetE2VideoPolicyChoices, \
                                                          GetE2VideoPolicy, SetE2VideoPolicy, GetDefaultLang, GetPolishSubEncoding, iptv_system, \
                                                          GetE2AudioCodecMixOption, SetE2AudioCodecMixOption, CreateTmpFile, GetTmpDir, IsExecutable, GetGstIfdSrc, GetGstPlayerPath, MapUcharEncoding, \
                                                          GetE2VideoModeChoices, GetE2VideoMode, SetE2VideoMode, GetPlayerSkinDir, GetNice, E2PrioFix, \
                                                          StripColorCodes, mkdirs
from Plugins.Extensions.IPTVPlayer.tools.iptvsubtitles import IPTVSubtitlesHandler, IPTVEmbeddedSubtitlesHandler, IPTVGraphicSubtitlesHandler
from Plugins.Extensions.IPTVPlayer.tools.iptvmoviemetadata import IPTVMovieMetaDataHandler
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.iptvsubdownloader import IPTVSubDownloaderWidget
from Plugins.Extensions.IPTVPlayer.components.iptvsubsimpledownloader import IPTVSubSimpleDownloaderWidget
from Plugins.Extensions.IPTVPlayer.components.iptvchoicebox import IPTVChoiceBoxWidget, IPTVChoiceBoxItem
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinfopanel import PlayerInfoPanel
from Plugins.Extensions.IPTVPlayer.components.iptvlist import IPTVPlaylistChoiceBoxList
from Plugins.Extensions.IPTVPlayer.tools import listselection
from Plugins.Extensions.IPTVPlayer.components.iptvdirbrowser import IPTVFileSelectorWidget
from Plugins.Extensions.IPTVPlayer.components.configextmovieplayer import ConfigExtMoviePlayerBase, ConfigExtMoviePlayer
from Plugins.Extensions.IPTVPlayer.components.iptvlcd import IPTVExtMoviePlayerColorSummary, IPTVExtMoviePlayerSummary, addLcdSources, isLargeLcd, lcdTimeHM
from Plugins.Extensions.IPTVPlayer.components import skinchrome
from Plugins.Extensions.IPTVPlayer.libs.pCommon import CParsingHelper
from Plugins.Extensions.IPTVPlayer.libs.urlparser import urlparser
from Plugins.Extensions.IPTVPlayer.libs import dashmpd
from Plugins.Extensions.IPTVPlayer.libs.subtitlesmatch import langCode, langName
from Plugins.Extensions.IPTVPlayer.p2p3.manipulateStrings import ensure_str

# FOREIGN import
from enigma import eConsoleAppContainer, getDesktop, eTimer, eLabel, gFont, ePoint, eSize, gRGB
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import config
from Components.Label import Label
from Components.ProgressBar import ProgressBar

from Screens.MessageBox import MessageBox
from Tools.LoadPixmap import LoadPixmap
from Tools.BoundFunction import boundFunction
from Tools.Directories import fileExists
from skin import parseColor

from datetime import timedelta
try:
    from math import floor, fabs
except Exception:
    printExc()

from os import path as os_path, rename as os_rename, stat as os_stat, listdir as os_listdir, remove as os_remove
import re
import time
import json
try:
    from PIL import Image
except ImportError:
    Image = None

###################################################

# exteplayer3 saves image subtitles (PGS / DVB / XSUB) as PNG files with -G <directory>, through the
# exteplayer3png.so plugin of e2iplayer-deps (dlopen, found in the library path); without -G it does not
# even list those tracks. Builds that do not know -G stop at the unknown option, so the getopt string
# (the one with "9:", the subtitle track option) is looked up in the binary first. The OE-A feed packs
# exteplayer3 with UPX on 32-bit boxes, the string is not readable then - those builds are recent and
# know -G (it came with the graphic subtitles in 2019).
EXTEPLAYER3PNG_PATHS = ['/usr/lib/exteplayer3png.so', '/lib/exteplayer3png.so']
graphicSubsCache = (None, False)


def LoadPlayerMessage(item):
    # one status line of the player as JSON. exteplayer3 cuts its PLAYBACK_OPEN message at about 2 KB (the url of a
    # Pluto TV stream is longer) and puts that unclosed text in front of every later message: the message is then
    # the first '{"' from which the rest of the line is valid JSON
    try:
        return json.loads(item)
    except ValueError:
        pos = item.find('{"', 1)
        while pos > 0:
            try:
                return json.loads(item[pos:])
            except ValueError:
                pos = item.find('{"', pos + 1)
        raise


def GraphicSubtitlesSupported(exteplayer3path):
    global graphicSubsCache
    if not any(os_path.isfile(path) for path in EXTEPLAYER3PNG_PATHS):
        return False
    try:
        st = os_stat(exteplayer3path)
        key = (exteplayer3path, st.st_mtime, st.st_size)
        if key != graphicSubsCache[0]:
            with open(exteplayer3path, 'rb') as f:
                data = f.read()
            if b'UPX!' in data[:4096]:
                supported, how = True, 'UPX packed'
            else:
                supported = any(b'G:' in opts for opts in re.findall(b'[0-9A-Za-z:]{20,}', data) if b'9:' in opts)
                how = 'getopt string'
            graphicSubsCache = (key, supported)
            printDBG("exteplayer3: image subtitles supported[%s] (%s)" % (supported, how))
        return graphicSubsCache[1]
    except Exception:
        printExc()
    return False


class ExtPlayerCommandsDispatcher():
    def __init__(self, owner):
        self.owner = owner

        # SEEK_SPEED_MAP = [0.125, 0.25, 0.5, 0, 2, 4, 8, 16, 32, 64, 128]
        self.SEEK_SPEED_MAP = []
        for item in reversed(config.seek.speeds_slowmotion.value):
            self.SEEK_SPEED_MAP.append(1.0 / float(item))
        self.SEEK_SPEED_MAP.append(0)
        for item in config.seek.speeds_forward.value:
            self.SEEK_SPEED_MAP.append(item)
        self.speedIdx = self.SEEK_SPEED_MAP.index(0)

    def doAddTriggers(self, arg):
        self.extPlayerSendCommand('ADD_TRIGGERS', arg)

    def stop(self):
        if self.extPlayerSendCommand('PLAYBACK_STOP'):
            self.owner = None
            return True
        return False

    def play(self):
        self.extPlayerSendCommand('PLAYBACK_CONTINUE')
        self.speedIdx = self.SEEK_SPEED_MAP.index(0)

    def pause(self):
        self.extPlayerSendCommand('PLAYBACK_PAUSE')
        self.speedIdx = self.SEEK_SPEED_MAP.index(0)

    def setAudioTrack(self, id):
        self.extPlayerSendCommand('PLAYBACK_SET_AUDIO_TRACK', id, False)

    def setSubtitleTrack(self, id):
        self.extPlayerSendCommand('PLAYBACK_SET_SUBTITLE_TRACK', id, False)

    def setDownloadFileTimeout(self, timeout):
        self.extPlayerSendCommand('PLAYBACK_SET_DOWNLOAD_FILE_TIMEOUT', timeout, False)

    def setProgressiveDownload(self, flag):
        self.extPlayerSendCommand('PLAYBACK_SET_PROGRESSIVE_DOWNLOAD', flag, False)

    def setLoopMode(self, value):
        self.extPlayerSendCommand('PLAYBACK_SET_LOOP_MODE', value, False)

    def doSeek(self, diff):
        self.extPlayerSendCommand('PLAYBACK_SEEK_RELATIVE', '%d' % diff)
        self.speedIdx = self.SEEK_SPEED_MAP.index(0)

    def doGoToSeek(self, arg):
        self.extPlayerSendCommand('PLAYBACK_SEEK_ABS', arg)
        self.speedIdx = self.SEEK_SPEED_MAP.index(0)

    def doSeekFwd(self, arg):
        self.extPlayerSendCommand('PLAYBACK_FASTFORWARD', arg)

    def doSlowMotion(self, arg):
        self.extPlayerSendCommand('PLAYBACK_SLOWMOTION', arg)

    def doUpdateInfo(self):
        self.extPlayerSendCommand('PLAYBACK_LENGTH', '', False)
        self.extPlayerSendCommand('PLAYBACK_CURRENT_TIME', '', False)

    def seekFwd(self):
        printDBG('seekFwd skipped')
        return
        self.speedIdx += 1
        self.tipMode()

    def seekBack(self):
        printDBG('seekBack skipped')
        return
        self.speedIdx -= 1
        self.tipMode()

    def tipMode(self):
        printDBG("ExtPlayerCommandsDispatcher.tipMode speedIdx[%d]" % self.speedIdx)
        if self.speedIdx >= len(self.SEEK_SPEED_MAP):
            self.speedIdx = len(self.SEEK_SPEED_MAP) - 1
        elif self.speedIdx < 0:
            self.speedIdx = 0
        val = self.SEEK_SPEED_MAP[self.speedIdx]
        printDBG("ExtPlayerCommandsDispatcher.tipMode val[%r]" % val)
        if 0 == val:
            self.play()
        elif 1 < val:
            if 'eplayer' == self.owner.player:
                val -= 1
            self.doSeekFwd(str(val))
        else:
            self.doSlowMotion(str(int(1.0 / val)))

    def extPlayerSendCommand(self, cmd, arg='', getStatus=True):
        ret = False
        if None is not self.owner:
            try:
                ret = self.owner.extPlayerSendCommand(cmd, arg)
            except Exception:
                printExc()
                if 'PLAYBACK_STOP' == cmd:
                    return False
                if getStatus:
                    self.owner = None
                    return False
        else:
            printDBG(">> extPlayerSendCommand owner NONE")
            return False

        if getStatus and None is not self.owner:
            try:
                self.owner.extPlayerSendCommand("PLAYBACK_INFO", '')
            except Exception:
                printExc()
                self.owner = None
        return ret


class IPTVExtMoviePlayer(Screen):
    NON_SUBTITLE_SIDE_EXTENSIONS = ['txt', 'sub', 'srt', 'vtt']

    Y_CROPPING_GUARD = 0
    playback = {}
    # every playerskins/*/playerskin.xml (bar "sd") is authored for this
    # canvas - see resolution="1280,720" on their <screen> tags
    REF_W = 1280
    REF_H = 720
    # rectangles of one image subtitle (MAX_RECT_DESC in exteplayer3's graphic_subtitle.c)
    GRAPHIC_SUB_RECTS = 4

    # theme -> (progress, cbuff, buff) bar image in playerskins/_scaled/,
    # shipped as <name>_1920.png/<name>_2560.png - see
    # _progressBarPixmapPath(). The themes share only 7 different bar
    # images, so the scaled copies live in one folder. A new theme needs
    # an entry here (or falls back to its own unscaled images).
    SCALED_BAR_IMAGES = {
        'default': ('blue', 'dark_green', 'dark_blue'),
        'black': ('wide_red', 'wide_light_blue', 'wide_red'),
        'red': ('wide_red', 'wide_light_blue', 'wide_red'),
        'blue': ('wide_light_blue', 'wide_red', 'wide_red'),
        'green': ('dark_green', 'gradient_green_red', 'gradient_red_green'),
        'black-white': ('gradient_green_red', 'dark_green', 'gradient_red_green'),
        'cobalt': ('blue', 'dark_green', 'gradient_red_green'),
        'jersey': ('gradient_green_red', 'dark_green', 'gradient_red_green'),
        'navy': ('blue', 'dark_green', 'gradient_red_green'),
        'line': ('gradient_green_red', 'dark_green', 'gradient_red_green'),
    }

    def __prepareSkin(self):
        # REF_W/REF_H: every playerskins/*/playerskin.xml (and the inline
        # fallback below) declares its widgets for a fixed 1280x720
        # canvas; resolution="1280,720" on every non-"sd" theme's
        # <screen> tag makes Enigma2 scale all of that automatically for
        # FHD/WQHD - initGuiComponentsPos()'s own runtime centering (reads
        # back the already-scaled widget sizes) and subSynchroIcon's
        # centering already cooperate with this correctly since they read
        # real instance sizes at runtime. The <screen> tag's own size= is
        # such a reference-canvas value too (REF_W x REF_H, not the desktop
        # size) - see the skin % (...) call below.
        #
        # The subLabel widgets declared below are only ever visible for
        # the brief instant before the first real subtitle line arrives -
        # setSubtitlesText() (see its own comment) immediately re-resizes/
        # re-positions them itself using real desktop pixels
        # directly via .instance.move()/.resize(), which never goes
        # through Enigma2's skin-level resolution= scaling at all (that
        # only applies to attributes declared in the skin XML/string, not
        # later plain Python calls) - so this initial declaration doesn't
        # need to be pixel-perfect, just reasonable, and is kept in
        # 1280x720-reference terms like everything else here for
        # consistency.
        REF_W, REF_H = self.REF_W, self.REF_H
        dw = getDesktop(0).size().width()

        if self.subConfig['wrapping_enabled']:
            self.subLinesNum = 1
        else:
            self.subLinesNum = 4

        sub = self.subConfig
        if self.subLinesNum > 1 or 'transparent' != self.subConfig['background']:
            valign = "center"
        else:
            valign = sub['box_valign']
        subSkinPart = ' valign="%s" foregroundColor="%s" font="%s;%s" ' % (valign, sub['font_color'], sub['font'], sub['font_size'])
        if 'border' in sub:
            subSkinPart += ' borderColor="%s" borderWidth="%s" ' % (sub['border']['color'], sub['border']['width'])
        if 'shadow' in sub:
            subSkinPart += ' shadowColor="%s" shadowOffset="%s,%s" ' % (sub['shadow']['color'], sub['shadow']['xoffset'], sub['shadow']['yoffset'])
        subSkinPart += ' backgroundColor="%s" ' % (sub['background'])

        if self.subLinesNum > 1:
            subSkinPart += ' noWrap="1" '

        # placeholder-only geometry (see class comment above) - kept in
        # reference-space terms for consistency, actual position/size on
        # screen comes from setSubtitlesText() instead
        subX = 10
        subY = REF_H - sub['pos'] - sub['box_height']
        subW = REF_W - 20
        subBoxH = sub['box_height']
        subSkinPart = '<widget name="subLabel{0}" position="%d,%d" size="%d,%d" zPosition="1" halign="center" %s/>' % (subX, subY, subW, subBoxH, subSkinPart)
        subSkin = ''
        for idx in range(self.subLinesNum):
            subSkin += subSkinPart.format(idx + 1)
        # image subtitles: placed and sized in real pixels by updateGraphicSubtitles()
        for idx in range(self.GRAPHIC_SUB_RECTS):
            subSkin += '<widget name="subGraphic%d" position="0,0" size="1,1" zPosition="1" transparent="1" alphatest="blend" />' % (idx + 1)

        self.playbackBannerFile = "playback_banner.png"

        if dw < 800:
            # skin for SD
            self.playerSkinFolder = GetPlayerSkinDir('sd')
        else:
            self.playerSkinFolder = GetPlayerSkinDir(ConfigExtMoviePlayerBase().getPlayerSkinFolder())

        self.playerSkinPath = self.playerSkinFolder + "/playerskin.xml"

        printDBG("Player skin folder:" + self.playerSkinFolder)
        printDBG("Player skin file path:" + self.playerSkinPath)

        if os_path.exists(self.playerSkinPath):
            # read player skin xml file
            skinFile = open(self.playerSkinPath, 'r')
            skin = skinFile.read()
            skinFile.close()

            # printDBG("---------------------------------------")
            # printDBG(skin)
            # printDBG("---------------------------------------")
        else:
            skin = ""

        if len(skin) == 0:
            # use default skin in code
            skin = """
            <screen name="IPTVExtMoviePlayer"    position="center,center" size="%d,%d" resolution="1280,720" flags="wfNoBorder" backgroundColor="#FFFFFFFF" >
                    <widget name="pleaseWait"         noWrap="1" position="30,30"        size="500,36"    zPosition="3" transparent="0" foregroundColor="#E0E0E0"   backgroundColor="#40000000" font="Regular;24" halign="center"  valign="center"/>

                    <widget name="logoIcon"           position="140,30"        size="160,40"    zPosition="4"             transparent="1" alphatest="blend" />
                    <widget name="playbackInfoBaner"  position="0,0"           size="1280,177"  zPosition="2" pixmap="%s" />
                    <widget name="progressBar"        position="220,86"        size="840,7"     zPosition="5" pixmap="%s" transparent="1" borderWidth="1" borderColor="#888888" />
                    <widget name="bufferingCBar"      position="220,86"        size="840,7"     zPosition="4" pixmap="%s" transparent="1" borderWidth="1" borderColor="#888888" />
                    <widget name="bufferingBar"       position="220,86"        size="840,7"     zPosition="3" pixmap="%s" borderWidth="1" borderColor="#888888" />
                    <widget name="statusIcon"         position="150,70"        size="40,40"     zPosition="4"             transparent="1" alphatest="blend" />
                    <widget name="loopIcon"           position="150,110"       size="40,21"     zPosition="4"             transparent="1" alphatest="blend" />

                    <widget name="goToSeekPointer"    position="94,30"          size="150,60"  zPosition="8" pixmap="%s" transparent="1" alphatest="blend" />
                    <widget name="goToSeekLabel"      noWrap="1" position="94,30"         size="150,40"   zPosition="9" transparent="1" foregroundColor="white"     backgroundColor="#251f1f1f" font="Regular;24" halign="center" valign="center"/>
                    <widget name="infoBarTitle"       noWrap="1" position="220,50"        size="840,30"   zPosition="3" transparent="1" foregroundColor="white"     backgroundColor="#251f1f1f" font="Regular;24" halign="center" valign="center"/>
                    <widget name="currTimeLabel"      noWrap="1" position="220,100"       size="200,40"   zPosition="3" transparent="1" foregroundColor="#66ccff"   backgroundColor="#251f1f1f" font="Regular;30" halign="left"   valign="top"/>
                    <widget name="lengthTimeLabel"    noWrap="1" position="540,100"       size="200,40"   zPosition="3" transparent="1" foregroundColor="#999999"   backgroundColor="#251f1f1f" font="Regular;30" halign="center" valign="top"/>
                    <widget name="remainedLabel"      noWrap="1" position="860,100"       size="200,40"   zPosition="3" transparent="1" foregroundColor="#66ccff"   backgroundColor="#251f1f1f" font="Regular;30" halign="right"  valign="top"/>
                    <widget name="videoInfo"          noWrap="1" position="560,20"        size="500,30"   zPosition="3" transparent="1" foregroundColor="#999999"   backgroundColor="#251f1f1f" font="Regular;24" halign="right"  valign="top"/>
                    <widget name="playlistInfo"       noWrap="1" position="220,20"        size="330,30"   zPosition="3" transparent="1" foregroundColor="#999999"   backgroundColor="#251f1f1f" font="Regular;24" halign="left"   valign="top"/>

                    %s

                    <widget name="subSynchroIcon"     position="0,0"           size="180,66"  zPosition="4" transparent="1" alphatest="blend" />
                    <widget name="subSynchroLabel"    position="1,3"           size="135,50"  zPosition="5" transparent="1" foregroundColor="white"      backgroundColor="transparent" font="Regular;24" halign="center"  valign="center"/>

                    %s
            </screen>"""

        if self.clockFormat:
            if dw < 800:
                clockFontSize = self.skinSettings.get("clockFontSize_SD", 30)
            else:
                # clockFontSize_HD is the true 1280x720-reference value,
                # already correct as-is now that resolution="1280,720"
                # (see REF_W/REF_H comment above) makes Enigma2 scale it up
                # proportionally for real FHD/WQHD screens.
                # clockFontSize_FHD existed only as a manual, real-pixel
                # workaround for the missing resolution= scaling
                # (settings.json never even got a WQHD value either) - now
                # redundant, and would double-scale on top of Enigma2's own
                # scaling if still applied.
                clockFontSize = self.skinSettings.get("clockFontSize_HD", 30)

            self.playerClockPath = self.playerSkinFolder + "/playerclock.xml"

            printDBG("Player clock file path:" + self.playerClockPath)

            if os_path.exists(self.playerClockPath):
                # read player skin xml file
                clockFile = open(self.playerClockPath, 'r')
                clockWidget = clockFile.read()
                clockFile.close()

                # printDBG("---------------------------------------")
                # printDBG(clockWidget)
                # printDBG("---------------------------------------")

                clockWidget = clockWidget % clockFontSize
            else:
                clockWidget = ""
        else:
            clockWidget = ''

        # the screen's own size= is read by Enigma2 in the same units as
        # everything else on a resolution="1280,720" screen, i.e. it gets
        # scaled with the widgets. Handing it real desktop pixels there
        # (as the "sd" theme, which has no resolution=, still needs) made
        # the window 1.5x (FHD) / 2x (WQHD) bigger than the desktop: OpenATV
        # clamps a negative "center" offset to 0 and hides it, but skin
        # engines that don't (OpenViX/OpenBH) centre it at a negative
        # offset - infobar in the middle of the screen, left side cut off.
        self.skinUsesRefCanvas = 'resolution="' in skin
        if self.skinUsesRefCanvas:
            screenW, screenH = REF_W, REF_H
            scaledBars = self.SCALED_BAR_IMAGES.get(os_path.basename(os_path.normpath(self.playerSkinFolder)))
        else:
            screenW, screenH = dw, getDesktop(0).size().height()
            scaledBars = None

        # kept for initGuiComponentsPos(), which swaps in pre-scaled copies
        self.progressBarFiles = (
            self._progressBarPixmapPath("playback_progress", scaledBars, 0, dw),
            self._progressBarPixmapPath("playback_cbuff_progress", scaledBars, 1, dw),
            self._progressBarPixmapPath("playback_buff_progress", scaledBars, 2, dw),
        )
        skin = skin % (
            screenW,
            screenH,
            self.playerSkinFolder + "/playback_banner.png",
            self.progressBarFiles[0],
            self.progressBarFiles[1],
            self.progressBarFiles[2],
            self.playerSkinFolder + "/playback_pointer.png",
            clockWidget,
            subSkin
        )  # 00000000 bottom
        # added here, not in the playerskin.xml files: every player skin gets the panel of the INFO key
        skin = skin.replace('</screen>', PlayerInfoPanel.skinWidgets(1.0 if self.skinUsesRefCanvas else dw / float(self.REF_W)) + '</screen>')

        sub = None
        return skin

    STREAM_PROTO_LABELS = {'m3u8': 'HLS', 'em3u8': 'HLS', 'mpd': 'DASH', 'f4m': 'HDS', 'uds': 'HDS',
                           'rtmp': 'RTMP', 'rtsp': 'RTSP', 'mms': 'MMS', 'mmsh': 'MMS'}
    STREAM_CONTAINERS = ('mp4', 'm4v', 'mkv', 'webm', 'flv', 'ts', 'm2ts', 'avi', 'mov', 'wmv', 'mpg', 'mpeg', 'vob', 'divx', '3gp', 'ogv')

    def getStreamSourceUrl(self):
        # in buffering mode fileSRC is the local buffer file, the downloader has the source
        if self.downloader is not None:
            return strwithmeta(self.downloader.getUrl())
        return self.fileSRC

    def getLocalFilePath(self):
        # the file the player reads when it is one here: a download or the buffer file
        path = self.fileSRC
        if path.startswith('file://'):
            path = path[len('file://'):].replace('//', '/')
        return str(path) if '://' not in path and os_path.isfile(path) else ''

    def _getStreamTypeLabel(self, url=None):
        # short delivery type for the info bar ("HLS", "DASH", "MP4", ...)
        try:
            if url is None:
                url = self.getStreamSourceUrl()
            url = strwithmeta(url)
            proto = url.meta.get('iptv_proto', '')
            urlLower = url.lower()
            if proto == 'merge' or urlLower.startswith('merge://'):
                # separate audio/video streams: DASH renditions unless the
                # video part is itself an HLS playlist (a DASH rendition's
                # own mime=video/mp4 must not turn this into "MP4")
                videoUrl = url.meta.get('video_url', '')
                if videoUrl and self._getStreamTypeLabel(videoUrl) == 'HLS':
                    return 'HLS'
                return 'DASH'
            # rstrip: KVS sites (most of hostxxx) serve .../get_file/.../123.mp4/?rnd=...
            path = urlLower.split('?', 1)[0].split('#', 1)[0].split('|', 1)[0].rstrip('/')
            if proto in self.STREAM_PROTO_LABELS:
                return self.STREAM_PROTO_LABELS[proto]
            if path.endswith('.m3u8') or 'protocol=hls' in urlLower:
                return 'HLS'
            if path.endswith('.mpd'):
                return 'DASH'
            for scheme in ('rtmp', 'rtsp', 'mms'):
                if urlLower.startswith(scheme):
                    return self.STREAM_PROTO_LABELS.get(scheme, scheme.upper())
            ext = url.meta.get('iptv_format', '') or path.rsplit('.', 1)[-1]
            if ext in self.STREAM_CONTAINERS:
                return ext.upper()
            # playlist named only further on, e.g. proxied
            # .../m3u8-proxy?url=https://cdn/x/index.m3u8&headers=...
            if re.search(r'\.m3u8(?=$|[?&#/|;,])', urlLower):
                return 'HLS'
            if re.search(r'\.mpd(?=$|[?&#/|;,])', urlLower):
                return 'DASH'
            # no file extension (e.g. googlevideo .../videoplayback?...) -
            # the container may still be named by a mime= query parameter
            mime = re.search(r'[?&]mime=video(?:/|%2f)([a-z0-9.+-]+)', urlLower)
            if mime:
                ext = {'x-flv': 'flv', 'mp2t': 'ts', '3gpp': '3gp'}.get(mime.group(1), mime.group(1))
                if ext in self.STREAM_CONTAINERS:
                    return ext.upper()
            # ... or by a file= query parameter (KVS remote storage redirect:
            # .../remote_control.php?time=..&file=%2Fvideos%2F..%2F123_720p.mp4&cv3=..)
            fileParam = re.search(r'[?&](?:file|filename)=([^&#|]+)', urlLower)
            if fileParam:
                ext = fileParam.group(1).replace('%2e', '.').replace('%2f', '/').replace('%3f', '?')
                ext = ext.split('?', 1)[0].rstrip('/').rsplit('.', 1)[-1]
                if ext in self.STREAM_CONTAINERS:
                    return ext.upper()
        except Exception:
            printExc(WarnOnly=True)
        return ''

    def _progressBarPixmapPath(self, name, scaledBars, idx, dw):
        # progressBar/bufferingCBar/bufferingBar are eSlider widgets: the
        # filled part is computed from the widget's (resolution="1280,720"-
        # scaled) size, but the pixmap is blitted at its native size and
        # only clipped to it. With the 840px-wide 1280x720 images the fill
        # therefore stopped at 840/1260 = 2/3 of the bar on FHD (1/3 on
        # WQHD). SCALED_BAR_IMAGES points every non-"sd" theme at
        # pre-scaled _1920/_2560 copies (full-width gradients must match
        # the bar width, not just cover it); anything else falls back to
        # the theme's own image, which initGuiComponentsPos() replaces by a
        # copy resized once with PIL (_prescaledPixmap).
        if scaledBars:
            path = GetPlayerSkinDir("_scaled/%s_%d.png" % (scaledBars[idx], dw))
            if os_path.exists(path):
                return path
        return "%s/%s.png" % (self.playerSkinFolder, name)

    def _prescaledPixmap(self, widgetName, path):
        # Enigma2 draws a pixmap at its native size, so on FHD/WQHD the
        # images of the 1280x720 reference skin stayed small inside their
        # resolution="1280,720"-scaled widgets. The scale flag
        # (setScale/setPixmapScale) makes every redraw a scaled blit, which
        # froze the OSD after a few pause/play presses on some boxes
        # (Octagon SF3038) while the stream kept running - so the PNG is
        # resized once with PIL and then drawn 1:1. None = keep the native
        # pixmap (HD, "sd" theme, image already fits, no PIL).
        if Image is None or not self.skinUsesRefCanvas or getDesktop(0).size().width() == self.REF_W:
            return None
        try:
            size = self[widgetName].instance.size()
            w, h = size.width(), size.height()
            if w <= 0 or h <= 0:
                return None
            theme = os_path.basename(os_path.dirname(path))
            name = os_path.splitext(os_path.basename(path))[0]
            outPath = GetTmpDir('e2i_playerskin_%s_%s_%dx%d_%d.png' % (theme, name, w, h, int(os_path.getmtime(path))))
            if not os_path.exists(outPath):
                with Image.open(path) as img:
                    if img.size == (w, h):
                        return None
                    # written under a temporary name first: a cut-off file
                    # (full disk, power loss) must not be found as finished
                    img.convert('RGBA').resize((w, h), Image.LANCZOS).save(outPath + '.part', format='png')
                os_rename(outPath + '.part', outPath)
            return LoadPixmap(outPath)
        except Exception:
            printExc()
        return None

    def _prescaleSkinPixmaps(self):
        # see _prescaledPixmap() - icons are swapped in their dicts (set on
        # status changes later), the skin-loaded images directly
        folder = self.playerSkinFolder + "/"
        statusIcons = self.playback['statusIcons']
        loopIcons = self.playback['loopIcons']
        logoFile = "playback_gstreamer_logo" if 'gstplayer' == self.player else "playback_ffmpeg_logo"
        for widgetName, icons, key, fileName in (('statusIcon', statusIcons, 'Play', "playback_a_play"),
                                                 ('statusIcon', statusIcons, 'Pause', "playback_a_pause"),
                                                 ('statusIcon', statusIcons, 'FastForward', "playback_a_ff"),
                                                 ('loopIcon', loopIcons, 'On', "playback_loop_on"),
                                                 ('loopIcon', loopIcons, 'Off', "playback_loop_off"),
                                                 ('logoIcon', self.playback, 'logoIcon', logoFile),
                                                 ('subSynchroIcon', self.subHandler['synchro'], 'icon', "sub_synchro")):
            pixmap = self._prescaledPixmap(widgetName, folder + fileName + ".png")
            if pixmap:
                icons[key] = pixmap
        statusIcons['SlowMotion'] = statusIcons['FastForward']

        for widgetName, path in (('playbackInfoBaner', folder + "playback_banner.png"),
                                 ('goToSeekPointer', folder + "playback_pointer.png"),
                                 ('progressBar', self.progressBarFiles[0]),
                                 ('bufferingCBar', self.progressBarFiles[1]),
                                 ('bufferingBar', self.progressBarFiles[2])):
            pixmap = self._prescaledPixmap(widgetName, path)
            if pixmap:
                self[widgetName].instance.setPixmap(pixmap)

    def _subtitleScale(self):
        # setSubtitlesText()/runConfigMoviePlayerCallback()'s subtitle
        # resize block/setSubOffsetFromInfoBar() all position subtitles
        # via direct eLabel.instance.move()/.resize()/.setFont() calls
        # computed from real getDesktop(0) pixels - unlike the rest of
        # this screen, these never go through Enigma2's skin-level
        # resolution="1280,720" scaling at all, since they're plain
        # Python calls acting on an already-built instance, not
        # skin-declared attributes Enigma2 itself scales. Without their
        # own scale factor, subtitles would stay a constant absolute size
        # while the rest of the OSD grows with resolution - shrinking
        # relative to the screen at FHD/WQHD. Same 1280-wide reference as
        # everything else here.
        return getDesktop(0).size().width() / float(self.REF_W)

    def _effectiveSubLineHeight(self, scale):
        # user-configured line_height can end up no taller than font_size
        # itself - real fonts need noticeably more vertical room than
        # their point size for descenders (e.g. "g") to not get clipped,
        # independent of the scale factor (this floor is computed
        # consistently in real, already-scaled pixels wherever a line
        # height is needed). 1.3x is a common, conservative
        # line-height-to-font-size ratio - only ever makes the line taller
        # than the user's own setting, never shrinks a deliberately
        # generous one.
        lineHeight = int(self.subConfig['line_height'] * scale)
        minHeight = int(self.subConfig['font_size'] * scale * 1.3)
        return max(lineHeight, minHeight)

    def getSkinSettings(self):
        printDBG("iptvextmovieplayer.getSkinSetting")

        if getDesktop(0).size().width() < 800:
            # skin for SD
            self.playerSkinFolder = GetPlayerSkinDir('sd')
        else:
            self.playerSkinFolder = GetPlayerSkinDir(ConfigExtMoviePlayerBase().getPlayerSkinFolder())

        settingsPath = self.playerSkinFolder + "/settings.json"

        try:
            if os_path.exists(settingsPath):
                # read player skin xml file
                settingsFile = open(settingsPath, 'r')
                response = settingsFile.read()
                settingsFile.close()

                # printDBG("---------------------------------------")
                # printDBG(response)
                # printDBG("---------------------------------------")

                return json.loads(response)

            return {}
        except Exception:
            printExc()
            return {}

    def __init__(self, session, filesrcLocation, FileName, lastPosition=None, player='eplayer', additionalParams={}):
        self.configObj = ConfigExtMoviePlayerBase()
        self.subConfig = self.configObj.getSubtitleFontSettings()
        self.clockFormat = self.configObj.getInfoBannerrClockFormat()
        self.skinSettings = self.getSkinSettings()
        self.skin = self.__prepareSkin()
        Screen.__init__(self, session)
        self.skinName = skinchrome.forceInternalSkinName("IPTVExtMoviePlayer")

        self.player = player
        if 'gstplayer' == self.player:
            self.playerName = _("external gstplayer")
            self.gstAdditionalParams = {}
            self.gstAdditionalParams['download-buffer-path'] = additionalParams.get('download-buffer-path', '')  # File template to store temporary files in, should contain directory and XXXXXX
            self.gstAdditionalParams['ring-buffer-max-size'] = additionalParams.get('ring-buffer-max-size', 0)  # in MB
            self.gstAdditionalParams['buffer-duration'] = additionalParams.get('buffer-duration', -1)  # in s
            self.gstAdditionalParams['buffer-size'] = additionalParams.get('buffer-size', 0)  # in KB
            self.gstAdditionalParams['file-download-timeout'] = additionalParams.get('file-download-timeout', 0)  # in MS
            self.gstAdditionalParams['file-download-live'] = additionalParams.get('file-download-live', False)  # True or False
        else:
            self.playerName = _("external eplayer3")

        self.extAdditionalParams = {}
        self.availableDataSizeCorrection = 0
        self.totalDataSizeCorrection = 0
        if 'moov_atom_info' in additionalParams:
            if additionalParams['moov_atom_info']['offset'] == 0:
                self.availableDataSizeCorrection = additionalParams['moov_atom_info']['size']
                self.totalDataSizeCorrection = self.availableDataSizeCorrection
            else:
                self.extAdditionalParams['moov_atom_offset'] = additionalParams['moov_atom_info']['offset']
                self.extAdditionalParams['moov_atom_size'] = additionalParams['moov_atom_info']['size']
                self.extAdditionalParams['moov_atom_file'] = additionalParams['moov_atom_info']['file']
                self.totalDataSizeCorrection = self.extAdditionalParams['moov_atom_size']

        self.session.nav.playService(None)  # current service must be None to give free access to DVB Audio and Video Sinks
        self.fileSRC = strwithmeta(filesrcLocation)
        self.title = FileName
        self.hostName = additionalParams.get('host_name', '')
        # "Select link automatically" has further links: an error before the first second of playback
        # closes the player without a message, E2iPlayer goes on with the next link
        self.quietStartErrors = additionalParams.get('quiet_start_errors', False)
        if lastPosition:
            self.lastPosition = lastPosition
        else:
            self.lastPosition = 0
        self.downloader = additionalParams.get('downloader', None)
        self.isDownladManagerAvailable = additionalParams.get('download_manager_available', False)
        self.externalSubTracks = additionalParams.get('external_sub_tracks', [])  # [{'title':'', 'lang':'', 'url':''}, ...]
        self.refreshCmd = additionalParams.get('iptv_refresh_cmd', '')
        self.refreshCmdConsole = None
        self.extLinkProv = {}
        self.extLinkProv['console'] = None
        self.extLinkProv['close_conn'] = None
        self.extLinkProv['data_conn'] = None
        self.extLinkProv['data'] = ''
        self.extLinkProv['started'] = False

        self.iframeParams = {}
        self.iframeParams['console'] = None
        self.iframeParams['show_iframe'] = additionalParams.get('show_iframe', False)
        self.iframeParams['iframe_file_start'] = additionalParams.get('iframe_file_start', '')
        self.iframeParams['iframe_file_end'] = additionalParams.get('iframe_file_end', '')
        self.iframeParams['iframe_continue'] = additionalParams.get('iframe_continue', False)

        # CH+/CH- (and >|/|<) close the player with 'zap_next'/'zap_prev', the list (E2iPlayerWidget.zapToItem)
        # then starts the next/previous playable item; only set by the list, not for the download manager
        self.zapEnabled = additionalParams.get('zap_enabled', False)
        # a run of the autoplay sequencer of the list (tools/listselection.buildPlaylist): "Playlist 3/10" in the
        # infobar and "Show playlist" in the MENU, whose entries close the player like a zap ('zap_to', ...)
        self.playlist = additionalParams.get('playlist') if self.zapEnabled else None

        # screensaver over audio-only playback (iptvscreensaver.py), see _screenSaverWanted()
        from Plugins.Extensions.IPTVPlayer.components.iptvscreensaver import IPTVAudioScreenSaver
        self.screenSaverAudioItem = additionalParams.get('audio_item', False)
        self.screenSaver = IPTVAudioScreenSaver(self, [additionalParams.get('cover_path', ''), additionalParams.get('logo_path', '')])

        printDBG('IPTVExtMoviePlayer.__init__ lastPosition[%r]' % self.lastPosition)

        self.extPlayerCmddDispatcher = ExtPlayerCommandsDispatcher(self)

        self["actions"] = ActionMap(['IPTVAlternateVideoPlayer', 'MoviePlayerActions', 'MediaPlayerActions', 'MediaPlayerSeekActions', 'WizardActions'],
            {
                "leavePlayer": self.key_stop,
                'play': self.key_play,
                'pause': self.key_pause,
                'exit': self.key_exit,
                'back': self.key_exit,
                'info': self.key_info,
                'seekdef:1': self.key_seek1,
                'seekdef:3': self.key_seek3,
                'seekdef:4': self.key_seek4,
                'seekdef:6': self.key_seek6,
                'seekdef:7': self.key_seek7,
                'seekdef:9': self.key_seek9,
                'seekFwd': self.key_seekFwd,
                'seekBack': self.key_seekBack,
                'left_press': self.key_left_press,
                'left_repeat': self.key_left_repeat,
                'rigth_press': self.key_rigth_press,
                'rigth_repeat': self.key_rigth_repeat,

                'up_press': self.key_up_press,
                'up_repeat': self.key_up_repeat,
                'down_press': self.key_down_press,
                'down_repeat': self.key_down_repeat,

                'ok': self.key_ok,
                'subtitles': self.key_subtitles,
                'audio': self.key_audio,
                'videooptions': self.key_videooption,
                'menu': self.key_menu,
                'loop': self.key_loop,
                'record': self.key_record,
                'zap_next': self.key_zap_next,
                'zap_prev': self.key_zap_prev,
            }, -1)

        self.onClose.append(self.__onClose)
        self.onShow.append(self.onStart)
        self.onLayoutFinish.append(self.fixWindowGeometry)
        self.onLayoutFinish.append(self.initPleaseWaitBox)
        # self.onLayoutFinish.append(self.onStart)

        self.console = None

        self.isClosing = False
        self.responseData = ""

        # playback info
        # GUI
        self.updateInfoTimer = eTimer()
        self.updateInfoTimer_conn = eConnectCallback(self.updateInfoTimer.timeout, self.updateInfo)

        # playback info bar gui elements
        self['logoIcon'] = Cover3()
        self['playbackInfoBaner'] = Cover3()
        self['statusIcon'] = Cover3()
        self['loopIcon'] = Cover3()
        self['progressBar'] = ProgressBar()
        self['bufferingCBar'] = ProgressBar()
        self['bufferingBar'] = ProgressBar()
        self['goToSeekPointer'] = Cover3()
        self['infoBarTitle'] = Label(self.title)
        self['goToSeekLabel'] = Label("0:00:00")
        self['currTimeLabel'] = Label("0:00:00")
        self['remainedLabel'] = Label("-0:00:00")
        self['lengthTimeLabel'] = Label("0:00:00")
        addLcdSources(self, self.title, currTime="0:00:00", remained="-0:00:00", length="0:00:00", percent="0%",
                      currTimeHM="0:00", remainedHM="0:00", lengthHM="0:00", remainedMin="0", remainedShort="", shortTimes=True, coverFile=additionalParams.get('cover_path'))
        self.lcdLastState = None
        self.lcdLastLength = 0
        self.lcdLengthGrowth = 0
        self['videoInfo'] = Label(" ")
        # empty without a playlist. Every playerskin.xml must declare it: initGuiComponentsPos() moves each
        # widget of the infobar (guiElemNames) and needs its instance
        self['playlistInfo'] = Label(listselection.playlistInfoText(self.playlist, _('Playlist'), _('marked'), _('shuffled'), _('reversed')))
        if self.clockFormat:
            self['clockTime'] = Label(" ")
        self['pleaseWait'] = Label(_("Opening. Please wait..."))

        # for subtitles
        self.infoBanerOffsetY = -1
        for idx in range(self.subLinesNum):
            # printf('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ' % ('subLabel%d'%(idx+1)))
            self['subLabel%d' % (idx + 1)] = Label(" ")
        self.hideSubtitles()
        self.subHandler = {}
        self.subHandler['current_sub_time_ms'] = -1
        self.subHandler['handler'] = IPTVSubtitlesHandler()
        self.subHandler['embedded_handler'] = IPTVEmbeddedSubtitlesHandler()
        self.subHandler['handler_type'] = 'embedded_handler'
        self.subHandler['enabled'] = False
        self.subHandler['timer'] = eTimer()
        self.subHandler['timer_conn'] = eConnectCallback(self.subHandler['timer'].timeout, self.updatSubtitlesTime)
        self.subHandler['latach_time'] = -1
        self.subHandler['last_time'] = -1
        self.subHandler['marker'] = None
        self.subHandler['synchro'] = {'visible': False, 'guiElemNames': ['subSynchroLabel', 'subSynchroIcon'], 'icon': None}
        self.subHandler['pos_y_offset'] = 0
        # image subtitles, 'enabled' when exteplayer3 runs with -G
        graphicDir = GetTmpDir('e2i_graphic_subs')
        self.graphicSubs = {'enabled': False, 'dir': graphicDir, 'handler': IPTVGraphicSubtitlesHandler(graphicDir), 'marker': None}
        for idx in range(self.GRAPHIC_SUB_RECTS):
            self['subGraphic%d' % (idx + 1)] = Cover3()
            self['subGraphic%d' % (idx + 1)].hide()
        self['subSynchroLabel'] = Label("0.0s")
        self['subSynchroIcon'] = Cover3()
        try:
            self.subHandler['synchro']['icon'] = LoadPixmap(self.playerSkinFolder + "/sub_synchro.png")
        except Exception:
            printExc()
        self.hideSubSynchroControl()

        # VIDEO options
        self.defVideoOptions = {'aspect': None, 'aspect_choices': [], 'policy': None, 'policy_choices': [], 'policy2': None, 'policy2_choices': [], 'videomode': additionalParams.get('defaul_videomode', None), 'videomode_choices': GetE2VideoModeChoices()}
        self.videoOptSetters = {'aspect': SetE2VideoAspect, 'policy': SetE2VideoPolicy, 'policy2': SetE2VideoPolicy}
        self.currVideoOptions = {'aspect': None, 'policy': None, 'policy2': None, 'videomode': None}

        # AUDIO options
        self.defAudioOptions = {'ac3': None, 'aac': None}

        # meta data
        self.metaHandler = IPTVMovieMetaDataHandler(self.hostName, self.title, self.fileSRC)

        # goto seek  timer
        self.playback['GoToSeekTimer'] = eTimer()
        self.playback['GoToSeekTimer_conn'] = eConnectCallback(self.playback['GoToSeekTimer'].timeout, self.doGoToSeek)

        # notice "only loaded up to ..." for a skip key cut at the end of the buffered part
        self.seekLimitNotice = {'until': 0, 'timer': eTimer()}
        self.seekLimitNotice['timer_conn'] = eConnectCallback(self.seekLimitNotice['timer'].timeout, self.hideSeekLimitNotice)

        self.playback.update({
            "CurrentTime": 0,
            "BufferCTime": 0,
            "ConfirmedCTime": 0,
            "BufferFill": 0,
            "Length": 0,
            "LengthFromPlayerReceived": False,
            "GoToSeekTime": 0,
            "StartGoToSeekTime": 0,
            "GoToSeeking": False,
            "IsLive": False,
            "IsLoop": False,
            "Status": None,
            "VideoTrack": {},
            "AudioTrack": {},
            "AudioTracks": [],
            "SubtitleTrack": {},
            "SubtitleTracks": [],
            # for other plugins: the dict is a class attribute and keeps its values after the player closed, Active
            # tells. IsLive is only what the player reports, LiveDetected what the LCD shows as live.
            "Active": True,
            "Title": StripColorCodes(self.title),
            "CoverFile": self.lcdCoverFile,
            "LiveDetected": False
        })

        # load pixmaps for statusIcon
        self.playback['loopIcons'] = {'On': None, 'Off': None}
        self.playback['statusIcons'] = {'Play': None, 'Pause': None, 'FastForward': None, 'SlowMotion': None}
        try:
            self.playback['statusIcons']['Play'] = LoadPixmap(self.playerSkinFolder + "/playback_a_play.png")
            self.playback['statusIcons']['Pause'] = LoadPixmap(self.playerSkinFolder + "/playback_a_pause.png")
            self.playback['statusIcons']['FastForward'] = LoadPixmap(self.playerSkinFolder + "/playback_a_ff.png")
            self.playback['statusIcons']['SlowMotion'] = self.playback['statusIcons']['FastForward']
            if 'gstplayer' == self.player:
                self.playback['logoIcon'] = LoadPixmap(self.playerSkinFolder + "/playback_gstreamer_logo.png")
            else:
                self.playback['logoIcon'] = LoadPixmap(self.playerSkinFolder + "/playback_ffmpeg_logo.png")
            self.playback['loopIcons']['On'] = LoadPixmap(self.playerSkinFolder + "/playback_loop_on.png")
            self.playback['loopIcons']['Off'] = LoadPixmap(self.playerSkinFolder + "/playback_loop_off.png")
        except Exception:
            printExc()

        # show hide info bar functionality
        self.goToSeekRepeatCount = 0
        self.goToSeekStep = 0
        self.playbackInfoBar = {'visible': False, 'blocked': False, 'guiElemNames': ['playbackInfoBaner', 'progressBar', 'bufferingCBar', 'bufferingBar', 'goToSeekPointer', 'goToSeekLabel', 'infoBarTitle', 'currTimeLabel', 'remainedLabel', 'lengthTimeLabel', 'videoInfo', 'playlistInfo', 'statusIcon', 'loopIcon', 'logoIcon']}
        if self.clockFormat:
            self.playbackInfoBar['guiElemNames'].append('clockTime')
            self.playbackInfoBar['clock_timer'] = eTimer()
            self.playbackInfoBar['clock_timer_conn'] = eConnectCallback(self.playbackInfoBar['clock_timer'].timeout, self.updateClock)
        self.playbackInfoBar['timer'] = eTimer()
        self.playbackInfoBar['timer_conn'] = eConnectCallback(self.playbackInfoBar['timer'].timeout, self.hidePlaybackInfoBar)

        self.isStarted = False
        self.hidePlaybackInfoBar()

        self.waitEOSAbortedFix = {'EOSaborted_received': False, 'poll_received': False, 'timer': None}
        self.waitEOSAbortedFix['timer'] = eTimer()
        self.waitEOSAbortedFix['timer_conn'] = eConnectCallback(self.waitEOSAbortedFix['timer'].timeout, self.waitEOSAbortedFixTimeoutCallback)

        self.waitCloseFix = {'waiting': False}
        self.waitCloseFix['timer'] = eTimer()
        self.waitCloseFix['timer_conn'] = eConnectCallback(self.waitCloseFix['timer'].timeout, self.waitCloseTimeoutCallback)

        self.closeRequestedByUser = None
        self.playerBinaryInfo = {'version': None, 'data': ''}
        self.messageQueue = []
        self.underMessage = False

        try:
            self.autoHideTime = 1000 * int(self.configObj.getInfoBarTimeout())
        except Exception:
            self.autoHideTime = 1000

        # INFO: the panel over the running video
        self.infoPanel = PlayerInfoPanel(self, additionalParams)

        self.fatalErrorOccurs = False
        self.delayedClosure = None
        self.childWindowsCount = 0

        self.workconsole = None
        # we will set movie player config at first use of subtitles
        # to fix problems with small subtitles at first run with custom
        # exteplayer skin
        self.setMoviePlayerConfig = True
        self.clipLength = None

    def _getChoiceBoxHeight(self, numItems):
        # shared by every plain IPTVChoiceBoxWidget popup in this class
        # (Menu/Video-Option/Video-Option-Wert/Video-Modus/Audiospur/
        # Untertitelspur, all chrome=True) - same formula/reasoning as
        # iptvplayerwidget.py's own
        # _getMoviePlayerPickerHeight()/_getLinkPickerHeight(): IPTVRadioButtonList's
        # (IPTVMainNavigatorList's) real per-tier item heights (35/40/55),
        # +146 = the footerMargin passed below (136, list's fixed y=66 +
        # 64px footer bar + 10px breathing buffer)
        itemH, scale = skinchrome.tierRowHeight(35, 40, 55)
        return int(numItems * itemH / scale) + 146

    def showMenuOptions(self):
        printDBG("showMenuOptions")
        options = []
        options.append(IPTVChoiceBoxItem(_("Configuration"), "", "menu"))
        options.append(IPTVChoiceBoxItem(_("Subtitles"), "", "subtitles"))
        if len(self.playback['AudioTracks']):
            options.append(IPTVChoiceBoxItem(_("Audio tracks"), "", "audio_tracks"))
        options.append(IPTVChoiceBoxItem(_("Video options"), "", "video_options"))
        if self.playlist:
            options.append(IPTVChoiceBoxItem(_("Show playlist"), "", "playlist"))

        if self.isDownladManagerAvailable and self.downloader:
            options.append(IPTVChoiceBoxItem(_("Stop playback with buffer save"), "", "close_with_buffer_save"))

        self.openChild(boundFunction(self.childClosed, self.showMenuOptionsCallback), IPTVChoiceBoxWidget, {'width': 500, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': 0, 'title': _("Menu"), 'options': options, 'chrome': True, 'footerMargin': 136})

    def showMenuOptionsCallback(self, ret=None):
        printDBG("showMenuOptionsCallback ret[%r]" % [ret])
        if not isinstance(ret, IPTVChoiceBoxItem):
            return

        if "menu" == ret.privateData:
            self.runConfigMoviePlayer()
        elif "subtitles" == ret.privateData:
            self.selectSubtitle()
        elif "audio_tracks" == ret.privateData:
            self.selectAudioTrack()
        elif "video_options" == ret.privateData:
            self.selectVideoOptions()
        elif "playlist" == ret.privateData:
            self.showPlaylist()
        elif "close_with_buffer_save" == ret.privateData:
            self.key_stop("save_buffer")

    def showPlaylist(self):
        # the rows of the sequencer's run in play order over the video (playback goes on): the current one
        # preselected, the played ones ticked; OK on another one closes the player like a zap to it
        if not self.playlist:
            return
        options = []
        for pos, entry in enumerate(self.playlist['entries']):
            item = IPTVChoiceBoxItem(entry['title'], "", entry, used=entry.get('played', False))
            if pos == self.playlist['current']:
                item.type = IPTVChoiceBoxItem.TYPE_ON
            options.append(item)
        title = self['playlistInfo'].getText() or _('Playlist')
        self.openChild(boundFunction(self.childClosed, self.showPlaylistCallback), IPTVChoiceBoxWidget, {'width': 800, 'height': self._getChoiceBoxHeight(min(len(options), 10)), 'current_idx': self.playlist['current'], 'title': title, 'options': options, 'list_class': IPTVPlaylistChoiceBoxList, 'chrome': True, 'footerMargin': 136})

    def showPlaylistCallback(self, ret=None):
        printDBG("showPlaylistCallback ret[%r]" % [ret])
        if not isinstance(ret, IPTVChoiceBoxItem) or not isinstance(ret.privateData, dict) or IPTVChoiceBoxItem.TYPE_ON == ret.type:
            return
        if self.zapEnabled and not self.isClosing:
            self.key_stop(listselection.zapToAnswer(ret.privateData))

    def runConfigMoviePlayer(self):
        printDBG("runConfigMoviePlayerCallback")
        self.openChild(boundFunction(self.childClosed, self.runConfigMoviePlayerCallback), ConfigExtMoviePlayer, True)

    def runConfigMoviePlayerCallback(self, confgiChanged=False):
        printDBG("runConfigMoviePlayerCallback confgiChanged[%s]" % confgiChanged)
        if not confgiChanged:
            return

        # change subtitles settings
        prevSub = self.subConfig
        self.subConfig = self.configObj.getSubtitleFontSettings()
        sub = self.subConfig

        scale = self._subtitleScale()
        for idx in range(self.subLinesNum):
            subLabel = "subLabel%d" % (idx + 1)
            self[subLabel].instance.setFont(gFont(sub['font'], int(sub['font_size'] * scale)))
            self[subLabel].instance.setForegroundColor(parseColor(sub['font_color']))
            self[subLabel].instance.setBackgroundColor(parseColor(sub['background']))

            if 'border' in sub:
                self[subLabel].instance.setBorderColor(parseColor(sub['border']['color']))
                self[subLabel].instance.setBorderWidth(sub['border']['width'])
            else:
                try:
                    tmp = dir(eLabel)
                    if 'setBorderColor' in tmp:
                        self[subLabel].instance.setBorderWidth(0)
                except Exception:
                    printExc()

            if 'shadow' in sub:
                self[subLabel].instance.setShadowColor(parseColor(sub['shadow']['color']))
                self[subLabel].instance.setShadowOffset(ePoint(sub['shadow']['xoffset'], sub['shadow']['yoffset']))
            elif 'shadow' in prevSub:
                self[subLabel].instance.setShadowOffset(ePoint(0, 0))
                self[subLabel].instance.setShadowColor(gRGB())  # parseColor("#ff111111") )

            if self.subLinesNum > 1 or 'transparent' != self.subConfig['background']:
                self[subLabel].instance.setVAlign(1)
            else:
                try:
                    valignMap = {'bottom': 2, 'center': 1, 'top': 0}
                    self[subLabel].instance.setVAlign(valignMap.get(sub['box_valign'], 2))

                    scaledBoxH = max(int(sub['box_height'] * scale), int(sub['font_size'] * scale * 1.3))
                    self[subLabel].instance.resize(eSize(getDesktop(0).size().width() - 20, scaledBoxH))
                    self[subLabel].resize(eSize(getDesktop(0).size().width() - 20, scaledBoxH))
                    self[subLabel].move(ePoint(10, getDesktop(0).size().height() - int(sub['pos'] * scale) - scaledBoxH))
                    self[subLabel].instance.move(ePoint(10, getDesktop(0).size().height() - int(sub['pos'] * scale) - scaledBoxH))
                except Exception:
                    printExc()
            self.setSubtitlesText(" ", False)
        self.setSubOffsetFromInfoBar()
        if -1 != self.subHandler['current_sub_time_ms']:
            self.updateSubtitles(self.subHandler['current_sub_time_ms'], True)
        else:
            self.setSubtitlesText("", False)
            self.hideSubtitles()
        sub = None

        # set video options
        videoOptionChange = False
        videoOptions = ['aspect', 'policy', 'policy2']
        playerDefOptions = self.configObj.getDefaultPlayerVideoOptions()
        for opt in videoOptions:
            playerVal = playerDefOptions[opt]
            metaVal = self.metaHandler.getVideoOption(opt)
            currVal = self.currVideoOptions[opt]
            defVal = self.defVideoOptions[opt]

            printDBG(">>>>>>>>>>>>> 0 [%s]" % (metaVal))
            if None is metaVal:
                printDBG(">>>>>>>>>>>>> A [%s] [%s]" % (currVal, playerVal))
                if currVal != playerVal:
                    printDBG(">>>>>>>>>>>>> B")
                    if None is playerVal:
                        self.currVideoOptions[opt] = defVal
                    else:
                        self.currVideoOptions[opt] = playerVal
                    videoOptionChange = True

        if videoOptionChange:
            self.applyVideoOptions(self.currVideoOptions)

        # set auto hide options
        try:
            self.autoHideTime = 1000 * int(self.configObj.getInfoBarTimeout())
        except Exception:
            self.autoHideTime = 1000

    def getE2AudioOptions(self):
        defAudioOptions = {
            'ac3': GetE2AudioCodecMixOption('ac3'),
            'aac': GetE2AudioCodecMixOption('aac'),
        }
        printDBG(">>>>>>>>>>>>>>>>>>>>> getE2AudioOptions[%s]" % defAudioOptions)
        return defAudioOptions

    def getE2VideoOptions(self):
        defVideoOptions = {
            "aspect": GetE2VideoAspect(),
            "aspect_choices": GetE2VideoAspectChoices(),
            "policy": GetE2VideoPolicy(),
            "policy_choices": GetE2VideoPolicyChoices(),
            "policy2": GetE2VideoPolicy("2"),
            "policy2_choices": GetE2VideoPolicyChoices(),
            "active": None
        }

        printDBG(">>>>>>>>>>>>>>>>>>>>> getE2VideoOptions[%s]" % defVideoOptions)
        return defVideoOptions

    def applyVideoOptions(self, newOptions):
        printDBG("applyVideoOptions newOptions[%s] ")
        options = ['aspect', 'policy', 'policy2']
        for opt in options:
            val = newOptions.get(opt, None)
            if None is not val:
                self.videoOptSetters[opt](val)

    def selectVideoOptions(self):
        printDBG("selectVideoOptions")
        options = []
        currIdx = 0
        optionsTab = [{'title': _('Video policy'), 'name': 'policy'}, {'title': _('Video policy for 4:3'), 'name': 'policy2'}, {'title': _('Aspect'), 'name': 'aspect'}, {'title': _('Video mode'), 'name': 'videomode'}]
        for option in optionsTab:
            if len(self.defVideoOptions[option['name'] + '_choices']) < 2:
                continue
            if None is self.defVideoOptions[option['name']]:
                continue
            if self.defVideoOptions['active'] == option['name']:
                currIdx = len(options)
            options.append(IPTVChoiceBoxItem(option['title'], "", option["name"]))

        if len(options):
            self.openChild(boundFunction(self.childClosed, self.selectVideoOptionsCallback), IPTVChoiceBoxWidget, {'width': 500, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': currIdx, 'title': _("Select video option"), 'options': options, 'chrome': True, 'footerMargin': 136})

    def selectVideoOptionsCallback(self, ret=None):
        printDBG("selectVideoOptionsCallback ret[%r]" % [ret])
        if not isinstance(ret, IPTVChoiceBoxItem):
            return
        options = []
        currIdx = 0

        option = ret.privateData
        self.defVideoOptions['active'] = option

        choices = self.defVideoOptions['%s_choices' % option]
        currValue = self.currVideoOptions[option]
        if None is currValue:
            currValue = self.defVideoOptions[option]

        if option != 'videomode':
            for item in choices:
                choiceItem = IPTVChoiceBoxItem(_(item), "", item)
                if item == currValue:
                    currIdx = len(options)
                    choiceItem.type = IPTVChoiceBoxItem.TYPE_ON
                else:
                    choiceItem.type = IPTVChoiceBoxItem.TYPE_OFF
                options.append(choiceItem)
            self.openChild(boundFunction(self.childClosed, self.selectVideoOptionCallback), IPTVChoiceBoxWidget, {'selection_changed': self.videoOptionSelectionChanged, 'width': 500, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': currIdx, 'title': _("Select %s") % ret.name, 'options': options, 'chrome': True, 'footerMargin': 136})
        else:
            printDBG('choices %s' % (choices))
            filteredChoices = []
            for item in choices:
                if item in [self.defVideoOptions['videomode'], self.currVideoOptions['videomode']] or item.startswith('1080') or item.startswith('2160'):
                    filteredChoices.append(item)

            for idx in range(len(filteredChoices)):
                item = IPTVChoiceBoxItem(_(filteredChoices[idx]), "", filteredChoices[idx])
                if filteredChoices[idx] == currValue:
                    item.type = IPTVChoiceBoxItem.TYPE_ON
                    currIdx = idx
                else:
                    item.type = IPTVChoiceBoxItem.TYPE_OFF
                options.append(item)
            self.openChild(boundFunction(self.childClosed, self.selectVideoModeCallback), IPTVChoiceBoxWidget, {'width': 500, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': currIdx, 'title': _("Select %s") % ret.name, 'options': options, 'chrome': True, 'footerMargin': 136})

    def selectVideoModeCallback(self, ret=None):
        printDBG("selectVideoModeCallback ret[%r]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            currValue = self.currVideoOptions['videomode']
            if None is currValue:
                currValue = self.defVideoOptions['videomode']
            if ret.privateData in self.defVideoOptions['videomode_choices'] and ret.privateData != currValue:
                SetE2VideoMode(ret.privateData)
                self.openChild(boundFunction(self.childClosed, self.confirmVideoModeCallback), MessageBox, text=_("Is this message displayed correctly?"), type=MessageBox.TYPE_YESNO, timeout=10, default=False)
                return
        self.selectVideoOptions()

    def confirmVideoModeCallback(self, ret=None):
        printDBG("confirmVideoModeCallback ret[%r]" % [ret])
        if ret:
            curVideoMode = GetE2VideoMode()
            self.currVideoOptions['videomode'] = curVideoMode
            self.metaHandler.setVideoOption('videomode', curVideoMode)
        else:
            SetE2VideoMode(self.currVideoOptions['videomode'])
        self.selectVideoOptions()

    def videoOptionSelectionChanged(self, ret=None):
        printDBG("videoOptionSelectionChanged ret[%s]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            newOptions = dict(self.currVideoOptions)
            newOptions[self.defVideoOptions['active']] = ret.privateData
            self.applyVideoOptions(newOptions)

    def selectVideoOptionCallback(self, ret=None):
        printDBG("selectVideoOptionsCallback ret[%r]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            self.metaHandler.setVideoOption(self.defVideoOptions['active'], ret.privateData)
            self.currVideoOptions[self.defVideoOptions['active']] = ret.privateData
        else:
            ret = IPTVChoiceBoxItem("", "", self.currVideoOptions[self.defVideoOptions['active']])
        self.videoOptionSelectionChanged(ret)
        self.selectVideoOptions()

    # _trackLabel() translates the names of subtitlesmatch.LANGUAGES through _(langName(...)) - a dynamic
    # call, invisible to xgettext. Listing them as literals makes the translation template pick them up
    # (tests/test_subtitlesmatch.py keeps this list in sync with LANGUAGES).
    LANGUAGE_NAMES = (
        _("Albanian"), _("Arabic"), _("Armenian"), _("Basque"), _("Bengali"), _("Bosnian"), _("Bulgarian"),
        _("Catalan"), _("Chinese"), _("Croatian"), _("Czech"), _("Danish"), _("Dutch"), _("English"),
        _("Estonian"), _("Persian"), _("Finnish"), _("French"), _("Galician"), _("Georgian"), _("German"),
        _("Greek"), _("Hebrew"), _("Hindi"), _("Hungarian"), _("Icelandic"), _("Indonesian"), _("Italian"),
        _("Japanese"), _("Korean"), _("Kurdish"), _("Latvian"), _("Lithuanian"), _("Macedonian"), _("Malay"),
        _("Norwegian"), _("Polish"), _("Portuguese"), _("Brazilian Portuguese"), _("Romanian"), _("Russian"),
        _("Serbian"), _("Sinhala"), _("Slovak"), _("Slovenian"), _("Spanish"), _("Swedish"), _("Tamil"),
        _("Thai"), _("Turkish"), _("Ukrainian"), _("Urdu"), _("Vietnamese"),
    )

    @staticmethod
    def _trackLabel(track, trackIdx, count):
        # "[AAC] German" for a stream language tag "ger"/"deu"; the tag "und" (ISO 639-2: undetermined, set by
        # many encoders when nobody entered a language) or an empty one leaves just the codec - with the track
        # number when there are several; any other name (a stream title like "Deutsch (AD)") as it is
        name = str(track.get('name', '')).strip()
        if name.lower() in ('', 'und', 'unknown', 'n/a'):
            name = '%d' % (trackIdx + 1) if count > 1 else ''
        elif len(name) <= 3 and langCode(name):
            name = _(langName(name))
        else:
            name = _(name)
        return ('[%s] %s' % (track.get('encode', ''), name)).strip()

    def selectAudioTrack(self):
        printDBG("selectAudioTrack")
        tracksTab = self.playback['AudioTracks']
        if len(tracksTab):
            options = []
            printDBG(">>>>>>>>>>>> AudioTrack[%s]" % self.playback['AudioTrack'])
            currentId = self.playback['AudioTrack'].get('id', -1)
            currIdx = 0
            for trackIdx in range(len(tracksTab)):
                name = self._trackLabel(tracksTab[trackIdx], trackIdx, len(tracksTab))
                item = IPTVChoiceBoxItem(name, "", {'track_id': tracksTab[trackIdx]['id'], 'track_idx': trackIdx})
                if tracksTab[trackIdx]['id'] == currentId:
                    item.type = IPTVChoiceBoxItem.TYPE_ON
                    currIdx = trackIdx
                else:
                    item.type = IPTVChoiceBoxItem.TYPE_OFF
                options.append(item)
            self.openChild(boundFunction(self.childClosed, self.selectAudioTrackCallback), IPTVChoiceBoxWidget, {'width': 500, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': currIdx, 'title': _("Select audio track"), 'options': options, 'chrome': True, 'footerMargin': 136})
        else:
            self.showMessage(_("Information about audio tracks not available."), MessageBox.TYPE_INFO, None)

    def selectAudioTrackCallback(self, ret):
        printDBG("selectAudioTrackCallback ret[%r]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            ret = ret.privateData
            if 'track_id' in ret and ret['track_id'] != self.playback['AudioTrack'].get('id', -1):
                self.metaHandler.setAudioTrackIdx(ret.get('track_idx', -1))
                self.extPlayerCmddDispatcher.setAudioTrack(ret['track_id'])

    def selectSubtitle(self):
        printDBG("IPTVExtMoviePlayer.selectSubtitle")
        options = []

        currIdx = self.metaHandler.getSubtitleIdx() + 1
        ####################################
        embeddedTrackId = self.playback['SubtitleTrack'].get('id', -1)
        embeddedTracksTab = self.playback['SubtitleTracks']
        if embeddedTrackId > -1:
            currIdx = 0
        ####################################

        # the row of the active track (embedded tracks are listed before the external ones)
        selRowIdx = 0
        item = IPTVChoiceBoxItem(_('None'), "", {'other': 'none'})
        if 0 == currIdx and -1 == embeddedTrackId:
            item.type = IPTVChoiceBoxItem.TYPE_ON
        else:
            item.type = IPTVChoiceBoxItem.TYPE_OFF
        options.append(item)

        #####################################
        for trackIdx in range(len(embeddedTracksTab)):
            name = self._trackLabel(embeddedTracksTab[trackIdx], trackIdx, len(embeddedTracksTab))
            item = IPTVChoiceBoxItem(name, "", {'track_id': embeddedTracksTab[trackIdx]['id'], 'track_idx': trackIdx})
            if embeddedTracksTab[trackIdx]['id'] == embeddedTrackId:
                item.type = IPTVChoiceBoxItem.TYPE_ON
                selRowIdx = len(options)
            else:
                item.type = IPTVChoiceBoxItem.TYPE_OFF
            options.append(item)
        #####################################

        tracksTab = self.metaHandler.getSubtitlesTracks()
        for trackIdx in range(len(tracksTab)):
            name = '[{0}] {1}'.format(tracksTab[trackIdx]['lang'], tracksTab[trackIdx]['title'])
            item = IPTVChoiceBoxItem(name, "", {'track_idx': trackIdx})
            if (trackIdx + 1) == currIdx:
                item.type = IPTVChoiceBoxItem.TYPE_ON
                selRowIdx = len(options)
            else:
                item.type = IPTVChoiceBoxItem.TYPE_OFF
            options.append(item)
        if self.subHandler['enabled'] and None is not self.metaHandler.getSubtitleTrack():
            options.append(IPTVChoiceBoxItem(_('Synchronize'), "", {'other': 'synchro'}))
        if len(self.externalSubTracks):
            for item in self.externalSubTracks:
                title = '[{0}] {1} ({2})'.format(item.get('lang', ''), item['title'], _('Download suggested'))
                options.append(IPTVChoiceBoxItem(title, "", {'other': 'download_suggested', 'track': item}))
        options.append(IPTVChoiceBoxItem(_('Load'), "", {'other': 'load'}))
        options.append(IPTVChoiceBoxItem(_('Download'), "", {'other': 'download'}))
        printDBG("IPTVExtMoviePlayer.selectSubtitle options = %s" % str(options))
        self.openChild(boundFunction(self.childClosed, self.selectSubtitleCallback), IPTVChoiceBoxWidget, {'width': 600, 'height': self._getChoiceBoxHeight(len(options)), 'current_idx': selRowIdx, 'title': _("Select subtitles track"), 'options': options, 'chrome': True, 'footerMargin': 136})

    def selectSubtitleCallback(self, ret):
        printDBG("selectSubtitleCallback ret[%r]" % [ret])
        if isinstance(ret, IPTVChoiceBoxItem):
            ret = ret.privateData
            if 'other' in ret:
                option = ret['other']
                if option == 'none':
                    # to speed up, should be set also as output from exteplayer3
                    self.playback['SubtitleTrack'] = {'id': -1}
                    self.metaHandler.setSubtitleIdx(-1)
                    self.metaHandler.setEmbeddedSubtileTrackIdx(-1)
                    self.disableSubtitles()
                elif option == 'synchro':
                    self.showSubSynchroControl()
                elif option == 'load':
                    self.openSubtitlesFromFile()
                elif option == 'download':
                    self.downloadSub()
                elif option == 'download_suggested' and 'track' in ret:
                    self.downloadSub([ret['track']])
            elif 'track_id' in ret:
                self.metaHandler.setEmbeddedSubtileTrackIdx(ret['track_idx'])
                self.metaHandler.setSubtitleIdx(-1)
                self.enableEmbeddedSubtitles(ret['track_id'])
            elif 'track_idx' in ret:
                self.metaHandler.setSubtitleIdx(ret['track_idx'])
                # to speed up, should be set also as output from exteplayer3
                self.playback['SubtitleTrack'] = {'id': -1}
                self.metaHandler.setEmbeddedSubtileTrackIdx(-1)
                self.extPlayerCmddDispatcher.setSubtitleTrack(-1)
                self.subHandler['embedded_handler'].flushSubtitles()
                self.flushGraphicSubtitles()
                self.enableSubtitles()

    def _looksLikeSubtitleFile(self, filePath):
        try:
            sts, reason = self._detectSubtitleFile(filePath)
            if not sts:
                printDBG("IPTVExtMoviePlayer._looksLikeSubtitleFile skip file[%s] reason[%s]" % (filePath, reason))
            return sts
        except Exception:
            printExc()
        return False

    def _detectSubtitleFile(self, filePath):
        if None is filePath or '' == filePath:
            return False, 'empty path'
        if not fileExists(filePath):
            return False, 'missing file'

        ext = os_path.splitext(filePath)[1].lower().lstrip('.')
        # every format the file picker offers (mpl always, ssa/smi/ttml/... with the parser extension)
        if ext not in self.NON_SUBTITLE_SIDE_EXTENSIONS and ext not in IPTVSubtitlesHandler.getSupportedFormats():
            return False, 'unsupported extension'

        try:
            with open(filePath, 'rb') as f:
                data = f.read(8192)
        except Exception:
            printExc()
            return False, 'read error'

        if not data:
            return False, 'empty file'

        try:
            text = ensure_str(data)
        except Exception:
            try:
                text = data.decode('utf-8', 'ignore')
            except Exception:
                printExc()
                return False, 'decode error'

        lines = [line.strip() for line in text.replace('\r', '\n').split('\n') if line.strip()]
        if not lines:
            return False, 'no text lines'

        score = 0
        for line in lines[:40]:
            if '-->' in line:
                score += 3
            elif re.match(r'^\d+$', line):
                score += 1
            elif re.match(r'^\d{2}:\d{2}:\d{2}[,.]\d{1,3}', line):
                score += 2
            elif re.match(r'^\d{1,2}:\d{2}:\d{2}[:=]', line):  # TMPlayer
                score += 2
            elif re.match(r'^\{\d+\}\{\d*\}', line):
                score += 3
            elif 'vtt' == ext and line.upper().startswith('WEBVTT'):
                score += 3
            elif re.match(r'^\[\d+\]\[\d+\]', line):  # MPL2
                score += 3
            elif re.match(r'^(dialogue:|\[script info\]|\[events\])', line.lower()):  # SSA/ASS
                score += 3
            elif re.search(r'<(sync|sami|tt[\s>]|time\s+begin)|\sbegin="', line.lower()):  # SAMI, TTML, RealText
                score += 3
            elif re.match(r'^(\{\d+:\d{2}:\d{2}\}|\[\d{2}:\d{2}:\d{2}\])', line):  # PSB, DKS
                score += 3

        if score >= 3:
            return True, 'subtitle markers detected'
        return False, 'no subtitle markers detected'

    def openSubtitlesFromFile(self):
        printDBG("openSubtitlesFromFile")
        currDir = GetSubtitlesDir()

        fileSRC = self.fileSRC
        tmpMatch = 'file://'
        if fileSRC.startswith(tmpMatch):
            fileSRC = fileSRC[len(tmpMatch):].replace('//', '/')
        if fileExists(fileSRC) and not fileSRC.endswith('/.iptv_buffering.flv'):
            try:
                currDir, tail = os_path.split(fileSRC)
            except Exception:
                printExc()

        fileMatch = re.compile(r"^.*?(?:\.%s)$" % r'|\.'.join(IPTVSubtitlesHandler.getSupportedFormats()), re.IGNORECASE)
        self.openChild(boundFunction(self.childClosed, self.openSubtitlesFromFileCallback), IPTVFileSelectorWidget, currDir, _("Select subtitles file"), fileMatch)

    def openSubtitlesFromFileCallback(self, filePath=None):
        printDBG("openSubtitlesFromFileCallback filePath[%s]" % filePath)
        if None is not filePath:
            if not self._looksLikeSubtitleFile(filePath):
                printDBG("openSubtitlesFromFileCallback rejected non subtitle file[%s]" % filePath)
                return
            self.subHandler['handler'].removeCacheFile(filePath)
            cmd = '/usr/bin/uchardet "%s"' % shellQuote(filePath)
            self.workconsole = iptv_system(cmd, boundFunction(self.enableSubtitlesFromFile, filePath))

    def enableSubtitlesFromFile(self, filePath, code=127, encoding=""):
        encoding = MapUcharEncoding(encoding)
        if 0 != code or 'unknown' in encoding:
            encoding = ''
        else:
            encoding = encoding.strip()

        # WORKAROUND for incorrectly recognized CP1250 encoding as iso-8859-2
        # because charset do not have model for CP1250 for polish language,
        # it incorrectly recognizes such coding as iso-8859-2
        if GetDefaultLang() == 'pl' and encoding == 'iso-8859-2':
            encoding = GetPolishSubEncoding(filePath)
        elif '' == encoding:
            encoding = 'utf-8'

        printDBG("enableSubtitlesFromFile filePath[%s] encoding[%s]" % (filePath, encoding))
        if None is not filePath:
            lang = CParsingHelper.getSearchGroups(filePath, r"_([a-z]{2})_[0-9]+?_[0-9]+?_[0-9]+?(?:\.%s)$" % r'|\.'.join(IPTVSubtitlesHandler.getSupportedFormats()))[0]
            try:
                currDir, fileName = os_path.split(filePath)
            except Exception:
                printExc()
                return
            trackIdx = -1
            tracks = self.metaHandler.getSubtitlesTracks()
            for idx in range(len(tracks)):
                try:
                    if os_path.samefile(tracks[idx]['path'], filePath):
                        trackIdx = idx
                        break
                except Exception:
                    printExc()
            if -1 == trackIdx:
                trackIdx = self.metaHandler.addSubtitleTrack({"title": fileName, "id": "", "provider": "", "lang": lang, "delay_ms": 0, "path": filePath})
            self.metaHandler.setSubtitleIdx(trackIdx)
            self.enableSubtitles(encoding)

    def disableSubtitles(self):
        self.playback['SubtitleTrack'] = {'id': -1}
        self.extPlayerCmddDispatcher.setSubtitleTrack(-1)
        self.subHandler['embedded_handler'].flushSubtitles()
        self.flushGraphicSubtitles()
        self.hideSubtitles()
        self.subHandler['enabled'] = False
        self.updateSubSynchroControl()

    def enableEmbeddedSubtitles(self, id):
        printDBG("enableEmbeddedSubtitles")
        if self.playback['SubtitleTrack'].get('id', -1) != id:
            self.subHandler['embedded_handler'].flushSubtitles()
            self.flushGraphicSubtitles()
            self.extPlayerCmddDispatcher.setSubtitleTrack(id)
        self.subHandler['handler_type'] = 'embedded_handler'
        self.subHandler['marker'] = None
        self.subHandler['enabled'] = True
        self.updateSubSynchroControl()
        if self.setMoviePlayerConfig:
            self.setMoviePlayerConfig = False
            self.runConfigMoviePlayerCallback(True)

    def _autoEnableSubtitleFile(self):
        # setting "auto enable": a subtitle file next to a played file
        if not self.subConfig['auto_enable']:
            return
        fileSRC = self.fileSRC
        tmpMatch = 'file://'
        if fileSRC.startswith(tmpMatch):
            fileSRC = fileSRC[len(tmpMatch):].replace('//', '/')
        if not fileExists(fileSRC) or fileSRC.endswith('/.iptv_buffering.flv'):
            return
        subFile = ''
        try:
            name, ext = os_path.splitext(fileSRC)
            # name.srt / name.vtt ... first, then the ones saved with a download: name.de.srt - the box
            # language first, then English, then any. Only files that read as subtitles: name.txt is
            # mostly the description sidecar of a download, it must not end the search
            boxLang = GetDefaultLang()
            langs = ['.%s.' % boxLang] + (['.en.'] if boxLang != 'en' else [])

            def langRank(path):
                suffix = path[len(name):].lower()
                for idx, lang in enumerate(langs):
                    if suffix.startswith(lang):
                        return idx
                return len(langs)
            candidates = [name + '.' + ext for ext in IPTVSubtitlesHandler.getSupportedFormats()]
            candidates += [path for path in sorted(subtitleSidecarFiles(name), key=langRank) if path not in candidates]
            for candidate in candidates:
                if self._detectSubtitleFile(candidate)[0]:  # also checks that the file is there
                    subFile = candidate
                    break
        except Exception:
            printExc()
        if '' != subFile:
            self.openSubtitlesFromFileCallback(subFile)

    def enableSubtitles(self, encoding='utf-8'):
        printDBG("enableSubtitles")
        if self.isClosing:
            return
        track = self.metaHandler.getSubtitleTrack()
        if None is track:
            if not self.metaHandler.hasSubtitlesTracks():
                self._autoEnableSubtitleFile()
            return

        printDBG("enableSubtitles track[%s]" % track)
        path = track['path']
        if path and not fileExists(path):
            # a remembered subtitle file that is gone (the download manager put it into the MKV, or it was deleted):
            # forgotten without an error, the search for one next to the video runs instead (also when other tracks
            # are remembered - none of them was the chosen one)
            printDBG("enableSubtitles file gone, track dropped [%s]" % path)
            self.metaHandler.removeSubtitleTrack(self.metaHandler.getSubtitleIdx())
            self._autoEnableSubtitleFile()
            return
        sts = self.subHandler['handler'].loadSubtitles(path, encoding)
        if not sts:
            # we will remove this subtitles track as it is can not be used
            self.metaHandler.removeSubtitleTrack(self.metaHandler.getSubtitleIdx())
            msg = _("An error occurred while loading a subtitle from [%s].") % path
            self.showMessage(msg, MessageBox.TYPE_ERROR)
            return
        self.subHandler['handler_type'] = 'handler'
        self.subHandler['marker'] = None
        self.subHandler['enabled'] = True
        self.updateSubSynchroControl()
        if self.setMoviePlayerConfig:
            self.setMoviePlayerConfig = False
            self.runConfigMoviePlayerCallback(True)

    def updatSubtitlesTime(self):
        if -1 != self.subHandler['last_time'] and -1 != self.subHandler['latach_time']:
            timeMS = self.subHandler['last_time'] + int((time.time() - self.subHandler['latach_time']) * 1000)
            self.subHandler['current_sub_time_ms'] = timeMS
            self.updateSubtitles(timeMS)

    def restartSubTimer(self):
        if 'Play' != self.playback['Status']:
            return
        if not self.subHandler['enabled']:
            return
        self.subHandler['timer'].stop()
        self.subHandler['timer'].start(100)

    def latchSubtitlesTime(self, timeMS):
        self.subHandler['latach_time'] = time.time()
        self.subHandler['last_time'] = timeMS
        self.restartSubTimer()
        self.updateSubtitles(timeMS)

    def updateSubtitles(self, timeMS, force=False):
        if self.isClosing:
            return
        if not self.subHandler['enabled']:
            return
        if None is self.metaHandler.getSubtitleTrack() and 'handler' == self.subHandler['handler_type']:
            return

        # marker is used for optimization
        # we remember some kind of fingerprint for last subtitles
        # subtitles handler first check this fingerprint
        # if the previous one is the same as current and it will return None instead
        # of subtitles text
        prevMarker = self.subHandler['marker']
        if force:
            prevMarker = None

        handler_type = self.subHandler['handler_type']
        if handler_type == 'handler':
            delay_ms = self.metaHandler.getSubtitleTrackDelay()
        else:
            delay_ms = 0
            self.updateGraphicSubtitles(timeMS, force)
        marker, text = self.subHandler[handler_type].getSubtitles(timeMS + delay_ms, prevMarker)
        if None is not text:
            self.subHandler['marker'] = marker
            # printDBG("===============================================================")
            # printDBG(text)
            # printDBG("===============================================================")
            if "" == text:
                self.hideSubtitles()
            else:
                self.setSubtitlesText(text)

    def hideSubtitles(self):
        for idx in range(self.subLinesNum):
            self['subLabel%d' % (idx + 1)].hide()

    def addGraphicSubAtom(self, obj):
        # {"id":..,"s":<ms>,"e":<ms> or null,"r":[{"x","y","w","h","f":<png in the -G directory>}]}
        if not self.graphicSubs['enabled']:
            return
        try:
            rects = []
            for rect in obj['r']:
                rects.append({'x': int(rect['x']), 'y': int(rect['y']), 'w': int(rect['w']), 'h': int(rect['h']), 'f': os_path.basename(str(rect['f']))})
            end = obj.get('e')
            self.graphicSubs['handler'].addAtom(int(obj['s']), None if end is None else int(end), rects)
        except Exception:
            printExc()

    def updateGraphicSubtitles(self, timeMS, force=False):
        if not self.graphicSubs['enabled']:
            return
        handler = self.graphicSubs['handler']
        marker, rects = handler.getRects(timeMS, None if force else self.graphicSubs['marker'])
        if rects is None:
            return
        self.graphicSubs['marker'] = marker
        for idx in range(self.GRAPHIC_SUB_RECTS):
            widget = self['subGraphic%d' % (idx + 1)]
            pixmap = None
            if idx < len(rects):
                rect = rects[idx]
                try:
                    # every picture is a new file: openATV would keep each one in its pixmap cache otherwise
                    pixmap = LoadPixmap(path=handler.getPath(rect), cached=False)
                except Exception:
                    printExc()
            if pixmap and widget.instance:
                # the rectangles already are in screen pixels (exteplayer3 -W/-H)
                widget.instance.move(ePoint(rect['x'], rect['y']))
                widget.instance.resize(eSize(rect['w'], rect['h']))
                widget.setPixmap(pixmap)
                widget.show()
            else:
                widget.hide()

    def hideGraphicSubtitles(self):
        self.graphicSubs['marker'] = None
        for idx in range(self.GRAPHIC_SUB_RECTS):
            self['subGraphic%d' % (idx + 1)].hide()

    def flushGraphicSubtitles(self):
        self.graphicSubs['handler'].flushSubtitles()
        self.hideGraphicSubtitles()

    def clearGraphicSubtitlesDir(self):
        # PNG files left by an exteplayer3 that was killed
        try:
            for name in os_listdir(self.graphicSubs['dir']):
                if name.endswith('.png'):
                    os_remove(os_path.join(self.graphicSubs['dir'], name))
        except Exception:
            pass

    def setSubtitlesText(self, text, stripLine=True, breakToLongLine=True):
        # back = True
        desktopW = getDesktop(0).size().width()
        desktopH = getDesktop(0).size().height()
        # this method positions every subtitle line via direct
        # .instance.move()/.resize() calls computed from real desktop
        # pixels - see _subtitleScale()'s own comment for why that needs
        # its own scale factor, separate from the resolution="1280,720"
        # skin-level scaling. _effectiveSubLineHeight() additionally
        # floors the configured line_height against font_size so
        # descenders (e.g. "g") don't get clipped when the two are set
        # too close together.
        scale = self._subtitleScale()

        dW = desktopW - 20
        dH = int(self.subConfig['box_height'] * scale)

        if stripLine:
            text = text.strip()

        if self.subLinesNum == 1 and 'transparent' == self.subConfig['background']:
            self['subLabel1'].setText(text)
            self['subLabel1'].show()
        else:
            if text.startswith('{\\an8}'):
                text = text[6:]
                subOnTopHack = True
            else:
                subOnTopHack = False

            if self.subLinesNum == 1:
                lineHeight = self._effectiveSubLineHeight(scale) * (text.count('\n') + 1)
                text = [text]
            else:
                text = text.split('\n')
                if not subOnTopHack:
                    text.reverse()
                lineHeight = self._effectiveSubLineHeight(scale)
            y = int(self.subConfig['pos'] * scale)
            if not subOnTopHack:
                y += self.subHandler['pos_y_offset']
            for lnIdx in range(self.subLinesNum):
                subLabel = 'subLabel%d' % (lnIdx + 1)
                if lnIdx < len(text):
                    lnText = text[lnIdx]
                    if stripLine:
                        lnText = lnText.strip()
                else:
                    lnText = ''

                if '' == lnText:
                    self[subLabel].hide()
                    continue
                try:
                    self[subLabel].instance.resize(eSize(dW, dH))
                    self[subLabel].resize(eSize(dW, dH))

                    self[subLabel].setText(lnText)
                    textSize = self[subLabel].getSize()

                    printDBG("lines [%d] width[%d] worlds[%d]" % (len(text), textSize[0], lnText.count(' ')))
                    if breakToLongLine and len(text) == 1 and textSize[0] >= dW and lnText.count(' ') > 4:
                        lnText = lnText.split(' ')
                        splitWord = len(lnText) // 2 + 1
                        lnText = '%s\n%s' % (' '.join(lnText[:splitWord]), ' '.join(lnText[splitWord:]))
                        self.setSubtitlesText(lnText, False, False)
                        return

                    lW = textSize[0] + int(self.subConfig['font_size'] * scale) / 2
                    lH = lineHeight  # textSize[1] + self.subConfig['font_size'] / 2
                    self[subLabel].instance.resize(eSize(int(lW), int(lH)))
                    if not subOnTopHack:
                        self[subLabel].instance.move(ePoint(int((desktopW - lW) / 2), int(desktopH - y - lH)))
                    else:
                        self[subLabel].instance.move(ePoint(int((desktopW - lW) / 2), int(y)))
                    y += lH + int(self.subConfig['line_spacing'] * scale)
                    self[subLabel].show()
                except Exception:
                    printExc()

    def updateInfo(self):
        self.extPlayerCmddDispatcher.doUpdateInfo()
        self.updateBufferFill()

    def updateBufferFill(self):
        if None is not self.downloader:
            if self.downloader.hasDurationInfo() and self.downloader.getTotalFileDuration() > 0:
                totalDuration = self.downloader.getTotalFileDuration()
                downloadDuration = self.downloader.getDownloadedFileDuration()
                if 0 < totalDuration and 0 < downloadDuration:
                    self.playback['BufferFill'] = int(downloadDuration * 100000 // totalDuration)
                    self['bufferingBar'].value = self.playback['BufferFill']
                    if self.playback['Length'] is not None and self.playback['Length'] < totalDuration:
                        self.setPlaybackLength(totalDuration)
                    # the watched mark compares the stop position with this; every update, the player's length
                    # messages (the file written so far) must not shrink it again
                    self.clipLength = totalDuration
                return

            remoteFileSize = self.downloader.getRemoteFileSize() - self.totalDataSizeCorrection
            if 0 < remoteFileSize:
                localFileSize = self.downloader.getLocalFileSize(True) - self.availableDataSizeCorrection
                if 0 < localFileSize:
                    self.playback['BufferFill'] = int(localFileSize * 100000 // remoteFileSize)
                    self['bufferingBar'].value = self.playback['BufferFill']

    def showMessage(self, message, type, callback=None):
        printDBG("IPTVExtMoviePlayer.showMessage")
        if self.isClosing and type is not None:
            return
        messageItem = {'msg': message, 'type': type, 'callback': callback}
        self.messageQueue.append(messageItem)
        self.processMessageQueue()

    def processMessageQueue(self):
        if self.underMessage or 0 == len(self.messageQueue):
            return
        self.underMessage = True
        while len(self.messageQueue):
            messageItem = self.messageQueue.pop(0)
            message, type, callback = messageItem['msg'], messageItem['type'], messageItem['callback']
            if None is type and None is not callback:
                callback()
            else:
                if self.isClosing and None is not callback:
                    continue  # skip message with callback
                else:
                    self.screenSaver.deactivate()
                    self.session.openWithCallback(boundFunction(self.messageClosedCallback, callback), MessageBox, text=message, type=type)
            return

    def messageClosedCallback(self, callback, arg=None):
        self.underMessage = False
        if None is not callback:
            callback()
        else:
            self.processMessageQueue()

    def waitEOSAbortedFixTimeoutCallback(self):
        if self.waitEOSAbortedFix['EOSaborted_received']:
            self.extPlayerCmddDispatcher.stop()

    def setPlaybackLength(self, newLength):
        # fix 071026: eSlider.setRange() only takes int - a float length from a downloader crashed enigma2
        newLength = int(newLength)
        self.playback['Length'] = newLength
        self['progressBar'].range = (0, newLength)
        self['bufferingCBar'].range = (0, newLength)
        self['lengthTimeLabel'].setText(str(timedelta(seconds=newLength)))
        self.updateLcdInfo()

    def updateLcdInfo(self):
        # feeds the colour LCD summary with position, remaining time and progress
        try:
            length = int(self.playback.get('Length') or 0)
            curr = int(self.playback.get('CurrentTime') or 0)
            # the player reports a normal length for most live streams: buffered ones play a growing file (only the
            # downloader knows), of a direct HLS stream it sees the growing playlist (the link's mark tells, without
            # one a length that keeps growing ahead of the position: setPlaybackLength() also follows a position
            # running past the length, at the end of a film or without a known length, that is length == position)
            if self.downloader is None and length > self.lcdLastLength > 0 and length > curr:
                self.lcdLengthGrowth += 1
            elif length < self.lcdLastLength:
                self.lcdLengthGrowth = 0
            self.lcdLastLength = length
            live = (self.playback.get('IsLive', False) or self.fileSRC.meta.get('iptv_livestream') or self.lcdLengthGrowth >= 3
                    or (self.downloader is not None and self.downloader.isLiveStream() is True))
            self.playback['LiveDetected'] = bool(live)
            known = length > 0 and not live
            percent = max(0, min(100, curr * 100 // length)) if known else 0
            state = (curr, length, live)
            if state == self.lcdLastState:
                return
            self.lcdLastState = state
            self['lcdProgress'].value = percent
            self['lcdCurrTime'].setText(str(timedelta(seconds=curr)))
            self['lcdCurrTimeHM'].setText(lcdTimeHM(curr))
            if known:
                remained = max(0, length - curr)
                self['lcdRemained'].setText('-' + str(timedelta(seconds=remained)))
                self['lcdRemainedHM'].setText(lcdTimeHM(remained))
                self['lcdRemainedMin'].setText('%d' % (remained // 60) if remained > 60 else '+%ds' % remained)
                self['lcdRemainedShort'].setText('+%d %s' % (remained // 60, _('min')) if remained >= 60 else '+%ds' % remained)
                self['lcdLength'].setText(str(timedelta(seconds=length)))
                self['lcdLengthHM'].setText(lcdTimeHM(length))
                self['lcdPercent'].setText('%d%%' % percent)
            elif live:
                self['lcdRemained'].setText(_('Live'))
                self['lcdRemainedHM'].setText(_('Live'))
                self['lcdRemainedMin'].setText(_('Live'))
                self['lcdRemainedShort'].setText(_('Live'))
                self['lcdLength'].setText('')
                self['lcdLengthHM'].setText('')
                self['lcdPercent'].setText('')
            else:
                # length not known yet: show placeholders, so the fields do not pop up later
                self['lcdRemained'].setText('-0:00:00')
                self['lcdRemainedHM'].setText('0:00')
                self['lcdRemainedMin'].setText('0')
                self['lcdRemainedShort'].setText('')
                self['lcdLength'].setText('0:00:00')
                self['lcdLengthHM'].setText('0:00')
                self['lcdPercent'].setText('0%')
        except Exception:
            printExc()

    def playbackUpdateInfo(self, stsObj):
        # fix TypeError: '>' not supported between instances of 'NoneType' and 'int'
        try:
            # workaround for missing playback length info for under muxing MKV
            if self.playback['Length'] > 0 and self.downloader is not None and self.downloader.getName() == 'ffmpeg':
                stsObj['Length'] = self.playback['Length']

            for key, val in stsObj.items():
                if 'Length' == key:
                    if 0 > val:
                        printDBG('IPTVExtMoviePlayer.playbackUpdateInfo Length[%d] - live stream?' % val)
                        val = 0
                        self.playback['IsLive'] = True
                    else:
                        self.playback['IsLive'] = False
                    if 0 < val:
                        # restore last position
                        if 10 < self.lastPosition and self.lastPosition < (self.playback['Length'] - 10):
                            self.updateBufferFill()
                            if self.playback['BufferFill'] > 0:
                                max = self.playback['Length'] * self.playback['BufferFill'] / 100000
                                if max > self.playback['Length']:
                                    max = self.playback['Length']
                            else:
                                max = self.playback['Length']

                            if self.lastPosition <= max:
                                self.showPlaybackInfoBar()
                                self.extPlayerCmddDispatcher.doGoToSeek(str(self.lastPosition - 5))
                                self.lastPosition = 0
                        tmpLength = self.playback['BufferCTime']
                        if self.playback['CurrentTime'] > tmpLength:
                            tmpLength = self.playback['CurrentTime']
                        if val > tmpLength:
                            tmpLength = val
                            # buffering: the player plays the file written so far, its length is no clip length while
                            # the download runs (an episode stopped after 3 of 53 minutes counted as watched) -
                            # updateBufferFill() sets the known total then; once the file is complete it is
                            if None is self.downloader or not self.downloader.isDownloading():
                                self.clipLength = val
                        if self.playback['Length'] is not None and self.playback['Length'] < tmpLength:
                            if None is self.downloader or not self.downloader.hasDurationInfo():
                                self.setPlaybackLength(tmpLength)
                        self.playback['LengthFromPlayerReceived'] = True
                elif 'CurrentTime' == key:
                    if self.playback['Length'] is not None and self.playback['Length'] < val and val > self.playback['BufferCTime']:
                        self.setPlaybackLength(val)
                    self['progressBar'].value = val
                    prevCTime = self.playback['CurrentTime']
                    self.playback['CurrentTime'] = stsObj['CurrentTime']
                    if 0 < self.playback['CurrentTime']:
                        self.playback['StartGoToSeekTime'] = self.playback['CurrentTime']
                        diff = self.playback['CurrentTime'] - prevCTime
                        if diff > 0 and diff < 3:  # CurrentTime in seconds
                            self.playback['ConfirmedCTime'] = self.playback['CurrentTime']
                    self['currTimeLabel'].setText(str(timedelta(seconds=self.playback['CurrentTime'])))
                    self['remainedLabel'].setText('-' + str(timedelta(seconds=self.playback['Length'] - self.playback['CurrentTime'])))
                    self.updateLcdInfo()
                    if time.time() >= self.seekLimitNotice['until']:
                        self['pleaseWait'].hide()
                elif 'BufferCTime' == key:
                    if self.playback['Length'] is not None and self.playback['Length'] < val:
                        self.setPlaybackLength(val)
                    self.playback['BufferCTime'] = val
                    self['bufferingCBar'].value = val
                elif 'Status' == key:
                    # curSts = self.playback['Status']
                    if self.playback['Status'] != val[0]:
                        if 'Play' == val[0]:
                            self.showPlaybackInfoBar()
                        elif val[0] in ['Pause', 'FastForward', 'SlowMotion']:
                            self.showPlaybackInfoBar(blocked=True)
                        self.playback['Status'] = val[0]
                        self['statusIcon'].setPixmap(self.playback['statusIcons'].get(val[0], None))
                elif 'IsLoop' == key:
                    if self.playback['IsLoop'] != val:
                        self.playback['IsLoop'] = val
                        icon = 'Off'
                        if val:
                            icon = 'On'
                        self['loopIcon'].setPixmap(self.playback['loopIcons'].get(icon, None))
                        self.showPlaybackInfoBar()

                elif 'VideoTrack' == key:
                    self.playback[key] = val
                    codec = val['encode'].split('/')[-1]
                    text = "%s %sx%s" % (codec, val['width'], val['height'])
                    if val['progressive']:
                        text += 'p'
                    elif False is val['progressive']:
                        text += 'i'
                    fps = val['frame_rate']
                    if not 0 < fps <= 120:
                        # exteplayer3 takes ffmpeg's guess, for a DASH time base of 1/200 (BBC) that is 200 fps - the
                        # frame rate of the link list then, else none
                        try:
                            fps = float(strwithmeta(self.fileSRC).meta.get('iptv_frame_rate') or 0)
                        except Exception:
                            fps = 0
                    if fps == floor(fps):
                        fps = int(fps)
                    if fps:
                        text += ', %sfps' % fps
                    text += ', %s' % val['aspect_ratio'].replace('_', ':')
                    streamType = self._getStreamTypeLabel()
                    if streamType:
                        text += ', %s' % streamType
                    self['videoInfo'].setText(text)
                else:
                    self.playback[key] = val
                    printDBG(">>> playback[%s] = %s" % (key, val))
            if 'VideoTrack' in stsObj or 'AudioTrack' in stsObj:
                self.infoPanel.updateStream()
        except Exception:
            printExc(WarnOnly=True)

    def doGoToSeek(self):
        self.playback['GoToSeekTimer'].stop()
        if self.playback['GoToSeeking']:
            self.showPlaybackInfoBar()
            self.playback['StartGoToSeekTime'] = self.playback['GoToSeekTime']
            printDBG("IPTVExtMoviePlayer.doGoToSeek current[%r] target[%r] length[%r]" % (self.playback['CurrentTime'], self.playback['GoToSeekTime'], self.playback['Length']))
            self.extPlayerCmddDispatcher.doGoToSeek(str(self.playback['GoToSeekTime']))
            self.playback['GoToSeeking'] = False
            self['goToSeekPointer'].hide()
            self["goToSeekLabel"].hide()

    def doGoToSeekPointerMove(self, seek):
        printDBG('IPTVExtMoviePlayer.doGoToSeekPointerMove seek[%r], LengthFromPlayerReceived[%r], GoToSeeking[%r]' % (seek, self.playback['LengthFromPlayerReceived'], self.playback['GoToSeeking']))
        self.playback['GoToSeekTimer'].stop()
        if not self.playback['LengthFromPlayerReceived']:
            return
        if self.playback['Length'] <= 0:
            # live streams report a zero length, no seek bar to move
            return
        if not self.playback['GoToSeeking']:
            self.playback['GoToSeeking'] = True
            self.playback['GoToSeekTime'] = self.playback['StartGoToSeekTime']
            self.showPlaybackInfoBar([], True)
            self['goToSeekPointer'].show()
            self["goToSeekLabel"].show()

        # update data
        if self.playback['BufferFill'] > 0:
            max = self.playback['Length'] * self.playback['BufferFill'] // 100000
            if max > self.playback['Length']:
                max = self.playback['Length']
            if max < self.playback['BufferCTime']:
                max = self.playback['BufferCTime']
        else:
            max = self.playback['Length']
        # buffering: never onto the end of the downloaded part (bufferedEnd(), like the skip keys) - exteplayer3 stood
        # still at the end of the file still being written
        bufEnd = self.bufferedEnd()
        if bufEnd is not None and max > bufEnd:
            max = bufEnd if bufEnd > self.playback['CurrentTime'] else self.playback['CurrentTime']

        pos = self.playback['GoToSeekTime'] + seek
        wanted = pos
        if pos > max:
            pos = max
        if pos < 0:
            pos = 0
        printDBG("IPTVExtMoviePlayer.doGoToSeekPointerMove seek[%r] current[%r] limit[%r] length[%r] wanted[%r] pointer[%r]" % (seek, self.playback['CurrentTime'], max, self.playback['Length'], wanted, pos))
        if seek > 0 and wanted > max and max < self.playback['Length']:
            # the seek bar is cut at the end of the downloaded part (buffering): say so, so the key does not look broken
            self.showSeekLimitNotice(max)

        self.playback['GoToSeekTime'] = pos
        self["goToSeekLabel"].setText(str(timedelta(seconds=int(self.playback['GoToSeekTime']))))

        # update position
        # convert time to width
        relativeX = self["progressBar"].instance.size().width() * self.playback['GoToSeekTime'] / self.playback['Length']
        x = self['progressBar'].position[0] - self["goToSeekPointer"].getWidth() / 2 + relativeX

        self['goToSeekPointer'].setPosition(x, self['goToSeekPointer'].position[1])
        self["goToSeekLabel"].setPosition(x, self['goToSeekLabel'].position[1])

        # trigger delayed seek
        self.playback['GoToSeekTimer'].start(1000)

    def saveLastPlaybackTime(self):
        lastPosition = self.playback.get('ConfirmedCTime', 0)
        length = self.playback['Length'] or 0
        if config.plugins.iptvplayer.remember_last_position.value and lastPosition > 0 and length > (config.plugins.iptvplayer.remember_last_position_time.value * 60):
            # watched to the end: the next start begins at 0 instead of at the old position. With buffering the length
            # is only the length of the part written so far, unless the downloader knows the whole duration
            # (a length the player did not report, or of a live stream, follows the position: always "at the end")
            lengthKnown = (None is self.downloader or self.downloader.hasDurationInfo()) and self.playback['LengthFromPlayerReceived'] and not self.playback['LiveDetected']
            if lengthKnown and lastPosition >= length - max(30, length * 0.03):
                printDBG("saveLastPlaybackTime position[%r] length[%r] watched to the end -> reset" % (lastPosition, length))
                lastPosition = -1
            self.metaHandler.setLastPosition(lastPosition)

    def loadLastPlaybackTime(self):
        if config.plugins.iptvplayer.remember_last_position.value and self.lastPosition < 1:
            self.lastPosition = self.metaHandler.getLastPosition()

    # handling of RCU keys
    def key_stop(self, requestedByUser="key_stop"):
        self.setPleaseWait(_("Closing. Please wait..."))
        self.closeRequestedByUser = requestedByUser
        if self.console is not None:
            if self.extPlayerCmddDispatcher.stop():
                self.saveLastPlaybackTime()
        else:
            self.isClosing = True

    def key_play(self):
        self.extPlayerCmddDispatcher.play()

    def key_pause(self):
        # remotes with one play/pause key send pause in both states
        if 'Pause' == self.playback['Status']:
            self.extPlayerCmddDispatcher.play()
        else:
            self.extPlayerCmddDispatcher.pause()

    def key_exit(self):
        self.doExit()

    def key_info(self):
        self.doInfo()

    def key_seek1(self):
        self.doSeek(config.seek.selfdefined_13.value * -1)

    def key_seek3(self):
        self.doSeek(config.seek.selfdefined_13.value)

    def key_seek4(self):
        self.doSeek(config.seek.selfdefined_46.value * -1)

    def key_seek6(self):
        self.doSeek(config.seek.selfdefined_46.value)

    def key_seek7(self):
        self.doSeek(config.seek.selfdefined_79.value * -1)

    def key_seek9(self):
        self.doSeek(config.seek.selfdefined_79.value)

    def key_seekFwd(self):
        self.extPlayerCmddDispatcher.seekFwd()

    def key_seekBack(self):
        self.extPlayerCmddDispatcher.seekBack()

    def key_left_press(self):
        self.goToSeekKey(-1, "press")

    def key_left_repeat(self):
        self.goToSeekKey(-1, "repeat")

    def key_rigth_press(self):
        self.goToSeekKey(1, "press")

    def key_rigth_repeat(self):
        self.goToSeekKey(1, "repeat")

    def key_up_press(self):
        self.goSubKey(-1, "press")

    def key_up_repeat(self):
        self.goSubKey(-1, "repeat")

    def key_down_press(self):
        self.goSubKey(1, "press")

    def key_down_repeat(self):
        self.goSubKey(1, "repeat")

    def bufferedEnd(self):
        # buffering: the last second of the part downloaded so far (like the seek pointer's limit), None without buffering
        # or when the downloaded part is not known
        if None is self.downloader or self.playback['BufferFill'] <= 0 or not self.playback['Length']:
            return None
        end = min(self.playback['Length'] * self.playback['BufferFill'] // 100000, self.playback['Length'])
        end = max(end, self.playback['BufferCTime'])
        # a few seconds before the end: a jump right onto it would stop again at once
        return max(0, end - 5) if end < self.playback['Length'] else end

    def showSeekLimitNotice(self, loadedUpTo):
        # a skip key was cut at the end of the downloaded part: a short notice, so the key does not look broken
        try:
            self.seekLimitNotice['text'] = _("Only loaded up to %s") % str(timedelta(seconds=int(loadedUpTo)))
            self.setPleaseWait(self.seekLimitNotice['text'])
            self.seekLimitNotice['until'] = time.time() + 3
            self.seekLimitNotice['timer'].start(3000, True)  # singleshot
        except Exception:
            printExc()

    def hideSeekLimitNotice(self):
        self.seekLimitNotice['until'] = 0
        # only the notice itself: "Closing. Please wait..." or "Opening..." that replaced it stays
        if not self.isClosing and self['pleaseWait'].getText() == self.seekLimitNotice.get('text'):
            self['pleaseWait'].hide()

    def doSeek(self, val):
        # the skip keys: with buffering never beyond the part downloaded so far - exteplayer3 stopped at the end of the
        # file still being written and the picture froze. An absolute jump sets the position at once: the player reports
        # it only every second, a second key press before that adds to the first one
        bufferedEnd = self.bufferedEnd()
        current = self.playback['CurrentTime']
        wanted = None
        if None is not self.downloader and self.downloader.hasDurationInfo() and current >= 0 and self.playback['Length'] > 10:
            target = wanted = min(max(current + val, 0), self.playback['Length'] - 10)
            if bufferedEnd is not None:
                target = min(target, max(bufferedEnd, current))
        elif bufferedEnd is not None and val > 0 and current >= 0:
            # (inside the last seconds of the buffered part a forward key must not jump back)
            target = wanted = current + val
            target = min(target, max(bufferedEnd, current))
        else:
            printDBG("IPTVExtMoviePlayer.doSeek val[%r] current[%r] bufferedEnd[%r] -> relative seek" % (val, current, bufferedEnd))
            self.extPlayerCmddDispatcher.doSeek(val)
            return
        printDBG("IPTVExtMoviePlayer.doSeek val[%r] current[%r] bufferedEnd[%r] length[%r] wanted[%r] target[%r]" % (val, current, bufferedEnd, self.playback['Length'], wanted, target))
        if val > 0 and bufferedEnd is not None and wanted is not None and int(target) < int(wanted):
            self.showSeekLimitNotice(max(bufferedEnd, current))
        if int(target) != int(current):
            self.playback['CurrentTime'] = int(target)
            self.extPlayerCmddDispatcher.doGoToSeek(str(int(target)))

    def key_ok(self):
        self.key_pause()

    def key_loop(self):
        if self.playback['IsLoop']:
            self.extPlayerCmddDispatcher.setLoopMode(0)
        else:
            self.extPlayerCmddDispatcher.setLoopMode(1)

    def key_subtitles(self):
        self.selectSubtitle()

    def key_audio(self):
        self.selectAudioTrack()

    def key_videooption(self):
        self.selectVideoOptions()

    def key_menu(self):
        self.showMenuOptions()

    def key_record(self):
        if self.isDownladManagerAvailable and self.downloader:
            self.key_stop("save_buffer")
            return
        return 0

    def key_zap_next(self):
        self.doZap("zap_next")

    def key_zap_prev(self):
        self.doZap("zap_prev")

    def doZap(self, sts):
        if self.zapEnabled and not self.isClosing:
            self.key_stop(sts)

    # audio screensaver (IPTVAudioScreenSaver): wanted while audio-only playback runs and nothing is open above
    def _screenSaverWanted(self):
        if not self.isStarted or self.isClosing or self.childWindowsCount > 0 or self.underMessage:
            return False
        if self.screenSaverAudioItem:
            return True
        # exteplayer3 reports the video track ("v_c") of every stream that has one; an audio track and no video
        # track is a radio/music stream. gstplayer is left out: it does not always report the video track.
        return 'eplayer' == self.player and bool(self.playback['AudioTrack']) and not self.playback['VideoTrack']

    def _screenSaverTimeText(self):
        currTime = self['currTimeLabel'].getText()
        length = self.playback.get('Length') or 0
        if length > 0:
            return "%s / %s" % (currTime, self['lengthTimeLabel'].getText())
        return currTime

    def goSubKey(self, direction, state='press'):
        if not self.subHandler['enabled'] or None is self.metaHandler.getSubtitleTrack():
            self.hideSubSynchroControl()
            return
        if self.subHandler['synchro']['visible']:
            currentDelay = self.metaHandler.getSubtitleTrackDelay()
            currentDelay += direction * 500  # in MS
            self.metaHandler.setSubtitleTrackDelay(currentDelay)
            self.updateSubSynchroControl()
        else:
            if 'orig_pos' not in self.subConfig:
                self.subConfig['orig_pos'] = self.subConfig['pos']
            self.subConfig['pos'] += (-5 * direction)
            self.setSubOffsetFromInfoBar()
            if -1 != self.subHandler['current_sub_time_ms']:
                self.updateSubtitles(self.subHandler['current_sub_time_ms'], True)

    def updateSubSynchroControl(self):
        if not self.subHandler['synchro']['visible'] or not self.subHandler['enabled'] or None is self.metaHandler.getSubtitleTrack():
            self.hideSubSynchroControl()
            return
        currentDelay = self.metaHandler.getSubtitleTrackDelay()
        if currentDelay > 0:
            textDelay = '+'
        else:
            textDelay = ''
        textDelay += "%.1fs" % (currentDelay / 1000.0)
        self['subSynchroLabel'].setText(textDelay)
        if -1 != self.subHandler['current_sub_time_ms']:
            self.updateSubtitles(self.subHandler['current_sub_time_ms'])

    def goToSeekKey(self, direction, state='press'):
        if 'press' == state:
            self.goToSeekStep = 5
            self.goToSeekRepeatCount = 1
        elif 3 <= self.goToSeekRepeatCount:
            self.goToSeekRepeatCount = 1
            self.goToSeekStep *= 2
        else:
            self.goToSeekRepeatCount += 1

        # not allow faster than (0.1 * playback length)
        # floor division: a py3 float step (e.g. 1535 / 10 = 153.5) made the
        # seek label read "0:20:59.500000" while the key was held
        if self.goToSeekStep > (self.playback['Length'] // 10):
            self.goToSeekStep = self.playback['Length'] // 10
        if 0 >= self.goToSeekStep:
            self.goToSeekStep = 1

        self.doGoToSeekPointerMove(self.goToSeekStep * direction)

    def doExit(self, fromInfo=False):
        if not fromInfo and self.subHandler['synchro']['visible']:
            self.hideSubSynchroControl()
        elif self.playbackInfoBar['visible'] or self.infoPanel.visible:
            self.infoPanel.hide()
            self.playbackInfoBar['blocked'] = False
            self.hidePlaybackInfoBar()
        else:
            self.key_stop("key_exit")

    def doInfo(self):
        if self.infoPanel.visible:
            self.doExit(True)
        elif self.isStarted and not self.isClosing:
            self.playbackInfoBar['blocked'] = True
            self.showPlaybackInfoBar()
            self.infoPanel.show()

    def eplayer3Finished(self, code):
        printDBG("IPTVExtMoviePlayer.eplayer3Finished code[%r]" % code)
        if self.isClosing:
            return

        msg = _("It seems that the video player \"%s\" does not work properly.\n\nSTS: %s\nERROR CODE: %r")
        if None is self.playerBinaryInfo['version']:
            msg = msg % (self.playerName, self.playerBinaryInfo['data'], code)
            self.showMessage(msg, MessageBox.TYPE_ERROR, self.onLeavePlayer)
        elif 'gstplayer' == self.player and 246 == code:
            msg = msg % (self.playerName, _("ERROR: pipeline could not be constructed: no element \"playbin2\" \nPlease check if gstreamer plugins are available in your system."), code)
            self.showMessage(msg, MessageBox.TYPE_ERROR, self.onLeavePlayer)
        else:
            self.onLeavePlayer()

    def waitCloseTimeoutCallback(self):
        printDBG("IPTVExtMoviePlayer.waitCloseTimeoutCallback")
        if None is not self.console:
            printDBG("Force close movie player by sending CtrlC")
            self.console.sendCtrlC()
        self.onLeavePlayer()

    def eplayer3DataAvailable2(self, data):
        if None is data or self.isClosing:
            return

        if 'got buffer empty from driver!' in data:
            self.extPlayerCmddDispatcher.stop()

        # work around to catch EOF event after seeking, pause .etc
        if 'wait EOS aborted!!' in data:
            self.waitEOSAbortedFix['EOSaborted_received'] = True
            self.waitEOSAbortedFix['timer'].start(2000, True)  # singleshot

        if self.waitEOSAbortedFix['EOSaborted_received'] and 'poll' in data:
            self.waitEOSAbortedFix['timer'].stop()
            self.waitEOSAbortedFix['timer'].start(2000, True)

    def eplayer3DataAvailable(self, data):

        def _mapTrack(obj, video=False):
            printDBG('>>>> _mapTrack [%s]' % obj)
            params = {}
            params['id'] = int(obj['id'])
            # exteplayer3 names start with "A_" / "V_" / "S_" (A_MP3), gstplayer sends the plain name (audio/mpeg)
            encode = str(obj['e'])
            params['encode'] = encode[2:] if encode[:2] in ('A_', 'V_', 'S_') else encode
            params['name'] = str(obj['n'])
            if video:
                params['frame_rate'] = float(obj['f']) / 1000.0
                params['width'] = int(obj['w'])
                params['height'] = int(obj['h'])
                params['progressive'] = None
                try:
                    if int(obj['p']):
                        params['progressive'] = True
                    else:
                        params['progressive'] = False

                except Exception:
                    printExc(WarnOnly=True)
                params['aspect_ratio'] = 'unknown'
                # gstplayer2 reports a DASH video track first without its size (0x0), the size follows
                if params['width'] and params['height']:
                    try:
                        DAR = float((obj.get('an') or 1) * params['width']) / float((obj.get('ad') or 1) * params['height'])
                        aTab = []
                        for item in [(16, 9, '16_9'), (4, 3, '4_3'), (16, 10, '16_10'), (3, 2, '3_2'), (5, 4, '5_4'), (1.85, 1, '1.85'), (2.35, 1, '2.35'), (1, 1, '1_1'), (3, 4, '3_4'), (9, 16, '9_16')]:
                            diff = fabs(float(item[0]) / item[1] - DAR)
                            aTab.append((diff, item[2]))
                        aTab.sort(key=lambda item: item[0])
                        params['aspect_ratio'] = aTab[0][1]
                    except Exception:
                        printExc()

            return params

        def _mapSubAtom(obj):
            printDBG('>>>> _mapTrack [%s]' % obj)
            params = {}
            params['id'] = int(obj['id'])
            params['start'] = int(obj['s'])
            params['end'] = int(obj['e'])
            params['text'] = str(obj['t'])
            return params

        if None is data or self.isClosing:
            return
        data = ensure_str(data)
        data = data.replace('"ifd"', "'ifd'")
        # data = data.decode('utf-8', 'strict').replace('"ifd"', '(ifd)')
        if None is self.playerBinaryInfo['version']:
            self.playerBinaryInfo['data'] += data
        data = self.responseData + data
        if '\n' != data[-1]:
            truncated = True
        else:
            truncated = False
        data = data.split('\n')
        if truncated:
            self.responseData = data[-1]
            del data[-1]
        msgText = ''
        msgType = MessageBox.TYPE_INFO
        for item in data:
            # printDBG('item= %s' % item)
            item = item.strip().replace('{"PLAYBACK_LENGTH":{"PLAYBACK_LENGTH":', '{"PLAYBACK_LENGTH":').replace('{"PLAYBACK_LENGTH":{"J":', '{"J":')
            if item.endswith(':'):
                item = item[:-1]
            if item.startswith('{'):
                try:
                    obj = LoadPlayerMessage(item)
                    # printDBG("Status object [%r]" % obj)
                    key = list(obj.keys())[0]
                    obj = obj[key]
                except Exception:
                    printExc(item)
                    continue

                if "T" == key:  # ADD_TRIGGERS
                    self.latchSubtitlesTime(obj['c'])
                elif "PLAYBACK_PLAY" == key:
                    self.onStartPlayer()
                    # if 'gstplayer' != self.player:
                    self.updateInfoTimer.start(1000)
                    if 0 == obj['sts']:
                        self.playbackUpdateInfo({'Status': ['Play', '1']})
                        # the stream is open: some live streams (Pluto TV without buffering) never report a
                        # playback time, which is what hid "Opening. Please wait..." until now
                        if not self.isClosing:
                            self['pleaseWait'].hide()
                elif "PLAYBACK_STOP" == key:
                    self.onLeavePlayer()
                elif "PLAYBACK_LENGTH" == key and 0 == obj['sts']:
                    self.playbackUpdateInfo({'Length': int(obj['length'])})
                elif "PLAYBACK_CURRENT_TIME" == key and 0 == obj['sts']:
                    self.playbackUpdateInfo({'CurrentTime': int(obj['sec'])})
                elif "J" == key and obj['ms'] > 0:
                    updateInfoParams = {'CurrentTime': int(obj['ms'] / 1000)}
                    if 'lms' in obj:
                        updateInfoParams['BufferCTime'] = int(obj['lms'] / 1000)
                    self.playbackUpdateInfo(updateInfoParams)
                    self.latchSubtitlesTime(obj['ms'])
                # CURRENT VIDEO TRACK
                elif "v_c" == key:
                    tmpTrack = _mapTrack(obj, True)
                    if tmpTrack.get('id', -1) > -1:
                        self.playbackUpdateInfo({'VideoTrack': tmpTrack})
                elif "a_c" == key:
                    tmpTrack = _mapTrack(obj)
                    if tmpTrack.get('id', -1) > -1:
                        self.playbackUpdateInfo({'AudioTrack': tmpTrack})
                elif "a_l" == key:
                    tracks = []
                    for item in obj:
                        tracks.append(_mapTrack(item))
                    self.playbackUpdateInfo({'AudioTracks': tracks})
                elif "s_c" == key:
                    tmpTrack = _mapTrack(obj)
                    if tmpTrack.get('id', -1) > -1:
                        self.playbackUpdateInfo({'SubtitleTrack': tmpTrack})
                        self.enableEmbeddedSubtitles(tmpTrack['id'])
                elif "s_l" == key:
                    tracks = []
                    for item in obj:
                        tracks.append(_mapTrack(item))
                    self.playbackUpdateInfo({'SubtitleTracks': tracks})
                elif "s_a" == key:
                    if self.subHandler['enabled']:
                        if 'r' in obj:
                            self.addGraphicSubAtom(obj)
                        else:
                            subAtom = _mapSubAtom(obj)
                            self.subHandler['embedded_handler'].addSubAtom(subAtom)
                elif "s_f" == key:
                    self.subHandler['embedded_handler'].flushSubtitles()
                    self.flushGraphicSubtitles()
                elif "e_plugin" == key:
                    # the PNG plugin could not be loaded: image subtitles stay empty
                    printDBG("exteplayer3 plugin error %s" % obj)
                elif "N" == key:
                    self.playbackUpdateInfo({'IsLoop': obj['isLoop']})
                elif "PLAYBACK_INFO" == key:
                    if obj['isPaused']:
                        self.playbackUpdateInfo({'Status': ['Pause', '0']})
                        # if 'gstplayer' == self.player: self.updateInfoTimer.stop()
                        self.subHandler['timer'].stop()
                    else:
                        # if 'gstplayer' == self.player: self.updateInfoTimer.start(1000)
                        if obj['isForwarding']:
                            self.playbackUpdateInfo({'Status': ['FastForward', str(obj['Speed'])]})
                        elif 0 < obj['SlowMotion']:
                            self.playbackUpdateInfo({'Status': ['SlowMotion', '1/%d' % obj['SlowMotion']]})
                        elif obj['isPlaying']:  # and 1 == obj['Speed']:
                            self.playbackUpdateInfo({'Status': ['Play', '1']})
                        else:
                            printDBG('eplayer3DataAvailable PLAYBACK_INFO not handled')
                elif "GSTPLAYER_EXTENDED" == key:
                    self.playerBinaryInfo['version'] = obj['version']
                elif "EPLAYER3_EXTENDED" == key:
                    self.playerBinaryInfo['version'] = obj['version']
                elif "GST_ERROR" == key:
                    printDBG('GST_ERROR: %s, code %s\n' % (ensure_str(obj['msg']), obj['code']))
                    msgType = MessageBox.TYPE_ERROR
                    msgText += 'GST_ERROR: %s (code %s)\n' % (ensure_str(obj['msg']), obj['code'])
                    # 'ifd' from the replace() above for gstplayer builds that do not escape
                    # their JSON, "ifd" from builds that do
                    if ensure_str(obj['msg']) in ("No URI handler implemented for 'ifd'.", 'No URI handler implemented for "ifd".'):
                        msgText += _('Try to change extplayer or reinstall gst-ifdsrc')
                elif "FF_ERROR" == key:
                    printDBG('FF_ERROR: %s, code %s\n' % (ensure_str(obj['msg']), obj['code']))
                    msgType = MessageBox.TYPE_ERROR
                    msgText += 'FF_ERROR: %s, code %s\n' % (ensure_str(obj['msg']), obj['code'])
                elif "GST_MISSING_PLUGIN" == key:
                    printDBG('GST_MISSING_PLUGIN: %s\n' % ensure_str(obj['msg']))
                    msgText += 'GST_MISSING_PLUGIN: %s\n' % ensure_str(obj['msg'])

                # {u'PLAYBACK_INFO':
                # {u'isSeeking': False,
                # u'BackWard': 0.0,
                # u'isForwarding': False,
                # u'mayWriteToFramebuffer': True,
                # u'AVSync': 1,
                # u'isTeletext': False,
                # u'isAudio': True,
                # u'isCreationPhase': False,
                # u'abortRequested': False,
                # u'isVideo': True,
                # u'isPaused': False,
                # u'SlowMotion': 0,
                # u'isPlaying': True,
                # u'Speed': 1,
                # u'isSubtitle': False,
                # u'isDvbSubtitle': False}}
        if msgText != '':
            if MessageBox.TYPE_ERROR == msgType and self.quietStartErrors and not self.playback.get('ConfirmedCTime', 0):
                printDBG("IPTVExtMoviePlayer error before playback, next link follows - message not shown")
                self.quietStartErrors = False
                self.waitCloseTimeoutCallback()
            else:
                self.showMessage(msgText, msgType, None)

    def onDownloadFinished(self, sts):
        printDBG("IPTVExtMoviePlayer.onDownloadFinished sts[%s]" % sts)
        if None is not self.extPlayerCmddDispatcher:
            if 'gstplayer' == self.player:
                self.extPlayerCmddDispatcher.setDownloadFileTimeout(0)
            else:
                self.extPlayerCmddDispatcher.setProgressiveDownload(0)

    def __onClose(self):
        printDBG(">>>>>>>>>>>>>>>>>>>>>> __onClose")
        self.isClosing = True
        self.playback['Active'] = False
        self.screenSaver.close()
        if None is not self.workconsole:
            self.workconsole.kill()
        self.workconsole = None

        if None is not self.refreshCmdConsole:
            self.refreshCmdConsole.kill()
        self.refreshCmdConsole = None

        if None is not self.extLinkProv['console']:
            self.extLinkProv['close_conn'] = None
            self.extLinkProv['data_conn'] = None
            self.extLinkProv['console'].sendCtrlC()
            self.extLinkProv['console'] = None

        if None is not self.iframeParams['console']:
            self.iframeParams['console'].kill()
        self.iframeParams['console'] = None

        if None is not self.console:
            self.console_appClosed_conn = None
            self.console_stderrAvail_conn = None
            self.console_stdoutAvail_conn = None
            self.console.sendCtrlC()
            self.console = None
        if self.graphicSubs['enabled']:
            self.graphicSubs['handler'].flushSubtitles()
            self.clearGraphicSubtitlesDir()
        if None is not self.downloader:
            self.downloader.unsubscribeFor_Finish(self.onDownloadFinished)
        self.downloader = None

        if self.clockFormat:
            self.playbackInfoBar['clock_timer'].stop()
            self.playbackInfoBar['clock_timer_conn'] = None
        self.playbackInfoBar['timer'].stop()
        self.playbackInfoBar['timer_conn'] = None
        self.waitEOSAbortedFix['timer_conn'] = None
        self.waitCloseFix['timer_conn'] = None

        self.subHandler['timer'].stop()
        self.subHandler['timer_conn'] = None

        self.updateInfoTimer_conn = None
        for key in self.playback.keys():
            self.playback[key] = None
        self.onClose.remove(self.__onClose)
        self.messageQueue = []

        # RESTORE DEFAULT VIDEO OPTION
        printDBG(">>>>>>>>>>>>>>>>>>>>> __onClose[%s]" % self.defVideoOptions)
        printDBG(">>>>>>>>>>>>>>>>>>>>> __onClose[%s]" % self.currVideoOptions)
        videoOptionChange = False
        for opt in ['aspect', 'policy', 'policy2']:
            val = self.defVideoOptions[opt]
            val2 = self.currVideoOptions[opt]
            if val in self.defVideoOptions['%s_choices' % opt] and val != val2:
                videoOptionChange = True
                break

        if videoOptionChange:
            self.applyVideoOptions(self.defVideoOptions)

        # RESTORE DEFAULT AUDIO OPTION
        playerDefOptions = self.getE2AudioOptions()
        audioOptions = ['ac3', 'aac']
        for opt in audioOptions:
            if playerDefOptions[opt] is not None and playerDefOptions[opt] != self.defAudioOptions[opt]:
                SetE2AudioCodecMixOption(opt, self.defAudioOptions[opt])
        self.metaHandler.save()

        # SAVE SUBTITLES POSITION IF CHANGED
        if 'orig_pos' in self.subConfig and self.subConfig['orig_pos'] != self.subConfig['pos']:
            self.configObj.setSubtitleFontSettings(self.subConfig)

        try:
            self.extPlayerCmddDispatcher.owner = None
        except Exception:
            printExc()

    def onStartPlayer(self):
        self.isStarted = True
        self.showPlaybackInfoBar()
        self.screenSaver.start()

    def onLeavePlayer(self):
        printDBG("IPTVExtMoviePlayer.onLeavePlayer")
        # also the ends that are not STOP/EXIT (end of the film, player crash, close timeout): save, or reset at the end
        if not self.isClosing:
            try:
                self.saveLastPlaybackTime()
            except Exception:
                printExc()
        self.screenSaver.stop()
        self.seekLimitNotice['timer'].stop()
        if self.waitCloseFix['waiting'] and None is not self.waitCloseFix['timer']:
            self.waitCloseFix['timer'].stop()
        self.updateInfoTimer.stop()
        self.subHandler['timer'].stop()
        self.infoPanel.close()
        self.playbackInfoBar['blocked'] = False
        self.hidePlaybackInfoBar()

        self.isClosing = True
        self.showMessage(None, None, boundFunction(self.extmovieplayerClose, self.closeRequestedByUser, self.playback.get('ConfirmedCTime', 0)))

    def extmovieplayerClose(self, sts, currentTime):
        if self.childWindowsCount > 0:
            self.delayedClosure = boundFunction(self.closeWithIframeClear, sts, currentTime)
        else:
            self.closeWithIframeClear(sts, currentTime)

    def closeWithIframeClear(self, sts, currentTime):
        blankIframeFilePath = ''
        if self.iframeParams['show_iframe']:
            blankIframeFilePath = self.iframeParams['iframe_file_end']
        elif self.configObj.clearVideoByIframeInjection():
            blankIframeFilePath = self.configObj.getBlankIframeFilePath()

        if blankIframeFilePath != '' and IsExecutable('showiframe') and fileExists(blankIframeFilePath):
            if not self.iframeParams['iframe_continue']:
                self.iframeParams['console'] = iptv_system('showiframe "{0}"'.format(shellQuote(blankIframeFilePath)), boundFunction(self.iptvDoClose, sts, currentTime))
                return
        self.iptvDoClose(sts, currentTime)

    def iptvDoClose(self, sts, currentTime, code=None, data=None):
        if None is not self.extLinkProv['console']:
            self.extLinkProv['console'].sendCtrlC()

        if None is not self.refreshCmdConsole:
            self.refreshCmdConsole.kill()
        self.refreshCmdConsole = None

        if None is not self.iframeParams['console']:
            self.iframeParams['console'].kill()
        self.iframeParams['console'] = None

        self.close(sts, currentTime, self.clipLength)

    def openChild(self, *args, **kwargs):
        self.childWindowsCount += 1
        self.screenSaver.deactivate()
        self.session.openWithCallback(*args, **kwargs)

    def childClosed(self, callback, *args):
        self.childWindowsCount -= 1
        callback(*args)

        if None is not self.delayedClosure and self.childWindowsCount < 1:
            self.delayedClosure()

    def downloadSub(self, simpleTracksTab=[]):
        if self.downloader is not None:
            url = strwithmeta(self.downloader.getUrl())
        else:
            url = strwithmeta(self.fileSRC)
        # colour codes of the list title would end up in the subtitle search and the subtitle file name
        movieTitle = StripColorCodes(self.title)
        if 0 == len(simpleTracksTab):
            self.openChild(boundFunction(self.childClosed, self.downloadSubCallback), IPTVSubDownloaderWidget, {'duration_sec': self.playback['Length'], 'movie_url': url, 'movie_title': movieTitle})
        else:
            self.openChild(boundFunction(self.childClosed, self.downloadSubCallback), IPTVSubSimpleDownloaderWidget, {'movie_url': url, 'movie_title': movieTitle, 'sub_list': simpleTracksTab})

    def downloadSubCallback(self, ret=None):
        if None is not ret:
            self.subHandler['handler'].removeCacheFile(ret.get('path', ''))
            idx = self.metaHandler.addSubtitleTrack(ret)
            self.metaHandler.setSubtitleIdx(idx)
            self.enableSubtitles()

    def onStart(self):
        self.onShow.remove(self.onStart)
        # self.onLayoutFinish.remove(self.onStart)

        if '' != self.refreshCmd and (self.downloader is not None or not self.fileSRC.startswith('ext://')):
            self.refreshCmdConsole = iptv_system(self.refreshCmd)

        if self.iframeParams['show_iframe'] and IsExecutable('showiframe')\
           and fileExists(self.iframeParams['iframe_file_start']):
            if self.iframeParams['iframe_continue']:
                self.iframeParams['console'] = iptv_system('showiframe "{0}"'.format(shellQuote(self.iframeParams['iframe_file_start'])))
            else:
                self.iframeParams['console'] = iptv_system('showiframe "{0}"'.format(shellQuote(self.iframeParams['iframe_file_start'])), self.iptvGetUrlStart)
                return
        self.iptvGetUrlStart()

    def iptvGetUrlStart(self, code=None, data=None):
        if self.isClosing:
            self.onLeavePlayer()
            return

        if self.downloader is None and self.refreshCmd != '' and self.fileSRC.startswith('ext://'):
            self.extLinkProv['console'] = eConsoleAppContainer()
            self.extLinkProv['close_conn'] = eConnectCallback(self.extLinkProv['console'].appClosed, self._updateGetUrlFinished)
            self.extLinkProv['data_conn'] = eConnectCallback(self.extLinkProv['console'].stderrAvail, self._updateGetUrlDataAvail)
            self.extLinkProv['console'].execute(self.refreshCmd)
        else:
            self.iptvDoStart()

    def _updateGetUrlFinished(self, code=0):
        printDBG('_updateGetUrlFinished update code[%d]--- ' % (code))
        if not self.extLinkProv['started']:
            self.onLeavePlayer()

    def _updateGetUrlDataAvail(self, data):
        if self.isClosing:
            return
        if None is not data and 0 < len(data):
            # the console delivers bytes on Python 3
            self.extLinkProv['data'] += ensure_str(data)
            if self.extLinkProv['data'].endswith('\n'):
                data = self.extLinkProv['data'].split('\n')
                url = ''
                for item in data:
                    if item.startswith('http'):
                        url = item.strip()
                if url.startswith('http'):
                    if not self.extLinkProv['started']:
                        self.fileSRC = strwithmeta(url, self.fileSRC.meta)
                        self.extLinkProv['started'] = True
                        self.iptvDoStart()
                self.extLinkProv['data'] = ''

    def iptvDoStart(self):
        if self.isClosing:
            self.onLeavePlayer()
            return

        self['progressBar'].value = 0
        self['bufferingCBar'].value = 0
        self['bufferingBar'].range = (0, 100000)
        self['bufferingBar'].value = 0
        self.initGuiComponentsPos()
        self.metaHandler.load()
        self.loadLastPlaybackTime()

        defVideoMode = self.defVideoOptions['videomode']
        videoModes = self.defVideoOptions['videomode_choices']

        if defVideoMode is not None and defVideoMode in videoModes:
            curVideoMode = GetE2VideoMode()
            videoMode = self.metaHandler.getVideoOption('videomode')
            if videoMode != curVideoMode and videoMode in videoModes:
                SetE2VideoMode(videoMode)
            self.currVideoOptions['videomode'] = GetE2VideoMode()

        if None is not self.downloader:
            self.downloader.subscribeFor_Finish(self.onDownloadFinished)

        if 'gstplayer' == self.player:
            if self.fileSRC.startswith('merge://'):
                msg = _("Link is not supported by the gstplayer. Please use the extelayer3 if available.")
                self.showMessage(msg, MessageBox.TYPE_ERROR)

            # active audio track
            audioTrackIdx = self.metaHandler.getAudioTrackIdx()

            # file download timeout, 0 keeps gstplayer away from ifd://
            timeout = 0
            if None is not self.downloader and self.downloader.isDownloading():
                if not GetGstIfdSrc()[1]:
                    printDBG("gstplayer: libgstifdsrc.so missing or not loadable, playing the buffer file without IFD")
                else:
                    timeout = self.gstAdditionalParams['file-download-timeout']
            isLive = 1 if self.gstAdditionalParams['file-download-live'] else 0

            # http headers + proxy, gstplayer takes both as "key=value" fields
            httpFields = []
            if "://" in self.fileSRC:
                tmp = strwithmeta(self.fileSRC)
                url, httpParams = DMHelper.getDownloaderParamFromUrlWithMeta(tmp, True)
                for key in httpParams:
                    if key == 'http_proxy':
                        # the proxy fields below, not an "http_proxy:" request header
                        continue
                    httpFields.append((key, httpParams[key]))
                if 'http_proxy' in tmp.meta:
                    tmp = tmp.meta['http_proxy']
                    if '://' in tmp:
                        if '@' in tmp:
                            tmp = re.search('([^:]+?://)([^:]+?):([^@]+?)@(.+?)$', tmp)
                            if tmp:
                                httpFields.extend([('proxy', tmp.group(1) + tmp.group(4)), ('proxy-id', tmp.group(2)), ('proxy-pw', tmp.group(3))])
                        else:
                            httpFields.append(('proxy', tmp))

            gstplayerPath = GetGstPlayerPath()
            # a DASH link: the MPD with only the chosen video / audio representation
            playSrc = dashmpd.localManifestUrl(self.fileSRC) or self.fileSRC
            # 'export GST_DEBUG="*:6" &&' +
            cmd = gstplayerPath + ' "%s"' % shellQuote(playSrc)
            if gstplayerPath.endswith('gstplayer2'):
                # getopt command line; buffer options are only passed when set,
                # gstplayer2 treats 0 as "turned off" and takes the ring buffer in KB
                if audioTrackIdx >= 0:
                    cmd += ' -i %d' % audioTrackIdx
                if timeout > 0:
                    cmd += ' -t %d -l %d' % (timeout, isLive)
                if "://" in self.fileSRC:
                    bufferPath = self.gstAdditionalParams['download-buffer-path']
                    ringBufferMB = int(self.gstAdditionalParams['ring-buffer-max-size'])
                    bufferDuration = int(self.gstAdditionalParams['buffer-duration'])
                    bufferSize = int(self.gstAdditionalParams['buffer-size'])
                    if bufferPath:
                        cmd += ' -p "%s"' % shellQuote(bufferPath)
                    if ringBufferMB > 0:
                        cmd += ' -r %d' % (ringBufferMB * 1024)
                    if bufferDuration > 0:
                        cmd += ' -d %d' % bufferDuration
                    if bufferSize > 0:
                        cmd += ' -s %d' % bufferSize
                    for key, value in httpFields:
                        cmd += ' -H "%s=%s"' % (key, shellQuote(value))
            else:
                # positional command line of the original gstplayer
                cmd += ' %d ' % audioTrackIdx
                cmd += ' {0} '.format(timeout)
                cmd += ' {0} '.format(isLive)
                if "://" in self.fileSRC:
                    cmd += ' "%s" "%s"  "%s"  "%s" ' % (shellQuote(self.gstAdditionalParams['download-buffer-path']), shellQuote(self.gstAdditionalParams['ring-buffer-max-size']), shellQuote(self.gstAdditionalParams['buffer-duration']), shellQuote(self.gstAdditionalParams['buffer-size']))
                    for key, value in httpFields:
                        cmd += (' "%s=%s" ' % (key, shellQuote(value)))
            cmd += " > /dev/null"
        else:
            exteplayer3path = "/usr/bin/exteplayer3"  # config.plugins.iptvplayer.exteplayer3path.value
            cmd = exteplayer3path
            if GraphicSubtitlesSupported(exteplayer3path) and mkdirs(self.graphicSubs['dir']):
                # image subtitles as PNG files, the rectangles scaled to the screen
                self.graphicSubs['enabled'] = True
                self.clearGraphicSubtitlesDir()
                desktopSize = getDesktop(0).size()
                cmd += ' -G "%s" -W %d -H %d' % (shellQuote(self.graphicSubs['dir']), desktopSize.width(), desktopSize.height())
            tmpUri = strwithmeta(self.fileSRC)

            audioUri = ''
            videoUri = self.fileSRC
            if self.fileSRC.startswith('merge://') and 'audio_url' in tmpUri.meta and 'video_url' in tmpUri.meta:
                audioUri = tmpUri.meta['audio_url']
                videoUri = tmpUri.meta['video_url']
                sts, audioUri = CreateTmpFile('.iptv_audio_uri', audioUri)
                sts, videoUri = CreateTmpFile('.iptv_video_uri', videoUri)
                audioUri = 'iptv://' + audioUri
                videoUri = 'iptv://' + videoUri
                if not sts:
                    msg = _("An error occurred while writing into: %s") % GetTmpDir()
                    self.showMessage(msg, MessageBox.TYPE_ERROR)
            elif tmpUri.meta.get('iptv_dash_sel'):
                # the MPD with only the chosen video / audio representation (dashdec opens all of them otherwise)
                videoUri = dashmpd.localManifestUrl(tmpUri) or videoUri
            if "://" in self.fileSRC:
                ramBufferSizeMB = config.plugins.iptvplayer.rambuffer_sizemb_network_proto.value
                url, httpParams = DMHelper.getDownloaderParamFromUrlWithMeta(tmpUri, True)
                # cmd += ' ""' # cookies for now will be send in headers
                headers = ''
                for key in httpParams:
                    if key == 'Range':  # Range is always used by ffmpeg
                        continue
                    elif key == 'User-Agent':
                        cmd += ' -u "%s"' % shellQuote(httpParams[key])
                    elif key == 'http_proxy':
                        # ffmpeg's http option (also for the HLS / DASH segments), it used to go
                        # out as an "http_proxy:" request header and no proxy was used
                        cmd += ' -f "http_proxy=%s"' % shellQuote(httpParams[key])
                    else:
                        headers += ('%s: %s\r\n' % (key, httpParams[key]))
                if len(headers):
                    cmd += ' -h "%s"' % shellQuote(headers)
                if url.startswith('http'):
                    url = urlparser.decorateParamsFromUrl(url)
                    if '1' == url.meta.get('MPEGTS-Live', '0'):
                        cmd += ' -v '
                programId = url.meta.get('PROGRAM-ID', '')
                if programId != '':
                    cmd += ' -P "%s" ' % shellQuote(programId)
            else:
                ramBufferSizeMB = config.plugins.iptvplayer.rambuffer_sizemb_files.value

            if ramBufferSizeMB > 0:
                cmd += ' -b %s ' % ramBufferSizeMB

            if config.plugins.iptvplayer.stereo_software_decode.value:
                cmd += ' -s '

            if config.plugins.iptvplayer.dts_software_decode.value:
                cmd += ' -d '

            if config.plugins.iptvplayer.wma_software_decode.value:
                cmd += ' -w '
            if config.plugins.iptvplayer.mp3_software_decode.value:
                cmd += ' -m '
            if config.plugins.iptvplayer.eac3_software_decode.value:
                cmd += ' -e '
            if config.plugins.iptvplayer.ac3_software_decode.value:
                cmd += ' -3 '
            if 'lpcm' == config.plugins.iptvplayer.software_decode_as.value:
                cmd += ' -l '

            if config.plugins.iptvplayer.aac_software_decode.value:
                cmd += ' -a 3 -p 10'
            else:
                cmd += ' -p 2'
                if None is not self.downloader:
                    cmd += ' -o 1 '

            audioTrackIdx = self.metaHandler.getAudioTrackIdx()
            printDBG(">>>>>>>>>>>>>>>>>>>>>>>> audioTrackIdx[%d]" % audioTrackIdx)
            if audioTrackIdx >= 0:
                cmd += ' -t %d ' % audioTrackIdx

            subtitleTrackIdx = self.metaHandler.getEmbeddedSubtileTrackIdx()
            printDBG(">>>>>>>>>>>>>>>>>>>>>>>> subtitleTrackIdx[%d]" % subtitleTrackIdx)
            if subtitleTrackIdx >= 0:
                cmd += ' -9 %d ' % subtitleTrackIdx

            if audioUri != '':
                cmd += ' -x "%s" ' % shellQuote(audioUri)

            if 'iptv_m3u8_live_start_index' in tmpUri.meta:
                cmd += ' -f "live_start_index=%s" ' % shellQuote(tmpUri.meta['iptv_m3u8_live_start_index'])

            if 'iptv_m3u8_key_uri_replace_old' in tmpUri.meta and 'iptv_m3u8_key_uri_replace_new' in tmpUri.meta:
                cmd += ' -f "key_uri_old=%s" -f "key_uri_new=%s" ' % (shellQuote(tmpUri.meta['iptv_m3u8_key_uri_replace_old']), shellQuote(tmpUri.meta['iptv_m3u8_key_uri_replace_new']))

            if self.extAdditionalParams.get('moov_atom_file', '') != '':
                cmd += ' -F "%s" -S %s -O %s' % (shellQuote(self.extAdditionalParams['moov_atom_file']), self.extAdditionalParams['moov_atom_offset'] + self.extAdditionalParams['moov_atom_size'], self.extAdditionalParams['moov_atom_offset'])

            cmd += (' "%s"' % shellQuote(videoUri)) + " > /dev/null"

        self.console = eConsoleAppContainer()
        self.console_appClosed_conn = eConnectCallback(self.console.appClosed, self.eplayer3Finished)
        self.console_stderrAvail_conn = eConnectCallback(self.console.stderrAvail, self.eplayer3DataAvailable)
        # if 'gstplayer' == self.player:
        #    self.console_stdoutAvail_conn = eConnectCallback(self.console.stdoutAvail, self.eplayer3DataAvailable2 ) # work around to catch EOF event after seeking, pause .etc
        printDBG("->||||||| onStart cmd[%s]" % cmd)
        if hasattr(self.console, "setNice"):
            self.console.setNice(GetNice() + 1)
            self.console.execute(cmd)
        else:
            self.console.execute(E2PrioFix(cmd, 1))
        self['statusIcon'].setPixmap(self.playback['statusIcons']['Play'])  # sulge for test
        self['loopIcon'].setPixmap(self.playback['loopIcons']['Off'])
        self['logoIcon'].setPixmap(self.playback['logoIcon'])
        self['subSynchroIcon'].setPixmap(self.subHandler['synchro']['icon'])
        # at least the stream type until the player reports the video track ("v_c" overwrites it) -
        # gstplayer2 reports none for a buffer file ffmpeg is still writing (merged audio/video)
        streamType = self._getStreamTypeLabel()
        if streamType and not self.playback['VideoTrack']:
            self['videoInfo'].setText(streamType)

        # SET Video option
        videoOptions = ['aspect', 'policy', 'policy2']
        playerDefOptions = self.configObj.getDefaultPlayerVideoOptions()
        for opt in videoOptions:
            val = self.metaHandler.getVideoOption(opt)
            if val is not None:
                self.currVideoOptions[opt] = val
            elif playerDefOptions[opt] is not None:
                self.currVideoOptions[opt] = playerDefOptions[opt]

        videoOptionChange = False
        self.defVideoOptions.update(self.getE2VideoOptions())
        for opt in videoOptions:
            val = self.currVideoOptions[opt]
            if val in self.defVideoOptions['%s_choices' % opt] and val != self.defVideoOptions[opt]:
                videoOptionChange = True
                self.currVideoOptions[opt] = val
            else:
                self.currVideoOptions[opt] = self.defVideoOptions[opt]

        if videoOptionChange:
            self.applyVideoOptions(self.currVideoOptions)

        # SET Audio option
        self.defAudioOptions = self.getE2AudioOptions()
        playerDefOptions = self.configObj.getDefaultAudioOptions()
        audioOptions = ['ac3', 'aac']
        for opt in audioOptions:
            if playerDefOptions[opt] is not None and playerDefOptions[opt] != self.defAudioOptions[opt]:
                SetE2AudioCodecMixOption(opt, playerDefOptions[opt])

        self.enableSubtitles()

    def fixWindowGeometry(self):
        # initGuiComponentsPos() places the infobar in real desktop pixels,
        # so the window itself must cover exactly the desktop at 0,0.
        #
        # resolution="1280,720" is not honoured the same way everywhere:
        # OpenATV scales every position=/size= (the window's own included),
        # OpenHDF 7.5 (OpenPLi-style SkinContext, which turns position=/
        # size= into final pixel tuples before the scale is applied) scales
        # the fonts only. There the window stayed 1280x720 in the middle
        # of a FHD desktop and clipped the infobar away, and the widgets
        # kept their 1280x720 boxes with 1.5x fonts in them. A window that
        # still has the reference size on a bigger desktop tells the two
        # apart - the widgets are then scaled here instead.
        try:
            desktopW = getDesktop(0).size().width()
            desktopH = getDesktop(0).size().height()
            windowW = self.instance.size().width()
            windowH = self.instance.size().height()
            printDBG("IPTVExtMoviePlayer window %dx%d at %d,%d -> desktop %dx%d" % (windowW, windowH, self.instance.position().x(), self.instance.position().y(), desktopW, desktopH))
            self.instance.move(ePoint(0, 0))
            self.instance.resize(eSize(desktopW, desktopH))
            if not self.skinUsesRefCanvas or (windowW, windowH) != (self.REF_W, self.REF_H) or (desktopW, desktopH) == (self.REF_W, self.REF_H):
                return
            scaleX = desktopW / float(self.REF_W)
            scaleY = desktopH / float(self.REF_H)
            printDBG("IPTVExtMoviePlayer skin engine did not scale the widgets - scaling them by %.2fx%.2f" % (scaleX, scaleY))
            done = set()
            for widget in list(self.values()) + list(getattr(self, 'renderer', [])) + list(getattr(self, 'additionalWidgets', [])):
                instance = getattr(widget, 'instance', None)
                if instance is None or id(widget) in done:
                    continue
                done.add(id(widget))
                try:
                    pos = instance.position()
                    size = instance.size()
                    instance.resize(eSize(int(size.width() * scaleX), int(size.height() * scaleY)))
                    instance.move(ePoint(int(pos.x() * scaleX), int(pos.y() * scaleY)))
                except Exception:
                    printExc()
        except Exception:
            printExc()

    def initPleaseWaitBox(self):
        # the notice has a half-transparent backdrop (plain grey text straight on the video
        # looked pixelated): remember the skin's box once, setPleaseWait() shrinks it to the text
        try:
            instance = self['pleaseWait'].instance
            pos = instance.position()
            size = instance.size()
            desktopW = getDesktop(0).size().width()
            centered = abs(pos.x() + size.width() / 2.0 - desktopW / 2.0) < 3
            self.pleaseWaitBox = (pos.x(), pos.y(), size.width(), size.height(), centered)
            self.fitPleaseWaitBox()
        except Exception:
            printExc()

    def fitPleaseWaitBox(self):
        box = getattr(self, 'pleaseWaitBox', None)
        if box is None:
            return
        try:
            x, y, w, h, centered = box
            instance = self['pleaseWait'].instance
            # calculateSize() measures the box first, so it starts from the full skin width
            instance.resize(eSize(w, h))
            pad = max(8, h // 2)
            newW = min(w, instance.calculateSize().width() + 2 * pad)
            if centered:
                x += (w - newW) // 2
            instance.resize(eSize(newW, h))
            instance.move(ePoint(x, y))
        except Exception:
            printExc()

    def setPleaseWait(self, text):
        self['pleaseWait'].setText(text)
        self.fitPleaseWaitBox()
        self['pleaseWait'].show()

    def initGuiComponentsPos(self):
        # widget sizes are final here (the instances don't exist in __init__)
        try:
            self._prescaleSkinPixmaps()
        except Exception:
            printExc()

        # info bar gui elements
        # calculate offset
        offset_x = (getDesktop(0).size().width() - self['playbackInfoBaner'].instance.size().width()) / 2
        offset_y = (getDesktop(0).size().height() - self['playbackInfoBaner'].instance.size().height()) - self.Y_CROPPING_GUARD
        if offset_x < 0:
            offset_x = 0
        if offset_y < 0:
            offset_y = 0

        self.infoBanerOffsetY = offset_y + self['playbackInfoBaner'].position[1]
        tmp = offset_y + self['logoIcon'].position[1]
        if tmp < self.infoBanerOffsetY:
            self.infoBanerOffsetY = tmp

        for elem in self.playbackInfoBar['guiElemNames']:
            self[elem].setPosition(self[elem].position[0] + offset_x, self[elem].position[1] + offset_y)
        try:
            for elem in ('playbackInfoBaner', 'progressBar', 'currTimeLabel'):
                printDBG("IPTVExtMoviePlayer %s at %d,%d size %dx%d" % (elem, self[elem].instance.position().x(), self[elem].instance.position().y(), self[elem].instance.size().width(), self[elem].instance.size().height()))
        except Exception:
            printExc()

        # sub synchro elements
        # calculate offset
        offset_x = (getDesktop(0).size().width() - self['subSynchroIcon'].instance.size().width()) / 2
        offset_y = (getDesktop(0).size().height() - self['subSynchroIcon'].instance.size().height()) / 2
        if offset_x < 0:
            offset_x = 0
        if offset_y < 0:
            offset_y = 0

        for elem in self.subHandler['synchro']['guiElemNames']:
            self[elem].setPosition(self[elem].position[0] + offset_x, self[elem].position[1] + offset_y)

    def showPlaybackInfoBar(self, excludeElems=['goToSeekPointer', 'goToSeekLabel'], blocked=None):
        self.playbackInfoBar['timer'].stop()

        for elem in self.playbackInfoBar['guiElemNames']:
            if elem not in excludeElems:
                self[elem].show()

        if None is blocked or self.playbackInfoBar['blocked']:
            blocked = self.playbackInfoBar['blocked']

        self.playbackInfoBar['visible'] = True

        if not blocked:
            self.playbackInfoBar['timer'].start(self.autoHideTime, True)  # singleshot
        self.setSubOffsetFromInfoBar()
        if -1 != self.subHandler['current_sub_time_ms']:
            self.updateSubtitles(self.subHandler['current_sub_time_ms'], True)

        if self.clockFormat:
            self.updateClock()
            self.playbackInfoBar['clock_timer'].start(1000)

    def hidePlaybackInfoBar(self, excludeElems=[], force=False):
        self.playbackInfoBar['timer'].stop()

        if self.playbackInfoBar['blocked'] and not force:
            return

        for elem in self.playbackInfoBar['guiElemNames']:
            if elem not in excludeElems:
                self[elem].hide()

        self.playbackInfoBar['visible'] = False
        self.setSubOffsetFromInfoBar()
        if -1 != self.subHandler['current_sub_time_ms']:
            self.updateSubtitles(self.subHandler['current_sub_time_ms'], True)

        if self.clockFormat:
            self.playbackInfoBar['clock_timer'].stop()

    def updateClock(self):
        if self.clockFormat == '24':
            timeFormatString = self.skinSettings.get("clockFormat_24H", "%H:%M")
            self['clockTime'].setText(time.strftime(timeFormatString))
        elif self.clockFormat == '12':
            timeFormatString = self.skinSettings.get("clockFormat_12H", "%I:%M")
            self['clockTime'].setText(time.strftime(timeFormatString))

    def _showHideSubSynchroControl(self, show=True):
        for elem in self.subHandler['synchro']['guiElemNames']:
            if show:
                self[elem].show()
            else:
                self[elem].hide()
        self.subHandler['synchro']['visible'] = show

    def setSubOffsetFromInfoBar(self):
        if self.playbackInfoBar['visible']:
            desktopH = getDesktop(0).size().height()
            if self.subLinesNum > 1:
                # calc sub pos - scale/_effectiveSubLineHeight here
                # must match setSubtitlesText()'s own real-pixel math
                # exactly, or this overlap check against
                # self.infoBanerOffsetY (already real, correctly-scaled
                # pixels from initGuiComponentsPos()) would compare
                # mismatched units at FHD/WQHD
                scale = self._subtitleScale()
                lineHeight = self._effectiveSubLineHeight(scale)
                subY = desktopH - int(self.subConfig['pos'] * scale) - lineHeight
                subH = lineHeight

                yOffset = subY + subH - self.infoBanerOffsetY
                if yOffset > 0:
                    self.subHandler['pos_y_offset'] = yOffset
                    return
        self.subHandler['pos_y_offset'] = 0

    def showSubSynchroControl(self):
        self._showHideSubSynchroControl(True)
        self.updateSubSynchroControl()

    def hideSubSynchroControl(self, excludeElems=[], force=False):
        self._showHideSubSynchroControl(False)

    def __onShow(self):
        pass
        # Screen.hide(self) # we do not need window at now maybe in future

    def fatalErrorHandler(self, msg):
        if self.fatalErrorOccurs:
            return
        self.fatalErrorOccurs = True
        self.showMessage(msg, MessageBox.TYPE_ERROR, self._fatalErrorCallback)

    def _fatalErrorCallback(self):
        self.waitCloseTimeoutCallback()

    def consoleWrite(self, data):
        try:
            self.console.write(data, len(data))
            return
        except Exception:
            try:
                self.console.write(data)
                return
            except Exception:
                printExc()
        msg = _("Fatal error: consoleWrite failed!")
        self.fatalErrorHandler(msg)

    def extPlayerSendCommand(self, command, arg1=''):
        # printDBG("IPTVExtMoviePlayer.extPlayerSendCommand command[%s] arg1[%s]" % (command, arg1))
        if None is self.console:
            printExc("IPTVExtMoviePlayer.extPlayerSendCommand console not available")
            return False

        if 'ADD_TRIGGERS' == command:
            self.consoleWrite("t{0}\n".format(arg1))
        elif 'PLAYBACK_SET_LOOP_MODE' == command:
            self.consoleWrite("n%s\n" % arg1)
        elif 'PLAYBACK_LENGTH' == command:
            self.consoleWrite("l\n")
        elif 'PLAYBACK_CURRENT_TIME' == command:
            self.consoleWrite("j\n")
        elif 'PLAYBACK_INFO' == command:
            self.consoleWrite("i\n")
        elif 'PLAYBACK_SET_DOWNLOAD_FILE_TIMEOUT' == command:
            self.consoleWrite("t%s\n" % arg1)
        elif 'PLAYBACK_SET_PROGRESSIVE_DOWNLOAD' == command:
            self.consoleWrite("o%s\n" % arg1)
        elif 'PLAYBACK_SET_SUBTITLE_TRACK' == command:
            if ('%s' % arg1) != '-1':
                # we need be in play mode to switch/enabled embedded subtitles
                self.consoleWrite("c\n")
            self.consoleWrite("s%s\n" % arg1)
            self.consoleWrite("sc\n")
        else:
            # All below commands require that 'PLAY ' status,
            # so we first send command to resume playback
            self.consoleWrite("c\n")

            if 'PLAYBACK_CONTINUE' == command:
                pass  # the "c" above already resumed
            elif 'PLAYBACK_PAUSE' == command:
                self.consoleWrite("p\n")
            elif 'PLAYBACK_SET_AUDIO_TRACK' == command:
                self.consoleWrite("a%s\n" % arg1)
                self.consoleWrite("ac\n")
            elif 'PLAYBACK_SEEK_RELATIVE' == command:
                self.consoleWrite("kc%s\n" % (arg1))
            elif 'PLAYBACK_SEEK_ABS' == command:
                self.consoleWrite("gf%s\n" % (arg1))
            elif 'PLAYBACK_FASTFORWARD' == command:
                self.consoleWrite("f%s\n" % arg1)
            elif 'PLAYBACK_FASTBACKWARD' == command:
                self.consoleWrite("b%s\n" % arg1)
            elif 'PLAYBACK_SLOWMOTION' == command:
                self.consoleWrite("m%s\n" % arg1)
            elif 'PLAYBACK_STOP' == command:
                printDBG("IPTVExtMoviePlayer.extPlayerSendCommand PLAYBACK_STOP")
                if not self.waitCloseFix['waiting']:
                    self.waitCloseFix['waiting'] = True
                    self.waitCloseFix['timer'].start(5000, True)  # singleshot
                self.consoleWrite("q\n")
            else:
                printDBG("IPTVExtMoviePlayer.extPlayerSendCommand unknown command[%s]" % command)
                return False
        return True

    def createSummary(self):
        summary = config.plugins.iptvplayer.extplayer_summary.value
        create = False
        if summary == 'yes':
            create = True
        elif summary == 'auto':
            try:
                if getDesktop(1).size().width() > 132:
                    create = True
            except Exception:
                pass
        if create:
            return IPTVExtMoviePlayerColorSummary if isLargeLcd() else IPTVExtMoviePlayerSummary
        return None
