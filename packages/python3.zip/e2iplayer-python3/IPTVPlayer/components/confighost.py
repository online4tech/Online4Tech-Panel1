# -*- coding: utf-8 -*-
#
#  Konfigurator dla iptv 2013
#  autorzy: j00zek, samsamsam
#

###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, IsHostEnabled, SaveHostsOrderList, SortHostsList
from Plugins.Extensions.IPTVPlayer.components.configbase import ConfigBaseWidget
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.iptvhostpin import AskHostPin, GetHostDisplayTitle, GetHostPinConfigList, HandleHostPinAction, HostNeedsPin, HOST_PIN_ACTION
###################################################

###################################################
# FOREIGN import
###################################################
from enigma import gRGB
from Screens.MessageBox import MessageBox
from Components.config import config, getConfigListEntry, NumericalTextInput
from Tools.BoundFunction import boundFunction
###################################################


class ConfigHostMenu(ConfigBaseWidget):

    # BLUE = search in the host's settings
    HAS_BLUE_KEY = True

    def __init__(self, session, hostName):
        printDBG("ConfigHostMenu.__init__ ")
        self.list = []
        self.hostName = hostName
        ConfigBaseWidget.__init__(self, session)
        self["key_blue"].setText(_("Search"))
        self.setup_title = _("Configuration [%s] service") % self.hostName
        self.host = __import__('Plugins.Extensions.IPTVPlayer.hosts.host' + hostName, globals(), locals(), ['GetConfigList'], 0)

    def __del__(self):
        printDBG("ConfigHostMenu.__del__ ")

    def __onClose(self):
        printDBG("ConfigHostMenu.__onClose ")
        ConfigBaseWidget.__onClose(self)

    def layoutFinished(self):
        ConfigBaseWidget.layoutFinished(self)
        self.setTitle("E2iPlayer " + (_("[%s] - configuration") % self.hostName))

    def runSetup(self):
        # the host's own settings, then the PIN protection every host has
        getConfigList = getattr(self.host, 'GetConfigList', None)
        self.list = list(getConfigList()) if callable(getConfigList) else []
        # a host whose settings come in sections ("----- ... -----" rows, e.g. hostxxx) gets one for the PIN too,
        # so the PIN rows do not look like part of its last section
        if any(entry and str(entry[0]).strip().startswith('-----') for entry in self.list):
            self.list.append(getConfigListEntry(_("----- SECURITY CONFIGURATION -----"),))
        self.list.extend(GetHostPinConfigList(self.hostName))
        ConfigBaseWidget.runSetup(self)

    def keyDefaults(self):
        # YELLOW: the host's own settings only - its PIN protection stays as it is
        getConfigList = getattr(self.host, 'GetConfigList', None)
        if not callable(getConfigList):
            return

        def keyDefaultsConfirm(result):
            if result:
                self.resetToDefaults(lambda: list(getConfigList()))
        message = _('Reset the settings of "%s" to their default values?') % GetHostDisplayTitle(self.hostName)
        self.session.openWithCallback(keyDefaultsConfirm, MessageBox, text=message, type=MessageBox.TYPE_YESNO, default=False)

    def keyOK(self):
        # A host may expose an "action row" in its GetConfigList() - a config
        # element carrying an `iptv_host_action` attribute - to run something
        # interactive (a sign-in dialog, a device pairing) straight from its
        # settings screen, which otherwise only edits plain config values.
        # The host module then handles it in a module-level HandleConfigAction
        # (session, action, callback) and calls the callback to have the list
        # redrawn (e.g. a "Sign in" row becoming "Sign out").
        try:
            currItem = self["config"].getCurrent()[1]
        except Exception:
            printExc()
            currItem = None
        action = getattr(currItem, "iptv_host_action", "") if currItem is not None else ""
        if action == HOST_PIN_ACTION:
            HandleHostPinAction(self.session, self.hostName, boundFunction(self._afterConfigAction))
            return
        if action:
            handler = getattr(self.host, "HandleConfigAction", None)
            if callable(handler):
                try:
                    handler(self.session, action, boundFunction(self._afterConfigAction))
                except Exception:
                    printExc()
                return
        ConfigBaseWidget.keyOK(self)

    def keyBlue(self):
        self.openSearch()

    def _afterConfigAction(self, *args):
        try:
            self.runSetup()
        except Exception:
            printExc()

    def changeSubOptions(self):
        try:
            if not isinstance(self["config"].getCurrent()[1], NumericalTextInput):
                self.runSetup()
        except Exception:
            pass


class ConfigHostsMenu(ConfigBaseWidget):
    # BLUE is a direct "Enable/Disable reordering mode" toggle rather
    # than a MENU+ChoiceBox popup with just that one option, so MENU
    # falls through to ConfigBaseWidget's own inherited keyMenu() (a
    # per-item ConfigSelection value popup) instead of being overridden
    # here.
    HAS_BLUE_KEY = True

    def __init__(self, session, listOfHostsNames):
        printDBG("ConfigHostsMenu.__init__ ")
        self.list = []
        self.hostsConfigsAvailableList = []
        self.listOfHostsNames = []
        self.orgListOfHostsNames = SortHostsList(listOfHostsNames)
        ConfigBaseWidget.__init__(self, session)
        self.setup_title = _("Services configuration")
        self.__preparHostsConfigs(self.orgListOfHostsNames)

        self.reorderingEnabled = False
        self.reorderingMode = False
        self._updateBlueLabel()

    def __del__(self):
        printDBG("ConfigHostsMenu.__del__ ")

    def __onClose(self):
        printDBG("ConfigHostsMenu.__onClose ")
        ConfigBaseWidget.__onClose(self)

    def layoutFinished(self):
        ConfigBaseWidget.layoutFinished(self)
        self.setTitle(_("%s services configuration") % ('E2iPlayer'))

    def runSetup(self):
        ConfigBaseWidget.runSetup(self)

    # def changeSubOptions(self):
    #    self.runSetup()

    def isChanged(self):
        if self.orgListOfHostsNames != self.listOfHostsNames:
            return True
        return ConfigBaseWidget.isChanged(self)

    def saveOrCancel(self, operation="save"):
        if "save" == operation:
            if self.orgListOfHostsNames != self.listOfHostsNames:
                SaveHostsOrderList(self.listOfHostsNames)
        ConfigBaseWidget.saveOrCancel(self, operation)

    def isOkActive(self):
        curIndex = self["config"].getCurrentIndex()
        if curIndex < len(self.hostsConfigsAvailableList):
            return self.hostsConfigsAvailableList[curIndex]
        return False

    def setOKLabel(self):
        # ConfigBaseWidget's own OK/footnote hint writes to "footnote",
        # not "key_ok" - that widget name doesn't exist. Plain "OK" (no
        # "<  OK  >" brackets) here since this override's whole point is
        # to suppress the base class's "value is left/right-adjustable"
        # formatting while reordering is enabled.
        if self.reorderingEnabled:
            self["footnote"].setText(_("OK"))
        else:
            ConfigBaseWidget.setOKLabel(self)

    def keyOK(self):
        if self["config"].instance is None:
            return
        if self.reorderingEnabled:
            if not self.reorderingMode:
                self["config"].instance.setForegroundColorSelected(gRGB(0xFF0505))
                self.reorderingMode = True
            else:
                self["config"].instance.setForegroundColorSelected(gRGB(0xFFFFFF))
                self.reorderingMode = False
            self.runSetup()
            return

        curIndex = self["config"].getCurrentIndex()
        currItem = self["config"].list[curIndex][1]
        if curIndex < len(self.listOfHostsNames):
            hostName = self.listOfHostsNames[curIndex]
            if self.hostsConfigsAvailableList[curIndex] and IsHostEnabled(hostName, switchOnly=True):
                # every host has settings: at least its PIN protection
                try:
                    __import__('Plugins.Extensions.IPTVPlayer.hosts.host' + hostName, globals(), locals(), ['GetConfigList'], 0)
                except Exception:
                    printExc('ConfigMenu host "%s" cannot be loaded' % hostName)
                    self.hostsConfigsAvailableList[curIndex] = False
                    self.onSelectionChanged()
                    self.session.open(MessageBox, _("Settings of service [%s] cannot be opened.") % hostName, type=MessageBox.TYPE_INFO, timeout=5)
                    return
                openSettings = boundFunction(self.session.open, ConfigHostMenu, hostName=hostName)
                if HostNeedsPin(hostName):
                    # a protected host's settings (also the protection itself) only with its PIN
                    AskHostPin(self.session, hostName, openSettings)
                else:
                    openSettings()
        else:
            ConfigBaseWidget.keyOK(self)

    def _updateBlueLabel(self):
        self["key_blue"].setText(_("Disable reordering mode") if self.reorderingEnabled else _("Enable reordering mode"))

    def keyBlue(self):
        # a direct BLUE toggle is simpler for a plain on/off switch than
        # a MENU+ChoiceBox popup, and frees MENU back up for
        # ConfigBaseWidget's own inherited per-item value popup.
        self.reorderingEnabled = not self.reorderingEnabled
        if not self.reorderingEnabled:
            self.reorderingMode = False
            self["config"].instance.setForegroundColorSelected(gRGB(0xFFFFFF))
            self.runSetup()
        self._updateBlueLabel()
        self.setOKLabel()

    def _moveItem(self, curIndex):
        assert (len(self.list) == len(self.hostsConfigsAvailableList) == len(self.listOfHostsNames))
        newIndex = self["config"].getCurrentIndex()
        if 0 <= curIndex and len(self.list) > curIndex and 0 <= newIndex and len(self.list) > newIndex:
            printDBG(">>>>>>>>>>>>>>>>>>> _moveItem")
            self.list.insert(newIndex, self.list.pop(curIndex))
            self.hostsConfigsAvailableList.insert(newIndex, self.hostsConfigsAvailableList.pop(curIndex))
            self.listOfHostsNames.insert(newIndex, self.listOfHostsNames.pop(curIndex))
            self.runSetup()

    def keyUp(self):
        if self.reorderingMode:
            printDBG(">>>>>>>>>>>>>>>>>>> keyUp")
            curIndex = self["config"].getCurrentIndex()
            ConfigBaseWidget.keyUp(self)
            self._moveItem(curIndex)
        else:
            ConfigBaseWidget.keyUp(self)

    def keyDown(self):
        if self.reorderingMode:
            printDBG(">>>>>>>>>>>>>>>>>>> keyDown")
            curIndex = self["config"].getCurrentIndex()
            ConfigBaseWidget.keyDown(self)
            self._moveItem(curIndex)
        else:
            ConfigBaseWidget.keyDown(self)

    def keyPageUp(self):
        if not self.reorderingEnabled:
            ConfigBaseWidget.keyPageUp(self)

    def keyPageDown(self):
        if not self.reorderingEnabled:
            ConfigBaseWidget.keyPageDown(self)

    def keyLeft(self):
        if not self.reorderingEnabled:
            ConfigBaseWidget.keyLeft(self)

    def keyRight(self):
        if not self.reorderingEnabled:
            ConfigBaseWidget.keyRight(self)

    def changedEntry(self):
        # the host on/off list has no sub options: keep ConfigBaseWidget.changedEntry() (sub option
        # rebuild) out of it (this used to hold the legal warning of the ipla host, now in Backup)
        pass

    def __preparHostsConfigs(self, listOfHostsNames):
        '''
        prepar config entries for hosts Enabling/Disabling
        '''
        self.list = []
        self.hostsConfigsAvailableList = []
        self.listOfHostsNames = []
        sortedList = list(listOfHostsNames)
        for hostName in sortedList:
            try:
                optionEntry = getattr(config.plugins.iptvplayer, 'host' + hostName)
                self.list.append(getConfigListEntry(hostName, optionEntry))
                self.hostsConfigsAvailableList.append(True)
                self.listOfHostsNames.append(hostName)
            except Exception:
                printExc()
