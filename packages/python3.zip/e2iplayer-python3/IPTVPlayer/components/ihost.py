# @file  ihost.py
# Last Modified: 2026-09-20 - CDisplayListItem.isFavourite/downloadState (row markers), CHostBase.getRowUrl()/getFavouriteDataOfRow()
# 2026-08-18 - CBaseHostClass.searchItems() now adds "search_history_editor" between "search_history" and "delete_history".
# CHostBase.getListForItem() catches this category and opens SearchHistoryEditor before any host handleService() runs.
# CHostBase.setSearchPattern() no longer calls addHistoryItem() when a history entry is re-selected, only getSearchResults() writes new entries
# Applies automatically to all hosts using CBaseHostClass - Kamikaze24
#

###################################################
# E2 GUI COMMPONENTS
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _, GetIPTVNotify
from Plugins.Extensions.IPTVPlayer.components.asynccall import MainSessionWrapper
from Plugins.Extensions.IPTVPlayer.libs.pCommon import common, CParsingHelper
from Plugins.Extensions.IPTVPlayer.libs.urlparser import urlparser
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import CSearchHistoryHelper, GetCookieDir, GetIconDir, printDBG, printExc, GetLogoDir
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps

from Components.config import config
from skin import parseColor

from Plugins.Extensions.IPTVPlayer.p2p3.manipulateStrings import ensure_str
from Screens.MessageBox import MessageBox
from Plugins.Extensions.IPTVPlayer.components.searchhistoryeditor import SearchHistoryEditor
from Plugins.Extensions.IPTVPlayer.components.iptvhostpin import HostNameOf, IsHostPinProtected, GetHostPinCode
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
import os
import re

# icon urls scraped from JSON inside a page instead of decoding it: "https:\/\/x\/a.jpg?w=1&h=2"
ICON_JSON_ESCAPE_RE = re.compile(r'\\u([0-9a-fA-F]{4})')


class CUrlItem:
    def __init__(self, name="", url="", urlNeedsResolve=0):
        if isinstance(name, str):
            self.name = name
        else:
            self.name = str(name)

        # used only for TYPE_VIDEO item
        if isinstance(url, str):
            self.url = url
        else:
            self.url = str(url)

        self.urlNeedsResolve = urlNeedsResolve  # additional request to host is needed to resolv this url (url is not direct link)
        # transient, session-only flag: set when resolving this mirror failed, so the
        # "Select link" list can highlight it; reset whenever the item's urlItems list
        # is rebuilt from a fresh host request (see iptvplayerwidget.py)
        self.failed = False
# class CDisplayListItem
# define attribiutes for item of diplay list
# communicate display layer with host
#


class CDisplayListItem:
    TYPE_CATEGORY = "CATEGORY"
    TYPE_VIDEO = "VIDEO"
    TYPE_AUDIO = "AUDIO"
    TYPE_SEARCH = "SEARCH"
    TYPE_ARTICLE = "ARTICLE"
    TYPE_PICTURE = "PICTURE"
    TYPE_DATA = "DATA"
    TYPE_MORE = "MORE"
    TYPE_MARKER = "MARKER"
    TYPE_SEARCH_HISTORY = "SEARCH_HISTORY"
    TYPE_SEARCH_HISTORY_EDITOR = "SEARCH_HISTORY_EDITOR"
    TYPE_SEARCH_HISTORY_DELETE = "SEARCH_HISTORY_DELETE"
    TYPE_NEXT = "NEXT"
    TYPE_DOWNLOAD = "DOWNLOAD"
    TYPE_MMC = "MMC"
    TYPE_USB = "USB"
    TYPE_WWW = "WWW"
    TYPE_JUMP = "JUMP"
    TYPE_FIRST = "FIRST"
    TYPE_PREVIOUS = "PREVIOUS"
    TYPE_LAST = "LAST"
    TYPE_SUBTITLE = "SUBTITLE"
    TYPE_SUB_PROVIDER = "SUB_PROVIDER"
    TYPE_UNKNOWN = "UNKNOWN"

    # item types that open a modal/perform an in-place action instead of
    # navigating to a different list - selecting one must not push a
    # nav-stack entry, since there would be nothing meaningful to go back to
    NON_NAVIGATING_TYPES = frozenset([TYPE_SEARCH_HISTORY_EDITOR])

    def __init__(self, name="",
                description="",
                type=TYPE_UNKNOWN,
                urlItems=[],
                urlSeparateRequest=0,
                iconimage='',
                possibleTypesOfSearch=None,
                pinLocked=False,
                isGoodForFavourites=False,
                isWatched=False,
                isStarted=False,
                textColor='',
                pinCode='',
                imageType=None):

        if isinstance(name, str):
            self.name = name
        else:
            self.name = str(name)

        if callable(description):
            self._description = description
        elif isinstance(description, str):
            self._description = description
        else:
            self._description = str(description)

        if isinstance(type, str):
            self.type = type
        else:
            self.type = str(type)

        self.imageType = imageType or self.type

        if isinstance(iconimage, str):
            self.iconimage = iconimage
        else:
            self.iconimage = str(iconimage)

        if pinLocked:
            self.pinLocked = True
        else:
            self.pinLocked = False

        self.pinCode = str(pinCode)
        # name of the PIN protected host a favourite comes from ('' = none)
        self.pinHost = ''

        if isGoodForFavourites:
            self.isGoodForFavourites = True
        else:
            self.isGoodForFavourites = False

        if isWatched:
            self.isWatched = True
        else:
            self.isWatched = False

        if isStarted:
            self.isStarted = True
        else:
            self.isStarted = False

        self.textColor = str(textColor)

        # markers drawn at the end of the row (components/iptvlist.py), set by the list widget:
        # already in the favourites / download state ('' | 'active' | 'done', tools/iptvdownloaded.py)
        self.isFavourite = False
        self.downloadState = ''

        # used only for TYPE_VIDEO item
        self.urlItems = urlItems  # url to VIDEO
        # links are not available the separate request is needed to get links
        self.urlSeparateRequest = urlSeparateRequest
        # used only for TYPE_SEARCH item
        self.possibleTypesOfSearch = possibleTypesOfSearch
        self.privateData = None
        self.itemIdx = -1

    def getDisplayTitle(self):
        # watched/started state is shown via the icon overlay badge
        # (see components/iptvlist.py), not a title prefix
        return self.name

    def getTextColor(self):
        try:
            if self.textColor != '':
                return parseColor(self.textColor).argb()
            if self.isWatched:
                return parseColor(config.plugins.iptvplayer.watched_item_color.value).argb()
            if self.isStarted:
                return parseColor(config.plugins.iptvplayer.started_item_color.value).argb()
            # 'done' = tools/iptvdownloaded.STATE_DONE; both states are only set while their "Mark ... items" option is on
            if self.downloadState == 'done':
                return parseColor(config.plugins.iptvplayer.downloaded_item_color.value).argb()
            if self.isFavourite:
                return parseColor(config.plugins.iptvplayer.favourite_item_color.value).argb()
        except Exception:
            printExc()
        return None

    def _getDescription(self):
        if callable(self._description):
            return self._description()
        return self._description

    def _setDescription(self, description):
        self._description = description

    description = property(_getDescription, _setDescription)


class ArticleContent:
    VISUALIZER_DEFAULT = 'DEFAULT'
    # Posible args and values for richDescParams:
    RICH_DESC_PARAMS = [
        "alternate_title", "original_title", "station", "price", "age_limit", "views", "status", "type", "first_air_date", "last_air_date", "seasons", "episodes", "country", "language", "duration", "quality", "subtitles", "year", "imdb_rating", "tmdb_rating",
        "released", "broadcast", "remaining", "rating", "rated", "genre", "genres", "category", "categories", "production", "director", "directors", "writer", "writers",
        "creator", "creators", "cast", "actors", "stars", "awards", "budget", "translation", "source"
    ]
    # labels here must be in english language
    # translation should be done before presentation using "locals" mechanism
    RICH_DESC_LABELS = {
        "alternate_title": "Alternate Title:",
        "original_title": "Original Title:",
        "station": "Station:",
        "price": "Price:",
        "status": "Status:",
        "type": "Type:",
        "age_limit": "Age limit:",
        "first_air_date": "First air date:",
        "last_air_date": "Last air date:",
        "seasons": "Seasons:",
        "episodes": "Episodes:",
        "quality": "Quality:",
        "subtitles": "Subtitles:",
        "country": "Country:",
        "language": "Language",
        "year": "Year:",
        "released": "Released:",
        "broadcast": "Broadcast:",
        "remaining": "Remaining:",
        "imdb_rating": "IMDb Rating:",
        "tmdb_rating": "TMDb Rating:",
        "rating": "Rating:",
        "rated": "Rated:",
        "duration": "Duration:",
        "genre": "Genre:",
        "genres": "Genres:",
        "category": "Category:",
        "categories": "Categories:",
        "production": "Production:",
        "director": "Director:",
        "directors": "Directors:",
        "writer": "Writer:",
        "writers": "Writers:",
        "creator": "Creator:",
        "creators": "Creators:",
        "cast": "Cast:",
        "actors": "Actors:",
        "stars": "Stars:",
        "awards": "Awards:",
        "views": "Views:",
        "budget": "Budget:",
        "translation": "Translation:",
        "source": "Source:"
    }

    def __init__(self, title='', text='', images=None, trailers=None, richDescParams=None, visualizer=None):
        self.title = title
        self.text = text
        self.images = images if images is not None else []
        self.trailers = trailers if trailers is not None else []
        self.richDescParams = richDescParams if richDescParams is not None else {}
        if None is visualizer:
            self.visualizer = ArticleContent.VISUALIZER_DEFAULT
        else:
            self.visualizer = visualizer


class CFavItem:
    RESOLVER_DIRECT_LINK = 'DIRECT_LINK'
    RESOLVER_SELF = 'SELF'
    RESOLVER_URLLPARSER = 'URLLPARSER'
    TYPE_UNKNOWN = CDisplayListItem.TYPE_UNKNOWN

    def __init__(self, name='',
                  description='',
                  type=TYPE_UNKNOWN,
                  iconimage='',
                  data='',
                  resolver=RESOLVER_SELF):
        self.name = name
        self.description = description
        self.type = type
        self.iconimage = iconimage
        self.data = data
        self.resolver = resolver
        self.hostName = ''

    def fromDisplayListItem(self, dispItem):
        self.name = dispItem.name
        self.description = dispItem.description
        self.type = dispItem.type
        self.iconimage = dispItem.iconimage
        return self

    def setFromDict(self, data):
        for key in data:
            setattr(self, key, data[key])
        return self

    def getAsDict(self):
        return vars(self)


class CHostsGroupItem:
    def __init__(self, name='', title=''):
        self.name = name
        self.title = title


class RetHost:
    OK = "OK"
    ERROR = "ERROR"
    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"

    def __init__(self, status, value, message=''):
        self.status = status
        self.value = value
        self.message = message

# class IHost
# interface base class with method used to
# communicate display layer with host
#


class IHost:

    # PIN protection per host (components/iptvhostpin.py): set in the host's settings, no host code needed
    def isProtectedByPinCode(self):
        return IsHostPinProtected(HostNameOf(self))

    # the host's own PIN, checked instead of the global player PIN when isProtectedByPinCode() is True;
    # '' = the global player PIN
    def getPinCode(self):
        return GetHostPinCode(HostNameOf(self))

    # return list of types which can be added as favourite
    def getSupportedFavoritesTypes(self):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # get favourite item CFavItem for item with given index
    def getFavouriteItem(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # similar as getLinksForItem, returns links
    # for given CFavItem
    def getLinksForFavourite(self, favItem):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def setInitFavouriteItem(self, favItem):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return firs available list of item category or video or link
    def getInitList(self):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return List of item from current List
    # for given Index
    # 1 == refresh - force to read data from
    #                server if possible
    # server instead of cache
    # item - object of CDisplayListItem for selected item
    def getListForItem(self, Index=0, refresh=0, item=None):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return prev requested List of item
    # for given Index
    # 1 == refresh - force to read data from
    #                server if possible
    def getPrevList(self, refresh=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return current List
    # for given Index
    # 1 == refresh - force to read data from
    #                server if possible
    def getCurrentList(self, refresh=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return current List
    # for given Index
    def getMoreForItem(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def getLinksForVideo(self, Index=0, item=None):
        return self.getLinksForItem(Index, item)

    # return list of links for AUDIO, VIDEO, PICTURE
    # for given Index,
    # item - object of CDisplayListItem for selected item
    def getLinksForItem(self, Index=0, item=None):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def getArticleContent(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return resolved url
    # for given url
    def getResolvedURL(self, url):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # return full path to player logo
    def getLogoPath(self):
        return RetHost(RetHost.OK, value=[GetLogoDir(getattr(self, '__module__').split('.')[-1][4:] + 'logo.png')])

    def getSearchResults(self, pattern, searchType=None):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # !!! NON BLOCKING !!!
    # return list of custom actions
    # for given Index
    def getCustomActions(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # !!! NON BLOCKING !!!
    # return list with search suggestions providers
    # for given Index
    def getSuggestionsProvider(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def performCustomAction(self, privateData):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def markItemAsViewed(self, Index=0):
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    # url of a row for the list markers (download state) - CHostBase implements it; a host built directly on
    # IHost overrides it (hostxxx) or gets '' here (the widget asks it for every row)
    def getRowUrl(self, Index):
        return ''


'''
CHostBase implements some typical methods
          from IHost interface
'''


class CHostBase(IHost):
    def __init__(self, host, withSearchHistrory, favouriteTypes=[]):
        self.host = host
        self.withSearchHistrory = withSearchHistrory
        self.favouriteTypes = favouriteTypes

        self.currIndex = -1
        self.listOfprevList = []
        self.listOfprevItems = []

        self.searchPattern = ''
        self.searchType = ''

    def getSupportedFavoritesTypes(self):
        return RetHost(RetHost.OK, value=self.favouriteTypes)

    def isValidIndex(self, Index, validTypes=None):
        listLen = len(self.host.currList)
        if listLen <= Index or Index < 0:
            printDBG("ERROR isValidIndex - current list is to short len: %d, Index: %d" % (listLen, Index))
            return False
        if None is not validTypes and self.converItem(self.host.currList[Index]).type not in validTypes:
            printDBG("ERROR isValidIndex - current item has wrong type")
            return False
        return True

    def withArticleContent(self, cItem):
        return False

    def getArticleContent(self, Index=0):
        retCode = RetHost.ERROR
        retlist = []
        if not self.isValidIndex(Index):
            return RetHost(retCode, value=retlist)
        cItem = self.host.currList[Index]

        if not self.withArticleContent(cItem):
            return RetHost(retCode, value=retlist)
        # libs/moviemeta notes the lookup that answers on this INFO - the item's download sidecar asks the same
        setInfoItem = None
        try:
            from Plugins.Extensions.IPTVPlayer.libs.moviemeta import setInfoItem
            setInfoItem(cItem)
        except Exception:
            printExc()
        try:
            hList = self.host.getArticleContent(cItem)
        finally:
            if setInfoItem is not None:
                setInfoItem(None)
        if None is hList:
            return RetHost(retCode, value=retlist)
        for item in hList:
            title = item.get('title', '')
            text = item.get('text', '')
            images = item.get("images", [])
            othersInfo = item.get('other_info', '')
            retlist.append(ArticleContent(title=title, text=text, images=images, richDescParams=othersInfo))
        if len(hList):
            retCode = RetHost.OK
        return RetHost(retCode, value=retlist)
    # end getArticleContent

    def getLinksForItem(self, Index=0, selItem=None):
        retCode = RetHost.ERROR
        retlist = []
        if not self.isValidIndex(Index):
            return RetHost(retCode, value=retlist)

        urlList = self.host.getLinksForItem(self.host.currList[Index])
        if isinstance(urlList, list):
            for item in urlList:
                need_resolve = item.get("need_resolve", 0)
                retlist.append(CUrlItem(item["name"], item["url"], need_resolve))

        return RetHost(RetHost.OK, value=retlist)
    # end getLinksForVideo

    def getResolvedURL(self, url):
        # resolve url to get direct url to video file
        retlist = []
        urlList = self.host.getVideoLinks(url)
        if isinstance(urlList, list):
            for item in urlList:
                need_resolve = 0
                retlist.append(CUrlItem(item["name"], item["url"], need_resolve))

        return RetHost(RetHost.OK, value=retlist)
    # end getResolvedURL

    def getFavouriteItem(self, Index=0):
        retCode = RetHost.ERROR
        retlist = []
        if not self.isValidIndex(Index):
            return RetHost(retCode, value=retlist)
        # folder rows a host marks with good_for_fav are favourites too
        if not self.host.currList[Index].get('good_for_fav', False) and not self.isValidIndex(Index, self.favouriteTypes):
            return RetHost(retCode, value=retlist)

        cItem = self.host.currList[Index]
        data = self.host.getFavouriteData(cItem)
        if None is not data:
            favItem = CFavItem(data=data)
            favItem.fromDisplayListItem(self.converItem(cItem))

            retlist = [favItem]
            retCode = RetHost.OK

        return RetHost(retCode, value=retlist)
    # end getFavouriteItem

    def _getRawRow(self, Index):
        # the host's own item dict of a row of the current list, None if there is no such row
        if 0 <= Index < len(self.host.currList):
            return self.host.currList[Index]
        return None

    def getRowUrl(self, Index):
        # the item's own url as the host listed it - the list widget replaces the url items of a
        # display item by the resolved links as soon as those were requested, this stays as it was
        try:
            cItem = self._getRawRow(Index)
            if cItem is not None:
                return str(cItem.get('url', '') or '')
        except Exception:
            printExc()
        return ''

    def getFavouriteDataOfRow(self, Index):
        # the data getFavouriteItem() would store for the row, without building the whole CFavItem;
        # None when the row can not be a favourite
        try:
            cItem = self._getRawRow(Index)
            if cItem is not None:
                return self.host.getFavouriteData(cItem) or None
        except Exception:
            printExc()
        return None

    def getLinksForFavourite(self, favItem):
        retlist = []
        urlList = self.host.getLinksForFavourite(favItem.data)
        if isinstance(urlList, list):
            for item in urlList:
                need_resolve = item.get("need_resolve", 0)
                name = self.host.cleanHtmlStr(item["name"])
                url = item["url"]
                retlist.append(CUrlItem(name, url, need_resolve))
        return RetHost(RetHost.OK, value=retlist)

    def setInitFavouriteItem(self, favItem):
        self.currIndex = -1
        self.listOfprevList = []
        self.listOfprevItems = []

        self.host.setCurrList([])
        self.host.setCurrItem({})

        if self.host.setInitListFromFavouriteItem(favItem.data):
            return RetHost(RetHost.OK, value=None)
        return RetHost(RetHost.ERROR, value=None)

    # return firs available list of item category or video or link
    def getInitList(self):
        self.currIndex = -1
        self.listOfprevList = []
        self.listOfprevItems = []

        self.host.handleService(self.currIndex)
        convList = self.convertList(self.host.getCurrList())

        return RetHost(RetHost.OK, value=convList)

    def getListForItem(self, Index=0, refresh=0, selItem=None):
        # selItem is the already-resolved CDisplayListItem the widget's own
        # currList had at Index (see requestListFromHost() in
        # iptvplayerwidget.py) - use it directly instead of re-deriving the
        # selection from self.host.getCurrList()[Index], which is a
        # differently-indexed raw list and isn't guaranteed to line up.
        if getattr(selItem, 'type', None) == CDisplayListItem.TYPE_SEARCH_HISTORY_EDITOR:
            try:
                historyFile = self.host.history.PATH_FILE
            except Exception:
                printExc()
                historyFile = ''

            try:
                if historyFile:
                    self.host.sessionEx.waitForFinishOpen(
                        SearchHistoryEditor,
                        historyFile=historyFile,
                        reverseForDisplay=True,
                        reverseForWrite=True
                    )
                else:
                    self.host.sessionEx.waitForFinishOpen(
                        MessageBox,
                        _('Search history is not available for this host.'),
                        type=MessageBox.TYPE_ERROR,
                        timeout=5
                    )
            except Exception:
                printExc()

            # search_history_editor is a NON_NAVIGATING_TYPES entry - it opens
            # a modal editor in place rather than navigating to a new list, so
            # (unlike the general case below) it must not push onto the nav
            # stack; the widget-side prevSelList already skips it for the
            # same reason, and pushing here would leave the two stacks
            # permanently out of sync. Nothing about the host's own state
            # changed, so just redisplay the exact same list.
            convList = self.convertList(self.host.getCurrList())
            return RetHost(RetHost.OK, value=convList)

        self.listOfprevList.append(self.host.getCurrList())
        self.listOfprevItems.append(self.host.getCurrItem())

        self.currIndex = Index
        if self.withSearchHistrory:
            self.setSearchPattern()
            try:
                if len(self.searchPattern):
                    sts, prevPattern = CSearchHistoryHelper.loadLastPattern()
                    if sts and prevPattern != self.searchPattern:
                        CSearchHistoryHelper.saveLastPattern(self.searchPattern)
            except Exception:
                printExc()

        self.host.handleService(Index, refresh, self.searchPattern, self.searchType)
        convList = self.convertList(self.host.getCurrList())

        return RetHost(RetHost.OK, value=convList)

    def getPrevList(self, refresh=0):
        if (len(self.listOfprevList) > 0):
            hostList = self.listOfprevList.pop()
            hostCurrItem = self.listOfprevItems.pop()
            self.host.setCurrList(hostList)
            self.host.setCurrItem(hostCurrItem)

            convList = self.convertList(hostList)
            return RetHost(RetHost.OK, value=convList)
        else:
            return RetHost(RetHost.ERROR, value=[])

    def getCurrentList(self, refresh=0):
        if refresh == 1:
            self.host.handleService(self.currIndex, refresh, self.searchPattern, self.searchType)
        convList = self.convertList(self.host.getCurrList())
        return RetHost(RetHost.OK, value=convList)

    def getMoreForItem(self, Index=0):
        self.host.handleService(Index, 2, self.searchPattern, self.searchType)
        convList = self.convertList(self.host.getCurrList())
        return RetHost(RetHost.OK, value=convList)

    def getSuggestionsProvider(self, Index=0):
        getProvider = getattr(self.host, "getSuggestionsProvider", None)
        if callable(getProvider):
            val = getProvider(Index)
            return RetHost(RetHost.OK, value=[val])
        return RetHost(RetHost.NOT_IMPLEMENTED, value=[])

    def getSearchItemInx(self):
        try:
            list = self.host.getCurrList()
            for i in range(len(list)):
                if list[i].get('category', '') == 'search':
                    return i
        except Exception:
            printDBG('getSearchItemInx EXCEPTION')
        # no search entry in the current list (None here broke "searchItemIdx > -1" on Python 3)
        return -1

    def setSearchPattern(self):
        try:
            list = self.host.getCurrList()
            # rows without "name" are normal (many hosts) - only search history rows matter here
            if 'history' == list[self.currIndex].get('name'):
                pattern = list[self.currIndex]['title']
                searchtype = list[self.currIndex]['search_type']
                try:
                    reorderOnReuse = self.host.history.isReorderOnReuseEnabled()
                except Exception:
                    reorderOnReuse = True
                if reorderOnReuse:
                    self.host.history.addHistoryItem(pattern, searchtype)
                self.searchPattern = pattern
                self.searchType = searchtype
        except Exception:
            printDBG('setSearchPattern EXCEPTION')
            self.searchPattern = ''
            self.searchType = ''
        return

    def convertList(self, cList):
        hostList = []
        for cItem in cList:
            hostItem = self.converItem(cItem)
            if None is not hostItem:
                hostList.append(hostItem)
        return hostList
    # end convertList

    def getSearchTypes(self):
        searchTypesOptions = []
        # searchTypesOptions.append((_("Movies"),   "movie"))
        # searchTypesOptions.append((_("TV Shows"), "series"))
        return searchTypesOptions

    def getDefaulIcon(self, cItem):
        return self.host.getDefaulIcon(cItem)

    @staticmethod
    def cleanIconUrl(url):
        # JSON escapes and stray quotes a host copied along with the icon url
        if not isinstance(url, str) or not url:
            return url
        clean = url.strip().strip('"\'')
        if '\\' in clean:
            # json_loads instead of chr(): py2 chr() only takes 0-255
            clean = ICON_JSON_ESCAPE_RE.sub(lambda m: ensure_str(json_loads('"%s"' % m.group(0))), clean.replace('\\/', '/'))
        if clean == url:
            return url
        return strwithmeta(clean, url.meta) if isinstance(url, strwithmeta) else clean

    def getFullIconUrl(self, url, currUrl=None):
        url = self.cleanIconUrl(url)
        if currUrl is not None:
            return self.host.getFullIconUrl(url, currUrl)
        else:
            return self.host.getFullIconUrl(url)

    def converItem(self, cItem, needUrlResolve=1, needUrlSeparateRequest=1):
        hostList = []
        hostLinks = []
        type = CDisplayListItem.TYPE_UNKNOWN
        possibleTypesOfSearch = None

        if 'category' == cItem['type']:
            if cItem.get('search_item', False):
                type = CDisplayListItem.TYPE_SEARCH
                possibleTypesOfSearch = self.getSearchTypes()
            elif cItem.get('category', '') == 'search_history':
                type = CDisplayListItem.TYPE_SEARCH_HISTORY
            elif cItem.get('category', '') == 'search_history_editor':
                type = CDisplayListItem.TYPE_SEARCH_HISTORY_EDITOR
            elif cItem.get('category', '') == 'delete_history':
                type = CDisplayListItem.TYPE_SEARCH_HISTORY_DELETE
            elif cItem.get('name', '') == 'history':
                type = CDisplayListItem.TYPE_SEARCH_HISTORY
            elif cItem.get('title', '') == _('Next page'):
                type = CDisplayListItem.TYPE_NEXT
            else:
                type = CDisplayListItem.TYPE_CATEGORY
        elif cItem['type'] == 'video':
            type = CDisplayListItem.TYPE_VIDEO
        elif 'audio' == cItem['type']:
            type = CDisplayListItem.TYPE_AUDIO
        elif 'picture' == cItem['type']:
            type = CDisplayListItem.TYPE_PICTURE
        elif 'article' == cItem['type']:
            type = CDisplayListItem.TYPE_ARTICLE
        elif 'more' == cItem['type']:
            type = CDisplayListItem.TYPE_MORE
        elif 'marker' == cItem['type']:
            type = CDisplayListItem.TYPE_MARKER
        elif 'data' == cItem['type']:
            type = CDisplayListItem.TYPE_DATA

        if type in [CDisplayListItem.TYPE_AUDIO, CDisplayListItem.TYPE_VIDEO,
                    CDisplayListItem.TYPE_PICTURE, CDisplayListItem.TYPE_ARTICLE,
                    CDisplayListItem.TYPE_DATA]:
            url = cItem.get('url', '')
            if '' != url:
                hostLinks.append(CUrlItem(_("Link"), url, needUrlResolve))

        title = cItem.get('title', '')
        description = cItem.get('desc', '')
        icon = self.getFullIconUrl(cItem.get('icon', ''))
        if icon == '':
            icon = self.getDefaulIcon(cItem)
        isGoodForFavourites = cItem.get('good_for_fav', False)
        pinLocked = cItem.get('pin_locked', False)
        pinCode = cItem.get('pin_code', '')
        textColor = cItem.get('text_color', '')

        if 'image_type' in cItem:
            imageType = cItem['image_type']
        elif (cItem.get('live') or cItem.get('is_live')) and type in (CDisplayListItem.TYPE_VIDEO, CDisplayListItem.TYPE_AUDIO):
            # a live stream / live radio ('live' / 'is_live' of the host's item): its own list icon (components/iptvlist.py)
            imageType = 'LIVE' if type == CDisplayListItem.TYPE_VIDEO else 'LIVE_AUDIO'
        else:
            imageType = type

        hostItem = CDisplayListItem(name=title,
                                    description=description,
                                    type=type,
                                    urlItems=hostLinks,
                                    urlSeparateRequest=needUrlSeparateRequest,
                                    iconimage=icon,
                                    possibleTypesOfSearch=possibleTypesOfSearch,
                                    pinLocked=pinLocked,
                                    isGoodForFavourites=isGoodForFavourites,
                                    textColor=textColor,
                                    pinCode=pinCode, imageType=imageType)
        hostItem.pinHost = cItem.get('pin_host', '')
        # a pager entry's 'page' is the page it leads to: the header path takes the list's page from it, also after a
        # jump, where counting the steps cannot know the page
        if type == CDisplayListItem.TYPE_NEXT or imageType in (CDisplayListItem.TYPE_NEXT, CDisplayListItem.TYPE_FIRST,
                                                               CDisplayListItem.TYPE_PREVIOUS, CDisplayListItem.TYPE_LAST):
            try:
                if int(cItem.get('page')) > 0:
                    hostItem.listPage = int(cItem.get('page'))
            except (TypeError, ValueError):
                pass
        elif imageType == CDisplayListItem.TYPE_JUMP:
            # tools/iptvpaging.py: the page of the list the Jump row sits in (the last page has no "Next page")
            try:
                if int(cItem.get('current_page')) > 0:
                    hostItem.currentPage = int(cItem.get('current_page'))
            except (TypeError, ValueError):
                pass
        # a host that knows the highest page puts it in its "Next page" entry as 'last_page':
        # "Next page (2/12)" in the list, "Page: 1/12" in the header path
        if type == CDisplayListItem.TYPE_NEXT:
            try:
                lastPage = int(cItem.get('last_page'))
                if isinstance(getattr(hostItem, 'listPage', None), int) and hostItem.listPage <= lastPage:
                    hostItem.lastPage = lastPage
                    hostItem.name = '%s (%d/%d)' % (hostItem.name, hostItem.listPage, lastPage)
            except (TypeError, ValueError):
                pass
        return hostItem
    # end converItem

    def getSearchResults(self, searchpattern, searchType=None):
        # retList = []
        if self.withSearchHistrory:
            self.host.history.addHistoryItem(searchpattern, searchType)

        self.searchPattern = searchpattern
        self.searchType = searchType

        # Find 'Search' item
        # list = self.host.getCurrList()

        searchItemIdx = self.getSearchItemInx()
        if searchItemIdx > -1:
            return self.getListForItem(searchItemIdx)
        else:
            return RetHost(RetHost.ERROR, value=[])

    # end getSearchResults


class CBaseHostClass:
    # getPage() through the browser-check handling (Cloudflare & co.) of pCommon
    USE_CF_PROTECTION = False

    def __init__(self, params={}):
        self.sessionEx = MainSessionWrapper()
        self.up = urlparser()

        proxyURL = params.get('proxyURL', '')
        useProxy = params.get('useProxy', False)
        self.cm = common(proxyURL, useProxy)

        self.currList = []
        self.currItem = {}
        self._historyLenTextFunction = ""
        if '' != params.get('history', ''):
            self.history = CSearchHistoryHelper(params['history'], params.get('history_store_type', False))
            self._historyLenTextFunction = self.getHistoryText
        if '' != params.get('cookie', ''):
            self.COOKIE_FILE = GetCookieDir(params['cookie'])
        self.moreMode = False
        if not hasattr(self, 'DEFAULT_ICON_URL'):
            self.DEFAULT_ICON_URL = self._hostLogoIcon()

    def _hostLogoIcon(self):
        # hosts/hostxyz.py -> icons/PlayerSelector/xyz135.png, a host sets DEFAULT_ICON_URL itself for anything else
        moduleName = self.__class__.__module__.rsplit('.', 1)[-1]
        if not moduleName.startswith('host'):
            return ''
        path = GetIconDir('PlayerSelector/%s135.png' % moduleName[4:])
        return 'file://' + path if os.path.isfile(path) else ''

    def getHistoryText(self):
        return self.history.getLength()

    def informAboutGeoBlockingIfNeeded(self, country, onlyOnce=True):
        try:
            if onlyOnce and self.isGeoBlockingChecked:
                return
        except Exception:
            self.isGeoBlockingChecked = False
        sts, data = self.cm.getPage('http://ip-api.com/json/')  # NOSONAR
        if not sts:
            return
        try:
            data = ensure_str(data.strip())
            try:
                data = json_loads(data[1:-1], '', True)
            except Exception:
                data = json_loads(data)
            try:
                data['country'] = data.get('countryCode', 'N/A')  # to avoid exceptions when something went wrong
            except Exception:
                printDBG(str(data))
                data = {"country": "N/A"}
            if data['country'] != country:
                message = _('%s uses "geo-blocking" measures to prevent you from accessing the services from abroad.\n Host country: %s, your country: %s')
                GetIPTVNotify().push(message % (self.getMainUrl(), country, data['country']), 'info', 5)
            self.isGeoBlockingChecked = True
        except Exception:
            printExc()

    def listsTab(self, tab, cItem, type='dir'):
        defaultType = type
        for item in tab:
            params = dict(cItem)
            params.update(item)
            params['name'] = 'category'
            type = item.get('type', defaultType)
            if type == 'dir':
                self.addDir(params)
            elif type == 'marker':
                self.addMarker(params)
            else:
                self.addVideo(params)

    def listSubItems(self, cItem):
        printDBG("CBaseHostClass.listSubItems")
        self.currList = cItem['sub_items']

    def listToDir(self, cList, idx):
        return self.cm.ph.listToDir(cList, idx)

    def getMainUrl(self):
        return self.MAIN_URL

    def setMainUrl(self, url):
        if self.cm.isValidUrl(url):
            self.MAIN_URL = self.cm.getBaseUrl(url)
            return True
        return False

    def getFullUrl(self, url, currUrl=None):
        if currUrl is None or not self.cm.isValidUrl(currUrl):
            try:
                currUrl = self.getMainUrl()
            except Exception:
                currUrl = None
            if currUrl is None or not self.cm.isValidUrl(currUrl):
                currUrl = 'http://fake/'  # NOSONAR
        return self.cm.getFullUrl(url, currUrl)

    def getFullIconUrl(self, url, currUrl=None):
        if currUrl is not None:
            return self.getFullUrl(url, currUrl)
        else:
            return self.getFullUrl(url)

    def getDefaulIcon(self, cItem=None):
        try:
            return self.DEFAULT_ICON_URL
        except Exception:
            pass
        return ''

    def getPage(self, url, addParams=None, post_data=None):
        if addParams is None:
            addParams = dict(getattr(self, 'defaultParams', {}))
        if self.USE_CF_PROTECTION:
            return self.cm.getPageCFProtection(url, addParams, post_data)
        return self.cm.getPage(url, addParams, post_data)

    def getVideoLinks(self, videoUrl):
        # a hosting link left to the url parser, with the subtitles / meta its row carried
        from Plugins.Extensions.IPTVPlayer.components.iptvconfigmenu import IsSidecarEnabled
        from Plugins.Extensions.IPTVPlayer.libs.urlmetahelper import sidecarFromUrlMeta, decorateResolvedLinkItems
        printDBG("%s.getVideoLinks [%s]" % (self.__class__.__name__, videoUrl))
        if not self.cm.isValidUrl(videoUrl):
            return []
        return decorateResolvedLinkItems(self.up.getVideoLinkExt(videoUrl), sidecarFromUrlMeta(videoUrl, IsSidecarEnabled()))

    @staticmethod
    def cleanHtmlStr(str):
        return CParsingHelper.cleanHtmlStr(str)

    @staticmethod
    def getStr(v, default=''):
        if isinstance(v, bytes):
            return v.decode('utf-8')
        elif isinstance(v, str):
            return v
        return default

    def getCurrList(self):
        return self.currList

    def setCurrList(self, list):
        self.currList = list

    def getCurrItem(self):
        return self.currItem

    def setCurrItem(self, item):
        self.currItem = item

    def addDir(self, params):
        params['type'] = 'category'
        self.currList.append(params)
        return

    def addMore(self, params):
        params['type'] = 'more'
        self.currList.append(params)
        return

    def addVideo(self, params):
        params['type'] = 'video'
        self.currList.append(params)
        return

    def addAudio(self, params):
        params['type'] = 'audio'
        self.currList.append(params)
        return

    def addPicture(self, params):
        params['type'] = 'picture'
        self.currList.append(params)
        return

    def addData(self, params):
        params['type'] = 'data'
        self.currList.append(params)
        return

    def addArticle(self, params):
        params['type'] = 'article'
        self.currList.append(params)
        return

    def addMarker(self, params):
        params['type'] = 'marker'
        self.currList.append(params)
        return

    def searchItems(self):
        if self._historyLenTextFunction:
            return [
                {'category': 'search', 'title': _('Search'), 'search_item': True, },
                {'category': 'search_history', 'title': _("Search history"), 'desc': _("History of searched phrases.")},
                {'category': 'search_history_editor', 'title': _('Edit search history'), 'desc': _('Edit, sort and delete search history entries')},
                {'category': 'delete_history', 'title': _('Delete search history'), 'desc': self._historyLenTextFunction}
            ]
        else:
            return []

    def delHistory(self, session):
        def doit(ret=None):
            if ret:
                err, msg = self.history.doRemove()
                session.open(MessageBox, msg, type=MessageBox.TYPE_ERROR if err else MessageBox.TYPE_INFO, timeout=5)
        msg = _('Are you sure you want to delete search history?')
        session.openWithCallback(doit, MessageBox, msg, type=MessageBox.TYPE_YESNO, default=True)

    def listsHistory(self, baseItem={'name': 'history', 'category': 'search'}, desc_key='plot', desc_base=None):
        if desc_base is None:
            desc_base = _("Type:") + " "
        list = self.history.getHistoryList()
        for histItem in list:
            plot = ''
            try:
                if type(histItem) is type({}):
                    pattern = histItem.get('pattern', '')
                    search_type = histItem.get('type', '')
                    if '' != search_type:
                        plot = desc_base + _(search_type)
                else:
                    pattern = histItem
                    search_type = None
                params = dict(baseItem)
                params.update({'title': pattern, 'search_type': search_type, desc_key: plot})
                self.addDir(params)
            except Exception:
                printExc()

    def getFavouriteData(self, cItem):
        try:
            return json_dumps(cItem)
        except Exception:
            printExc()
        return ''

    def getFavouriteFieldsData(self, cItem):
        # a favourite with only the item keys in the host's FAV_FIELDS (the whole item when that fails)
        try:
            return json_dumps(dict((key, cItem[key]) for key in self.FAV_FIELDS if key in cItem))
        except Exception:
            printExc()
        return CBaseHostClass.getFavouriteData(self, cItem)

    def getLinksForFavourite(self, fav_data):
        try:
            if self.MAIN_URL is None:
                self.selectDomain()
        except Exception:
            printExc()
        links = []
        try:
            cItem = json_loads(fav_data)
            links = self.getLinksForItem(cItem)
        except Exception:
            printExc()
        return links

    def setInitListFromFavouriteItem(self, fav_data):
        try:
            if self.MAIN_URL is None:
                self.selectDomain()
        except Exception:
            printExc()
        try:
            params = json_loads(fav_data)
        except Exception:
            params = {}
            printExc()
            return False
        self.currList.append(params)
        return True

    def getLinksForItem(self, cItem):
        return self.getLinksForVideo(cItem)

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        self.moreMode = False
        if 0 == refresh:
            if len(self.currList) <= index:
                return
            if -1 == index:
                self.currItem = {"name": None}
            else:
                self.currItem = self.currList[index]
        if 2 == refresh:  # refresh for more items
            printDBG(">> endHandleService index[%s]" % index)
            # remove item more and store items before and after item more
            self.beforeMoreItemList = self.currList[0:index]
            self.afterMoreItemList = self.currList[index + 1:]
            self.moreMode = True
            self.beforeMoreItem = self.currItem
            if -1 == index:
                self.currItem = {"name": None}
            else:
                self.currItem = self.currList[index]

    def endHandleService(self, index, refresh):
        if 2 == refresh:  # refresh for more items
            currList = self.currList
            self.currList = self.beforeMoreItemList
            for item in currList:
                if 'more' == item['type'] or (item not in self.beforeMoreItemList and item not in self.afterMoreItemList):
                    self.currList.append(item)
            self.currList.extend(self.afterMoreItemList)
            self.beforeMoreItemList = []
            self.afterMoreItemList = []
            # the list still belongs to its folder: a refresh must not load only the part behind the "more" row
            self.currItem = self.beforeMoreItem
        self.moreMode = False

    def apply_next_page_url(self, citem, url=None, page=None):
        params = dict(citem)
        if url:
            params.update({"url": url})
        if page:
            params.update({"page": page})
        params.update({"good_for_fav": False, "title": _("Next page")})
        self.addDir(params)

    def apply_next_page(self, citem, page):
        self.apply_next_page_url(citem, url=None, page=page)

    def apply_next_url(self, citem, url):
        self.apply_next_page_url(citem, url=url, page=None)
