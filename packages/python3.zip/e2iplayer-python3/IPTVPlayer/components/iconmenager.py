# -*- coding: utf-8 -*-

###################################################
# LOCAL import
###################################################
from .asynccall import AsyncMethod
from Plugins.Extensions.IPTVPlayer.libs.pCommon import common, ConvertibleImageFirstBytes, ImageFileNeedsPreparing, PrepareImageFile, \
    DescribeImageFile, MatchFirstBytes
from Plugins.Extensions.IPTVPlayer.libs.urlparser import urlparser
from Plugins.Extensions.IPTVPlayer.libs.botprotection import remembered_user_agent
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import mkdirs, \
                      FreeSpace as iptvtools_FreeSpace, \
                      printDBG, printExc, RemoveOldDirsIcons, RemoveAllFilesIconsFromPath, \
                      RemoveAllDirsIconsFromPath, GetIconsFilesFromDir, GetNewIconsDirName, \
                      GetIconsDirs, RemoveIconsDirByPath, MergeDicts, GetCookieDir
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.p2p3.manipulateStrings import ensure_binary

###################################################

###################################################
# FOREIGN import
###################################################
from hashlib import md5
import base64
import re
import threading
import time
from urllib.parse import urljoin
from binascii import hexlify
from os import path as os_path, rename as os_rename, remove as os_remove, stat as os_stat
from Components.config import config
###################################################


def IconLogName(url):
    # an inline picture (data:image/...;base64,...) is the whole picture, often 10 KB and more: the log gets its start
    if isinstance(url, str) and url.startswith('data:'):
        return '%s... (inline picture, %d characters)' % (url[:40], len(url))
    return url


def PictureFirstBytes():
    # what a downloaded picture may start with: JPEG, PNG, GIF, WebP ("RI"), AVIF when this box can convert it
    # NOTE: RI is not 100% reliable for webp, it is used for some images, but not all
    return [b'\xFF\xD8', b'\xFF\xD9', b'\x89\x50\x4E\x47', b'GIF87a', b'GIF89a', b'RI'] + ConvertibleImageFirstBytes()


def SaveInlinePicture(img_url, file_path, prepare=True, firstBytes=None):
    # an inline picture (data:[type];base64,data - sites without a picture address put it into the page) written
    # to file_path like a download; '' or why not. The type it names is not trusted (showcamrips.com calls WebP
    # image/png): the first bytes decide (firstBytes, PictureFirstBytes() without). prepare: WebP/AVIF/gzip
    # converted here - only in a worker thread (convertWebp may wait for ffmpeg), the GUI thread leaves it to
    # Cover.decodePreparedCover. hostxxx looks for this function: without it the framework shows no inline pictures
    try:
        header, payload = img_url.split(',', 1)
        if not header.lower().endswith(';base64'):
            return 'inline picture without base64 (%s)' % header[:40]
        data = base64.b64decode(re.sub(r'\s+', '', payload))
    except Exception as e:
        return 'inline picture can not be decoded %r' % (e,)
    if not MatchFirstBytes(data, PictureFirstBytes() if firstBytes is None else firstBytes):
        return 'inline picture is not a picture, first bytes %r' % data[:16]
    try:
        with open(file_path, 'wb') as f:
            f.write(data)
        if prepare and ImageFileNeedsPreparing(file_path):
            PrepareImageFile(file_path)
    except Exception as e:
        printExc()
        return 'inline picture not written %r' % (e,)
    return ''


def FindCachedIcon(url):
    # the cached copy of a picture's url: its md5 name in one of the icon folders of the cache dir (newest folder
    # first, the folder names carry their time); '' without one. For a screen without an IconMenager of its own,
    # e.g. the download manager's LCD cover of a running download
    try:
        from os import listdir as os_listdir
        from Plugins.Extensions.IPTVPlayer.tools.iptvtools import GetIconsDirPrefix
        if not url or url.startswith(('file://', 'data:')):
            return ''
        name = md5(ensure_binary(url)).hexdigest() + '.jpg'
        base = config.plugins.iptvplayer.CacheDir.value
        if not os_path.isdir(base):
            return ''
        for entry in sorted(os_listdir(base), reverse=True):
            if GetIconsDirPrefix(entry) is None:
                continue
            path = os_path.join(base, entry, name)
            if os_path.isfile(path) and os_path.getsize(path) > 0:
                return path
    except Exception:
        printExc()
    return ''


# config.plugins.iptvplayer.showcover (true|false)
# config.plugins.iptvplayer.CacheDir = ConfigText(default = "/hdd/IPTVCache")

class IconMenager:
    FAILED_RETRY = 60
    HEADER = {'User-Agent': common.HOST, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate'}

    def __init__(self, updateFun=None, downloadNew=True):
        printDBG("IconMenager.__init__")
        self.DOWNLOADED_IMAGE_PATH_BASE = config.plugins.iptvplayer.CacheDir.value
        self.cm = common()

        # download queue
        self.queueDQ = []
        self.lockDQ = threading.Lock()
        self.workThread = None

        # already available
        self.queueAA = {}
        self.lockAA = threading.Lock()

        # this function will be called after a new icon will be available
        self.updateFun = None

        # icons that exist at the source but failed (download error, not a picture, can't be decoded):
        # url -> time.monotonic() of the failure (the box clock jumps at the NTP sync); the list shows a red X
        # for them, a new try after FAILED_RETRY seconds
        self.queueFailed = {}
        # why the last download_img() failed; None when it was not the picture's fault (no space, no cache dir)
        self.lastError = None

        # new icons dir for each run
        self.currDownloadDir = self.DOWNLOADED_IMAGE_PATH_BASE + '/' + GetNewIconsDirName()
        if not os_path.exists(self.currDownloadDir):
            mkdirs(self.currDownloadDir)

        # load available icon from disk
        # will be runned in separeted thread to speed UP start plugin
        AsyncMethod(self.loadHistoryFromDisk)(self.currDownloadDir)

        # this is called to remove icons which are stored in old version
        AsyncMethod(RemoveAllFilesIconsFromPath)(self.DOWNLOADED_IMAGE_PATH_BASE)

        self.stopThread = False

        self.checkSpace = 0  # if 0 the left space on disk will be checked
        self.downloadNew = downloadNew

    def __del__(self):
        printDBG("IconMenager.__del__ -------------------------------")
        self.clearDQueue()
        self.clearAAueue()

        if config.plugins.iptvplayer.CacheDir.value == self.DOWNLOADED_IMAGE_PATH_BASE and config.plugins.iptvplayer.showcover.value:
            AsyncMethod(RemoveOldDirsIcons)(self.DOWNLOADED_IMAGE_PATH_BASE, config.plugins.iptvplayer.deleteIcons.value)
        else:
            # remove all icons as they are not more needed due to config changes
            AsyncMethod(RemoveAllDirsIconsFromPath)(self.DOWNLOADED_IMAGE_PATH_BASE)
        printDBG("IconMenager.__del__ end")

    def setUpdateCallBack(self, updateFun):
        self.updateFun = updateFun

    def stopWorkThread(self):
        self.lockDQ.acquire()

        if self.workThread is not None and self.workThread.Thread.is_alive():
            self.stopThread = True

        self.lockDQ.release()

    def runWorkThread(self):
        if self.workThread is None or not self.workThread.Thread.is_alive():
            self.workThread = AsyncMethod(self.processDQ)()

    def clearDQueue(self):
        self.lockDQ.acquire()
        self.queueDQ = []
        self.lockDQ.release()

    def addToDQueue(self, addQueue=[]):
        self.lockDQ.acquire()
        self.queueDQ.extend(addQueue)
        # self.queueDQ.append(addQueue)
        self.runWorkThread()
        self.lockDQ.release()

    ###############################################################
    #                                AA queue
    ###############################################################
    def loadHistoryFromDisk(self, currDownloadDir):
        path = self.DOWNLOADED_IMAGE_PATH_BASE
        printDBG('+++++++++++++++++++++++++++++++++++++++ IconMenager.loadHistoryFromDisk path[%s]' % path)
        iconsDirs = GetIconsDirs(path)
        for item in iconsDirs:
            if os_path.normcase(path + '/' + item + '/') != os_path.normcase(currDownloadDir + '/'):
                self.loadIconsFromPath(os_path.join(path, item))

    def loadIconsFromPath(self, path):
        printDBG('IconMenager.loadIconsFromPath path[%s]' % path)
        iconsFiles = GetIconsFilesFromDir(path)
        if 0 == len(iconsFiles):
            RemoveIconsDirByPath(path)
        for item in iconsFiles:
            # an empty file (a download cut off, e.g. by a restart) would count as the picture for good
            filePath = os_path.join(path, item)
            try:
                if 0 == os_stat(filePath).st_size:
                    printDBG('IconMenager.loadIconsFromPath empty file removed [%s]' % filePath)
                    os_remove(filePath)
                    continue
            except Exception:
                printExc()
                continue
            self.addItemToAAueue(path, item)
            # printDBG('IconMenager.loadIconsFromPath path[%s], name[%s] loaded' % (path, item))

    def addItemToAAueue(self, path, name):
        self.lockAA.acquire()
        self.queueAA[name] = path
        self.lockAA.release()

    def clearAAueue(self):
        self.lockAA.acquire()
        self.queueAA = {}
        self.lockAA.release()

    def isItemInAAueue(self, item, hashed=0):
        if hashed == 0:
            file = md5(ensure_binary(item)).hexdigest() + '.jpg'
        else:
            file = item
        ret = False
        # without locking. Is it safety?
        self.lockAA.acquire()
        if None is not self.queueAA.get(file, None):
            ret = True
        self.lockAA.release()

        return ret

    ###############################################################
    #                        failed icons
    ###############################################################
    def markIconFailed(self, url, reason, removeFile=False):
        # removeFile: a downloaded file the picture loader can't show - without it the next try would find
        # the broken file in the cache again
        printDBG("IconMenager icon failed url[%s] reason[%s]" % (IconLogName(url), reason))
        filename = md5(ensure_binary(url)).hexdigest() + '.jpg'
        self.lockAA.acquire()
        self.queueFailed[url] = time.monotonic()
        if removeFile and not url.startswith('file://'):
            path = self.queueAA.pop(filename, None)
            if path:
                try:
                    os_remove(os_path.join(path, filename))
                except Exception:
                    printExc()
        self.lockAA.release()

    def isIconFailed(self, url):
        self.lockAA.acquire()
        ret = url in self.queueFailed
        self.lockAA.release()
        return ret

    def _retryFailedIcon(self, url):
        self.lockAA.acquire()
        failedAt = self.queueFailed.get(url)
        self.lockAA.release()
        return failedAt is None or time.monotonic() - failedAt >= self.FAILED_RETRY

    def _clearIconFailed(self, url):
        self.lockAA.acquire()
        self.queueFailed.pop(url, None)
        self.lockAA.release()

    def getIconPathFromAAueue(self, item):
        printDBG("getIconPathFromAAueue item[%s]" % IconLogName(item))
        if item.startswith('file://'):
            if not ImageFileNeedsPreparing(item[7:]):
                return item[7:]
            # WebP / AVIF / gzip: its converted copy in the icon cache ('' until processDQ has made it)
            filename = self._localIconFileName(item)
        else:
            filename = md5(ensure_binary(item)).hexdigest() + '.jpg'

        self.lockAA.acquire()
        file_path = self.queueAA.get(filename, '')
        if file_path != '':
            try:
                if os_path.normcase(self.currDownloadDir + '/') != os_path.normcase(file_path + '/'):
                    file_path = os_path.normcase(file_path + '/' + filename)
                    os_rename(file_path, os_path.normcase(self.currDownloadDir + '/' + filename))
                    self.queueAA[filename] = os_path.normcase(self.currDownloadDir + '/')
                    file_path = os_path.normcase(self.currDownloadDir + '/' + filename)
                else:
                    file_path = os_path.normcase(file_path + '/' + filename)
            except Exception:
                printExc()
        self.lockAA.release()

        printDBG("getIconPathFromAAueue A file_path[%s]" % file_path)
        return file_path

    def processDQ(self):
        printDBG("IconMenager.processDQ: Thread started")

        while 1:
            die = 0
            url = ''

            # getFirstFromDQueue
            self.lockDQ.acquire()

            if False is self.stopThread:
                if len(self.queueDQ):
                    url = self.queueDQ.pop(0)
                else:
                    self.workThread = None
                    die = 1
            else:
                self.stopThread = False
                self.workThread = None
                die = 1

            self.lockDQ.release()

            if die:
                return

            printDBG("IconMenager.processDQ url: [%s]" % IconLogName(url))
            if url != '':
                isLocal = url.startswith('file://')
                file = self._localIconFileName(url) if isLocal else md5(ensure_binary(url)).hexdigest() + '.jpg'
                # check if this image is not already available in cache AA list
                if self.isItemInAAueue(file, 1):
                    continue
                # a failed icon is asked for again on every move over its item - not every time a new download
                if not self._retryFailedIcon(url):
                    continue
                if isLocal:
                    self.prepareLocalIcon(url, file)
                    continue

                self.lastError = None
                if self.download_img(url, file):
                    self._clearIconFailed(url)
                    self.addItemToAAueue(self.currDownloadDir, file)
                    if self.updateFun:
                        self.updateFun(url)
                elif self.lastError is not None:
                    self.markIconFailed(url, self.lastError)
                    if self.updateFun:
                        self.updateFun(url)

    def _localIconFileName(self, url):
        # the converted copy of a local picture: named after path, size and time, a changed file gets a new copy
        try:
            st = os_stat(url[7:])
            key = '%s|%d|%d' % (url, st.st_size, int(st.st_mtime))
        except Exception:
            key = url
        return md5(ensure_binary(key)).hexdigest() + '.jpg'

    def prepareLocalIcon(self, url, filename):
        # a local picture the box can't show as it is (WebP/AVIF/gzip): converted in a copy in the icon cache,
        # the user's own file is never changed. Anything else is shown straight from the file.
        localPath = url[7:]
        if not ImageFileNeedsPreparing(localPath) or not self.downloadNew or len(self.currDownloadDir) < 4:
            return
        copyPath = os_path.join(self.currDownloadDir, filename)
        PrepareImageFile(copyPath, localPath)
        if os_path.isfile(copyPath) and not ImageFileNeedsPreparing(copyPath):
            self._clearIconFailed(url)
            self.addItemToAAueue(self.currDownloadDir, filename)
        else:
            try:
                os_remove(copyPath)
            except Exception:
                pass
            self.markIconFailed(url, "local picture can not be converted (Pillow/ffmpeg without this format?), %s"
                                % DescribeImageFile(localPath))
        if self.updateFun:
            self.updateFun(url)

    def download_img(self, img_url, filename):
        # if at start there was NOT enough space on disk
        # new icon will not be downloaded
        if False is self.downloadNew:
            return False

        if len(self.currDownloadDir) < 4:
            printDBG('IconMenager.download_img: wrong path for IPTVCache')
            return False

        path = self.currDownloadDir + '/'

        # if at start there was enough space on disk
        # we will check if we still have free space
        if 0 >= self.checkSpace:
            printDBG('IconMenager.download_img: checking space on device')
            if not iptvtools_FreeSpace(path, 10):
                printDBG('IconMenager.download_img: not enough space for new icons, new icons will not be downloaded any more')
                self.downloadNew = False
                return False
            else:
                # for another 50 check again
                self.checkSpace = 50
        else:
            self.checkSpace -= 1
        file_path = "%s%s" % (path, filename)

        params = {}  # {'maintype': 'image'}

        # + AVIF (ftyp brand at offset 4) when this box can convert it to JPEG after the download, like WebP
        params['check_first_bytes'] = PictureFirstBytes()
        # a missing picture (HTTP 404 / 500) is a failed download with its reason, not an empty "success"
        params['ignore_http_code_ranges'] = []

        if img_url.startswith('data:'):
            # an inline picture: written to the cache, nothing to download
            self.lastError = SaveInlinePicture(img_url, file_path, firstBytes=params['check_first_bytes']) or None
            return self.lastError is None

        if img_url.endswith('|cf'):
            # (the url meta stays - e.g. the host's proxy, iptv_http_proxy)
            img_url = strwithmeta(img_url[:-3], getattr(img_url, 'meta', {}))
            # CFProtection: the urllib way like the host's getPageCFProtection pages (cf_clearance is bound to its TLS
            # fingerprint, pycurl gets 403)
            params_cfad = {'with_metadata': True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'CFProtection': True}
            domain = urlparser.getDomain(img_url, onlyDomain=True)

            params_cfad['cookiefile'] = GetCookieDir('{0}.cookie'.format(domain))
            # cf_clearance only counts together with the User-Agent that solved the check (MyE2i): the host's
            # requests remember it next to the jar, the cover has to send the same one
            solvedUserAgent = remembered_user_agent(params_cfad['cookiefile'])
            if solvedUserAgent:
                params_cfad['header'] = {'User-Agent': solvedUserAgent, 'Referer': '/'.join(img_url.split('/')[:3]) + '/',
                                         'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'}

        else:
            params_cfad = {}

        if img_url.endswith('need_resolve.jpeg'):
            domain = urlparser.getDomain(img_url)
            if domain.startswith('www.'):
                domain = domain[4:]
            # link need resolve, at now we will have only one img resolver,
            # we should consider add img resolver to urlparser if more will be needed
            sts, data = self.cm.getPage(img_url)
            if not sts:
                self.lastError = 'page for the picture not loaded'
                return False
            if 'imdb.com' in domain:
                img_url = self.cm.ph.getDataBeetwenMarkers(data, 'class="poster"', '</div>')[1]
                img_url = self.cm.ph.getSearchGroups(img_url, 'src="([^"]+?)"')[0]
                if not self.cm.isValidUrl(img_url):
                    img_url = self.cm.ph.getDataBeetwenMarkers(data, 'class="slate"', '</div>')[1]
                    img_url = self.cm.ph.getSearchGroups(img_url, 'src="([^"]+?)"')[0]
            elif 'bs.to' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getSearchGroups(data, '(<img[^>]+?alt="Cover"[^>]+?>)')[0]
                img_url = self.cm.ph.getSearchGroups(img_url, 'src="([^"]+?)"')[0]
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            elif 'watchseriesmovie.' in domain or 'gowatchseries' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<div', '>', 'picture'), ('</div', '>'), False)[1]
                img_url = self.cm.ph.getSearchGroups(img_url, '<img[^>]+?src="([^"]+?)"')[0]
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            elif 'classiccinemaonline.com' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<center>', '</center>', '<img'), ('<', '>'))[1]
                img_url = self.cm.ph.getSearchGroups(img_url, r'<img[^>]+?src="([^"]+?\.(?:jpe?g|png)(?:\?[^"]+?)?)"')[0]
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            elif 'nasze-kino.tv' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<div', '>', 'single-poster'), ('<img', '>'))[1]
                img_url = self.cm.ph.getSearchGroups(img_url, r'<img[^>]+?src="([^"]+?\.(?:jpe?g|png)(?:\?[^"]+?)?)"')[0]
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            elif 'allbox.' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<img', '>', '"image"'), ('<', '>'))[1]
                if img_url != '':
                    img_url = self.cm.ph.getSearchGroups(img_url, r'<img[^>]+?src="([^"]+?\.(?:jpe?g|png)(?:\?[^"]+?)?)"')[0]
                else:
                    img_url = self.cm.ph.getSearchGroups(data, r'url\(([^"^\)]+?\.(?:jpe?g|png)(?:\?[^"^\)]+?)?)\);')[0].strip()
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            elif 'efilmy.' in domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<img', '>', 'align="left"'), ('<', '>'))[1]
                img_url = self.cm.ph.getSearchGroups(img_url, r'<img[^>]+?src="([^"]+?\.(?:jpe?g|png)(?:\?[^"]+?)?)"')[0]
                img_url = self.cm.getFullUrl(img_url, baseUrl)
            elif 'bajeczki.org' == domain:
                baseUrl = img_url
                img_url = self.cm.ph.getDataBeetwenNodes(data, ('<img', '>', 'wp-post-image'), ('<', '>'))[1]
                if img_url != '':
                    img_url = self.cm.ph.getSearchGroups(img_url, r'<img[^>]+?src="([^"]+?\.(?:jpe?g|png)(?:\?[^"]+?)?)"')[0]
                if img_url.startswith('/'):
                    img_url = urljoin(baseUrl, img_url)
            if not self.cm.isValidUrl(img_url):
                self.lastError = 'no picture url found on the page, got %r' % img_url
                return False
        else:
            img_url = strwithmeta(img_url)
            if img_url.meta.get('icon_resolver', None) is not None:
                try:
                    img_url = img_url.meta['icon_resolver'](self.cm, img_url)
                except Exception as e:
                    printExc()
                    self.lastError = 'icon resolver error %r' % (e,)
                    return False

        if not self.cm.isValidUrl(img_url):
            self.lastError = 'invalid picture url %r' % img_url
            return False

        params = MergeDicts(params, params_cfad)
        if 'header' not in params:
            # a picture request like a browser's <img>: with the text/html Accept of a page request i.imgur.com
            # answers 302 to its HTML page instead of the picture. jpeg / png first: a CDN that has them sends no
            # AVIF / WebP that would need a conversion per picture (convertWebp, ffmpeg); image/* keeps them possible
            params['header'] = {'User-Agent': self.cm.HOST, 'Accept': 'image/jpeg,image/png,image/gif,image/*;q=0.8,*/*;q=0.5'}

        ret = self.cm.saveWebFile(file_path, img_url, addParams=params)
        if not ret['sts']:
            self.lastError = ret.get('reason') or 'download failed'
        elif not os_path.isfile(file_path) or 0 == os_stat(file_path).st_size:
            self.lastError = 'empty file'
            try:
                os_remove(file_path)
            except Exception:
                pass
            return False
        return ret['sts']
